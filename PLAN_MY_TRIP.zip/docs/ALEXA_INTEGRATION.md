# Alexa+ Integration Architecture & Scoped Companion Protocol

**Plan My Trip** integrates an intelligent travel assistant ("Alexa+ simulation") capable of full-trip planning, multi-category budget optimization, and live journey disruption rescue.

---

## 1. System Architecture

```mermaid
flowchart TD
    User([User Voice or Text]) --> UI[App UI / AlexaDrawer / AlexaVoicePanel / Companion]
    UI --> ClientInterface[AlexaClient Interface\nsrc/lib/alexa/client.ts]
    
    subgraph Client Selection
        ClientInterface -->|VITE_ALEXA_MODE=mock| MockClient[MockAlexaClient\nDeterministic Engine]
        ClientInterface -->|VITE_ALEXA_MODE=remote| RemoteClient[RemoteAlexaClient\nMCP Streamable HTTP + REST]
    end

    subgraph Dual Scope Routing
        MockClient --> ScopeRouter{Scope Mode?}
        ScopeRouter -->|mode: "plan"| PlanEngine[Full Trip Planner & Budget Optimizer]
        ScopeRouter -->|mode: "trip"| TripCompanion[Trip Companion & Vendor Dispatch]
    end

    subgraph Backend / Cloud
        RemoteClient -->|JSON-RPC 2.0 / REST| Endpoint[External Alexa+ / MCP Agent]
        Endpoint --> MCPTools[Model Context Protocol Tools]
    end

    subgraph Tool Registry
        MCPTools --> T1[search_transport]
        MCPTools --> T2[search_stays]
        MCPTools --> T3[search_activities]
        MCPTools --> T4[calculate_budget]
        MCPTools --> T5[send_vendor_message]
        MCPTools --> T6[request_vendor_hold]
        MCPTools --> T7[find_transit_alternatives]
        MCPTools --> T8[request_booking_refund]
    end

    MCPTools --> TripContext[TripContext State Sync]
    TripCompanion --> VendorNetwork[Simulated Vendor Network]
    VendorNetwork --> MessagesLog[Messages Log & Trip Updates]
```

---

## 2. Scoped Invocation Modes

The `AlexaClient` interface accepts a mandatory or optional scope:
```typescript
export interface AlexaScope {
  mode: 'plan' | 'trip';
  tripId?: string;
}

export interface AlexaContext {
  userId: string;
  scope?: AlexaScope;
  tripId?: string;
  draft?: TripDraft;
}
```

### Scope 1: `mode: "plan"` (Intake & Itinerary Assembly)
- Used during free-text and voice trip planning from the Home dashboard and Plan page.
- Resolves destinations, traveller counts, days, and budgets.
- Optimizes multi-category distributions within the user's financial ceiling.

### Scope 2: `mode: "trip"` (Post-Booking Live Companion)
- Scoped to **one active trip** via `tripId`.
- Accesses confirmed bookings, scheduled times, driver phone numbers, and hotel desk check-in cutoffs.
- Intercepts disruptions (late arrivals, traffic delays, missed departures).
- Drafts messages for third parties (drivers, front desk managers, bus operators) and executes them **only after explicit user approval**.

---

## 3. Example Payloads

### A. Plan Scope Payload (JSON-RPC 2.0)
```json
{
  "jsonrpc": "2.0",
  "id": "msg-1718000001",
  "method": "tools/call",
  "params": {
    "name": "alexa_chat",
    "arguments": {
      "message": "Plan a trip to Mumbai for 3 days, 5 members, budget ₹60,000",
      "userId": "demo-traveler-001",
      "scope": {
        "mode": "plan"
      }
    }
  }
}
```

### B. Trip Scope Companion Payload (JSON-RPC 2.0)
```json
{
  "jsonrpc": "2.0",
  "id": "msg-1718000002",
  "method": "tools/call",
  "params": {
    "name": "alexa_chat",
    "arguments": {
      "message": "My friends arrived late, I need 30 more minutes before the driver comes.",
      "userId": "demo-traveler-001",
      "tripId": "SIM-PMT-0142",
      "scope": {
        "mode": "trip",
        "tripId": "SIM-PMT-0142"
      }
    }
  }
}
```

#### Example Trip Companion Response with Explicit Approval Action:
```json
{
  "jsonrpc": "2.0",
  "id": "msg-1718000002",
  "result": {
    "text": "I checked your cab booking (SIM-CAB-123). Moving pickup to 10:00 PM keeps you safe before the 11:00 PM hotel desk cutoff. May I notify driver Ramesh Patel?",
    "toolCalls": [
      {
        "name": "get_booking_context",
        "input": { "tripId": "SIM-PMT-0142", "bookingType": "cab" },
        "status": "ok"
      },
      {
        "name": "verify_downstream_cutoffs",
        "input": { "checkInCutoff": "11:00 PM", "proposedArrival": "10:30 PM" },
        "status": "ok"
      },
      {
        "name": "draft_vendor_message",
        "input": {
          "recipient": "Driver: Ramesh Patel (SIM-CAB-123)",
          "message": "Hello, pickup time for booking SIM-CAB-123 has changed from 9:30 PM to 10:00 PM. Please confirm."
        },
        "status": "ok"
      }
    ],
    "cards": [
      {
        "type": "approval_card",
        "actionId": "act-shift-cab",
        "title": "Shift Cab Pickup Time",
        "recipient": "Driver: Ramesh Patel (SIM-CAB-123)",
        "extraCost": 0,
        "extraCostLabel": "+₹0",
        "explanation": "Hello, pickup time for booking SIM-CAB-123 has changed from 9:30 PM to 10:00 PM. Please confirm.",
        "caveat": "Driver must acknowledge. Check-in desk remains open until 11:00 PM.",
        "simulated": true
      }
    ]
  }
}
```

---

## 4. Environment Variables

Configure these in `.env` or `.env.local`:

| Variable | Type | Default | Description |
|---|---|---|---|
| `VITE_ALEXA_MODE` | `'mock' \| 'remote'` | `'mock'` | In `'mock'` mode, deterministic local engines handle planning and companion scenarios S1–S5 offline. |
| `VITE_ALEXA_ENDPOINT` | string | `http://localhost:8000/api/alexa` | Base URL for remote MCP Streamable HTTP JSON-RPC or REST endpoint. |
| `VITE_ALEXA_API_KEY` | string | `""` | Optional authorization Bearer token. |

---

## 5. Safety & Honesty Model

1. **Explicit Third-Party Approval**: The assistant **never** contacts drivers, hotels, or bus operators without presenting the exact drafted message to the traveller for explicit approval.
2. **Deterministic Budgets**: All cost modifications flow through `src/lib/budget.ts` ensuring integer precision in rupees ($\text{₹}$).
3. **Transparent Simulation Labels**: All simulated provider replies are marked with `"Simulated"`. Refunds display `"Sample timeline: a few hours. Real timing depends on your bank and the provider."`.
