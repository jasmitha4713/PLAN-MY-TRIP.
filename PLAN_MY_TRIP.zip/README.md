# PLAN MY TRIP — AI-Powered Voice Companion & Journey Recovery Assistant

**Product:** PLAN MY TRIP  
**Category:** AI-powered travel planning, multimodal trip management, and journey recovery  
**Platform:** Web application (Mobile-friendly, Alexa+ Integration)  
**Hackathon Track:** Amazon Developer Hackathon — Alexa+  
**Guiding Principle:** The user decides. The assistant guides, compares, and coordinates with explicit approval gates.

---

## 🌟 Key Capabilities

1. **Alexa+ Multimodal Voice Companion**:
   - Hands-free wake phrase activation: say **"Hello Alexa"** to wake the assistant with natural conversational speech.
   - Real-time speech transcription (Web Speech API) supporting Indian English accents (`en-IN`).
   - Natural spoken summaries (<180 chars) rather than screen-reader dumps of tables or cards.
   - Immediate **Stop Speaking** voice interruption controls.

2. **Model Context Protocol (MCP) Backend**:
   - Schema-driven tool discovery via `tools/list` (`plan_trip`, `get_saved_trip`, `assess_disruption`, `prepare_recovery_action`, `approve_recovery_action`, `get_budget_breakdown`).
   - Streamable HTTP protocol with JSON-RPC standard messaging.

3. **Journey Rescue & Disruption Recovery**:
   - Real-time delay assessment (traffic delays, missed buses, train schedule changes).
   - Generates staged recovery proposals (`pending_approval`) requiring explicit user confirmation before booking or re-dispatching.
   - Honest disclosure of simulated operator inventory.

4. **Multi-User Isolation & Persistent SQLite Storage**:
   - WAL-mode SQLite database with full ACID persistence across app restarts.
   - Dedicated user partitioning with demo traveler presets.

---

## 🚀 Quick Start Guide

### Prerequisites
- **Node.js** (v18 or higher)
- **Python** (v3.10 or higher)

### 1. Frontend Setup
```bash
# Install dependencies
npm install

# Start Vite development server (Port 3000)
npm run dev
```

### 2. Python Backend & Database Setup
In a new terminal window:
```bash
# Create and activate virtual environment
python -m venv .venv

# Windows:
.\.venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate

# Install requirements
pip install -r requirements.txt

# Start FastAPI Backend (Port 8000)
python -m mock_backend.run_mock
```

### 3. Alexa MCP Server Setup
In a third terminal window:
```bash
# Activate virtual environment
.\.venv\Scripts\activate

# Start Alexa MCP server (Port 8001)
python -m alexa_mcp.server
```

---

## 🧭 How to Test & Use

1. **Open the App in your browser:**  
   👉 **[http://localhost:3000/app/trip/PMT-0142?demo=true&tab=companion](http://localhost:3000/app/trip/PMT-0142?demo=true&tab=companion)**

2. **Activate Voice:**
   - Confirm the badge displays **`Voice: ON`**.
   - Click the **Microphone** button (🎙️) and grant browser microphone permission.
   - Say: **"Hello Alexa"** -> Assistant replies: *"I'm here. What can I help you with?"*

3. **Check Trip Budget:**
   - Say or type: **"Hello Alexa, what is my current trip budget?"**
   - Displays the interactive Budget Snapshot Card and speaks a natural summary.

4. **Simulate Travel Delay & Safe Recovery:**
   - Say or type: **"I'm in traffic and might miss my bus. Is there an alternative?"**
   - Displays assessed recovery options.
   - Say: **"I want to cancel my bus and take the next bus."**
   - An **Approval Card** appears with **"Approve & Send"** and **"Don't send"**. No booking executes without your explicit click!

---

## 🧪 Running Automated Tests

```bash
# Run Frontend Tests (66 Vitest unit & E2E tests)
npm test

# Run Backend Tests (33 Pytest tests)
pytest

# Production build check
npm run build
```

---

## 🛠️ Built With

- **Frontend:** React 19, TypeScript, Vite, Tailwind CSS, Lucide Icons, Web Speech API
- **Backend:** Python, FastAPI, Uvicorn, SQLite (WAL mode), Pydantic
- **AI & Agentic Tools:** Model Context Protocol (MCP), Groq Cloud API (`openai/gpt-oss-120b`, `llama-3.3-70b`), Web Speech Synthesis
- **Testing:** Vitest, Pytest, Puppeteer
