"""Tests verifying graceful error handling when the backend is unreachable or fails."""

import pytest
import httpx
from mock_backend.app import app as mock_app
from alexa_mcp.backend_client import BackendClient, set_backend_client
from alexa_mcp.tools.saved_trip import handle_get_saved_trip


@pytest.mark.asyncio
async def test_backend_unreachable_handling():
    """Verify that when the backend service is offline, tools return a clean error without crashing."""
    offline_client = BackendClient(base_url="http://127.0.0.1:59999", timeout=1.0)
    set_backend_client(offline_client)

    try:
        res = await handle_get_saved_trip("trip_del_jai_001")
        assert res["status"] == "error"
        assert res["code"] == "BACKEND_ERROR"
        assert res["status_code"] in [503, 504]
        assert "Could not connect" in res["error"] or "timed out" in res["error"]
    finally:
        # Restore mock client
        transport = httpx.ASGITransport(app=mock_app)
        set_backend_client(BackendClient(base_url="http://testbackend", transport=transport))


@pytest.mark.asyncio
async def test_nonexistent_trip_handling():
    """Verify handling when backend returns 404 for an unknown trip."""
    res = await handle_get_saved_trip("trip_non_existent_9999")
    assert res["status"] == "error"
    assert res["code"] == "BACKEND_ERROR"
    assert res["status_code"] == 404
    assert "not found" in res["error"].lower()
