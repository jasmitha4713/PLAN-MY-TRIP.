"""Integration tests for MCP tool handlers connected to backend."""

import pytest
from alexa_mcp.tools.plan_trip import handle_plan_trip
from alexa_mcp.tools.saved_trip import handle_get_saved_trip
from alexa_mcp.tools.disruption import handle_assess_disruption
from alexa_mcp.tools.recovery import (
    handle_prepare_recovery_action,
    handle_approve_recovery_action,
)
from alexa_mcp.tools.discovery import (
    handle_search_transport_options,
    handle_search_accommodation_options,
    handle_get_budget_breakdown,
)


@pytest.mark.asyncio
async def test_plan_trip_tool_execution():
    result = await handle_plan_trip(
        origin="Delhi",
        destination="Jaipur",
        budget_inr=5000.0,
        start_date="2026-11-01",
        end_date="2026-11-03",
        travelers_count=1,
    )
    assert result["status"] == "success"
    data = result["data"]
    assert "trip_id" in data
    assert data["origin"] == "Delhi"
    assert data["destination"] == "Jaipur"
    assert "itinerary" in data
    assert len(data["itinerary"]) > 0


@pytest.mark.asyncio
async def test_get_saved_trip_tool_execution():
    result = await handle_get_saved_trip("trip_del_jai_001")
    assert result["status"] == "success"
    data = result["data"]
    assert data["trip_id"] == "trip_del_jai_001"
    assert data["accommodation"]["name"] == "Zostel Jaipur"
    assert data["transport"]["operator"] == "RSRTC Express"


@pytest.mark.asyncio
async def test_assess_disruption_tool_execution():
    result = await handle_assess_disruption(
        trip_id="trip_del_jai_001",
        disruption_type="bus_delay",
        delay_minutes=180,
        notes="Highway breakdown near Neemrana",
    )
    assert result["status"] == "success"
    data = result["data"]
    assert data["disruption"]["severity"] == "high"
    assert data["impact"]["hotel_check_in_affected"] is True
    assert len(data["recovery_options"]) >= 2
    # Check that late check-in notification is recommended
    opt_ids = [opt["option_id"] for opt in data["recovery_options"]]
    assert "opt_reschedule_checkin" in opt_ids


@pytest.mark.asyncio
async def test_prepare_and_approve_recovery_action_flow():
    # 1. Prepare action
    prep_res = await handle_prepare_recovery_action(
        trip_id="trip_del_jai_001",
        action_type="notify_hotel_late_checkin",
        selected_option_id="opt_reschedule_checkin",
        estimated_cost_inr=0.0,
    )
    assert prep_res["status"] == "success"
    data = prep_res["data"]
    action_id = data["action_id"]
    assert data["status"] == "pending_approval"
    assert data["requires_user_approval"] is True
    assert "Zostel Jaipur" in data["approval_prompt"]

    # 2. Approve action
    appr_res = await handle_approve_recovery_action(
        action_id=action_id,
        approved=True,
        user_confirmation="Yes Alexa, notify the hotel",
    )
    assert appr_res["status"] == "success"
    appr_data = appr_res["data"]
    assert appr_data["status"] == "succeeded"
    assert "receipt_id" in appr_data


@pytest.mark.asyncio
async def test_search_transport_options_tool_execution():
    result = await handle_search_transport_options(
        origin="Hyderabad",
        destination="Delhi",
        mode_preference="train",
    )
    assert result["status"] == "success"
    data = result["data"]
    assert "options" in data
    assert len(data["options"]) >= 1
    assert any(opt["mode"] == "train" for opt in data["options"])


@pytest.mark.asyncio
async def test_search_accommodation_options_tool_execution():
    result = await handle_search_accommodation_options(
        destination="Delhi",
        preference_tier="hostel",
    )
    assert result["status"] == "success"
    data = result["data"]
    assert "options" in data
    assert len(data["options"]) >= 1
    assert any("Hostel" in opt["name"] for opt in data["options"])


@pytest.mark.asyncio
async def test_get_budget_breakdown_tool_execution():
    result = await handle_get_budget_breakdown(trip_id="trip_hyd_del_001")
    assert result["status"] == "success"
    data = result["data"]
    assert data["trip_id"] == "trip_hyd_del_001"
    assert "total_budget_inr" in data
    assert "estimated_cost_inr" in data
    assert "unallocated_cushion_inr" in data
    assert data["unallocated_cushion_inr"] >= 0
