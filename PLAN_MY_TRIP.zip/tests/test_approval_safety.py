"""Safety tests verifying that actions cannot be executed without user approval."""

import pytest
from alexa_mcp.tools.recovery import (
    handle_prepare_recovery_action,
    handle_approve_recovery_action,
)


@pytest.mark.asyncio
async def test_action_requires_explicit_approval():
    # 1. Prepare action
    prep_res = await handle_prepare_recovery_action(
        trip_id="trip_del_jai_001",
        action_type="book_cab",
        selected_option_id="opt_express_cab",
        estimated_cost_inr=1200.0,
    )
    assert prep_res["status"] == "success"
    action = prep_res["data"]
    action_id = action["action_id"]

    # Must be pending approval
    assert action["status"] == "pending_approval"
    assert action["requires_user_approval"] is True

    # 2. Rejection by user (approved=False)
    reject_res = await handle_approve_recovery_action(
        action_id=action_id,
        approved=False,
        user_confirmation="No, do not book this cab",
    )
    assert reject_res["status"] == "cancelled"
    assert "cancelled" in reject_res["message"].lower()

    # 3. Subsequent approval attempt on cancelled/non-pending action must fail
    second_try = await handle_approve_recovery_action(
        action_id=action_id,
        approved=True,
        user_confirmation="Wait, book it now",
    )
    assert second_try["status"] == "error"
    assert second_try["code"] == "BACKEND_ERROR"


@pytest.mark.asyncio
async def test_idempotent_duplicate_approval():
    # 1. Prepare action
    prep_res = await handle_prepare_recovery_action(
        trip_id="trip_del_jai_001",
        action_type="rebook_bus",
        selected_option_id="opt_next_volvo_bus",
        estimated_cost_inr=350.0,
    )
    assert prep_res["status"] == "success"
    action_id = prep_res["data"]["action_id"]

    # 2. First Approval
    first_app = await handle_approve_recovery_action(
        action_id=action_id,
        approved=True,
        user_confirmation="Yes, approve bus rebooking",
    )
    assert first_app["status"] == "success"
    assert first_app["data"]["status"] == "succeeded"
    assert "receipt_id" in first_app["data"]
    receipt_1 = first_app["data"]["receipt_id"]

    # 3. Second Duplicate Approval (Must be idempotent: return existing success, not 400 error)
    second_app = await handle_approve_recovery_action(
        action_id=action_id,
        approved=True,
        user_confirmation="Approve again",
    )
    assert second_app["status"] == "success"
    assert second_app["data"]["status"] == "succeeded"
    assert second_app["data"]["receipt_id"] == receipt_1
    assert second_app["data"].get("is_duplicate_approval") is True

