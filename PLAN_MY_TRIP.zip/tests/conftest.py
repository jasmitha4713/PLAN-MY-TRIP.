"""Pytest configuration and shared test fixtures."""

import pytest
import httpx
from mock_backend.app import app as mock_app
from alexa_mcp.backend_client import BackendClient, set_backend_client


@pytest.fixture(autouse=True)
def setup_mock_backend_client():
    """Automatically routes all backend_client calls to the mock FastAPI app in-memory."""
    transport = httpx.ASGITransport(app=mock_app)
    test_client = BackendClient(base_url="http://testbackend", transport=transport)
    set_backend_client(test_client)
    yield test_client
    set_backend_client(None)
