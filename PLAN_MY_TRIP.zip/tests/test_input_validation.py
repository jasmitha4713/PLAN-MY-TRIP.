"""Tests for strict input validation across all MCP tool handlers."""

import pytest
from alexa_mcp.tools.plan_trip import handle_plan_trip
from alexa_mcp.tools.saved_trip import handle_get_saved_trip
from alexa_mcp.tools.disruption import handle_assess_disruption
from alexa_mcp.tools.recovery import (
    handle_prepare_recovery_action,
    handle_approve_recovery_action,
)


@pytest.mark.asyncio
async def test_plan_trip_validation():
    # Empty origin
    res1 = await handle_plan_trip(origin="", destination="Jaipur", budget_inr=5000)
    assert res1["status"] == "error"
    assert res1["code"] == "VALIDATION_ERROR"
    assert "Origin" in res1["error"]

    # Empty destination
    res2 = await handle_plan_trip(origin="Delhi", destination="  ", budget_inr=5000)
    assert res2["status"] == "error"
    assert res2["code"] == "VALIDATION_ERROR"
    assert "Destination" in res2["error"]

    # Zero or negative budget
    res3 = await handle_plan_trip(origin="Delhi", destination="Jaipur", budget_inr=0)
    assert res3["status"] == "error"
    assert res3["code"] == "VALIDATION_ERROR"
    assert "Budget" in res3["error"]

    # Invalid travelers count
    res4 = await handle_plan_trip(origin="Delhi", destination="Jaipur", budget_inr=5000, travelers_count=0)
    assert res4["status"] == "error"
    assert res4["code"] == "VALIDATION_ERROR"
    assert "Travelers" in res4["error"]


@pytest.mark.asyncio
async def test_get_saved_trip_validation():
    res = await handle_get_saved_trip(trip_id="   ")
    assert res["status"] == "error"
    assert res["code"] == "VALIDATION_ERROR"
    assert "Trip ID" in res["error"]


@pytest.mark.asyncio
async def test_assess_disruption_validation():
    # Empty trip id
    res1 = await handle_assess_disruption(trip_id="", disruption_type="bus_delay", delay_minutes=60)
    assert res1["status"] == "error"
    assert res1["code"] == "VALIDATION_ERROR"

    # Empty disruption type
    res2 = await handle_assess_disruption(trip_id="trip_001", disruption_type="", delay_minutes=60)
    assert res2["status"] == "error"
    assert res2["code"] == "VALIDATION_ERROR"

    # Negative delay minutes
    res3 = await handle_assess_disruption(trip_id="trip_001", disruption_type="bus_delay", delay_minutes=-10)
    assert res3["status"] == "error"
    assert res3["code"] == "VALIDATION_ERROR"
    assert "non-negative" in res3["error"]


@pytest.mark.asyncio
async def test_prepare_recovery_action_validation():
    # Empty trip_id
    res1 = await handle_prepare_recovery_action(
        trip_id="", action_type="notify_hotel_late_checkin", selected_option_id="opt_1"
    )
    assert res1["status"] == "error"
    assert res1["code"] == "VALIDATION_ERROR"

    # Empty action_type
    res2 = await handle_prepare_recovery_action(
        trip_id="trip_001", action_type="", selected_option_id="opt_1"
    )
    assert res2["status"] == "error"
    assert res2["code"] == "VALIDATION_ERROR"

    # Empty selected_option_id
    res3 = await handle_prepare_recovery_action(
        trip_id="trip_001", action_type="notify_hotel_late_checkin", selected_option_id=""
    )
    assert res3["status"] == "error"
    assert res3["code"] == "VALIDATION_ERROR"

    # Negative cost
    res4 = await handle_prepare_recovery_action(
        trip_id="trip_001",
        action_type="book_cab",
        selected_option_id="opt_cab",
        estimated_cost_inr=-50.0,
    )
    assert res4["status"] == "error"
    assert res4["code"] == "VALIDATION_ERROR"


@pytest.mark.asyncio
async def test_approve_recovery_action_validation():
    # Empty action_id
    res = await handle_approve_recovery_action(action_id="", approved=True)
    assert res["status"] == "error"
    assert res["code"] == "VALIDATION_ERROR"
