"""Tests for the Mock Backend REST API endpoints."""

import pytest
import httpx
from mock_backend.app import app


@pytest.fixture
def client():
    transport = httpx.ASGITransport(app=app)
    return httpx.AsyncClient(transport=transport, base_url="http://testbackend")


@pytest.mark.asyncio
async def test_health_endpoint(client):
    res = await client.get("/health")
    assert res.status_code == 200
    data = res.json()
    assert data["status"] == "healthy"
    assert data["active_trips_count"] >= 2


@pytest.mark.asyncio
async def test_plan_trip_api(client):
    payload = {
        "origin": "Mumbai",
        "destination": "Goa",
        "budget_inr": 6000.0,
        "travelers_count": 2,
    }
    res = await client.post("/api/trips/plan", json=payload)
    assert res.status_code == 201
    trip = res.json()
    assert "trip_id" in trip
    assert trip["origin"] == "Mumbai"
    assert trip["destination"] == "Goa"
    assert trip["total_budget_inr"] == 6000.0
    assert len(trip["itinerary"]) > 0


@pytest.mark.asyncio
async def test_get_saved_trip_api(client):
    res = await client.get("/api/trips/trip_del_jai_001")
    assert res.status_code == 200
    trip = res.json()
    assert trip["trip_id"] == "trip_del_jai_001"
    assert trip["origin"] == "Delhi"
    assert trip["destination"] == "Jaipur"
    assert trip["accommodation"]["name"] == "Zostel Jaipur"


@pytest.mark.asyncio
async def test_disruption_rescue_api(client):
    payload = {
        "disruption_type": "bus_delay",
        "delay_minutes": 180,
        "notes": "Stuck in severe highway congestion",
    }
    res = await client.post("/api/trips/trip_del_jai_001/rescue", json=payload)
    assert res.status_code == 200
    rescue = res.json()
    assert rescue["disruption"]["severity"] == "high"
    assert rescue["impact"]["hotel_check_in_affected"] is True
    assert len(rescue["recovery_options"]) >= 2


@pytest.mark.asyncio
async def test_action_lifecycle_api(client):
    # 1. Prepare action
    prep_payload = {
        "trip_id": "trip_del_jai_001",
        "action_type": "notify_hotel_late_checkin",
        "selected_option_id": "opt_reschedule_checkin",
        "estimated_cost_inr": 0.0,
    }
    prep_res = await client.post("/api/actions/prepare", json=prep_payload)
    assert prep_res.status_code == 201
    action = prep_res.json()
    action_id = action["action_id"]
    assert action["status"] == "pending_approval"
    assert action["requires_user_approval"] is True
    assert "approval_prompt" in action

    # 2. Query action before approval
    get_res = await client.get(f"/api/actions/{action_id}")
    assert get_res.status_code == 200
    assert get_res.json()["status"] == "pending_approval"

    # 3. Approve action
    appr_payload = {"approved": True, "user_confirmation": "Yes, please confirm"}
    appr_res = await client.post(f"/api/actions/{action_id}/approve", json=appr_payload)
    assert appr_res.status_code == 200
    appr_data = appr_res.json()
    assert appr_data["status"] == "succeeded"
    assert "receipt_id" in appr_data

    # 4. Query action after approval
    final_res = await client.get(f"/api/actions/{action_id}")
    assert final_res.status_code == 200
    assert final_res.json()["status"] == "succeeded"


@pytest.mark.asyncio
async def test_search_transport_api(client):
    res = await client.post("/api/transport/search", json={
        "origin": "Hyderabad",
        "destination": "Delhi",
        "mode_preference": "train",
    })
    assert res.status_code == 200
    data = res.json()
    assert "options" in data
    assert len(data["options"]) >= 1


@pytest.mark.asyncio
async def test_search_accommodation_api(client):
    res = await client.post("/api/accommodation/search", json={
        "destination": "Delhi",
        "preference_tier": "boutique",
    })
    assert res.status_code == 200
    data = res.json()
    assert "options" in data
    assert len(data["options"]) >= 1


@pytest.mark.asyncio
async def test_get_budget_breakdown_api(client):
    res = await client.get("/api/trips/trip_hyd_del_001/budget")
    assert res.status_code == 200
    data = res.json()
    assert data["trip_id"] == "trip_hyd_del_001"
    assert "unallocated_cushion_inr" in data


@pytest.mark.asyncio
async def test_sqlite_persistence_across_repository_instances():
    """Verify that records written via DatabaseTripsRepository persist across instances."""
    from mock_backend.db import DatabaseTripsRepository, DatabaseActionsRepository, DB_PATH
    import uuid

    repo1 = DatabaseTripsRepository(DB_PATH)
    test_id = f"test_trip_{uuid.uuid4().hex[:6]}"
    trip_record = {
        "trip_id": test_id,
        "origin": "Bengaluru",
        "destination": "Coorg",
        "title": "Weekend in Coorg",
        "start_date": "2026-11-10",
        "end_date": "2026-11-12",
        "travelers_count": 2,
        "total_budget_inr": 12000.0,
        "estimated_cost_inr": 9500.0,
        "currency": "INR",
        "status": "planned",
        "transport": {"mode": "bus"},
        "accommodation": {"name": "Plantation Stay"},
        "itinerary": [],
    }
    repo1.save(trip_record)

    # Read from brand new repo instance connected to the same sqlite db
    repo2 = DatabaseTripsRepository(DB_PATH)
    fetched = repo2.get(test_id)
    assert fetched is not None
    assert fetched["destination"] == "Coorg"
    assert fetched["total_budget_inr"] == 12000.0

    # Also test actions persistence across instances
    actions_repo1 = DatabaseActionsRepository(DB_PATH)
    action_id = f"test_act_{uuid.uuid4().hex[:6]}"
    action_record = {
        "action_id": action_id,
        "trip_id": test_id,
        "action_type": "notify_hotel",
        "selected_option_id": "opt_reschedule",
        "estimated_cost_inr": 0.0,
        "status": "pending_approval",
        "requires_user_approval": True,
        "approval_prompt": "Approve notification?",
    }
    actions_repo1.save(action_record)

    actions_repo2 = DatabaseActionsRepository(DB_PATH)
    fetched_act = actions_repo2.get(action_id)
    assert fetched_act is not None
    assert fetched_act["status"] == "pending_approval"
