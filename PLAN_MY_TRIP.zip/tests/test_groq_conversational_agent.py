"""Unit and integration tests for the Groq llama-3.3-70b tool-calling conversational agent."""

import pytest
import json
import httpx
from unittest.mock import AsyncMock, patch, MagicMock

from mock_backend.conversational_agent import (
    ConversationalOrchestrator,
    resolve_groq_api_key,
    format_inr,
)
from mock_backend.app import InternalToolExecutor, TRIPS_DB, ACTIONS_DB


@pytest.mark.asyncio
async def test_groq_absent_falls_back_to_semantic_agent_with_accurate_disclosure():
    """When GROQ_API_KEY is not set or invalid, accurately falls back to semantic agent with llm_active: False."""
    orchestrator = ConversationalOrchestrator()
    tool_executor = InternalToolExecutor()

    # Query with no key configured
    with patch("mock_backend.conversational_agent.resolve_groq_api_key", return_value=None):
        result = await orchestrator.process_turn(
            message="What is my current trip budget?",
            trip_id="trip_hyd_del_001",
            history=[],
            context={},
            trips_db=TRIPS_DB,
            actions_db=ACTIONS_DB,
            tool_executor=tool_executor,
        )

        assert result["llm_active"] is False
        assert result["engine"] == "backend-semantic-orchestrator"
        assert "₹" in result["text"] or "budget" in result["text"].lower()


@pytest.mark.asyncio
async def test_groq_tool_calling_executes_mcp_tool_and_synthesizes_response():
    """Simulates Groq API returning a tool call, verifies tool execution and response synthesis."""
    orchestrator = ConversationalOrchestrator()
    tool_executor = InternalToolExecutor()

    fake_groq_key = "gsk_test_mock_groq_key_99999"

    # Step 1: Groq requests tool call `get_budget_breakdown`
    mock_tool_call_response = {
        "choices": [
            {
                "message": {
                    "role": "assistant",
                    "content": None,
                    "tool_calls": [
                        {
                            "id": "call_12345",
                            "type": "function",
                            "function": {
                                "name": "get_budget_breakdown",
                                "arguments": json.dumps({"trip_id": "trip_hyd_del_001"}),
                            },
                        }
                    ],
                }
            }
        ]
    }

    # Step 2: After tool result is fed back, Groq returns final natural spoken summary
    mock_final_response = {
        "choices": [
            {
                "message": {
                    "role": "assistant",
                    "content": "Your total trip budget is ₹15,000 with ₹3,200 remaining in your emergency cushion.",
                    "tool_calls": None,
                }
            }
        ]
    }

    mock_client = AsyncMock()
    mock_client.__aenter__.return_value = mock_client
    mock_client.post.side_effect = [
        MagicMock(status_code=200, json=lambda: mock_tool_call_response),
        MagicMock(status_code=200, json=lambda: mock_final_response),
    ]

    with patch("httpx.AsyncClient", return_value=mock_client):
        result = await orchestrator._call_groq_orchestrator(
            groq_key=fake_groq_key,
            message="Check my remaining budget",
            trip_id="trip_hyd_del_001",
            history=[],
            context={},
            trips_db=TRIPS_DB,
            actions_db=ACTIONS_DB,
            tool_executor=tool_executor,
        )

        assert result["llm_active"] is True
        assert result["engine"].startswith("groq-")
        assert len(result["tool_calls"]) == 1
        assert result["tool_calls"][0]["name"] == "get_budget_breakdown"
        assert result["tool_calls"][0]["status"] == "ok"
        assert "₹15,000" in result["text"]


@pytest.mark.asyncio
async def test_groq_rate_limit_or_timeout_falls_back_safely():
    """When Groq returns HTTP 429 or times out, process_turn falls back to semantic agent."""
    orchestrator = ConversationalOrchestrator()
    tool_executor = InternalToolExecutor()

    mock_client = AsyncMock()
    mock_client.__aenter__.return_value = mock_client
    mock_client.post.return_value = MagicMock(status_code=429, text="Rate limit exceeded")

    with patch("mock_backend.conversational_agent.resolve_groq_api_key", return_value="gsk_fake_key_123"):
        with patch("httpx.AsyncClient", return_value=mock_client):
            result = await orchestrator.process_turn(
                message="Hello",
                trip_id="trip_hyd_del_001",
                history=[],
                context={},
                trips_db=TRIPS_DB,
                actions_db=ACTIONS_DB,
                tool_executor=tool_executor,
            )

            # Falls back cleanly to semantic agent
            assert result["llm_active"] is False
            assert result["engine"] == "backend-semantic-orchestrator"
            assert "Hello!" in result["text"]
