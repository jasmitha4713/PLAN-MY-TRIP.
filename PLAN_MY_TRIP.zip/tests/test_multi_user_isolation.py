"""Multi-user data isolation and authorization tests for PLAN MY TRIP.

Proves:
1. Two distinct users can create multiple trips without seeing each other's private records.
2. Ownership checks strictly enforce HTTP 403 Forbidden on unauthorized read/delete/actions.
3. Canonical trip IDs are assigned and destination slugs (e.g. 'mumbai') cannot be used as trip IDs.
4. Nonexistent trips return HTTP 404 without silently switching to demo trips.
"""

import pytest
import httpx
from mock_backend.app import app

@pytest.fixture
def client():
    transport = httpx.ASGITransport(app=app)
    return httpx.AsyncClient(transport=transport, base_url="http://testbackend")


@pytest.mark.asyncio
async def test_multi_user_trip_creation_and_listing_isolation(client):
    user_a = "user_aarav_001"
    user_b = "user_priya_002"

    # User A creates Trip 1
    res_a1 = await client.post("/api/trips/plan", json={
        "origin": "Hyderabad",
        "destination": "Delhi",
        "budget_inr": 20000.0,
        "travelers_count": 2,
        "user_id": user_a
    })
    assert res_a1.status_code == 201
    trip_a1_id = res_a1.json()["trip_id"]
    assert trip_a1_id.startswith("trip_")
    assert "mumbai" not in trip_a1_id.lower()

    # User A creates Trip 2
    res_a2 = await client.post("/api/trips/plan", json={
        "origin": "Hyderabad",
        "destination": "Goa",
        "budget_inr": 35000.0,
        "travelers_count": 3,
        "user_id": user_a
    })
    assert res_a2.status_code == 201
    trip_a2_id = res_a2.json()["trip_id"]

    # User B creates Trip 1
    res_b1 = await client.post("/api/trips/plan", json={
        "origin": "Bengaluru",
        "destination": "Manali",
        "budget_inr": 40000.0,
        "travelers_count": 2,
        "user_id": user_b
    })
    assert res_b1.status_code == 201
    trip_b1_id = res_b1.json()["trip_id"]

    # User A lists trips
    list_a = await client.get("/api/trips", params={"user_id": user_a})
    assert list_a.status_code == 200
    trips_a = list_a.json()["trips"]
    ids_a = [t["trip_id"] for t in trips_a]
    assert trip_a1_id in ids_a
    assert trip_a2_id in ids_a
    assert trip_b1_id not in ids_a, "User A must not see User B's private trip in listing"

    # User B lists trips
    list_b = await client.get("/api/trips", params={"user_id": user_b})
    assert list_b.status_code == 200
    trips_b = list_b.json()["trips"]
    ids_b = [t["trip_id"] for t in trips_b]
    assert trip_b1_id in ids_b
    assert trip_a1_id not in ids_b, "User B must not see User A's private trip in listing"
    assert trip_a2_id not in ids_b


@pytest.mark.asyncio
async def test_unauthorized_cross_user_access_is_denied(client):
    user_a = "user_aarav_001"
    user_b = "user_priya_002"

    # Create private trip for User B
    res_b = await client.post("/api/trips/plan", json={
        "origin": "Bengaluru",
        "destination": "Coorg",
        "budget_inr": 15000.0,
        "travelers_count": 2,
        "user_id": user_b
    })
    assert res_b.status_code == 201
    trip_b_id = res_b.json()["trip_id"]

    # User A attempts to read User B's trip directly
    get_res = await client.get(f"/api/trips/{trip_b_id}", params={"user_id": user_a})
    assert get_res.status_code == 403, "Cross-user direct read must return HTTP 403 Forbidden"
    assert "Access denied" in get_res.json()["detail"]

    # User A attempts to prepare a recovery action on User B's trip
    prep_res = await client.post("/api/actions/prepare", json={
        "trip_id": trip_b_id,
        "action_type": "notify_hotel_late_checkin",
        "selected_option_id": "opt_reschedule_checkin",
        "estimated_cost_inr": 0.0
    }, params={"user_id": user_a})
    assert prep_res.status_code == 403, "Cross-user action preparation must return HTTP 403 Forbidden"

    # User A attempts to delete User B's trip
    del_res = await client.delete(f"/api/trips/{trip_b_id}", params={"user_id": user_a})
    assert del_res.status_code == 403, "Cross-user trip deletion must return HTTP 403 Forbidden"

    # User B can read their own trip
    get_b = await client.get(f"/api/trips/{trip_b_id}", params={"user_id": user_b})
    assert get_b.status_code == 200
    assert get_b.json()["trip_id"] == trip_b_id

    # User B can delete their own trip
    del_b = await client.delete(f"/api/trips/{trip_b_id}", params={"user_id": user_b})
    assert del_b.status_code == 200
    assert del_b.json()["deleted"] is True


@pytest.mark.asyncio
async def test_nonexistent_trip_and_destination_slug_rejection(client):
    # Destination slug 'mumbai' must not resolve as a trip
    res_mumbai = await client.get("/api/trips/mumbai")
    assert res_mumbai.status_code == 404
    assert "not found" in res_mumbai.json()["detail"].lower()

    # Nonexistent canonical trip ID must return 404 without fallback
    res_unknown = await client.get("/api/trips/trip_nonexistent_9999")
    assert res_unknown.status_code == 404
    assert "trip_nonexistent_9999" in res_unknown.json()["detail"]


@pytest.mark.asyncio
async def test_signed_jwt_token_issuance_and_verification(client):
    """Verifies that cryptographically signed JWT tokens are issued, verified, and enforce isolation."""
    user_a = "user_jwt_aarav"
    user_b = "user_jwt_priya"

    # 1. Obtain signed token for User A
    tok_res_a = await client.post("/api/auth/token", json={"user_id": user_a, "email": "aarav@example.com"})
    assert tok_res_a.status_code == 200
    token_a = tok_res_a.json()["access_token"]
    assert len(token_a) > 20

    # 2. Obtain signed token for User B
    tok_res_b = await client.post("/api/auth/token", json={"user_id": user_b, "email": "priya@example.com"})
    assert tok_res_b.status_code == 200
    token_b = tok_res_b.json()["access_token"]

    # 3. User A creates trip using Bearer Token
    res_a = await client.post(
        "/api/trips/plan",
        json={"origin": "Hyderabad", "destination": "Kochi", "budget_inr": 22000.0, "user_id": user_a},
        headers={"Authorization": f"Bearer {token_a}"}
    )
    assert res_a.status_code == 201
    trip_a_id = res_a.json()["trip_id"]

    # 4. User A reads own trip with Token A -> 200 OK
    get_a = await client.get(f"/api/trips/{trip_a_id}", headers={"Authorization": f"Bearer {token_a}"})
    assert get_a.status_code == 200
    assert get_a.json()["trip_id"] == trip_a_id

    # 5. User B attempts to read User A's trip with Token B -> 403 Forbidden
    get_b = await client.get(f"/api/trips/{trip_a_id}", headers={"Authorization": f"Bearer {token_b}"})
    assert get_b.status_code == 403
    assert "Access denied" in get_b.json()["detail"]

    # 6. Tampered token -> 401 Unauthorized
    tampered_token = token_a[:-5] + "XXXXX"
    bad_res = await client.get(f"/api/trips/{trip_a_id}", headers={"Authorization": f"Bearer {tampered_token}"})
    assert bad_res.status_code == 401
    assert "verification failed" in bad_res.json()["detail"].lower()
