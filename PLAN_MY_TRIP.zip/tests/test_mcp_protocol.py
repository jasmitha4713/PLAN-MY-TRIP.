"""Protocol integration test verifying MCP session initialization, tool listing,
and tool execution over Streamable HTTP transport using the official MCP client.
"""

import asyncio
import socket
import pytest
import uvicorn

from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamable_http_client
from alexa_mcp.server import app


def get_free_port() -> int:
    """Find an available port on localhost."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.mark.asyncio
async def test_mcp_streamable_http_protocol():
    """Verify MCP Spec 2025-11-25+ over Streamable HTTP transport."""
    port = get_free_port()
    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning")
    server = uvicorn.Server(config)
    server_task = asyncio.create_task(server.serve())

    # Wait for server startup
    await asyncio.sleep(0.6)

    try:
        mcp_url = f"http://127.0.0.1:{port}/mcp"

        async with streamable_http_client(mcp_url) as (read_stream, write_stream):
            async with ClientSession(read_stream, write_stream) as session:
                # 1. Initialize MCP Session
                init_result = await session.initialize()
                assert init_result is not None
                assert init_result.protocol_version >= "2025-11-25"
                assert init_result.server_info.name == "plan-my-trip-alexa-mcp"

                # 2. tools/list - Verify registered tool discovery
                tools_response = await session.list_tools()
                tool_names = [t.name for t in tools_response.tools]

                expected_tools = [
                    "plan_trip",
                    "get_saved_trip",
                    "assess_disruption",
                    "prepare_recovery_action",
                    "approve_recovery_action",
                ]
                for exp_tool in expected_tools:
                    assert exp_tool in tool_names, f"Tool '{exp_tool}' not found in registered tools"

                # 3. tools/call - Test get_saved_trip invocation
                call_res = await session.call_tool(
                    name="get_saved_trip",
                    arguments={"trip_id": "trip_del_jai_001"},
                )
                assert call_res is not None
                assert len(call_res.content) > 0
                assert "trip_del_jai_001" in call_res.content[0].text
                assert "Zostel Jaipur" in call_res.content[0].text

                # 4. tools/call - Test assess_disruption invocation
                disrupt_res = await session.call_tool(
                    name="assess_disruption",
                    arguments={
                        "trip_id": "trip_del_jai_001",
                        "disruption_type": "bus_delay",
                        "delay_minutes": 180,
                    },
                )
                assert disrupt_res is not None
                assert "hotel_check_in_affected" in disrupt_res.content[0].text

    finally:
        server.should_exit = True
        await server_task
