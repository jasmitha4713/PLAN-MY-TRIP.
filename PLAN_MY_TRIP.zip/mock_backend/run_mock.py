"""Runner script for the mock backend server on port 8000."""

import uvicorn
from mock_backend.app import app

def main():
    print("=" * 60)
    print(" PLAN MY TRIP — Mock Backend API Server")
    print(" Running on http://127.0.0.1:8000")
    print(" Docs available at http://127.0.0.1:8000/docs")
    print("=" * 60)
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="info")

if __name__ == "__main__":
    main()
