"""Persistent SQLite Storage Layer for PLAN MY TRIP.

Replaces in-memory stores with a thread-safe, transactional SQLite database.
Maintains canonical trip IDs, recovery proposals, selections, and audit events across backend restarts.
"""

import json
import os
import sqlite3
import uuid
import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

DB_PATH = os.environ.get(
    "SQLITE_DB_PATH",
    str(Path(__file__).parent / "pmt_data.db")
)


def get_connection(db_path: Optional[str] = None) -> sqlite3.Connection:
    """Create a configured SQLite connection with row factory and WAL mode."""
    target_path = db_path or DB_PATH
    conn = sqlite3.connect(target_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db(db_path: Optional[str] = None) -> None:
    """Initialize database tables, indexes, and constraints."""
    conn = get_connection(db_path)
    try:
        with conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS trips (
                    trip_id TEXT PRIMARY KEY,
                    display_id TEXT,
                    reference_id TEXT,
                    user_id TEXT,
                    origin TEXT NOT NULL,
                    destination TEXT NOT NULL,
                    title TEXT,
                    start_date TEXT,
                    end_date TEXT,
                    travelers_count INTEGER DEFAULT 1,
                    total_budget_inr REAL DEFAULT 0.0,
                    estimated_cost_inr REAL DEFAULT 0.0,
                    currency TEXT DEFAULT 'INR',
                    status TEXT DEFAULT 'planned',
                    transport_json TEXT,
                    accommodation_json TEXT,
                    itinerary_json TEXT,
                    extra_data_json TEXT,
                    created_at TEXT,
                    updated_at TEXT
                );

                CREATE INDEX IF NOT EXISTS idx_trips_display_id ON trips(display_id);
                CREATE INDEX IF NOT EXISTS idx_trips_reference_id ON trips(reference_id);
                CREATE INDEX IF NOT EXISTS idx_trips_user_id ON trips(user_id);

                CREATE TABLE IF NOT EXISTS users (
                    user_id TEXT PRIMARY KEY,
                    email TEXT UNIQUE,
                    display_name TEXT,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS recovery_actions (
                    action_id TEXT PRIMARY KEY,
                    trip_id TEXT NOT NULL,
                    action_type TEXT NOT NULL,
                    selected_option_id TEXT NOT NULL,
                    estimated_cost_inr REAL DEFAULT 0.0,
                    status TEXT DEFAULT 'pending_approval',
                    requires_user_approval INTEGER DEFAULT 1,
                    receipt_id TEXT,
                    preview_json TEXT,
                    approval_prompt TEXT,
                    history_json TEXT,
                    created_at TEXT,
                    executed_at TEXT,
                    notes TEXT
                );

                CREATE INDEX IF NOT EXISTS idx_actions_trip_id ON recovery_actions(trip_id);
                CREATE INDEX IF NOT EXISTS idx_actions_status ON recovery_actions(status);

                CREATE TABLE IF NOT EXISTS trip_selections (
                    selection_id TEXT PRIMARY KEY,
                    trip_id TEXT NOT NULL,
                    category TEXT NOT NULL,
                    option_id TEXT NOT NULL,
                    details_json TEXT,
                    cost_inr REAL DEFAULT 0.0,
                    created_at TEXT
                );

                CREATE TABLE IF NOT EXISTS audit_events (
                    event_id TEXT PRIMARY KEY,
                    entity_type TEXT NOT NULL,
                    entity_id TEXT NOT NULL,
                    event_name TEXT NOT NULL,
                    details_json TEXT,
                    timestamp TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_events(entity_type, entity_id);
            """)
    finally:
        conn.close()


def seed_default_trips(db_path: Optional[str] = None) -> int:
    """Seed default demo trips idempotently from seed_data without duplicating rows."""
    from mock_backend.seed_data import SEED_TRIPS

    conn = get_connection(db_path)
    seeded_count = 0
    now_iso = datetime.datetime.now(datetime.timezone.utc).isoformat()

    try:
        with conn:
            # Only iterate unique canonical trip records
            canonical_records: Dict[str, Dict[str, Any]] = {}
            for key, trip_data in SEED_TRIPS.items():
                t_id = trip_data.get("trip_id") or key
                if t_id not in canonical_records:
                    canonical_records[t_id] = trip_data

            for trip_id, data in canonical_records.items():
                cursor = conn.execute("SELECT 1 FROM trips WHERE trip_id = ?", (trip_id,))
                if cursor.fetchone():
                    continue

                display_id = data.get("display_id")
                reference_id = data.get("reference_id")
                user_id = data.get("user_id", "usr_demo_01")
                origin = data.get("origin", "Hyderabad")
                destination = data.get("destination", "New Delhi")
                title = data.get("title", f"{origin} to {destination} Trip")
                start_date = data.get("start_date", "2026-11-01")
                end_date = data.get("end_date", "2026-11-03")
                travelers_count = data.get("travelers_count", 2)
                total_budget_inr = float(data.get("total_budget_inr", 15000.0))
                estimated_cost_inr = float(data.get("estimated_cost_inr", total_budget_inr * 0.85))
                currency = data.get("currency", "INR")
                status = data.get("status", "confirmed")

                transport_json = json.dumps(data.get("transport", {}))
                accommodation_json = json.dumps(data.get("accommodation", {}))
                itinerary_json = json.dumps(data.get("itinerary", []))

                # Collect extra fields
                known_keys = {
                    "trip_id", "display_id", "reference_id", "user_id", "origin", "destination",
                    "title", "start_date", "end_date", "travelers_count", "total_budget_inr",
                    "estimated_cost_inr", "currency", "status", "transport", "accommodation", "itinerary"
                }
                extra_data = {k: v for k, v in data.items() if k not in known_keys}
                extra_data_json = json.dumps(extra_data)

                conn.execute("""
                    INSERT INTO trips (
                        trip_id, display_id, reference_id, user_id, origin, destination,
                        title, start_date, end_date, travelers_count, total_budget_inr,
                        estimated_cost_inr, currency, status, transport_json,
                        accommodation_json, itinerary_json, extra_data_json, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    trip_id, display_id, reference_id, user_id, origin, destination,
                    title, start_date, end_date, travelers_count, total_budget_inr,
                    estimated_cost_inr, currency, status, transport_json,
                    accommodation_json, itinerary_json, extra_data_json, now_iso, now_iso
                ))
                seeded_count += 1
    finally:
        conn.close()

    return seeded_count


def row_to_trip_dict(row: sqlite3.Row) -> Dict[str, Any]:
    """Convert a database trip row back into the standard schema dictionary."""
    d = {
        "trip_id": row["trip_id"],
        "origin": row["origin"],
        "destination": row["destination"],
        "title": row["title"],
        "start_date": row["start_date"],
        "end_date": row["end_date"],
        "travelers_count": row["travelers_count"],
        "total_budget_inr": row["total_budget_inr"],
        "estimated_cost_inr": row["estimated_cost_inr"],
        "currency": row["currency"],
        "status": row["status"],
        "transport": json.loads(row["transport_json"]) if row["transport_json"] else {},
        "accommodation": json.loads(row["accommodation_json"]) if row["accommodation_json"] else {},
        "itinerary": json.loads(row["itinerary_json"]) if row["itinerary_json"] else [],
    }
    if row["display_id"]:
        d["display_id"] = row["display_id"]
    if row["reference_id"]:
        d["reference_id"] = row["reference_id"]
    if row["user_id"]:
        d["user_id"] = row["user_id"]
    if row["created_at"]:
        d["created_at"] = row["created_at"]
    if row["updated_at"]:
        d["updated_at"] = row["updated_at"]

    if row["extra_data_json"]:
        try:
            extra = json.loads(row["extra_data_json"])
            for k, v in extra.items():
                if k not in d:
                    d[k] = v
        except Exception:
            pass
    return d


def row_to_action_dict(row: sqlite3.Row) -> Dict[str, Any]:
    """Convert a database recovery action row into the standard action dictionary."""
    d = {
        "action_id": row["action_id"],
        "trip_id": row["trip_id"],
        "action_type": row["action_type"],
        "selected_option_id": row["selected_option_id"],
        "estimated_cost_inr": row["estimated_cost_inr"],
        "status": row["status"],
        "requires_user_approval": bool(row["requires_user_approval"]),
        "created_at": row["created_at"],
        "approval_prompt": row["approval_prompt"],
        "preview": json.loads(row["preview_json"]) if row["preview_json"] else {},
        "history": json.loads(row["history_json"]) if row["history_json"] else [],
    }
    if row["receipt_id"]:
        d["receipt_id"] = row["receipt_id"]
    if row["executed_at"]:
        d["executed_at"] = row["executed_at"]
    if row["notes"]:
        d["notes"] = row["notes"]
    return d


class DatabaseTripsRepository:
    """Repository handling all CRUD and canonical lookups for trips."""

    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or DB_PATH

    def get(self, trip_id: str) -> Optional[Dict[str, Any]]:
        """Look up trip strictly by canonical trip_id, display_id, or reference_id.
        Does NOT silently resolve destination slugs (e.g., 'mumbai').
        """
        conn = get_connection(self.db_path)
        try:
            cursor = conn.execute("""
                SELECT * FROM trips 
                WHERE trip_id = ? OR display_id = ? OR reference_id = ?
                LIMIT 1
            """, (trip_id, trip_id, trip_id))
            row = cursor.fetchone()
            if row:
                return row_to_trip_dict(row)
            return None
        finally:
            conn.close()

    def save(self, trip: Dict[str, Any]) -> Dict[str, Any]:
        """Insert or replace a trip in SQLite storage."""
        conn = get_connection(self.db_path)
        now_iso = datetime.datetime.now(datetime.timezone.utc).isoformat()
        trip_id = trip.get("trip_id") or f"trip_{uuid.uuid4().hex[:6]}"
        trip["trip_id"] = trip_id

        transport_json = json.dumps(trip.get("transport", {}))
        accommodation_json = json.dumps(trip.get("accommodation", {}))
        itinerary_json = json.dumps(trip.get("itinerary", []))

        known_keys = {
            "trip_id", "display_id", "reference_id", "user_id", "origin", "destination",
            "title", "start_date", "end_date", "travelers_count", "total_budget_inr",
            "estimated_cost_inr", "currency", "status", "transport", "accommodation", "itinerary"
        }
        extra_data = {k: v for k, v in trip.items() if k not in known_keys}
        extra_data_json = json.dumps(extra_data)

        try:
            with conn:
                conn.execute("""
                    INSERT INTO trips (
                        trip_id, display_id, reference_id, user_id, origin, destination,
                        title, start_date, end_date, travelers_count, total_budget_inr,
                        estimated_cost_inr, currency, status, transport_json,
                        accommodation_json, itinerary_json, extra_data_json, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(trip_id) DO UPDATE SET
                        user_id = COALESCE(excluded.user_id, trips.user_id),
                        display_id = excluded.display_id,
                        reference_id = excluded.reference_id,
                        origin = excluded.origin,
                        destination = excluded.destination,
                        title = excluded.title,
                        start_date = excluded.start_date,
                        end_date = excluded.end_date,
                        travelers_count = excluded.travelers_count,
                        total_budget_inr = excluded.total_budget_inr,
                        estimated_cost_inr = excluded.estimated_cost_inr,
                        currency = excluded.currency,
                        status = excluded.status,
                        transport_json = excluded.transport_json,
                        accommodation_json = excluded.accommodation_json,
                        itinerary_json = excluded.itinerary_json,
                        extra_data_json = excluded.extra_data_json,
                        updated_at = excluded.updated_at
                """, (
                    trip_id,
                    trip.get("display_id"),
                    trip.get("reference_id"),
                    trip.get("user_id") or "demo-traveler-001",
                    trip.get("origin", "Hyderabad"),
                    trip.get("destination", "New Delhi"),
                    trip.get("title", f"{trip.get('origin', 'Hyderabad')} to {trip.get('destination', 'New Delhi')} Trip"),
                    trip.get("start_date", "2026-11-01"),
                    trip.get("end_date", "2026-11-03"),
                    trip.get("travelers_count", 1),
                    float(trip.get("total_budget_inr", 15000.0)),
                    float(trip.get("estimated_cost_inr", 11800.0)),
                    trip.get("currency", "INR"),
                    trip.get("status", "planned"),
                    transport_json,
                    accommodation_json,
                    itinerary_json,
                    extra_data_json,
                    trip.get("created_at", now_iso),
                    now_iso
                ))
            return trip
        finally:
            conn.close()

    def list_all(self) -> List[Dict[str, Any]]:
        """Return all trips ordered by created date."""
        conn = get_connection(self.db_path)
        try:
            cursor = conn.execute("SELECT * FROM trips ORDER BY created_at DESC")
            return [row_to_trip_dict(r) for r in cursor.fetchall()]
        finally:
            conn.close()

    def list_by_user(self, user_id: str, include_public: bool = True) -> List[Dict[str, Any]]:
        """Return all trips belonging to a specific user, plus shared demo templates."""
        conn = get_connection(self.db_path)
        try:
            if include_public:
                cursor = conn.execute("""
                    SELECT * FROM trips 
                    WHERE user_id = ? 
                       OR trip_id IN ('trip_hyd_del_001', 'trip_del_jai_001', 'trip_blr_crg_002')
                    ORDER BY created_at DESC
                """, (user_id,))
            else:
                cursor = conn.execute("""
                    SELECT * FROM trips 
                    WHERE user_id = ? 
                    ORDER BY created_at DESC
                """, (user_id,))
            return [row_to_trip_dict(r) for r in cursor.fetchall()]
        finally:
            conn.close()

    def delete(self, trip_id: str, user_id: Optional[str] = None) -> bool:
        """Delete a trip and its associated actions and selections, verifying ownership if user_id is provided."""
        conn = get_connection(self.db_path)
        try:
            with conn:
                trip = self.get(trip_id)
                if not trip:
                    return False
                if user_id and not self.verify_ownership(trip_id, user_id):
                    return False
                actual_id = trip["trip_id"]
                conn.execute("DELETE FROM recovery_actions WHERE trip_id = ?", (actual_id,))
                conn.execute("DELETE FROM trip_selections WHERE trip_id = ?", (actual_id,))
                conn.execute("DELETE FROM trips WHERE trip_id = ?", (actual_id,))
                return True
        finally:
            conn.close()

    def verify_ownership(self, trip_id: str, user_id: str) -> bool:
        """Return True if the trip is owned by user_id or is a shared canonical demo trip."""
        if not user_id:
            return True
        trip = self.get(trip_id)
        if not trip:
            return False
        # Public demo templates are readable by any authenticated or guest user
        if trip.get("trip_id") in ["trip_hyd_del_001", "trip_del_jai_001", "trip_blr_crg_002"]:
            return True
        trip_owner = trip.get("user_id")
        return trip_owner == user_id

    def count(self) -> int:
        """Return total number of saved trips."""
        conn = get_connection(self.db_path)
        try:
            cursor = conn.execute("SELECT COUNT(*) FROM trips")
            return cursor.fetchone()[0]
        finally:
            conn.close()


class DatabaseActionsRepository:
    """Repository handling all recovery actions, approvals, and audit trails."""

    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or DB_PATH

    def get(self, action_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve action by ID."""
        conn = get_connection(self.db_path)
        try:
            cursor = conn.execute("SELECT * FROM recovery_actions WHERE action_id = ? LIMIT 1", (action_id,))
            row = cursor.fetchone()
            if row:
                return row_to_action_dict(row)
            return None
        finally:
            conn.close()

    def save(self, action: Dict[str, Any]) -> Dict[str, Any]:
        """Insert or replace an action."""
        conn = get_connection(self.db_path)
        action_id = action["action_id"]
        preview_json = json.dumps(action.get("preview", {}))
        history_json = json.dumps(action.get("history", []))

        try:
            with conn:
                conn.execute("""
                    INSERT INTO recovery_actions (
                        action_id, trip_id, action_type, selected_option_id,
                        estimated_cost_inr, status, requires_user_approval, receipt_id,
                        preview_json, approval_prompt, history_json, created_at, executed_at, notes
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(action_id) DO UPDATE SET
                        status = excluded.status,
                        requires_user_approval = excluded.requires_user_approval,
                        receipt_id = excluded.receipt_id,
                        preview_json = excluded.preview_json,
                        history_json = excluded.history_json,
                        executed_at = excluded.executed_at,
                        notes = excluded.notes
                """, (
                    action_id,
                    action["trip_id"],
                    action["action_type"],
                    action["selected_option_id"],
                    float(action.get("estimated_cost_inr", 0.0)),
                    action.get("status", "pending_approval"),
                    1 if action.get("requires_user_approval", True) else 0,
                    action.get("receipt_id"),
                    preview_json,
                    action.get("approval_prompt"),
                    history_json,
                    action.get("created_at"),
                    action.get("executed_at"),
                    action.get("notes")
                ))
            return action
        finally:
            conn.close()

    def list_all(self) -> List[Dict[str, Any]]:
        """Return all recovery actions."""
        conn = get_connection(self.db_path)
        try:
            cursor = conn.execute("SELECT * FROM recovery_actions ORDER BY created_at DESC")
            return [row_to_action_dict(r) for r in cursor.fetchall()]
        finally:
            conn.close()

    def count(self) -> int:
        """Return total count of actions."""
        conn = get_connection(self.db_path)
        try:
            cursor = conn.execute("SELECT COUNT(*) FROM recovery_actions")
            return cursor.fetchone()[0]
        finally:
            conn.close()


def record_audit_event(entity_type: str, entity_id: str, event_name: str, details: Dict[str, Any], db_path: Optional[str] = None):
    """Record an audit trail event into the audit_events table."""
    conn = get_connection(db_path)
    event_id = f"aud_{uuid.uuid4().hex[:10]}"
    now_iso = datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        with conn:
            conn.execute("""
                INSERT INTO audit_events (event_id, entity_type, entity_id, event_name, details_json, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (event_id, entity_type, entity_id, event_name, json.dumps(details), now_iso))
    finally:
        conn.close()


# Database-backed Dict mapping adapter for backward-compatible TRIPS_DB and ACTIONS_DB access
class DatabaseTripsMapping:
    """Dict-like mapping adapter that reads and writes directly to SQLite."""

    def __init__(self, repo: DatabaseTripsRepository):
        self.repo = repo

    def __getitem__(self, key: str) -> Dict[str, Any]:
        val = self.repo.get(key)
        if val is None:
            raise KeyError(key)
        return val

    def __setitem__(self, key: str, value: Dict[str, Any]) -> None:
        value["trip_id"] = value.get("trip_id") or key
        self.repo.save(value)

    def __contains__(self, key: str) -> bool:
        return self.repo.get(key) is not None

    def __len__(self) -> int:
        return self.repo.count()

    def get(self, key: str, default: Any = None) -> Any:
        val = self.repo.get(key)
        return val if val is not None else default

    def items(self) -> List[Tuple[str, Dict[str, Any]]]:
        all_trips = self.repo.list_all()
        result = []
        for t in all_trips:
            result.append((t["trip_id"], t))
            if t.get("display_id") and t.get("display_id") != t["trip_id"]:
                result.append((t["display_id"], t))
        return result

    def values(self) -> List[Dict[str, Any]]:
        return self.repo.list_all()

    def keys(self) -> List[str]:
        return [k for k, _ in self.items()]


class DatabaseActionsMapping:
    """Dict-like mapping adapter that reads and writes actions directly to SQLite."""

    def __init__(self, repo: DatabaseActionsRepository):
        self.repo = repo

    def __getitem__(self, key: str) -> Dict[str, Any]:
        val = self.repo.get(key)
        if val is None:
            raise KeyError(key)
        return val

    def __setitem__(self, key: str, value: Dict[str, Any]) -> None:
        value["action_id"] = value.get("action_id") or key
        self.repo.save(value)

    def __contains__(self, key: str) -> bool:
        return self.repo.get(key) is not None

    def __len__(self) -> int:
        return self.repo.count()

    def get(self, key: str, default: Any = None) -> Any:
        val = self.repo.get(key)
        return val if val is not None else default

    def items(self) -> List[Tuple[str, Dict[str, Any]]]:
        return [(a["action_id"], a) for a in self.repo.list_all()]

    def values(self) -> List[Dict[str, Any]]:
        return self.repo.list_all()

    def keys(self) -> List[str]:
        return [a["action_id"] for a in self.repo.list_all()]
