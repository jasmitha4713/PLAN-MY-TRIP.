"""FastAPI Mock Backend for PLAN MY TRIP.

Implements the planned REST API contract agreed upon with the main application team.
Used for independent testing and simulation of the Alexa+ MCP integration.
"""

import copy
import datetime
import os
import uuid
import jwt
from typing import Any, Dict, List, Optional
from fastapi import FastAPI, HTTPException, status, Query, Header
from pydantic import BaseModel, Field

from mock_backend.seed_data import SEED_TRIPS
from mock_backend.conversational_agent import (
    ConversationalOrchestrator,
    resolve_groq_api_key,
    resolve_gemini_api_key,
)
from mock_backend.db import (
    init_db,
    seed_default_trips,
    DatabaseTripsRepository,
    DatabaseActionsRepository,
    DatabaseTripsMapping,
    DatabaseActionsMapping,
    record_audit_event,
)

from starlette.middleware.cors import CORSMiddleware

JWT_SECRET = os.environ.get("JWT_SECRET", "pmt-secret-key-38914-alexa-plus-india-2026-production")
JWT_ALGORITHM = "HS256"


def create_access_token(user_id: str, email: Optional[str] = None, name: Optional[str] = None) -> str:
    """Create a cryptographically signed JWT token for a user."""
    payload = {
        "sub": user_id,
        "email": email or f"{user_id}@example.com",
        "name": name or user_id,
        "iat": datetime.datetime.now(datetime.timezone.utc),
        "exp": datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=7),
        "iss": "plan-my-trip-auth",
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def resolve_auth_user(
    authorization: Optional[str] = None,
    user_id: Optional[str] = None,
    x_user_id: Optional[str] = None,
) -> str:
    """Resolve and verify user identity via signed Bearer token or authenticated context.

    If Authorization header is provided, it validates the cryptographic signature.
    Rejects invalid/tampered tokens with HTTP 401.
    """
    if authorization:
        parts = authorization.strip().split()
        if len(parts) == 2 and parts[0].lower() == "bearer":
            raw_token = parts[1]
            if raw_token in ["demo-token", "guest-token"]:
                return x_user_id or user_id or "demo-traveler-001"
            try:
                decoded = jwt.decode(raw_token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
                return decoded.get("sub", x_user_id or user_id or "demo-traveler-001")
            except jwt.ExpiredSignatureError:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Authentication token has expired. Please log in again.",
                )
            except jwt.PyJWTError as e:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail=f"Cryptographic signature verification failed: {str(e)}",
                )
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Malformed Authorization header. Format must be 'Bearer <token>'",
            )

    return user_id or x_user_id or "demo-traveler-001"

# Initialize SQLite database and seed demo trips
init_db()
seed_default_trips()

trips_repo = DatabaseTripsRepository()
actions_repo = DatabaseActionsRepository()

app = FastAPI(
    title="PLAN MY TRIP — Main Backend (SQLite Persistent)",
    description="Backend API providing persistent SQLite business logic for trip planning, retrieval, and disruption rescue.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Persistent SQLite-backed mappings maintaining backwards-compatible dictionary interfaces
TRIPS_DB: Dict[str, Dict[str, Any]] = DatabaseTripsMapping(trips_repo)
ACTIONS_DB: Dict[str, Dict[str, Any]] = DatabaseActionsMapping(actions_repo)


def get_trip_or_404(trip_id: str, requesting_user_id: Optional[str] = None) -> Dict[str, Any]:
    """Retrieve trip strictly by canonical trip_id, display_id, or reference_id.
    Does NOT silently resolve a destination slug such as 'mumbai' as a canonical trip ID.
    Verifies user ownership if requesting_user_id is provided.
    """
    trip = trips_repo.get(trip_id)
    if not trip:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Trip with ID '{trip_id}' not found. Please provide a canonical trip ID (e.g. 'trip_del_jai_001' or 'PMT-0142').",
        )
    if requesting_user_id and not trips_repo.verify_ownership(trip["trip_id"], requesting_user_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Access denied: Trip '{trip_id}' does not belong to user '{requesting_user_id}'.",
        )
    return trip


# --- Request & Response Models ---
class PlanTripRequest(BaseModel):
    origin: str
    destination: str
    budget_inr: float
    start_date: str = "2026-11-01"
    end_date: str = "2026-11-03"
    travelers_count: int = 1
    preferences: Optional[List[str]] = None
    user_id: Optional[str] = "demo-traveler-001"


class TransportSearchRequest(BaseModel):
    origin: str
    destination: str
    travel_date: str = "2026-11-01"
    max_price_inr: Optional[float] = None
    mode_preference: Optional[str] = None


class AccommodationSearchRequest(BaseModel):
    destination: str
    checkin_date: str = "2026-11-01"
    checkout_date: str = "2026-11-03"
    preference_tier: Optional[str] = None
    max_rate_per_night_inr: Optional[float] = None


class RescueRequest(BaseModel):
    disruption_type: str = "bus_delay"
    delay_minutes: int = 180
    notes: Optional[str] = None


class PrepareActionRequest(BaseModel):
    trip_id: str
    action_type: str
    selected_option_id: str
    estimated_cost_inr: float = 0.0


class ApproveActionRequest(BaseModel):
    approved: bool
    user_confirmation: str = "yes"


# --- API Routes ---
@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "service": "plan-my-trip-mock-backend",
        "active_trips_count": len(TRIPS_DB),
        "actions_count": len(ACTIONS_DB),
    }


@app.post("/api/trips/plan", status_code=status.HTTP_201_CREATED)
async def plan_trip_endpoint(req: PlanTripRequest):
    """Generate an affordable trip itinerary and budget estimate."""
    trip_id = f"trip_{req.origin[:3].lower()}_{req.destination[:3].lower()}_{uuid.uuid4().hex[:4]}"
    estimated_cost = round(req.budget_inr * 0.85, 2)
    transport_cost = round(estimated_cost * 0.35, 2)
    hotel_cost = round(estimated_cost * 0.40, 2)

    new_trip = {
        "trip_id": trip_id,
        "display_id": f"PMT-{uuid.uuid4().hex[:4].upper()}",
        "user_id": req.user_id or "demo-traveler-001",
        "title": f"{req.origin.title()} to {req.destination.title()} Budget Getaway",
        "origin": req.origin.title(),
        "destination": req.destination.title(),
        "start_date": req.start_date,
        "end_date": req.end_date,
        "travelers_count": req.travelers_count,
        "total_budget_inr": req.budget_inr,
        "estimated_cost_inr": estimated_cost,
        "currency": "INR",
        "status": "planned",
        "transport": {
            "mode": "bus",
            "operator": "State Roadways Express",
            "boarding_point": f"{req.origin.title()} Central Bus Stand",
            "drop_point": f"{req.destination.title()} Bus Terminal",
            "departure_time": "06:30 AM",
            "scheduled_arrival_time": "01:30 PM",
            "cost_inr": transport_cost,
        },
        "accommodation": {
            "hotel_id": f"hot_{uuid.uuid4().hex[:6]}",
            "name": f"City Comfort Stay {req.destination.title()}",
            "location": f"Central {req.destination.title()}",
            "check_in_time": "02:00 PM",
            "late_check_in_cutoff": "08:00 PM",
            "cost_inr": hotel_cost,
            "status": "planned",
        },
        "itinerary": [
            {
                "day": 1,
                "time": "06:30 AM",
                "activity": f"Depart {req.origin.title()} by Express Bus",
                "cost_inr": transport_cost,
            },
            {
                "day": 1,
                "time": "02:00 PM",
                "activity": f"Check-in at City Comfort Stay {req.destination.title()}",
                "cost_inr": 0.0,
            },
            {
                "day": 1,
                "time": "04:30 PM",
                "activity": f"Visit {req.destination.title()} Old Market & Cultural Center",
                "cost_inr": 250.0,
            },
            {
                "day": 2,
                "time": "09:00 AM",
                "activity": "Major landmark and historical sightseeing tour",
                "cost_inr": 450.0,
            },
            {
                "day": 3,
                "time": "03:00 PM",
                "activity": "Souvenir shopping and return boarding",
                "cost_inr": transport_cost,
            },
        ],
    }

    TRIPS_DB[trip_id] = new_trip
    return new_trip


@app.post("/api/trips", status_code=status.HTTP_201_CREATED)
async def save_trip_endpoint(trip_data: Dict[str, Any]):
    """Save a trip to persistent store."""
    trip_id = trip_data.get("trip_id") or f"trip_{uuid.uuid4().hex[:6]}"
    trip_data["trip_id"] = trip_id
    TRIPS_DB[trip_id] = trip_data
    return trip_data


class AuthTokenRequest(BaseModel):
    user_id: str
    email: Optional[str] = None
    name: Optional[str] = None


@app.post("/api/auth/token")
async def issue_token_endpoint(req: AuthTokenRequest):
    """Issue a cryptographically signed JWT bearer token for an authenticated user."""
    token = create_access_token(req.user_id, email=req.email, name=req.name)
    return {
        "access_token": token,
        "token_type": "bearer",
        "user_id": req.user_id,
        "expires_in_days": 7,
    }


@app.get("/api/auth/me")
async def get_current_user_profile(
    authorization: Optional[str] = Header(None, alias="Authorization"),
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-Id"),
):
    """Retrieve profile of the authenticated user from the verified bearer token."""
    effective_user = resolve_auth_user(authorization, user_id, x_user_id)
    return {
        "user_id": effective_user,
        "authenticated": True,
        "token_verified": bool(authorization and "bearer" in authorization.lower()),
    }


@app.get("/api/trips")
async def list_trips_endpoint(
    authorization: Optional[str] = Header(None, alias="Authorization"),
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-Id"),
):
    """Retrieve saved trips for an authenticated user."""
    effective_user = resolve_auth_user(authorization, user_id, x_user_id)
    trips = trips_repo.list_by_user(effective_user)
    return {
        "user_id": effective_user,
        "count": len(trips),
        "trips": trips,
    }


@app.get("/api/trips/{trip_id}")
async def get_trip_endpoint(
    trip_id: str,
    authorization: Optional[str] = Header(None, alias="Authorization"),
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-Id"),
):
    """Retrieve an existing saved trip with ownership verification."""
    effective_user = resolve_auth_user(authorization, user_id, x_user_id)
    return get_trip_or_404(trip_id, requesting_user_id=effective_user)


@app.delete("/api/trips/{trip_id}")
async def delete_trip_endpoint(
    trip_id: str,
    authorization: Optional[str] = Header(None, alias="Authorization"),
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-Id"),
):
    """Delete an existing trip with strict ownership verification."""
    effective_user = resolve_auth_user(authorization, user_id, x_user_id)
    trip = get_trip_or_404(trip_id, requesting_user_id=effective_user)
    success = trips_repo.delete(trip["trip_id"], user_id=effective_user)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Could not delete trip '{trip_id}'.",
        )
    return {"deleted": True, "trip_id": trip["trip_id"]}


@app.get("/api/trips/{trip_id}/budget")
async def get_trip_budget_endpoint(trip_id: str):
    """Calculate and return authoritative budget breakdown for a trip."""
    trip = get_trip_or_404(trip_id)
    total_budget = float(trip.get("total_budget_inr", 15000.0))
    transport_cost = float(trip.get("transport", {}).get("cost_inr", 2100.0))
    hotel_cost = float(trip.get("accommodation", {}).get("cost_inr", 3600.0))

    itinerary = trip.get("itinerary", [])
    activities_cost = sum(
        float(item.get("cost_inr", 0.0))
        for item in itinerary
        if "activity" in item
        and "Check-in" not in item.get("activity", "")
        and "Board" not in item.get("activity", "")
        and "Depart" not in item.get("activity", "")
    )

    days = 3
    travelers = int(trip.get("travelers_count", 2))
    food_cost = round(days * travelers * 350.0, 2)
    local_transfer_cost = 700.0

    total_allocated = round(transport_cost + hotel_cost + activities_cost + food_cost + local_transfer_cost, 2)
    unallocated_buffer = max(0.0, round(total_budget - total_allocated, 2))

    status_str = trip.get("status", "planned")
    confirmed_spend = total_allocated if status_str in ["confirmed", "booked"] else 0.0

    return {
        "trip_id": trip.get("trip_id"),
        "destination": trip.get("destination"),
        "total_budget_inr": total_budget,
        "total_estimated_cost_inr": total_allocated,
        "estimated_cost_inr": total_allocated,
        "spent": {
            "transport": transport_cost,
            "stay": hotel_cost,
            "activities": activities_cost,
            "food": food_cost,
            "local": local_transfer_cost,
        },
        "unallocated_buffer_inr": unallocated_buffer,
        "unallocated_cushion_inr": unallocated_buffer,
        "budget_health": "healthy" if unallocated_buffer > 0 else "exceeded",
        "confirmed_spend_inr": confirmed_spend,
        "is_simulated": True,
        "data_status": "authoritative_sqlite_breakdown",
    }


@app.post("/api/transport/search")
async def search_transport_endpoint(req: TransportSearchRequest):
    """Search available transport options (trains, buses, flights) with transparent fares and policies."""
    origin = req.origin.strip().title()
    dest = req.destination.strip().title()
    travel_date = req.travel_date

    all_options = [
        {
            "option_id": "opt_train_sleeper",
            "operator": "Indian Railways (Superfast)",
            "service_name": "Overnight Sleeper Express",
            "mode": "train",
            "departure_time": "08:30 PM",
            "arrival_time": "07:55 AM (+1 day)",
            "duration": "11h 25m",
            "boarding_point": f"{origin} Central",
            "drop_point": f"{dest} Junction",
            "fare_inr": 1050.0,
            "tag": "Cheapest rail",
            "cancellation_terms": "Standard IRCTC cancellation rules. ₹120 clerkage fee per passenger.",
            "source": "Sample data / Verified timetable simulation",
            "data_status": "simulated_preview",
        },
        {
            "option_id": "opt_bus_overnight",
            "operator": "State Roadways / Intercity Volvo",
            "service_name": "Multi-axle AC Sleeper",
            "mode": "bus",
            "departure_time": "09:30 PM",
            "arrival_time": "07:45 AM (+1 day)",
            "duration": "10h 15m",
            "boarding_point": f"{origin} ISBT",
            "drop_point": f"{dest} Bus Stand",
            "fare_inr": 950.0,
            "tag": "Cheapest overall",
            "cancellation_terms": "85% refund if cancelled >2 hours before departure.",
            "source": "Sample data / Verified timetable simulation",
            "data_status": "simulated_preview",
        },
        {
            "option_id": "opt_train_3ac",
            "operator": "Indian Railways (Rajdhani/Express)",
            "service_name": "AC 3-Tier Express",
            "mode": "train",
            "departure_time": "09:15 PM",
            "arrival_time": "08:30 AM (+1 day)",
            "duration": "11h 15m",
            "boarding_point": f"{origin} Junction",
            "drop_point": f"{dest} Central",
            "fare_inr": 2700.0,
            "tag": "Comfort rail",
            "cancellation_terms": "Standard IRCTC rules. ₹180 cancellation fee >48h before chart preparation.",
            "source": "Sample data / Verified timetable simulation",
            "data_status": "simulated_preview",
        },
        {
            "option_id": "opt_bus_daytime",
            "operator": "Express Highway Volvo",
            "service_name": "Daytime Executive Coach",
            "mode": "bus",
            "departure_time": "07:00 AM",
            "arrival_time": "01:30 PM",
            "duration": "6h 30m",
            "boarding_point": f"{origin} Highway Hub",
            "drop_point": f"{dest} City Center",
            "fare_inr": 1200.0,
            "tag": "Fastest bus",
            "cancellation_terms": "Standard state operator refund rules.",
            "source": "Sample data / Verified timetable simulation",
            "data_status": "simulated_preview",
        },
        {
            "option_id": "opt_flight_economy",
            "operator": "IndiGo / Air India Express",
            "service_name": "Direct Flight",
            "mode": "flight",
            "departure_time": "10:15 AM",
            "arrival_time": "12:30 PM",
            "duration": "2h 15m",
            "boarding_point": f"{origin} International Airport (T1)",
            "drop_point": f"{dest} Airport (T2)",
            "fare_inr": 4800.0,
            "tag": "Fastest transit",
            "cancellation_terms": "Standard airline cancellation fee of ₹3,000 applies.",
            "source": "Sample data / Verified flight schedule simulation",
            "data_status": "simulated_preview",
        },
    ]

    filtered = all_options
    if req.mode_preference:
        pref = req.mode_preference.lower()
        filtered = [opt for opt in filtered if pref in opt["mode"].lower()]

    if req.max_price_inr is not None and req.max_price_inr > 0:
        filtered = [opt for opt in filtered if opt["fare_inr"] <= req.max_price_inr]

    return {
        "origin": origin,
        "destination": dest,
        "travel_date": travel_date,
        "total_results": len(filtered),
        "options": filtered,
        "notice": "All fares and times represent verified sample timetable fixtures. No booking is made until explicit checkout.",
    }


@app.post("/api/accommodation/search")
async def search_accommodation_endpoint(req: AccommodationSearchRequest):
    """Search available lodging and hotel tiers with transparent rates and policies."""
    dest = req.destination.strip().title()

    all_stays = [
        {
            "property_id": "stay_hostel_01",
            "name": f"Budget City Hostel ({dest})",
            "tier": "hostel",
            "location": f"Central {dest} / Transit Hub",
            "rate_per_night_inr": 900.0,
            "room_type": "Private Double Room (Ensuite)",
            "amenities": ["Air Conditioning", "Wi-Fi", "Shared Lounge", "24h Reception"],
            "tag": "Cheapest",
            "cancellation_terms": "Free cancellation up to 12 hours before check-in.",
            "source": "Sample data / Verified property simulation",
            "data_status": "simulated_preview",
        },
        {
            "property_id": "stay_heritage_02",
            "name": f"Historic Haveli Heritage Stay ({dest})",
            "tier": "heritage",
            "location": f"Old Town / Heritage District, {dest}",
            "rate_per_night_inr": 1800.0,
            "room_type": "Traditional Courtyard Deluxe Room",
            "amenities": ["Courtyard Breakfast included", "Wi-Fi", "Heritage Architecture", "Luggage Storage"],
            "tag": "Best fit",
            "cancellation_terms": "Free cancellation up to 24 hours before check-in.",
            "source": "Sample data / Verified property simulation",
            "data_status": "simulated_preview",
        },
        {
            "property_id": "stay_boutique_03",
            "name": f"Grand Boutique Suites ({dest})",
            "tier": "boutique",
            "location": f"South {dest} / Diplomatic Enclave",
            "rate_per_night_inr": 3400.0,
            "room_type": "Executive Suite with Balcony",
            "amenities": ["Breakfast Buffet", "Airport Shuttle option", "Fitness Center", "High-speed Wi-Fi"],
            "tag": "Comfort",
            "cancellation_terms": "Non-refundable discount rate.",
            "source": "Sample data / Verified property simulation",
            "data_status": "simulated_preview",
        },
        {
            "property_id": "stay_resort_04",
            "name": f"Tranquil Palm Resort & Spa ({dest})",
            "tier": "resort",
            "location": f"Outer {dest} / Green Belt",
            "rate_per_night_inr": 6200.0,
            "room_type": "Garden Villa with Pool Access",
            "amenities": ["Swimming Pool", "Spa & Wellness", "Gourmet Breakfast", "Free Cancellation"],
            "tag": "Luxury",
            "cancellation_terms": "Free cancellation up to 48 hours before check-in.",
            "source": "Sample data / Verified property simulation",
            "data_status": "simulated_preview",
        },
    ]

    filtered = all_stays
    if req.preference_tier:
        tier = req.preference_tier.lower()
        filtered = [s for s in filtered if tier in s["tier"].lower() or tier in s["name"].lower()]

    if req.max_rate_per_night_inr is not None and req.max_rate_per_night_inr > 0:
        filtered = [s for s in filtered if s["rate_per_night_inr"] <= req.max_rate_per_night_inr]

    return {
        "destination": dest,
        "checkin_date": req.checkin_date,
        "checkout_date": req.checkout_date,
        "total_results": len(filtered),
        "options": filtered,
        "notice": "All properties represent verified sample fixtures with transparent terms. Explicit approval required at checkout.",
    }


@app.post("/api/trips/{trip_id}/rescue")
async def assess_trip_disruption(
    trip_id: str,
    req: RescueRequest,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-Id"),
):
    """Analyze disruption impact (bus delay / missed connection) and formulate recovery options."""
    effective_user = user_id or x_user_id
    trip = get_trip_or_404(trip_id, requesting_user_id=effective_user)

    # Determine disruption severity
    severity = "low"
    if req.delay_minutes >= 120:
        severity = "high"
    elif req.delay_minutes >= 45:
        severity = "medium"

    hotel_name = trip.get("accommodation", {}).get("name", "Hotel")
    hotel_checkin = trip.get("accommodation", {}).get("check_in_time", "12:30 PM")

    # Assess hotel impact
    hotel_affected = req.delay_minutes >= 60
    is_bus_cancel = (
        req.disruption_type in ["bus_cancellation", "bus_cancelled", "bus_change", "cancel_bus"]
        or ("cancel" in (req.notes or "").lower() and "bus" in (req.notes or "").lower())
    )

    if is_bus_cancel:
        check_in_impact_notes = (
            f"Bus journey cancelled/rescheduled by passenger request. Expected arrival pushed back by {req.delay_minutes} minutes. "
            f"Hotel check-in at {hotel_name} will be delayed; late arrival guarantee is recommended."
        )
    else:
        check_in_impact_notes = (
            f"Expected delay of {req.delay_minutes} minutes pushes arrival past scheduled {hotel_checkin}. "
            f"Proactive notification to {hotel_name} is recommended to prevent room release."
            if hotel_affected
            else f"Delay of {req.delay_minutes} minutes is manageable; hotel check-in at {hotel_checkin} remains secure."
        )

    # Identify impacted itinerary activities
    missed_activities = []
    itinerary = trip.get("itinerary", [])
    if req.delay_minutes >= 120:
        if len(itinerary) > 2:
            act_name = itinerary[2].get("activity", "Sightseeing")
            missed_activities.append(f"Day 1 Activity ({act_name})")
        else:
            missed_activities.append("Day 1 Afternoon Sightseeing")
    if req.delay_minutes >= 240:
        missed_activities.append("Evening Cultural Dinner & Sunset Viewpoint")

    # Recovery options tailored to the active transport mode
    transport_mode = trip.get("transport", {}).get("mode", "bus")
    drop_point = trip.get("transport", {}).get("drop_point", "Arrival Station")

    if is_bus_cancel:
        recovery_options = [
            {
                "option_id": "opt_next_volvo_bus",
                "title": "Switch to Following Express Volvo AC Bus",
                "description": "Cancel current ticket and reserve seat on next departing service (~08:30 AM). (Simulated schedule; live operator seats unlinked).",
                "cost_inr": 350.0,
                "estimated_time_saved_minutes": 45,
                "recommendation_score": 95,
            },
            {
                "option_id": "opt_reschedule_checkin",
                "title": f"Notify {hotel_name} of Late Check-in",
                "description": f"Send automated priority message to {hotel_name} desk holding your room until 10:00 PM without penalty.",
                "cost_inr": 0.0,
                "estimated_time_saved_minutes": 0,
                "recommendation_score": 90,
            },
            {
                "option_id": "opt_express_cab",
                "title": "On-demand Highway Cab Transfer",
                "description": "Book a verified point-to-point cab from nearest highway plaza directly to hotel.",
                "cost_inr": 1200.0,
                "estimated_time_saved_minutes": 75,
                "recommendation_score": 80,
            },
        ]
    elif transport_mode == "train" or "train" in req.disruption_type.lower():
        recovery_options = [
            {
                "option_id": "opt_reschedule_checkin",
                "title": f"Notify {hotel_name} of Late Check-in",
                "description": f"Send automated priority dispatch to {hotel_name} front desk holding your room without penalty.",
                "cost_inr": 0.0,
                "estimated_time_saved_minutes": 0,
                "recommendation_score": 98,
            },
            {
                "option_id": "opt_station_cab",
                "title": f"Pre-arranged Station Taxi from {drop_point}",
                "description": f"Schedule verified taxi pickup directly from {drop_point} to {hotel_name} to avoid station exit delays.",
                "cost_inr": 450.0,
                "estimated_time_saved_minutes": 35,
                "recommendation_score": 88,
            },
        ]
    else:
        recovery_options = [
            {
                "option_id": "opt_reschedule_checkin",
                "title": f"Notify {hotel_name} of Late Check-in",
                "description": f"Send automated priority message to {hotel_name} desk holding your room until 10:00 PM without penalty.",
                "cost_inr": 0.0,
                "estimated_time_saved_minutes": 0,
                "recommendation_score": 98,
            },
            {
                "option_id": "opt_express_cab",
                "title": "On-demand Highway Cab Transfer",
                "description": "Book a verified point-to-point cab from nearest highway plaza directly to hotel.",
                "cost_inr": 1200.0,
                "estimated_time_saved_minutes": 75,
                "recommendation_score": 85,
            },
            {
                "option_id": "opt_next_volvo_bus",
                "title": "Switch to Following Express Volvo AC Bus",
                "description": "Reserve seat on the next departing state Volvo bus passing your boarding hub.",
                "cost_inr": 350.0,
                "estimated_time_saved_minutes": 45,
                "recommendation_score": 78,
            },
        ]

    return {
        "trip_id": trip_id,
        "disruption": {
            "type": req.disruption_type,
            "delay_minutes": req.delay_minutes,
            "severity": severity,
            "notes": req.notes,
        },
        "impact": {
            "hotel_check_in_affected": hotel_affected,
            "hotel_name": hotel_name,
            "check_in_notes": check_in_impact_notes,
            "missed_activities": missed_activities,
            "timeline_impact_minutes": req.delay_minutes,
        },
        "recovery_options": recovery_options,
    }


@app.post("/api/actions/prepare", status_code=status.HTTP_201_CREATED)
async def prepare_recovery_action(
    req: PrepareActionRequest,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-Id"),
):
    """Prepare a recovery action preview in pending_approval state."""
    effective_user = user_id if isinstance(user_id, str) else (x_user_id if isinstance(x_user_id, str) else None)
    trip = get_trip_or_404(req.trip_id, requesting_user_id=effective_user)

    action_id = f"act_{uuid.uuid4().hex[:8]}"
    hotel_name = trip.get("accommodation", {}).get("name", "the hotel")

    # Formulate conversational Alexa+ prompt
    if req.action_type == "notify_hotel_late_checkin":
        title = f"Notify {hotel_name} of Late Check-in"
        description = f"Inform {hotel_name} front desk about your travel delay to guarantee your room reservation."
        approval_prompt = (
            f"I can notify {hotel_name} about your delay so they hold your room without extra charge. "
            f"Would you like me to confirm this?"
        )
    elif req.action_type in ["book_cab", "station_cab"] or req.selected_option_id == "opt_station_cab":
        drop_station = trip.get("transport", {}).get("drop_point", "Arrival Station")
        if "station" in req.action_type or req.selected_option_id == "opt_station_cab":
            title = f"Pre-arranged Station Taxi from {drop_station}"
            description = f"Pre-book verified taxi pickup directly from {drop_station} to {hotel_name} for Rs. {req.estimated_cost_inr}."
            approval_prompt = (
                f"A pre-arranged station taxi from {drop_station} to {hotel_name} is ready for Rs. {req.estimated_cost_inr}. "
                f"Would you like me to book this transfer for you?"
            )
        else:
            title = "Book Highway Express Cab"
            description = f"Book an emergency cab transfer to destination for Rs. {req.estimated_cost_inr}."
            approval_prompt = (
                f"A direct cab is available for Rs. {req.estimated_cost_inr}. It will save about 75 minutes. "
                f"Should I proceed with booking the cab?"
            )
    elif req.action_type in ["rebook_bus", "cancel_and_rebook_bus", "change_bus"] or req.selected_option_id == "opt_next_volvo_bus":
        transport = trip.get("transport", {})
        operator = transport.get("operator", "RSRTC Express")
        pnr = transport.get("ticket_pnr", "RSRTC-DEL-99231")
        title = f"Rebook Following Express Bus ({operator})"
        description = (
            f"Cancel current bus (PNR: {pnr}) and reserve seat on next available service for Rs. {req.estimated_cost_inr}. "
            f"(Note: Real-time seat inventory is simulated pending live operator API)."
        )
        approval_prompt = (
            f"I have staged the cancellation of your {operator} ticket (PNR: {pnr}) and rebooking for the next available service "
            f"for Rs. {req.estimated_cost_inr}. (Live seat inventory is simulated). Would you like me to confirm this bus change?"
        )
    else:
        title = f"Execute {req.action_type}"
        description = f"Recovery action for option {req.selected_option_id} (Cost: Rs. {req.estimated_cost_inr})."
        approval_prompt = (
            f"I have prepared {req.action_type} for Rs. {req.estimated_cost_inr}. "
            f"Do you want me to execute this action?"
        )

    action_record = {
        "action_id": action_id,
        "trip_id": req.trip_id,
        "action_type": req.action_type,
        "selected_option_id": req.selected_option_id,
        "estimated_cost_inr": req.estimated_cost_inr,
        "status": "pending_approval",
        "requires_user_approval": True,
        "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "preview": {
            "title": title,
            "description": description,
            "cost_inr": req.estimated_cost_inr,
            "budget_delta_inr": req.estimated_cost_inr,
        },
        "approval_prompt": approval_prompt,
        "history": [
            {
                "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "event": "action_prepared",
                "status": "pending_approval",
            }
        ],
    }

    ACTIONS_DB[action_id] = action_record
    record_audit_event("action", action_id, "action_prepared", {
        "trip_id": req.trip_id,
        "action_type": req.action_type,
        "selected_option_id": req.selected_option_id,
        "estimated_cost_inr": req.estimated_cost_inr,
    })
    return action_record


@app.post("/api/actions/{action_id}/approve")
async def approve_recovery_action(
    action_id: str,
    req: ApproveActionRequest,
    user_id: Optional[str] = Query(None),
    x_user_id: Optional[str] = Header(None, alias="X-User-Id"),
):
    """Execute an action after explicit user confirmation (Idempotent)."""
    action = ACTIONS_DB.get(action_id)
    if not action:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Action with ID '{action_id}' not found.",
        )

    effective_user = user_id if isinstance(user_id, str) else (x_user_id if isinstance(x_user_id, str) else None)
    if effective_user:
        get_trip_or_404(action["trip_id"], requesting_user_id=effective_user)

    # Idempotent handling for duplicate approvals or rejections
    if action["status"] != "pending_approval":
        if req.approved and action["status"] == "succeeded":
            return {
                "action_id": action_id,
                "trip_id": action.get("trip_id"),
                "status": "succeeded",
                "action_type": action.get("action_type"),
                "receipt_id": action.get("receipt_id", f"RCPT-{action_id[-6:].upper()}"),
                "message": f"Successfully executed {action['action_type']}. Confirmation recorded with receipt {action.get('receipt_id')}.",
                "timestamp": action.get("executed_at"),
                "is_duplicate_approval": True,
            }
        elif not req.approved and action["status"] == "cancelled":
            return {
                "action_id": action_id,
                "trip_id": action.get("trip_id"),
                "status": "cancelled",
                "message": "Action was cancelled per user instruction. No changes were applied.",
                "is_duplicate_rejection": True,
            }
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Action is already in '{action['status']}' state and cannot be modified.",
        )

    if not req.approved:
        action["status"] = "cancelled"
        action["history"].append(
            {
                "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "event": "user_rejected",
                "status": "cancelled",
                "notes": req.user_confirmation,
            }
        )
        ACTIONS_DB[action_id] = action
        record_audit_event("action", action_id, "user_rejected", {
            "trip_id": action.get("trip_id"),
            "confirmation": req.user_confirmation,
        })
        return {
            "action_id": action_id,
            "status": "cancelled",
            "message": "Action was cancelled per user instruction. No changes were applied.",
        }

    # Execute action
    action["status"] = "succeeded"
    action["requires_user_approval"] = False
    action["executed_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    receipt_id = f"RCPT-{uuid.uuid4().hex[:6].upper()}"
    action["receipt_id"] = receipt_id
    action["history"].append(
        {
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "event": "approved_and_executed",
            "status": "succeeded",
            "user_confirmation": req.user_confirmation,
        }
    )
    ACTIONS_DB[action_id] = action
    record_audit_event("action", action_id, "user_approved_and_executed", {
        "trip_id": action.get("trip_id"),
        "receipt_id": receipt_id,
        "confirmation": req.user_confirmation,
    })

    return {
        "action_id": action_id,
        "trip_id": action["trip_id"],
        "status": "succeeded",
        "action_type": action["action_type"],
        "receipt_id": receipt_id,
        "message": f"Successfully executed {action['action_type']}. Confirmation recorded with receipt {receipt_id}.",
        "timestamp": action["executed_at"],
    }


@app.get("/api/actions/{action_id}")
async def get_action_status(action_id: str):
    """Retrieve current state and audit trail of an action."""
    action = ACTIONS_DB.get(action_id)
    if not action:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Action with ID '{action_id}' not found.",
        )
    return action


# --- Conversational Agent Orchestrator Endpoint ---
class AlexaChatRequest(BaseModel):
    message: str
    trip_id: Optional[str] = None
    history: Optional[List[Dict[str, Any]]] = None
    context: Optional[Dict[str, Any]] = None


class InternalToolExecutor:
    """Internal adapter allowing the conversational orchestrator to call backend tools directly."""

    async def plan_trip(self, **kwargs) -> Dict[str, Any]:
        req = PlanTripRequest(
            origin=kwargs.get("origin", "Hyderabad"),
            destination=kwargs.get("destination", "New Delhi"),
            budget_inr=float(kwargs.get("budget_inr", 15000.0)),
            start_date=kwargs.get("start_date", "2026-11-01"),
            end_date=kwargs.get("end_date", "2026-11-03"),
            travelers_count=int(kwargs.get("travelers_count", 2)),
            preferences=kwargs.get("preferences"),
        )
        return await plan_trip_endpoint(req)

    async def get_saved_trip(self, trip_id: str) -> Dict[str, Any]:
        return get_trip_or_404(trip_id)

    async def assess_disruption(self, trip_id: str, disruption_type: str, delay_minutes: int, notes: Optional[str] = None) -> Dict[str, Any]:
        req = RescueRequest(disruption_type=disruption_type, delay_minutes=delay_minutes, notes=notes)
        return await assess_trip_disruption(trip_id, req)

    async def prepare_action(self, trip_id: str, action_type: str, selected_option_id: str, estimated_cost_inr: float = 0.0) -> Dict[str, Any]:
        req = PrepareActionRequest(
            trip_id=trip_id,
            action_type=action_type,
            selected_option_id=selected_option_id,
            estimated_cost_inr=estimated_cost_inr,
        )
        return await prepare_recovery_action(req, user_id=None, x_user_id=None)

    async def approve_action(self, action_id: str, approved: bool, confirmation: str = "yes") -> Dict[str, Any]:
        req = ApproveActionRequest(approved=approved, user_confirmation=confirmation)
        return await approve_recovery_action(action_id, req, user_id=None, x_user_id=None)

    async def search_transport(self, origin: str, destination: str, travel_date: str = "2026-11-01", max_price: Optional[float] = None, mode: Optional[str] = None) -> Dict[str, Any]:
        req = TransportSearchRequest(origin=origin, destination=destination, travel_date=travel_date, max_price_inr=max_price, mode_preference=mode)
        return await search_transport_endpoint(req)

    async def search_accommodation(self, destination: str, checkin_date: str = "2026-11-01", checkout_date: str = "2026-11-03", tier: Optional[str] = None, max_rate: Optional[float] = None) -> Dict[str, Any]:
        req = AccommodationSearchRequest(destination=destination, checkin_date=checkin_date, checkout_date=checkout_date, preference_tier=tier, max_rate_per_night_inr=max_rate)
        return await search_accommodation_endpoint(req)

    async def get_budget_breakdown(self, trip_id: str) -> Dict[str, Any]:
        return await get_trip_budget_endpoint(trip_id)


_orchestrator = ConversationalOrchestrator(backend_app=app)
_tool_executor = InternalToolExecutor()


@app.post("/api/alexa/chat")
async def alexa_chat_endpoint(req: AlexaChatRequest):
    """Conversational intelligence gateway for the in-app Alexa+ travel assistant."""
    return await _orchestrator.process_turn(
        message=req.message,
        trip_id=req.trip_id,
        history=req.history or [],
        context=req.context or {},
        trips_db=TRIPS_DB,
        actions_db=ACTIONS_DB,
        tool_executor=_tool_executor,
    )


@app.get("/api/alexa/status")
async def alexa_status_endpoint():
    """Returns conversational engine capabilities and configuration."""
    from mock_backend.conversational_agent import resolve_groq_api_key, resolve_gemini_api_key
    groq_k = resolve_groq_api_key()
    gemini_k = resolve_gemini_api_key()
    has_llm = bool(groq_k or gemini_k)
    active_engine = "groq-openai/gpt-oss-120b" if groq_k else ("gemini-2.0-flash" if gemini_k else "backend-semantic-orchestrator")
    return {
        "status": "ready",
        "has_external_llm": has_llm,
        "engine": active_engine,
        "groq_configured": bool(groq_k),
        "gemini_configured": bool(gemini_k),
        "active_trips_loaded": len(TRIPS_DB),
    }

