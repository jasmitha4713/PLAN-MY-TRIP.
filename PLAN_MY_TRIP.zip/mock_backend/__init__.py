"""Mock Backend simulating the main application's FastAPI REST endpoints."""
