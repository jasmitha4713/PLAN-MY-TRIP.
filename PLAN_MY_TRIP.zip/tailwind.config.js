/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: '#0B1B2B',
          2: '#3C4B5A',
        },
        cream: {
          DEFAULT: '#FBF6EE',
          2: '#F3E9D8',
        },
        paper: '#FFFFFF',
        line: '#E8E0D2',
        marigold: {
          DEFAULT: '#F5A524',
          ink: '#3B2500',
        },
        teal: {
          DEFAULT: '#0E7C7B',
          soft: '#E6F4F4',
        },
        amber: {
          DEFAULT: '#C77700',
          soft: '#FDF4E6',
        },
        coral: {
          DEFAULT: '#D9453D',
          soft: '#FCEBEA',
        },
      },
      fontFamily: {
        display: ['"Clash Display"', 'Outfit', '"DM Sans"', 'system-ui', 'sans-serif'],
        sans: ['Satoshi', '"DM Sans"', 'system-ui', '-apple-system', 'sans-serif'],
      },
      borderRadius: {
        card: '14px',
        btn: '12px',
      },
      boxShadow: {
        floating: '0 12px 32px rgba(11, 27, 43, 0.12)',
      },
      maxWidth: {
        container: '1240px',
        prose: '62ch',
      },
    },
  },
  plugins: [],
}
