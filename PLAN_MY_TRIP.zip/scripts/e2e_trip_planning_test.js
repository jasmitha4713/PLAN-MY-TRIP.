import puppeteer from 'puppeteer-core';

const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';

async function runRealBrowserE2ETests() {
  console.log('====================================================');
  console.log('STARTING REAL BROWSER E2E TESTS (ALL 7 TEST FLOWS)');
  console.log('====================================================\n');

  const browser = await puppeteer.launch({
    headless: 'new',
    executablePath: CHROME_PATH,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const results = [];
  const wait = ms => new Promise(r => setTimeout(r, ms));

  try {
    // ---------------------------------------------------------------
    // TEST 1: Typed Mumbai trip, choose 5, submit, itinerary loads
    // ---------------------------------------------------------------
    console.log('--- TEST 1: Typed Mumbai trip, choose 5, submit, itinerary loads ---');
    {
      const page = await browser.newPage();
      await page.setViewport({ width: 1280, height: 800 });

      let capturedRequest = null;
      let capturedResponse = null;

      page.on('request', req => {
        if (req.url().includes(':8001/mcp') && req.method() === 'POST') {
          try {
            const body = JSON.parse(req.postData() || '{}');
            if (body.method === 'tools/call' && body.params?.name === 'plan_trip') {
              capturedRequest = body.params.arguments;
            }
          } catch {}
        } else if (req.url().includes('/api/trips/plan') && req.method() === 'POST') {
          try {
            capturedRequest = JSON.parse(req.postData() || '{}');
          } catch {}
        }
      });

      page.on('response', async resp => {
        if (resp.url().includes(':8001/mcp') && resp.request().method() === 'POST') {
          try {
            const json = await resp.json();
            if (json.result?.content?.[0]?.text) {
              capturedResponse = JSON.parse(json.result.content[0].text);
            }
          } catch {}
        } else if (resp.url().includes('/api/trips/plan') && resp.request().method() === 'POST') {
          try {
            capturedResponse = await resp.json();
          } catch {}
        }
      });

      await page.goto('http://localhost:3000/app?demo=true', { waitUntil: 'networkidle2' });
      await page.waitForSelector('textarea', { timeout: 10000 });

      // Type prompt
      await page.evaluate(() => {
        const ta = document.querySelector('textarea');
        const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
        setter.call(ta, 'Plan a trip to Mumbai for 3 days, 5 to 6 members, budget ₹60,000');
        ta.dispatchEvent(new Event('input', { bubbles: true }));
      });

      // Click Plan button
      const planBtn = await page.waitForSelector('button[type="submit"]');
      await planBtn.click();
      await wait(800);

      // Click "Plan for 5 travellers"
      await page.evaluate(() => {
        const btns = Array.from(document.querySelectorAll('button'));
        const b = btns.find(x => x.innerText.includes('Plan for 5 travellers'));
        if (b) b.click();
        else throw new Error('Button "Plan for 5 travellers" not found');
      });
      await wait(400);

      // Extract form values before submitting
      const formValues = await page.evaluate(() => {
        const dialog = document.querySelector('[role="dialog"]');
        const fromVal = dialog.querySelector('select:nth-of-type(1)')?.value;
        const toVal = dialog.querySelectorAll('select')[1]?.value;
        const budgetVal = dialog.querySelector('input[type="number"]')?.value;
        const dateVal = dialog.querySelector('input[type="date"]')?.value;
        const travellersText = dialog.innerText.match(/Travellers \((\d+) Total\)/)?.[1];
        return { fromVal, toVal, budgetVal, dateVal, travellersText };
      });

      // Click "Plan trip" submit button
      await page.evaluate(() => {
        const dialog = document.querySelector('[role="dialog"]');
        dialog.querySelector('button[type="submit"]').click();
      });

      await wait(2500);

      const finalUrl = page.url();
      const modalStillOpen = await page.evaluate(() => !!document.querySelector('[role="dialog"]'));
      const headings = await page.evaluate(() => Array.from(document.querySelectorAll('h1, h2, h3')).map(h => h.innerText));

      const passed = finalUrl.includes('/app/trip/') && !modalStillOpen && capturedRequest?.travelers_count === 5 && formValues.travellersText === '5';
      console.log('Test 1 Form Values:', formValues);
      console.log('Test 1 Captured Request:', capturedRequest);
      console.log('Test 1 Backend Response Trip ID:', capturedResponse?.trip_id || capturedResponse?.data?.trip_id);
      console.log('Test 1 Final URL:', finalUrl);
      console.log('Test 1 Headings on Final Page:', headings);
      console.log('Test 1 Result:', passed ? 'PASS' : 'FAIL');
      results.push({ test: '1. Typed Mumbai trip (5 travellers)', passed, formValues, capturedRequest, capturedResponse, finalUrl });
      await page.close();
    }

    // ---------------------------------------------------------------
    // TEST 2: Typed Mumbai trip, choose 6, submit, itinerary loads
    // ---------------------------------------------------------------
    console.log('\n--- TEST 2: Typed Mumbai trip, choose 6, submit, itinerary loads ---');
    {
      const page = await browser.newPage();
      await page.setViewport({ width: 1280, height: 800 });

      let capturedRequest = null;
      let capturedResponse = null;

      page.on('request', req => {
        if (req.url().includes(':8001/mcp') && req.method() === 'POST') {
          try {
            const body = JSON.parse(req.postData() || '{}');
            if (body.method === 'tools/call' && body.params?.name === 'plan_trip') {
              capturedRequest = body.params.arguments;
            }
          } catch {}
        } else if (req.url().includes('/api/trips/plan') && req.method() === 'POST') {
          try {
            capturedRequest = JSON.parse(req.postData() || '{}');
          } catch {}
        }
      });

      page.on('response', async resp => {
        if (resp.url().includes(':8001/mcp') && resp.request().method() === 'POST') {
          try {
            const json = await resp.json();
            if (json.result?.content?.[0]?.text) {
              capturedResponse = JSON.parse(json.result.content[0].text);
            }
          } catch {}
        } else if (resp.url().includes('/api/trips/plan') && resp.request().method() === 'POST') {
          try {
            capturedResponse = await resp.json();
          } catch {}
        }
      });

      await page.goto('http://localhost:3000/app?demo=true', { waitUntil: 'networkidle2' });
      await page.waitForSelector('textarea', { timeout: 10000 });

      await page.evaluate(() => {
        const ta = document.querySelector('textarea');
        const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
        setter.call(ta, 'Plan a trip to Mumbai for 3 days, 5 to 6 members, budget ₹60,000');
        ta.dispatchEvent(new Event('input', { bubbles: true }));
      });

      const planBtn = await page.waitForSelector('button[type="submit"]');
      await planBtn.click();
      await wait(800);

      // Click "Plan for 6 travellers"
      await page.evaluate(() => {
        const btns = Array.from(document.querySelectorAll('button'));
        const b = btns.find(x => x.innerText.includes('Plan for 6 travellers'));
        if (b) b.click();
        else throw new Error('Button "Plan for 6 travellers" not found');
      });
      await wait(400);

      const formValues = await page.evaluate(() => {
        const dialog = document.querySelector('[role="dialog"]');
        const fromVal = dialog.querySelector('select:nth-of-type(1)')?.value;
        const toVal = dialog.querySelectorAll('select')[1]?.value;
        const budgetVal = dialog.querySelector('input[type="number"]')?.value;
        const travellersText = dialog.innerText.match(/Travellers \((\d+) Total\)/)?.[1];
        return { fromVal, toVal, budgetVal, travellersText };
      });

      // Click "Plan trip" submit button
      await page.evaluate(() => {
        const dialog = document.querySelector('[role="dialog"]');
        dialog.querySelector('button[type="submit"]').click();
      });

      await wait(2500);

      const finalUrl = page.url();
      const modalStillOpen = await page.evaluate(() => !!document.querySelector('[role="dialog"]'));
      const passed = finalUrl.includes('/app/trip/') && !modalStillOpen && capturedRequest?.travelers_count === 6 && formValues.travellersText === '6';

      console.log('Test 2 Form Values:', formValues);
      console.log('Test 2 Captured Request:', capturedRequest);
      console.log('Test 2 Backend Response Trip ID:', capturedResponse?.trip_id || capturedResponse?.data?.trip_id);
      console.log('Test 2 Final URL:', finalUrl);
      console.log('Test 2 Result:', passed ? 'PASS' : 'FAIL');
      results.push({ test: '2. Typed Mumbai trip (6 travellers)', passed, formValues, capturedRequest, capturedResponse, finalUrl });
      await page.close();
    }

    // ---------------------------------------------------------------
    // TEST 3: Voice Mumbai trip for 5 people around ₹60,000
    // ---------------------------------------------------------------
    console.log('\n--- TEST 3: Voice Mumbai trip for 5 people around ₹60,000 ---');
    {
      const page = await browser.newPage();
      await page.setViewport({ width: 1280, height: 800 });

      await page.goto('http://localhost:3000/app?demo=true', { waitUntil: 'networkidle2' });
      await page.waitForSelector('textarea', { timeout: 10000 });

      // Trigger voice panel
      await page.evaluate(() => {
        const voiceTrigger = Array.from(document.querySelectorAll('button')).find(b => b.innerText.toLowerCase().includes('voice'));
        if (voiceTrigger) voiceTrigger.click();
      });

      await wait(500);

      const voiceModalOpen = await page.evaluate(() => !!document.querySelector('[role="dialog"] textarea'));
      if (voiceModalOpen) {
        await page.evaluate(() => {
          const ta = document.querySelector('[role="dialog"] textarea');
          const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
          setter.call(ta, 'Planet trip to Mumbai for 3 days For five members around 60k');
          ta.dispatchEvent(new Event('input', { bubbles: true }));
        });
        await wait(300);

        await page.evaluate(() => {
          const btns = Array.from(document.querySelectorAll('[role="dialog"] button'));
          const planBtn = btns.find(b => b.innerText.includes('Plan') || b.innerText.includes('Journey'));
          if (planBtn) planBtn.click();
        });
      } else {
        await page.evaluate(() => {
          const ta = document.querySelector('textarea');
          const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
          setter.call(ta, 'Planet trip to Mumbai for 3 days For five members around 60k');
          ta.dispatchEvent(new Event('input', { bubbles: true }));
          document.querySelector('form button[type="submit"]').click();
        });
      }

      await wait(1000);

      const formValues = await page.evaluate(() => {
        const dialog = document.querySelector('[role="dialog"]');
        if (!dialog) return null;
        const fromVal = dialog.querySelector('select:nth-of-type(1)')?.value;
        const toVal = dialog.querySelectorAll('select')[1]?.value;
        const budgetVal = dialog.querySelector('input[type="number"]')?.value;
        const travellersText = dialog.innerText.match(/Travellers \((\d+) Total\)/)?.[1];
        return { fromVal, toVal, budgetVal, travellersText };
      });

      const passed = formValues && formValues.toVal === 'Mumbai' && formValues.travellersText === '5' && formValues.budgetVal === '60000';
      console.log('Test 3 Form Values in Confirmation Sheet:', formValues);
      console.log('Travellers extracted as 5:', formValues?.travellersText === '5');
      console.log('Budget extracted as 60000:', formValues?.budgetVal === '60000');
      console.log('Test 3 Result:', passed ? 'PASS' : 'FAIL');
      results.push({ test: '3. Voice Mumbai trip (5 travellers, 60k)', passed, formValues });
      await page.close();
    }

    // ---------------------------------------------------------------
    // TEST 4: Edit transcript before submitting
    // ---------------------------------------------------------------
    console.log('\n--- TEST 4: Edit transcript before submitting ---');
    {
      const page = await browser.newPage();
      await page.setViewport({ width: 1280, height: 800 });

      await page.goto('http://localhost:3000/app?demo=true', { waitUntil: 'networkidle2' });
      await page.waitForSelector('textarea', { timeout: 10000 });

      // Open voice panel
      await page.evaluate(() => {
        const voiceTrigger = Array.from(document.querySelectorAll('button')).find(b => b.innerText.toLowerCase().includes('voice'));
        if (voiceTrigger) voiceTrigger.click();
      });
      await wait(500);

      const voiceModalOpen = await page.evaluate(() => !!document.querySelector('[role="dialog"] textarea'));
      if (voiceModalOpen) {
        // Initial transcript: 2 members 30k
        await page.evaluate(() => {
          const ta = document.querySelector('[role="dialog"] textarea');
          const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
          setter.call(ta, 'Planet trip to Mumbai for 3 days for 2 members around 30k');
          ta.dispatchEvent(new Event('input', { bubbles: true }));
        });
        await wait(300);

        // User edits transcript to 5 members 60k
        await page.evaluate(() => {
          const ta = document.querySelector('[role="dialog"] textarea');
          const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
          setter.call(ta, 'Plan a trip to Mumbai for 3 days for five members around 60k');
          ta.dispatchEvent(new Event('input', { bubbles: true }));
        });
        await wait(300);

        await page.evaluate(() => {
          const btns = Array.from(document.querySelectorAll('[role="dialog"] button'));
          const planBtn = btns.find(b => b.innerText.includes('Plan') || b.innerText.includes('Journey'));
          if (planBtn) planBtn.click();
        });
      } else {
        await page.evaluate(() => {
          const ta = document.querySelector('textarea');
          const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
          setter.call(ta, 'Plan a trip to Mumbai for 3 days for five members around 60k');
          ta.dispatchEvent(new Event('input', { bubbles: true }));
          document.querySelector('form button[type="submit"]').click();
        });
      }

      await wait(1000);

      const formValues = await page.evaluate(() => {
        const dialog = document.querySelector('[role="dialog"]');
        if (!dialog) return null;
        const budgetVal = dialog.querySelector('input[type="number"]')?.value;
        const travellersText = dialog.innerText.match(/Travellers \((\d+) Total\)/)?.[1];
        return { budgetVal, travellersText };
      });

      const passed = formValues && formValues.travellersText === '5' && formValues.budgetVal === '60000';
      console.log('Test 4 Form Values after editing transcript:', formValues);
      console.log('Test 4 Result:', passed ? 'PASS' : 'FAIL');
      results.push({ test: '4. Edit transcript before submitting', passed, formValues });
      await page.close();
    }

    // ---------------------------------------------------------------
    // TEST 5: Missing budget; ask for budget without losing details
    // ---------------------------------------------------------------
    console.log('\n--- TEST 5: Missing budget; ask for budget without losing details ---');
    {
      const page = await browser.newPage();
      await page.setViewport({ width: 1280, height: 800 });

      await page.goto('http://localhost:3000/app?demo=true', { waitUntil: 'networkidle2' });
      await page.waitForSelector('textarea', { timeout: 10000 });

      await page.evaluate(() => {
        const ta = document.querySelector('textarea');
        const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
        setter.call(ta, 'Plan a trip to Mumbai for 3 days for five members');
        ta.dispatchEvent(new Event('input', { bubbles: true }));
        document.querySelector('form button[type="submit"]').click();
      });

      await wait(1000);

      const modalState = await page.evaluate(() => {
        const dialog = document.querySelector('[role="dialog"]');
        if (!dialog) return null;
        const toVal = dialog.querySelectorAll('select')[1]?.value;
        const travellersText = dialog.innerText.match(/Travellers \((\d+) Total\)/)?.[1];
        const budgetVal = dialog.querySelector('input[type="number"]')?.value;
        const clarificationText = dialog.innerText;
        const isSubmitDisabled = dialog.querySelector('button[type="submit"]')?.disabled;
        return { toVal, travellersText, budgetVal, clarificationText, isSubmitDisabled };
      });

      const asksForBudget = modalState?.clarificationText?.includes('What is your total budget in rupees (₹)?');
      const preservedDetails = modalState?.toVal === 'Mumbai' && modalState?.travellersText === '5' && modalState?.budgetVal === '';
      const passed = Boolean(asksForBudget && preservedDetails);

      console.log('Test 5 Modal State:', {
        destination: modalState?.toVal,
        travellers: modalState?.travellersText,
        budget: modalState?.budgetVal,
        asksForBudget
      });
      console.log('Test 5 Result:', passed ? 'PASS' : 'FAIL');
      results.push({ test: '5. Missing budget clarification', passed, modalState });
      await page.close();
    }

    // ---------------------------------------------------------------
    // TEST 6: Backend failure; preserve draft and show actual error
    // ---------------------------------------------------------------
    console.log('\n--- TEST 6: Backend failure; preserve draft and show actual error ---');
    {
      const page = await browser.newPage();
      await page.setViewport({ width: 1280, height: 800 });

      // Intercept both MCP and direct backend calls to simulate 500 failure
      await page.setRequestInterception(true);
      page.on('request', interceptedReq => {
        const url = interceptedReq.url();
        if (url.includes(':8001/mcp') && interceptedReq.method() === 'POST') {
          try {
            const body = JSON.parse(interceptedReq.postData() || '{}');
            if (body.method === 'tools/call' && body.params?.name === 'plan_trip') {
              interceptedReq.respond({
                status: 200,
                headers: {
                  'Access-Control-Allow-Origin': '*',
                  'Access-Control-Allow-Headers': '*',
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                  jsonrpc: '2.0',
                  id: body.id,
                  result: {
                    content: [
                      {
                        type: 'text',
                        text: JSON.stringify({
                          status: 'error',
                          error: 'Backend request failed with status 500: Database cluster connection timeout'
                        })
                      }
                    ]
                  }
                })
              });
              return;
            }
          } catch {}
          interceptedReq.continue();
        } else if (url.includes('/api/trips/plan') && interceptedReq.method() === 'POST') {
          interceptedReq.respond({
            status: 500,
            headers: {
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Headers': '*',
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ detail: 'Backend request failed with status 500: Database cluster connection timeout' })
          });
          return;
        } else {
          interceptedReq.continue();
        }
      });

      await page.goto('http://localhost:3000/app?demo=true', { waitUntil: 'networkidle2' });
      await page.waitForSelector('textarea', { timeout: 10000 });

      await page.evaluate(() => {
        const ta = document.querySelector('textarea');
        const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
        setter.call(ta, 'Plan a trip to Mumbai for 3 days for five members with budget ₹60,000');
        ta.dispatchEvent(new Event('input', { bubbles: true }));
        document.querySelector('form button[type="submit"]').click();
      });

      await wait(1000);

      // Submit modal
      await page.evaluate(() => {
        const dialog = document.querySelector('[role="dialog"]');
        dialog.querySelector('button[type="submit"]').click();
      });

      await wait(1500);

      // Check modal is STILL open, error is displayed, and draft values are preserved
      const failureState = await page.evaluate(() => {
        const dialog = document.querySelector('[role="dialog"]');
        if (!dialog) return null;
        const errorText = dialog.innerText;
        const toVal = dialog.querySelectorAll('select')[1]?.value;
        const travellersText = dialog.innerText.match(/Travellers \((\d+) Total\)/)?.[1];
        const budgetVal = dialog.querySelector('input[type="number"]')?.value;
        return { errorText, toVal, travellersText, budgetVal };
      });

      const showsError = failureState?.errorText?.includes('500') || failureState?.errorText?.includes('Database cluster');
      const preservedDraft = failureState?.toVal === 'Mumbai' && failureState?.travellersText === '5' && failureState?.budgetVal === '60000';
      const passed = Boolean(showsError && preservedDraft);

      console.log('Test 6 Failure State Captured:', {
        showsError,
        preservedDraft,
        destination: failureState?.toVal,
        travellers: failureState?.travellersText,
        budget: failureState?.budgetVal
      });
      console.log('Test 6 Result:', passed ? 'PASS' : 'FAIL');
      results.push({ test: '6. Backend failure error display & draft retention', passed, failureState });
      await page.close();
    }

    // ---------------------------------------------------------------
    // TEST 7: Single planning request sent and no modal reopens after success
    // ---------------------------------------------------------------
    console.log('\n--- TEST 7: Single planning request sent and no modal reopens after success ---');
    {
      const page = await browser.newPage();
      await page.setViewport({ width: 1280, height: 800 });

      let planRequestCount = 0;
      page.on('request', req => {
        if (req.url().includes(':8001/mcp') && req.method() === 'POST') {
          try {
            const body = JSON.parse(req.postData() || '{}');
            if (body.method === 'tools/call' && body.params?.name === 'plan_trip') {
              planRequestCount++;
            }
          } catch {}
        } else if (req.url().includes('/api/trips/plan') && req.method() === 'POST') {
          planRequestCount++;
        }
      });

      await page.goto('http://localhost:3000/app?demo=true', { waitUntil: 'networkidle2' });
      await page.waitForSelector('textarea', { timeout: 10000 });

      await page.evaluate(() => {
        const ta = document.querySelector('textarea');
        const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
        setter.call(ta, 'Plan a trip to Mumbai for 3 days for five members with budget ₹60,000');
        ta.dispatchEvent(new Event('input', { bubbles: true }));
        document.querySelector('form button[type="submit"]').click();
      });

      await wait(1000);

      // Rapidly double-click submit button to verify single submission guard
      await page.evaluate(() => {
        const dialog = document.querySelector('[role="dialog"]');
        const submitBtn = dialog.querySelector('button[type="submit"]');
        submitBtn.click();
        submitBtn.click();
      });

      await wait(3000);

      const finalUrl = page.url();
      const modalOpen = await page.evaluate(() => !!document.querySelector('[role="dialog"]'));

      const passed = planRequestCount === 1 && !modalOpen && finalUrl.includes('/app/trip/');
      console.log('Test 7 Plan Requests Count:', planRequestCount);
      console.log('Test 7 Modal Open after success:', modalOpen);
      console.log('Test 7 Final URL:', finalUrl);
      console.log('Test 7 Result:', passed ? 'PASS' : 'FAIL');
      results.push({ test: '7. Single request and no modal reopening', passed, planRequestCount, modalOpen, finalUrl });
      await page.close();
    }

  } finally {
    await browser.close();
  }

  console.log('\n====================================================');
  console.log('E2E TEST SUMMARY:');
  console.log('====================================================');
  results.forEach(r => {
    console.log(`${r.passed ? '✓ PASS' : '✗ FAIL'}: ${r.test}`);
  });
  const allPassed = results.every(r => r.passed);
  console.log(`\nOVERALL: ${allPassed ? 'ALL 7 TESTS PASSED' : 'SOME TESTS FAILED'}`);
  return allPassed;
}

runRealBrowserE2ETests().then(success => {
  process.exit(success ? 0 : 1);
}).catch(err => {
  console.error('Test execution failed:', err);
  process.exit(1);
});
