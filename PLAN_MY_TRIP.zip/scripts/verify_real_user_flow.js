// scripts/verify_real_user_flow.js
import puppeteer from 'puppeteer-core';
import { existsSync } from 'fs';

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const browserExecutable = existsSync(EDGE_PATH) ? EDGE_PATH : (existsSync(CHROME_PATH) ? CHROME_PATH : null);

function assert(condition, message, extra) {
  if (!condition) {
    console.error(`[FAIL] ${message}${extra ? ' -> ' + JSON.stringify(extra) : ''}`);
    throw new Error(`Assertion failed: ${message}`);
  }
  console.log(`[PASS] ${message}`);
}

async function run() {
  console.log('=== VERIFYING REAL DASHBOARD -> SELECTION -> REVIEW -> APPROVAL FLOW ===\n');
  if (!browserExecutable) {
    console.error('No browser executable found!');
    process.exit(1);
  }

  const browser = await puppeteer.launch({
    executablePath: browserExecutable,
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 850 });

  page.on('console', msg => {
    const text = msg.text();
    if (text.includes('error') || text.includes('warn') || text.includes('[vite]')) {
      console.log(`BROWSER CONSOLE: ${msg.type()} ${text.slice(0, 160)}`);
    }
  });

  try {
    // -------------------------------------------------------------------------
    // TEST 1: Typed intake with complete details navigates directly to Options Flow
    // -------------------------------------------------------------------------
    console.log('--- TEST 1: Typed intake directly enters Options Flow (No repeated modal) ---');
    await page.goto('http://localhost:3000/app?demo=true', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await new Promise(r => setTimeout(r, 1500));

    const promptInput = await page.$('textarea[placeholder*="Mumbai"]');
    assert(Boolean(promptInput), '1. Dashboard rendered with trip prompt textarea');

    await promptInput.type('Plan a trip to Mumbai for 3 days, 5 members, budget ₹60,000');
    const planBtn = await page.$('button[type="submit"]');
    await planBtn.click();
    await new Promise(r => setTimeout(r, 2000));

    // First screen must be /app/plan/... displaying selectable transport options
    const planUrl = page.url();
    assert(planUrl.includes('/app/plan'), '2. First screen navigates to options flow (/app/plan/...)', planUrl);

    const hasNoModal = await page.evaluate(() => !document.querySelector('form.p-6.space-y-5'));
    assert(hasNoModal, '3. No generic confirmation modal is forced when details are complete');

    const step1Title = await page.evaluate(() => document.body.innerText);
    assert(
      step1Title.includes('Step 1') && (step1Title.includes('Choose Transit') || step1Title.includes('Transit to Mumbai')),
      '4. Step 1: Displays selectable transit options to Mumbai'
    );

    // -------------------------------------------------------------------------
    // TEST 2: Select a transport option & verify authoritative state update
    // -------------------------------------------------------------------------
    console.log('\n--- TEST 2: User selects transport option ---');
    const hasTransportOptions = await page.evaluate(() => {
      const text = document.body.innerText;
      return (text.includes('Vande Bharat') || text.includes('Tejas') || text.includes('InterCity') || text.includes('Sleeper')) &&
             text.includes('Select');
    });
    assert(hasTransportOptions, '5. Selectable transport options (trains, flights, buses) are rendered');

    // Click "Select" on the first transport option
    const selectedTransportTitle = await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const selectBtn = buttons.find(b => b.innerText.trim() === 'Select');
      if (selectBtn) {
        selectBtn.click();
        return true;
      }
      return false;
    });
    assert(selectedTransportTitle, '6. User successfully clicked "Select" on transport option');
    await new Promise(r => setTimeout(r, 1000));

    const isTransportSelected = await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      return buttons.some(b => b.innerText.includes('Selected'));
    });
    assert(isTransportSelected, '7. Transport card indicates "Selected" state');

    // -------------------------------------------------------------------------
    // TEST 3: Advance to Step 2 (Stay), select hotel, verify state persistence
    // -------------------------------------------------------------------------
    console.log('\n--- TEST 3: User advances to Stay and selects accommodation ---');
    const nextToStayClicked = await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const nextBtn = buttons.find(b => b.innerText.includes('Next Step') || b.innerText.includes('Stay'));
      if (nextBtn) {
        nextBtn.click();
        return true;
      }
      return false;
    });
    assert(nextToStayClicked, '8. Clicked Next Step to proceed to Stay selection');
    await new Promise(r => setTimeout(r, 1200));

    const step2Title = await page.evaluate(() => document.body.innerText);
    assert(
      step2Title.includes('Step 2') && (step2Title.includes('Where to Stay') || step2Title.includes('Stay in Mumbai')),
      '9. Step 2: Displays selectable accommodations in Mumbai'
    );

    // Select a hotel / stay
    const selectedStayClicked = await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const selectStayBtn = buttons.find(b => b.innerText.includes('Select Stay') || b.innerText.trim() === 'Select');
      if (selectStayBtn) {
        selectStayBtn.click();
        return true;
      }
      return false;
    });
    assert(selectedStayClicked, '10. User successfully clicked "Select Stay" on hotel option');
    await new Promise(r => setTimeout(r, 1000));

    // -------------------------------------------------------------------------
    // TEST 4: Advance to Review & Verify NO booking executed before approval
    // -------------------------------------------------------------------------
    console.log('\n--- TEST 4: Review page shows complete price, terms & zero auto-bookings ---');
    const reviewBtnClicked = await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const revBtn = buttons.find(b => b.innerText.includes('Review & Pay') || b.innerText.includes('Review'));
      if (revBtn) {
        revBtn.click();
        return true;
      }
      return false;
    });
    assert(reviewBtnClicked, '11. Clicked Review & Pay to enter Review step');
    await new Promise(r => setTimeout(r, 1500));

    const reviewUrl = page.url();
    assert(reviewUrl.includes('/review'), '12. Reached checkout review screen (/app/plan/.../review)', reviewUrl);

    const reviewBodyText = await page.evaluate(() => document.body.innerText);
    assert(
      reviewBodyText.includes('Itemised Journey Summary') || reviewBodyText.includes('Getting There'),
      '13. Displays itemised journey summary with selected services'
    );
    assert(
      reviewBodyText.includes('Refundable') || reviewBodyText.includes('cancellation'),
      '14. Displays clear cancellation and operator terms'
    );

    // Check localStorage / trip state: status must STILL be 'draft'
    const tripStatusBeforeApproval = await page.evaluate(() => {
      const draft = localStorage.getItem('pmt_trip_draft_demo-traveler-001') || localStorage.getItem('pmt_trip_draft_guest-user');
      if (draft) {
        try {
          const parsed = JSON.parse(draft);
          return parsed.status;
        } catch {}
      }
      return null;
    });
    assert(
      tripStatusBeforeApproval === 'draft' || tripStatusBeforeApproval === null,
      '15. Authoritative trip status is "draft" — NO booking was placed before approval',
      tripStatusBeforeApproval
    );

    // -------------------------------------------------------------------------
    // TEST 5: Proceed to Payment & Explicit Final Approval
    // -------------------------------------------------------------------------
    console.log('\n--- TEST 5: Proceed to explicit approval step ---');
    // From Review -> Travellers
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const cont = buttons.find(b => b.innerText.toLowerCase().includes('passenger details'));
      if (cont) cont.click();
    });
    await new Promise(r => setTimeout(r, 1200));

    // From Travellers -> Pay
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const payStep = buttons.find(b => b.innerText.toLowerCase().includes('payment'));
      if (payStep) payStep.click();
    });
    await new Promise(r => setTimeout(r, 1200));

    const payUrl = page.url();
    assert(payUrl.includes('/pay'), '16. Reached payment and approval screen (/app/plan/.../pay)', payUrl);

    const payBodyText = await page.evaluate(() => document.body.innerText);
    assert(
      payBodyText.includes('Pay') && (payBodyText.includes('Confirm') || payBodyText.includes('Simulation')),
      '17. Explicit confirmation button is displayed ("Pay ... & Confirm Booking (Simulation)")'
    );

    // Click explicit confirmation
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const confirmBtn = buttons.find(b => b.innerText.includes('Pay') && b.innerText.includes('Simulation'));
      if (confirmBtn) confirmBtn.click();
    });
    await page.waitForFunction(() => window.location.pathname.includes('/done'), { timeout: 10000 });
    await new Promise(r => setTimeout(r, 1000));

    const doneBodyText = await page.evaluate(() => document.body.innerText);
    assert(
      doneBodyText.includes('Trip Booked') && doneBodyText.includes('Simulation'),
      '18. Booking executes ONLY after explicit final confirmation and discloses simulation'
    );
    assert(
      doneBodyText.includes('Booking Reference') || doneBodyText.includes('SIM-PMT'),
      '19. Displays authoritative booking reference and provider vouchers'
    );

    // -------------------------------------------------------------------------
    // TEST 6: Ambiguous intake opens clarification modal & resolves without loop
    // -------------------------------------------------------------------------
    console.log('\n--- TEST 6: Ambiguous intake clarification flow ---');
    await page.goto('http://localhost:3000/app?demo=true', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await new Promise(r => setTimeout(r, 1500));

    const ambiguousInput = await page.$('textarea[placeholder*="Mumbai"]');
    await ambiguousInput.type('Plan a trip to Mumbai for 3 days, 5 to 6 members, budget ₹60,000');
    const submitAmbiguous = await page.$('button[type="submit"]');
    await submitAmbiguous.click();
    await new Promise(r => setTimeout(r, 1000));

    const sheetOpen = await page.evaluate(() => Boolean(document.querySelector('form.p-6.space-y-5')));
    assert(sheetOpen, '20. Clarification modal opens when traveller count is ambiguous ("5 to 6")');

    // Click "Plan for 5 travellers"
    const resolved5 = await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const b = buttons.find(el => el.innerText.includes('Plan for 5'));
      if (b) { b.click(); return true; }
      return false;
    });
    assert(resolved5, '21. Resolved clarification by selecting 5 travellers');
    await new Promise(r => setTimeout(r, 800));

    // Click "Plan trip"
    await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const b = buttons.find(el => el.innerText.includes('Plan trip'));
      if (b) b.click();
    });
    await new Promise(r => setTimeout(r, 2000));

    const postClarifyUrl = page.url();
    assert(postClarifyUrl.includes('/app/plan/'), '22. Navigates cleanly to options flow after clarification', postClarifyUrl);

    const modalIsClosed = await page.evaluate(() => !document.querySelector('form.p-6.space-y-5'));
    assert(modalIsClosed, '23. Clarification modal closed cleanly without looping');

    console.log('\n======================================================');
    console.log('ALL REGRESSION TESTS PASSED IN REAL BROWSER (23/23)');
    console.log('======================================================\n');
  } catch (err) {
    console.error('\nTEST SUITE FAILED:', err.message);
    process.exit(1);
  } finally {
    await browser.close();
  }
}

run();
