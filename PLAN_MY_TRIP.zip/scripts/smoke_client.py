"""Smoke test client to verify the live Alexa+ MCP Server over Streamable HTTP."""

import asyncio
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamable_http_client
import httpx
import uvicorn
from alexa_mcp.server import app as mcp_app
from mock_backend.app import app as mock_app
from alexa_mcp.backend_client import BackendClient, set_backend_client

MCP_URL = "http://127.0.0.1:8001/mcp"


async def main():
    print(f"Connecting to MCP Server at {MCP_URL}...")
    server_task = None

    # Check if server is already running on 8001
    already_running = False
    try:
        async with httpx.AsyncClient(timeout=0.3) as client:
            r = await client.get("http://127.0.0.1:8001/health")
            if r.status_code == 200:
                already_running = True
    except Exception:
        already_running = False

    if not already_running:
        print("Starting in-process MCP server on port 8001...")
        transport = httpx.ASGITransport(app=mock_app)
        set_backend_client(BackendClient(base_url="http://testbackend", transport=transport))
        config = uvicorn.Config(mcp_app, host="127.0.0.1", port=8001, log_level="warning")
        server = uvicorn.Server(config)
        server_task = asyncio.create_task(server.serve())
        await asyncio.sleep(0.5)

    try:
        async with streamable_http_client(MCP_URL) as (read, write):
            async with ClientSession(read, write) as session:
                init = await session.initialize()
                print("✓ Protocol version:", init.protocol_version)
                print("✓ Server name:", init.server_info.name)

                tools = await session.list_tools()
                print("✓ Registered Tools:", [t.name for t in tools.tools])

                print("\nCalling 'get_saved_trip' for 'trip_del_jai_001'...")
                result = await session.call_tool("get_saved_trip", {"trip_id": "trip_del_jai_001"})
                print("✓ Tool Response:\n", result.content[0].text[:200])
    except Exception as e:
        print(f"✗ Connection failed: {e}")
    finally:
        if server_task is not None:
            server.should_exit = True
            await server_task


if __name__ == "__main__":
    asyncio.run(main())
