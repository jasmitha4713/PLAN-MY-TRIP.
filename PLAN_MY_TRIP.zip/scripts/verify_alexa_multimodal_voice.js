import puppeteer from 'puppeteer-core';
import { existsSync } from 'fs';

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const browserExecutable = existsSync(EDGE_PATH) ? EDGE_PATH : (existsSync(CHROME_PATH) ? CHROME_PATH : null);

if (!browserExecutable) {
  console.error('No suitable browser found for automation.');
  process.exit(1);
}

async function runMultimodalVoiceVerification() {
  console.log('================================================================');
  console.log('PLAN MY TRIP — Alexa+ Multimodal Voice & Reasoning Verification');
  console.log('================================================================');

  const browser = await puppeteer.launch({
    executablePath: browserExecutable,
    headless: true,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--use-fake-ui-for-media-stream', // Auto-approves microphone permission for testing
      '--use-fake-device-for-media-stream'
    ]
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 900 });

  const results = {};

  try {
    // -------------------------------------------------------------------------
    // TEST SCENARIO 1 & 2: Greeting, Voice Controls & Audio Replay
    // -------------------------------------------------------------------------
    console.log('\n--- Scenario 1 & 2: Greeting, Voice Controls & Audio Replay ---');
    await page.goto('http://localhost:3000/app/trip/PMT-0142?demo=true', { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('button', { timeout: 8000 });

    // Switch to Companion (Alexa) Tab
    const tabButtons = await page.$$('button');
    for (const btn of tabButtons) {
      const text = await (await btn.getProperty('textContent')).jsonValue();
      if (text.includes('Companion')) {
        await btn.click();
        break;
      }
    }
    await new Promise(r => setTimeout(r, 800));

    // Verify Microphone Button exists
    const micButton = await page.$('button[title*="speak"], button[aria-label*="voice"]');
    const hasMicButton = Boolean(micButton);
    console.log('Microphone button present in companion input bar:', hasMicButton);

    // Verify Voice Output Toggle button exists
    const voiceToggleBtn = await page.$('button[title*="Alexa Voice Output"]');
    const hasVoiceToggle = Boolean(voiceToggleBtn);
    console.log('Voice Output audio toggle button present:', hasVoiceToggle);

    // Send "hi" and verify short greeting
    const inputSelector = 'input[placeholder*="companion"], input[placeholder*="Waiting"], input[placeholder*="Listening"]';
    await page.waitForSelector(inputSelector);
    await page.click(inputSelector);
    await page.keyboard.type('hi');
    await page.keyboard.press('Enter');

    await new Promise(r => setTimeout(r, 1200));

    let bodyText = await page.evaluate(() => document.body.innerText);
    const greetingPass = bodyText.includes('Hello! How can I') && !bodyText.includes('tools/call') && !bodyText.includes('assess_disruption()');
    console.log('"hi" received short conversational greeting without tool dump:', greetingPass);

    // Verify Replay Button exists on Alexa reply
    const replayButtons = await page.$$('button[title*="Replay"]');
    const hasReplayButton = replayButtons.length > 0;
    console.log('Audio replay button present on companion messages:', hasReplayButton);

    results['1_greeting'] = greetingPass;
    results['2_voice_loop'] = hasMicButton && hasVoiceToggle && hasReplayButton;

    // -------------------------------------------------------------------------
    // TEST SCENARIO 3: Multi-Turn Trip Planning with Slot Preservation & Correction
    // Turn 1: "Plan a three-day trip to Mumbai for six people" -> asks for missing budget
    // Turn 2: "Keep it under sixty thousand" -> plans trip & updates draft
    // Turn 3: "Actually, make it five people" -> updates travellers to 5, retains Mumbai & 60k
    // -------------------------------------------------------------------------
    console.log('\n--- Scenario 3: Multi-Turn Trip Planning with Correction ---');

    // Turn 1: Plan without budget
    await page.click(inputSelector);
    await page.keyboard.down('Control');
    await page.keyboard.press('A');
    await page.keyboard.up('Control');
    await page.keyboard.press('Backspace');
    await page.keyboard.type('Plan a three-day trip to Mumbai for six people');
    await page.keyboard.press('Enter');

    await new Promise(r => setTimeout(r, 1500));
    bodyText = await page.evaluate(() => document.body.innerText);
    const asksMissingBudget = bodyText.includes('Mumbai for 6') && bodyText.includes('What total budget');
    console.log('Turn 1: Assistant asks only for missing budget:', asksMissingBudget);

    // Turn 2: "Keep it under sixty thousand"
    await page.click(inputSelector);
    await page.keyboard.type('Keep it under sixty thousand');
    await page.keyboard.press('Enter');

    await new Promise(r => setTimeout(r, 2200));
    bodyText = await page.evaluate(() => document.body.innerText);
    const plansWithBudget = bodyText.includes('60,000') && bodyText.includes('Mumbai');
    console.log('Turn 2: Assistant plans trip with ₹60,000 budget & Mumbai:', plansWithBudget);

    // Turn 3: Correction: "Actually, make it five people"
    await page.click(inputSelector);
    await page.keyboard.type('Actually, make it five people');
    await page.keyboard.press('Enter');

    await new Promise(r => setTimeout(r, 2000));
    bodyText = await page.evaluate(() => document.body.innerText);
    const correctionPass = bodyText.includes('traveller count to 5') && bodyText.includes('Mumbai') && bodyText.includes('60,000');
    console.log('Turn 3: Correction preserves Mumbai & ₹60,000 while updating pax to 5:', correctionPass);

    results['3_multiturn_planning'] = asksMissingBudget && plansWithBudget && correctionPass;

    // -------------------------------------------------------------------------
    // TEST SCENARIO 4: Adding an Activity to the Correct Itinerary
    // Turn: "Add a local food trail" -> adds Mumbai food trail to Mumbai trip
    // -------------------------------------------------------------------------
    console.log('\n--- Scenario 4: Adding Experience to Active Itinerary ---');
    await page.click(inputSelector);
    await page.keyboard.type('Add a local food trail');
    await page.keyboard.press('Enter');

    await new Promise(r => setTimeout(r, 1800));
    bodyText = await page.evaluate(() => document.body.innerText);
    const activityAdded = bodyText.includes('Street Food Trail') || bodyText.includes('Culinary Walk');
    console.log('Assistant added localized food trail to itinerary:', activityAdded);

    results['4_add_activity'] = activityAdded;

    // -------------------------------------------------------------------------
    // TEST SCENARIO 5: Active Trip Budget Query
    // -------------------------------------------------------------------------
    console.log('\n--- Scenario 5: Budget Inquiry ---');
    await page.click(inputSelector);
    await page.keyboard.type('What is my current trip budget?');
    await page.keyboard.press('Enter');

    await new Promise(r => setTimeout(r, 1800));
    bodyText = await page.evaluate(() => document.body.innerText);
    const budgetPass = bodyText.includes('budget ceiling') || bodyText.includes('Budget Snapshot') || bodyText.includes('Allocated');
    console.log('Budget inquiry returned verified ceiling & breakdown:', budgetPass);

    results['5_budget_query'] = budgetPass;

    // -------------------------------------------------------------------------
    // TEST SCENARIO 6: Disruption Assessment & Recovery Proposal
    // -------------------------------------------------------------------------
    console.log('\n--- Scenario 6: Disruption Assessment & Recovery Proposal ---');
    await page.click(inputSelector);
    await page.keyboard.type("I'm in traffic and my bus leaves in 10 minutes. What should I do?");
    await page.keyboard.press('Enter');

    await new Promise(r => setTimeout(r, 2200));
    bodyText = await page.evaluate(() => document.body.innerText);
    const assessPass = bodyText.includes('assessed your travel disruption') || bodyText.includes('Recovery Options') || bodyText.includes('Disruption');
    console.log('Disruption assessed with recovery alternatives:', assessPass);

    // Staging Recovery Proposal
    await page.click(inputSelector);
    await page.keyboard.type("Prepare a recovery action for my disrupted journey, but let me review it before applying anything.");
    await page.keyboard.press('Enter');

    await new Promise(r => setTimeout(r, 2500));
    bodyText = await page.evaluate(() => document.body.innerText);
    const stagePass = bodyText.includes('Action Requires Explicit Approval') || bodyText.includes('Approve & Send') || bodyText.includes('Don\'t send');
    console.log('Action staged with approval card:', stagePass);

    results['6_disruption_recovery'] = assessPass && stagePass;

    // -------------------------------------------------------------------------
    // TEST SCENARIO 7: Rejection and Approval Safety Gates
    // -------------------------------------------------------------------------
    console.log('\n--- Scenario 7: Rejection & Approval Safety Gates ---');
    const rejectBtn = await page.$('button ::-p-text(Don\'t send)');
    if (rejectBtn) {
      await rejectBtn.click();
      await new Promise(r => setTimeout(r, 1800));
      bodyText = await page.evaluate(() => document.body.innerText);
      const rejectSuccess = bodyText.includes('Cancelled') || bodyText.includes('rejected') || bodyText.includes('Unexecuted');
      console.log('Rejection marked action unexecuted and cancelled:', rejectSuccess);
      results['7_safety_gates'] = rejectSuccess;
    } else {
      console.warn('Reject button not found in DOM');
      results['7_safety_gates'] = false;
    }

    // -------------------------------------------------------------------------
    // TEST SCENARIO 7B: Bus Cancellation and Rebooking ("I want to cancel my bus...")
    // -------------------------------------------------------------------------
    console.log('\n--- Scenario 7B: Bus Cancellation & Next-Bus Rebooking Flow ---');
    await page.goto('http://localhost:3000/app/trip/trip_del_jai_001?demo=true', { waitUntil: 'domcontentloaded' });
    await new Promise(r => setTimeout(r, 600));

    const companionTabJai = await page.waitForSelector('button ::-p-text(Companion (Alexa))');
    await companionTabJai.click();
    await new Promise(r => setTimeout(r, 800));

    const jaiInput = 'input[placeholder*="Speak or type"]';
    await page.waitForSelector(jaiInput);
    await page.click(jaiInput);
    await page.keyboard.type('I want to cancel my bus. I want to go in the next bus; I have some work.');
    await page.keyboard.press('Enter');

    await new Promise(r => setTimeout(r, 2500));
    bodyText = await page.evaluate(() => document.body.innerText);

    const recognizesCancel = bodyText.includes('cancel your') && (bodyText.includes('next available bus') || bodyText.includes('next bus'));
    const checksBooking = bodyText.includes('RSRTC-DEL-99231') || bodyText.includes('RSRTC Express');
    const explainsConditions = bodyText.includes('Cancellation Conditions') || bodyText.includes('85% refund');
    const honestDisclosure = bodyText.includes('Honest Disclosure') || bodyText.includes('simulated');
    const stagesApproval = bodyText.includes('Action Requires Explicit Approval') || bodyText.includes('Approve & Send');

    console.log('Recognizes intent to change bus:', recognizesCancel);
    console.log('Checks active bus booking & PNR:', checksBooking);
    console.log('Explains verified cancellation conditions:', explainsConditions);
    console.log('Honestly discloses next bus simulation:', honestDisclosure);
    console.log('Stages recovery action with approval card:', stagesApproval);

    results['7b_bus_cancellation'] = recognizesCancel && checksBooking && explainsConditions && honestDisclosure && stagesApproval;

    // -------------------------------------------------------------------------
    // TEST SCENARIO 8: Error Handling (Unknown Trip ID & Fallbacks)
    // -------------------------------------------------------------------------
    console.log('\n--- Scenario 8: Error Handling & Unknown Trip ID ---');
    await page.goto('http://localhost:3000/app/trip/trip_nonexistent_999?demo=true', { waitUntil: 'domcontentloaded' });
    await new Promise(r => setTimeout(r, 600));

    const compTab = await page.waitForSelector('button ::-p-text(Companion (Alexa))');
    await compTab.click();
    await new Promise(r => setTimeout(r, 600));

    bodyText = await page.evaluate(() => document.body.innerText);
    const bannerShown = bodyText.includes('is not registered in the backend trip repository') || bodyText.includes('Unregistered Trip ID');
    console.log('Unknown trip renders explicit unregistered warning banner:', bannerShown);

    results['8_error_handling'] = bannerShown;

  } catch (err) {
    console.error('Browser automation error:', err);
  } finally {
    await browser.close();
  }

  console.log('\n========================================');
  console.log('E2E BROWSER AUTOMATION TEST SUMMARY');
  console.log('========================================');
  let allPass = true;
  for (const [key, val] of Object.entries(results)) {
    console.log(`${val ? '✓ PASS' : '✗ FAIL'} : ${key}`);
    if (!val) allPass = false;
  }
  console.log('========================================');
  if (allPass) {
    console.log('ALL 8 REAL BROWSER SCENARIOS PASSED SUCCESSFULLY!');
  } else {
    process.exit(1);
  }
}

runMultimodalVoiceVerification();
