"""Verify SQLite Persistence across full backend server restart.

Demonstrates that newly created trips, staged actions, and budget breakdowns
survive process termination and reload cleanly from disk.
"""

import sys
import time
import subprocess
import httpx

BACKEND_URL = "http://localhost:8000"

def log(msg: str):
    print(f"[PERSISTENCE-TEST] {msg}", flush=True)

def main():
    log("Step 1: Planning a brand new trip through FastAPI...")
    plan_payload = {
        "origin": "Bengaluru",
        "destination": "Goa",
        "budget_inr": 25000.0,
        "start_date": "2026-12-15",
        "end_date": "2026-12-18",
        "travelers_count": 2,
        "preferences": ["resort", "scenic"]
    }
    with httpx.Client(timeout=10.0) as client:
        r = client.post(f"{BACKEND_URL}/api/trips/plan", json=plan_payload)
        assert r.status_code in [200, 201], f"Plan trip failed: {r.text}"
        trip_data = r.json()
        trip_id = trip_data["trip_id"]
        log(f"Created new trip in SQLite: {trip_id} (Bengaluru -> Goa, Budget: INR 25,000)")

        # Verify initial budget breakdown
        b_res = client.get(f"{BACKEND_URL}/api/trips/{trip_id}/budget")
        assert b_res.status_code == 200
        assert b_res.json()["total_budget_inr"] == 25000.0
        log(f"Initial budget calculated: INR {b_res.json()['total_budget_inr']}")

        # Stage a recovery action
        action_payload = {
            "trip_id": trip_id,
            "action_type": "notify_hotel_late_checkin",
            "selected_option_id": "opt_reschedule_checkin",
            "estimated_cost_inr": 0.0
        }
        act_res = client.post(f"{BACKEND_URL}/api/actions/prepare", json=action_payload)
        assert act_res.status_code == 201
        action_id = act_res.json()["action_id"]
        log(f"Staged recovery action in SQLite: {action_id} (status: pending_approval)")

    log("Step 2: Simulating full backend crash / kill by terminating port 8000 process...")
    # Find PID listening on 8000 and kill it
    find_cmd = "Get-NetTCPConnection -LocalPort 8000 -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess"
    proc = subprocess.run(["powershell", "-Command", find_cmd], capture_output=True, text=True)
    pids = [p.strip() for p in proc.stdout.split() if p.strip()]
    if pids:
        for pid in set(pids):
            log(f"Terminating backend process PID {pid}...")
            subprocess.run(["powershell", "-Command", f"Stop-Process -Id {pid} -Force -ErrorAction SilentlyContinue"])
    time.sleep(2)

    # Verify server is down
    try:
        with httpx.Client(timeout=1.0) as client:
            client.get(f"{BACKEND_URL}/health")
            log("WARNING: Server still responded?")
    except Exception:
        log("Server confirmed offline (Connection refused).")

    log("Step 3: Starting fresh backend process from disk...")
    # Start process in background
    new_proc = subprocess.Popen([sys.executable, "-m", "mock_backend.run_mock"])
    
    # Wait for server to come up
    online = False
    for attempt in range(15):
        time.sleep(1)
        try:
            with httpx.Client(timeout=2.0) as client:
                hr = client.get(f"{BACKEND_URL}/health")
                if hr.status_code == 200:
                    online = True
                    log(f"New backend process online! Health: {hr.json()}")
                    break
        except Exception:
            pass

    assert online, "Failed to bring new backend online"

    log("Step 4: Querying persisted trip and action from the newly started server...")
    with httpx.Client(timeout=10.0) as client:
        # Check trip survival
        t_res = client.get(f"{BACKEND_URL}/api/trips/{trip_id}")
        assert t_res.status_code == 200, f"Trip failed to survive restart: {t_res.status_code}"
        reloaded_trip = t_res.json()
        assert reloaded_trip["trip_id"] == trip_id
        assert reloaded_trip["destination"] == "Goa"
        assert reloaded_trip["total_budget_inr"] == 25000.0
        log(f"[PASS] Persisted trip {trip_id} survived restart completely! Destination: {reloaded_trip['destination']}")

        # Check budget survival
        b_res2 = client.get(f"{BACKEND_URL}/api/trips/{trip_id}/budget")
        assert b_res2.status_code == 200
        assert b_res2.json()["total_budget_inr"] == 25000.0
        log(f"[PASS] Trip budget calculation survived restart: INR {b_res2.json()['total_budget_inr']}")

        # Check action survival
        a_res = client.get(f"{BACKEND_URL}/api/actions/{action_id}")
        assert a_res.status_code == 200, f"Action failed to survive restart: {a_res.status_code}"
        reloaded_act = a_res.json()
        assert reloaded_act["action_id"] == action_id
        assert reloaded_act["status"] == "pending_approval"
        log(f"[PASS] Persisted action {action_id} survived restart in pending_approval state!")

        # Step 5: Approve action on the fresh server to prove full operational continuity
        appr_res = client.post(f"{BACKEND_URL}/api/actions/{action_id}/approve", json={
            "approved": True,
            "user_confirmation": "Yes, approve after restart"
        })
        assert appr_res.status_code == 200
        appr_data = appr_res.json()
        assert appr_data["status"] == "succeeded"
        receipt = appr_data["receipt_id"]
        log(f"[PASS] Approved action on fresh server! Receipt: {receipt}")

        # Check that executed status persisted
        final_act = client.get(f"{BACKEND_URL}/api/actions/{action_id}").json()
        assert final_act["status"] == "succeeded"
        assert final_act["receipt_id"] == receipt
        log(f"[PASS] Final status 'succeeded' and receipt persisted in SQLite!")

    print("\n============================================================")
    print("ALL SQLITE RESTART PERSISTENCE ASSERTIONS VERIFIED (5/5 PASS)")
    print("============================================================")

if __name__ == "__main__":
    main()
