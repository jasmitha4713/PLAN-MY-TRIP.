// scripts/verify_trip_context_and_voice.js
import puppeteer from 'puppeteer-core';
import { existsSync } from 'fs';
import path from 'path';

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const browserExecutable = existsSync(EDGE_PATH) ? EDGE_PATH : (existsSync(CHROME_PATH) ? CHROME_PATH : null);

const ARTIFACT_DIR = 'C:\\Users\\RAJEEV KUMAR\\.gemini\\antigravity\\brain\\670243a0-7254-4ed0-b3db-20a8bf4a7d44';

function assert(condition, message, extra) {
  if (!condition) {
    console.error(`[FAIL] ${message}${extra ? ' -> ' + JSON.stringify(extra) : ''}`);
    throw new Error(`Assertion failed: ${message}`);
  }
  console.log(`[PASS] ${message}`);
}

async function run() {
  console.log('=== VERIFYING TRIP CONTEXT + ALEXA-STYLE VOICE + SAFE BUS CANCELLATION ===\n');
  if (!browserExecutable) {
    console.error('No browser executable found!');
    process.exit(1);
  }

  const browser = await puppeteer.launch({
    executablePath: browserExecutable,
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--window-size=1280,900']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 900 });

  page.on('console', msg => {
    const text = msg.text();
    if (text.includes('error') || text.includes('MCP') || text.includes('Groq') || text.includes('speakText')) {
      console.log(`[Browser Console] ${msg.type().toUpperCase()}: ${text}`);
    }
  });

  try {
    // -------------------------------------------------------------
    // SCENARIO 1: Navigate to /app/trip/mumbai (Unregistered Trip Context)
    // -------------------------------------------------------------
    console.log('\n--- Step 1: Navigating to http://localhost:3000/app/trip/mumbai?demo=true&tab=companion ---');
    await page.goto('http://localhost:3000/app/trip/mumbai?demo=true&tab=companion', { waitUntil: 'networkidle2', timeout: 15000 });
    await new Promise(r => setTimeout(r, 2000));

    const bodyText = await page.evaluate(() => document.body.innerText);
    console.log('--- EXTRACTED BODY TEXT ---:\n' + bodyText.substring(0, 500) + '\n--- END ---');
    const pageContent1 = await page.content();
    assert(pageContent1.includes("Trip reference 'mumbai' is not registered"), "Unregistered trip banner displays 'mumbai is not registered'");
    assert(pageContent1.includes("Switch to Active Trip (PMT-0142 · New Delhi)"), "Banner offers button to switch to active trip PMT-0142");
    assert(pageContent1.includes("Trip Companion (Unregistered (mumbai))") || pageContent1.includes("Trip Companion (Unregistered"), "Companion heading indicates unregistered status instead of New Delhi");
    assert(pageContent1.includes("Unregistered scope: mumbai"), "Scope clearly flags unregistered mumbai scope");

    await page.screenshot({ path: path.join(ARTIFACT_DIR, 'verify-01-unregistered-mumbai.png') });
    console.log('[Artifact] Saved verify-01-unregistered-mumbai.png');

    // -------------------------------------------------------------
    // SCENARIO 2: Click 'Switch to Active Trip (PMT-0142 · New Delhi)'
    // -------------------------------------------------------------
    console.log('\n--- Step 2: Clicking Switch to Active Trip (PMT-0142 · New Delhi) ---');
    const switchBtn = await page.evaluateHandle(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      return btns.find(b => b.textContent && b.textContent.includes('Switch to Active Trip (PMT-0142'));
    });

    assert(Boolean(switchBtn.asElement()), "Found Switch to Active Trip button");
    await switchBtn.asElement().click();
    await new Promise(r => setTimeout(r, 2000));

    const currentUrl = page.url();
    assert(currentUrl.includes('/app/trip/PMT-0142') || currentUrl.includes('/app/trip/trip_hyd_del_001'), `Navigated to canonical active route (${currentUrl})`);

    const pageContent2 = await page.content();
    assert(!pageContent2.includes("Trip reference 'mumbai' is not registered"), "Unregistered banner is completely removed");
    assert(pageContent2.includes("Trip Companion (New Delhi)"), "Companion heading shows verified destination: New Delhi");
    assert(pageContent2.includes("Scoped to trip PMT-0142 (New Delhi) · Live booking context"), "Companion scope shows canonical PMT-0142 (New Delhi)");

    await page.screenshot({ path: path.join(ARTIFACT_DIR, 'verify-02-switched-active-trip.png') });
    console.log('[Artifact] Saved verify-02-switched-active-trip.png');

    // -------------------------------------------------------------
    // SCENARIO 3: Send Safe Bus Cancellation & Rebooking Request
    // -------------------------------------------------------------
    console.log('\n--- Step 3: Sending user request: "I want to cancel my bus. I want to go in the next bus; I have some work." ---');
    const inputSelector = 'input[placeholder*="Ask your companion"], input[placeholder*="Type a message"], input[type="text"]';
    await page.waitForSelector(inputSelector, { timeout: 5000 });
    
    // Find the companion input specifically
    const inputElement = await page.evaluateHandle(() => {
      const inputs = Array.from(document.querySelectorAll('input[type="text"]'));
      return inputs[inputs.length - 1]; // Companion input is typically last
    });
    
    await inputElement.asElement().click();
    await page.keyboard.type("I want to cancel my bus. I want to go in the next bus; I have some work.");
    await new Promise(r => setTimeout(r, 300));

    // Click Send button
    const sendBtn = await page.evaluateHandle(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      return btns.find(b => b.getAttribute('aria-label') === 'Send message' || b.querySelector('svg.lucide-send') || b.textContent.includes('Send'));
    });
    
    if (sendBtn.asElement()) {
      await sendBtn.asElement().click();
    } else {
      await page.keyboard.press('Enter');
    }

    console.log('Message sent. Waiting for Groq/MCP assistant response...');
    // Wait for response to appear
    await page.waitForFunction(() => {
      const msgs = document.querySelectorAll('.space-y-4 .bg-paper');
      return msgs.length > 0;
    }, { timeout: 20000 });

    await new Promise(r => setTimeout(r, 4000));

    const chatCardText = await page.evaluate(() => {
      const container = document.querySelector('.bg-paper.border.border-line.rounded-card');
      return container ? container.innerText : 'NO CONTAINER FOUND';
    });
    console.log('--- CHAT CONTAINER TEXT ---:\n' + chatCardText + '\n--- END CHAT TEXT ---');

    const pageContent3 = await page.content();
    assert(chatCardText.includes("Approve & Send") || pageContent3.includes("Approve &amp; Send"), "Approval Card rendered with explicit 'Approve & Send' button");
    assert(chatCardText.includes("Don't send") || pageContent3.includes("Don't send"), "Approval Card rendered with explicit 'Don't send' button");
    assert(chatCardText.includes("staged recovery action") || chatCardText.includes("prepared the cancellation and rebooking"), "Recovery action staged without automatic booking");
    assert(chatCardText.includes("₹350") || chatCardText.includes("350"), "Clear cost disclosure included");

    await page.screenshot({ path: path.join(ARTIFACT_DIR, 'verify-03-bus-cancellation-staged.png') });
    console.log('[Artifact] Saved verify-03-bus-cancellation-staged.png');

    // -------------------------------------------------------------
    // SCENARIO 4: Test Human Confirmation Gate (Click "Don't send" / Reject)
    // -------------------------------------------------------------
    console.log('\n--- Step 4: Testing Human Confirmation Gate (Declining / "Don\'t send") ---');
    const dontSendBtn = await page.evaluateHandle(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      return btns.find(b => b.textContent && b.textContent.includes("Don't send"));
    });

    assert(Boolean(dontSendBtn.asElement()), "Found 'Don\\'t send' rejection button");
    await dontSendBtn.asElement().click();
    console.log("Clicked 'Don't send'. Waiting for assistant acknowledgement...");

    await new Promise(r => setTimeout(r, 2500));
    const pageContent4 = await page.content();
    assert(pageContent4.includes("Reject") || pageContent4.includes("reject") || pageContent4.includes("cancelled") || pageContent4.includes("declined"), "Rejection acknowledged safely without booking execution");

    await page.screenshot({ path: path.join(ARTIFACT_DIR, 'verify-04-action-declined-safely.png') });
    console.log('[Artifact] Saved verify-04-action-declined-safely.png');

    console.log('\n=== ALL BROWSER CONTEXT & CONVERSATIONAL VOICE TESTS PASSED SUCCESSFULLY! ===\n');
  } catch (err) {
    console.error('\n[FATAL ERROR in browser verification]:', err);
    await page.screenshot({ path: path.join(ARTIFACT_DIR, 'verify-error.png') });
    throw err;
  } finally {
    await browser.close();
  }
}

run();
