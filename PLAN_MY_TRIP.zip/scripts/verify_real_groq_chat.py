import httpx
import json
import sys

sys.stdout.reconfigure(encoding="utf-8")

def test_real_groq_endpoint():
    url = "http://localhost:8000/api/alexa/chat"

    # Step 1: Real contextual chat query requiring budget tool
    payload = {
        "message": "What is the budget and remaining cushion for trip_hyd_del_001?",
        "trip_id": "trip_hyd_del_001",
        "history": [],
        "context": {}
    }

    print("--- 1. Sending Chat Request to /api/alexa/chat ---")
    print(f"Message: {payload['message']}")
    print(f"Trip ID: {payload['trip_id']}")

    with httpx.Client(timeout=30.0) as client:
        resp = client.post(url, json=payload)
        print(f"HTTP Status: {resp.status_code}")
        
        if resp.status_code != 200:
            print("Error:", resp.text)
            sys.exit(1)

        data = resp.json()
        print("\n--- 2. Response Metadata ---")
        print(f"Engine: {data.get('engine')}")
        print(f"LLM Active: {data.get('llm_active')}")

        print("\n--- 3. Tool Calls Executed by Model ---")
        tool_calls = data.get("tool_calls", [])
        print(f"Total Tool Calls: {len(tool_calls)}")
        for i, tc in enumerate(tool_calls, 1):
            print(f"Tool {i}: {tc.get('name')}")
            print(f"  Arguments: {json.dumps(tc.get('input'))}")
            print(f"  Status: {tc.get('status')}")
            print(f"  Output: {json.dumps(tc.get('output'))[:200]}...")

        print("\n--- 4. Model Synthesized Spoken/Written Text ---")
        print(data.get("text"))

        # Verify assertions
        assert data.get("llm_active") is True, "Expected llm_active to be True"
        assert data.get("engine") == "groq-openai/gpt-oss-120b", f"Expected groq-openai/gpt-oss-120b, got {data.get('engine')}"
        assert len(tool_calls) > 0, "Expected at least 1 tool call executed by the model"
        assert "get_budget_breakdown" in [tc.get("name") for tc in tool_calls], "Expected get_budget_breakdown to be called"
        print("\n[SUCCESS] Real Groq model inference and tool calling verified!")

if __name__ == "__main__":
    test_real_groq_endpoint()
