// scripts/verify_wake_word_and_voice_pipeline.js
import puppeteer from 'puppeteer-core';
import { existsSync } from 'fs';
import path from 'path';

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const browserExecutable = existsSync(EDGE_PATH) ? EDGE_PATH : (existsSync(CHROME_PATH) ? CHROME_PATH : null);

const ARTIFACT_DIR = 'C:\\Users\\RAJEEV KUMAR\\.gemini\\antigravity\\brain\\670243a0-7254-4ed0-b3db-20a8bf4a7d44';

function assert(condition, message, extra) {
  if (!condition) {
    console.error(`[FAIL] ${message}${extra ? ' -> ' + JSON.stringify(extra) : ''}`);
    throw new Error(`Assertion failed: ${message}`);
  }
  console.log(`[PASS] ${message}`);
}

async function run() {
  console.log('=== VERIFYING ALEXA WAKE WORD + TRANSCRIPTION + CONVERSATION PIPELINE ===\n');
  if (!browserExecutable) {
    console.error('No browser executable found!');
    process.exit(1);
  }

  const browser = await puppeteer.launch({
    executablePath: browserExecutable,
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--window-size=1280,900']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 900 });

  page.on('console', msg => {
    const text = msg.text();
    if (text.includes('error') || text.includes('aborted') || text.includes('Wake') || text.includes('speakText')) {
      console.log(`[Browser Console] ${msg.type().toUpperCase()}: ${text}`);
    }
  });

  try {
    // -------------------------------------------------------------
    // STEP 1: Open BookedTripPage in Companion Tab
    // -------------------------------------------------------------
    console.log('\n--- Step 1: Navigating to http://localhost:3000/app/trip/PMT-0142?demo=true&tab=companion ---');
    await page.goto('http://localhost:3000/app/trip/PMT-0142?demo=true&tab=companion', { waitUntil: 'networkidle2', timeout: 15000 });
    await new Promise(r => setTimeout(r, 1500));

    // Confirm no false error banner on startup
    const pageText1 = await page.evaluate(() => document.body.innerText);
    assert(!pageText1.includes('Audio input error: aborted'), "No false 'Audio input error: aborted' banner on initial load");
    assert(pageText1.includes('Trip Companion (New Delhi)'), "Authoritative destination New Delhi displayed");
    assert(pageText1.includes('Scoped to trip PMT-0142 (New Delhi)'), "Canonical PMT-0142 trip context active");

    await page.screenshot({ path: path.join(ARTIFACT_DIR, 'wake-01-companion-loaded.png') });
    console.log('[Artifact] Saved wake-01-companion-loaded.png');

    // Helper function to send message through companion
    const sendMessage = async (text) => {
      console.log(`\nSending message: "${text}"`);
      await page.evaluate((msg) => {
        const input = document.querySelector('input[placeholder*="Speak or type"], input[type="text"]');
        if (input) {
          // Native value setter to trigger React state updates
          const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
          nativeInputValueSetter.call(input, msg);
          input.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }, text);
      await new Promise(r => setTimeout(r, 200));

      const sendBtn = await page.evaluateHandle(() => {
        const btns = Array.from(document.querySelectorAll('button'));
        return btns.find(b => b.textContent && b.textContent.includes('Send'));
      });
      if (sendBtn.asElement()) {
        await sendBtn.asElement().click();
      } else {
        await page.keyboard.press('Enter');
      }
      // Wait for assistant response
      await new Promise(r => setTimeout(r, 2500));
    };

    // -------------------------------------------------------------
    // TEST A: WAKE PHRASE ("Hello Alexa")
    // -------------------------------------------------------------
    console.log('\n--- Test A: Wake Phrase "Hello Alexa" ---');
    await sendMessage("Hello Alexa");

    const chatTextA = await page.evaluate(() => document.querySelector('.bg-paper.border.border-line.rounded-card')?.innerText || '');
    assert(chatTextA.includes("I'm here. What can I help you with?"), "Standalone 'Hello Alexa' responds with 'I\'m here. What can I help you with?'");
    assert(!chatTextA.includes("You don't have an active saved trip"), "Wake phrase does NOT trigger a fake trip plan error");
    assert(!chatTextA.includes("Tools executed"), "Wake phrase does NOT trigger unrelated backend tool executions");

    await page.screenshot({ path: path.join(ARTIFACT_DIR, 'wake-02-hello-alexa-reply.png') });
    console.log('[Artifact] Saved wake-02-hello-alexa-reply.png');

    // -------------------------------------------------------------
    // TEST A2: WAKE PHRASE + COMMAND ("Hello Alexa, what is my current trip budget?")
    // -------------------------------------------------------------
    console.log('\n--- Test A2: Wake Phrase + Command: "Hello Alexa, what is my current trip budget?" ---');
    await sendMessage("Hello Alexa, what is my current trip budget?");

    const chatTextA2 = await page.evaluate(() => document.querySelector('.bg-paper.border.border-line.rounded-card')?.innerText || '');
    assert(chatTextA2.includes("15,000") || chatTextA2.includes("₹15,000") || chatTextA2.includes("budget"), "Wake word is stripped and actual trip budget is retrieved");

    await page.screenshot({ path: path.join(ARTIFACT_DIR, 'wake-03-budget-retrieved.png') });
    console.log('[Artifact] Saved wake-03-budget-retrieved.png');

    // -------------------------------------------------------------
    // TEST B: AMBIGUOUS MISHEARD SPEECH ("Cancel metric")
    // -------------------------------------------------------------
    console.log('\n--- Test B: Ambiguous Misheard Speech ("Cancel metric") ---');
    await sendMessage("Cancel metric");

    const chatTextB = await page.evaluate(() => document.querySelector('.bg-paper.border.border-line.rounded-card')?.innerText || '');
    assert(chatTextB.includes("not clear") || chatTextB.includes("incomplete") || chatTextB.includes("which was not clear"), "Ambiguous 'Cancel metric' asks for clarification instead of triggering disruption or cancellation");
    assert(!chatTextB.includes("act_"), "No recovery action is staged for ambiguous words");

    await page.screenshot({ path: path.join(ARTIFACT_DIR, 'wake-04-ambiguous-clarified.png') });
    console.log('[Artifact] Saved wake-04-ambiguous-clarified.png');

    // -------------------------------------------------------------
    // TEST C: DISRUPTION INQUIRY ("I'm in traffic and might miss my bus. Is there an alternative?")
    // -------------------------------------------------------------
    console.log('\n--- Test C: Disruption Inquiry ("I\'m in traffic and might miss my bus. Is there an alternative?") ---');
    await sendMessage("I'm in traffic and might miss my bus. Is there an alternative?");

    const chatTextC = await page.evaluate(() => document.querySelector('.bg-paper.border.border-line.rounded-card')?.innerText || '');
    assert(chatTextC.includes("assessed your travel disruption") || chatTextC.includes("traffic_delay") || chatTextC.includes("Recovery Options"), "Disruption is properly assessed with recommended options");
    assert(!chatTextC.includes("Audio input error: aborted"), "No aborted audio error thrown during conversational flow");

    await page.screenshot({ path: path.join(ARTIFACT_DIR, 'wake-05-disruption-options.png') });
    console.log('[Artifact] Saved wake-05-disruption-options.png');

    // -------------------------------------------------------------
    // TEST D: SAFE BUS CANCELLATION & APPROVAL CARD (NO DUPLICATES)
    // -------------------------------------------------------------
    console.log('\n--- Test D: Bus Cancellation Staging ("I want to cancel my bus. I want to go in the next bus; I have some work.") ---');
    await sendMessage("I want to cancel my bus. I want to go in the next bus; I have some work.");

    const chatTextD = await page.evaluate(() => document.querySelector('.bg-paper.border.border-line.rounded-card')?.innerText || '');
    assert(chatTextD.includes("Approve & Send") || chatTextD.includes("Approve"), "Approval card rendered with Approve button");
    assert(chatTextD.includes("Don't send"), "Approval card rendered with 'Don\'t send' button");

    // Check for duplicate messages
    const userMsgCount = await page.evaluate(() => {
      const msgs = Array.from(document.querySelectorAll('.space-y-4 .bg-ink'));
      return msgs.filter(m => m.textContent && m.textContent.includes('I want to cancel my bus')).length;
    });
    assert(userMsgCount === 1, `Exact 1 logical user turn rendered (found ${userMsgCount})`);

    await page.screenshot({ path: path.join(ARTIFACT_DIR, 'wake-06-bus-cancellation-card.png') });
    console.log('[Artifact] Saved wake-06-bus-cancellation-card.png');

    // -------------------------------------------------------------
    // TEST E: DECLINING ACTION & VOICE CONTROLS
    // -------------------------------------------------------------
    console.log('\n--- Test E: Human Decline Gate ("Don\'t send") ---');
    const dontSendBtn = await page.evaluateHandle(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      return btns.find(b => b.textContent && b.textContent.includes("Don't send"));
    });
    assert(Boolean(dontSendBtn.asElement()), "Found 'Don\'t send' button");
    await dontSendBtn.asElement().click();
    await new Promise(r => setTimeout(r, 2000));

    const chatTextE = await page.evaluate(() => document.querySelector('.bg-paper.border.border-line.rounded-card')?.innerText || '');
    assert(chatTextE.includes("Reject") || chatTextE.includes("cancelled") || chatTextE.includes("declined"), "Rejection safely confirmed without booking");

    // Test Voice Audio Toggle (Voice: ON -> Voice: Muted)
    console.log('\n--- Testing Voice Toggle ---');
    const voiceToggleBtn = await page.evaluateHandle(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      return btns.find(b => b.textContent && (b.textContent.includes("Voice: ON") || b.textContent.includes("Voice: Muted")));
    });
    assert(Boolean(voiceToggleBtn.asElement()), "Found Voice Toggle button");
    await voiceToggleBtn.asElement().click();
    await new Promise(r => setTimeout(r, 500));

    const pageTextE = await page.evaluate(() => document.body.innerText);
    assert(pageTextE.includes("Voice: Muted"), "Toggled voice to Muted safely halting speech");

    await page.screenshot({ path: path.join(ARTIFACT_DIR, 'wake-07-voice-muted.png') });
    console.log('[Artifact] Saved wake-07-voice-muted.png');

    console.log('\n=== ALL TESTS IN MASTER PIPELINE SUITE PASSED SUCCESSFULLY! ===\n');
  } catch (err) {
    console.error('\n[FATAL ERROR in browser verification]:', err);
    await page.screenshot({ path: path.join(ARTIFACT_DIR, 'wake-error.png') });
    throw err;
  } finally {
    await browser.close();
  }
}

run();
