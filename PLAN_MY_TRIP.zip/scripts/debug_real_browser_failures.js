import puppeteer from 'puppeteer-core';
import { existsSync } from 'fs';

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const browserExecutable = existsSync(EDGE_PATH) ? EDGE_PATH : (existsSync(CHROME_PATH) ? CHROME_PATH : null);

async function debugBrowser() {
  console.log('Launching browser to reproduce Phase 2 A and B...');
  const browser = await puppeteer.launch({
    executablePath: browserExecutable,
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 900 });

  page.on('console', msg => console.log('BROWSER CONSOLE:', msg.type(), msg.text()));
  page.on('pageerror', err => console.error('BROWSER PAGE ERROR:', err));
  page.on('request', req => {
    if (req.url().includes('/api/') || req.url().includes('plan')) {
      console.log('BROWSER REQUEST:', req.method(), req.url(), req.postData());
    }
  });
  page.on('response', async res => {
    if (res.url().includes('/api/') || res.url().includes('plan')) {
      try {
        const text = await res.text();
        console.log('BROWSER RESPONSE:', res.status(), res.url(), text.slice(0, 200));
      } catch (e) {}
    }
  });

  try {
    // -----------------------------------------------------------------------
    // TEST A: Typed planning
    // -----------------------------------------------------------------------
    console.log('\n=== REPRODUCING SCENARIO A (Typed Planning) ===');
    await page.goto('http://localhost:3000/app?demo=true', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForSelector('textarea', { timeout: 15000 });

    const promptA = "Plan a trip to Mumbai for 3 days, 5 to 6 members, budget ₹60,000.";
    await page.type('textarea', promptA);
    
    // Click Plan
    const planBtns = await page.$$('button');
    for (const btn of planBtns) {
      const text = await (await btn.getProperty('textContent')).jsonValue();
      if (text.trim() === 'Plan') {
        await btn.click();
        break;
      }
    }

    await new Promise(r => setTimeout(r, 1200));

    // Check if modal opened
    let modalText = await page.evaluate(() => {
      const modal = document.querySelector('[role="dialog"], .fixed');
      return modal ? modal.innerText : 'NO MODAL';
    });
    console.log('Scenario A Modal opened. Contains "5 or 6 travellers":', modalText.includes('5 or 6 travellers'));

    // Click "Plan for 5 travellers" button/chip
    const allBtns = await page.$$('button');
    let clickedChip = false;
    for (const btn of allBtns) {
      const text = await (await btn.getProperty('textContent')).jsonValue();
      if (text.includes('Plan for 5 travellers') || text.includes('5 travellers')) {
        await btn.click();
        clickedChip = true;
        console.log('Clicked chip:', text.trim());
        break;
      }
    }
    console.log('Found & clicked 5 travellers chip:', clickedChip);

    await new Promise(r => setTimeout(r, 800));

    // Now click the submit "Plan trip" button at bottom of modal
    const modalButtons = await page.$$('button');
    let clickedSubmit = false;
    for (const btn of modalButtons) {
      const text = await (await btn.getProperty('textContent')).jsonValue();
      if (text.trim() === 'Plan trip' || text.includes('Plan trip')) {
        await btn.click();
        clickedSubmit = true;
        console.log('Clicked bottom button:', text.trim());
        break;
      }
    }
    console.log('Clicked "Plan trip" submit button:', clickedSubmit);

    // Wait and check if URL changed or if modal closed
    await new Promise(r => setTimeout(r, 3000));

    const currentUrl = page.url();
    console.log('Current URL after submit:', currentUrl);

    const isModalStillOpen = await page.evaluate(() => {
      const modal = document.querySelector('[role="dialog"], .fixed');
      return Boolean(modal && modal.innerText.includes('Confirm Trip Details'));
    });
    console.log('Is modal still open?', isModalStillOpen);

    // -----------------------------------------------------------------------
    // TEST B: Voice planning
    // -----------------------------------------------------------------------
    console.log('\n=== REPRODUCING SCENARIO B (Voice Planning) ===');
    await page.goto('http://localhost:3000/app?demo=true', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForSelector('button', { timeout: 15000 });

    // Find and click the "Start talking" button on the dashboard
    const allDashboardBtns = await page.$$('button');
    let foundStartTalking = false;
    for (const b of allDashboardBtns) {
      const text = await (await b.getProperty('textContent')).jsonValue();
      if (text.includes('Start talking')) {
        await b.click();
        foundStartTalking = true;
        console.log('Clicked "Start talking" button on dashboard');
        break;
      }
    }
    console.log('Found Start Talking button:', foundStartTalking);

    await new Promise(r => setTimeout(r, 1000));

    // Type into the voice panel transcript textarea:
    // "Plan a trip to Mumbai for 3 days, for five people, with a total budget of sixty thousand rupees."
    const promptB = "Plan a trip to Mumbai for 3 days, for five people, with a total budget of sixty thousand rupees.";
    
    // In AlexaVoicePanel, find textarea
    const voiceTextarea = await page.$('div[role="dialog"] textarea');
    console.log('Found voice textarea:', Boolean(voiceTextarea));
    if (voiceTextarea) {
      await voiceTextarea.click();
      // Clear any previous text
      await page.evaluate(el => el.value = '', voiceTextarea);
      await voiceTextarea.type(promptB);
      console.log('Typed prompt B into voice transcript textarea');
    }

    await new Promise(r => setTimeout(r, 500));

    // Click "Plan" button in voice modal
    const voiceModalBtns = await page.$$('div[role="dialog"] button');
    for (const b of voiceModalBtns) {
      const t = await (await b.getProperty('textContent')).jsonValue();
      if (t.trim() === 'Plan' || (t.includes('Plan') && !t.includes('Cancel') && !t.includes('with'))) {
        await b.click();
        console.log('Clicked voice modal Plan button:', t.trim());
        break;
      }
    }

    await new Promise(r => setTimeout(r, 1500));

    // Inspect values in ConfirmTripSheet
    const formValues = await page.evaluate(() => {
      const dialog = document.querySelector('div[role="dialog"]');
      if (!dialog) return { error: 'No dialog open' };
      const selects = Array.from(dialog.querySelectorAll('select'));
      const fromSelect = selects[0];
      const toSelect = selects[1];
      const budgetInput = dialog.querySelector('input[type="number"]');
      const spans = Array.from(dialog.querySelectorAll('span'));
      const durationSpan = spans.find(s => s.innerText.includes('Day'));
      const adultSpans = spans.filter(s => /^\d+$/.test(s.innerText.trim()));

      return {
        origin: fromSelect ? fromSelect.value : null,
        destination: toSelect ? toSelect.value : null,
        duration: durationSpan ? durationSpan.innerText.trim() : null,
        adults: adultSpans[0] ? adultSpans[0].innerText.trim() : null,
        children: adultSpans[1] ? adultSpans[1].innerText.trim() : null,
        budget: budgetInput ? budgetInput.value : null,
        bodyTextSnippet: dialog.innerText.slice(0, 400)
      };
    });

    console.log('Scenario B Captured Form Values:', JSON.stringify(formValues, null, 2));

  } catch (err) {
    console.error('Debug script error:', err);
  } finally {
    await browser.close();
  }
}

debugBrowser();
