import puppeteer from 'puppeteer-core';

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const BASE_URL = 'http://localhost:3000';

async function runBrowserTests() {
  console.log('Launching Headless Edge for End-to-End Browser Tests...');
  const browser = await puppeteer.launch({
    executablePath: EDGE_PATH,
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 800 });

  const testResults = [];

  try {
    // -----------------------------------------------------------------
    // TEST 1 & 2: Ambiguous Mumbai trip request & single clarification
    // -----------------------------------------------------------------
    console.log('\n--- Running Test 1 & 2: Homepage typed intake & clarification ---');
    await page.goto(`${BASE_URL}/app?demo=true`, { waitUntil: 'domcontentloaded' });
    const promptInput = await page.waitForSelector('textarea');
    await promptInput.click({ clickCount: 3 });
    await promptInput.type('Plan a trip to Mumbai for 3 days, 5 to 6 members, budget ₹60,000');

    // Click Plan button
    const planBtn = await page.waitForSelector('form button[type="submit"]');
    await planBtn.click();

    // Wait for ConfirmTripSheet dialog
    await page.waitForSelector('div[role="dialog"]');
    const dialogs = await page.$$('div[role="dialog"]');
    console.log(`Active confirmation dialog count: ${dialogs.length}`);
    if (dialogs.length !== 1) throw new Error(`Expected exactly 1 dialog, found ${dialogs.length}`);

    // Verify clarification notice
    const clarifText = await page.$eval('div[role="dialog"]', el => el.innerText);
    const hasClarif = clarifText.includes('Would you like to plan for 5 or 6 travellers?');
    console.log(`Contains "Would you like to plan for 5 or 6 travellers?": ${hasClarif}`);

    // Check pre-filled details
    const originVal = await page.$eval('select', el => el.value);
    const toCityVal = await page.$$eval('select', selects => selects[1]?.value);
    const budgetVal = await page.$eval('input[type="number"]', el => el.value);
    console.log(`Parsed Origin: ${originVal}, Destination: ${toCityVal}, Budget: ${budgetVal}`);

    if (originVal !== 'Hyderabad') throw new Error(`Expected origin Hyderabad, got ${originVal}`);
    if (toCityVal !== 'Mumbai') throw new Error(`Expected destination Mumbai, got ${toCityVal}`);
    if (!budgetVal.includes('60000') && !budgetVal.includes('60,000')) throw new Error(`Expected budget 60000, got ${budgetVal}`);

    // Click "Plan for 5 travellers" button
    const pick5Btn = await page.waitForSelector('button ::-p-text(Plan for 5 travellers)');
    await pick5Btn.click();
    await page.evaluate(() => new Promise(r => setTimeout(r, 500)));

    const afterPickText = await page.$eval('div[role="dialog"]', el => el.innerText);
    const clarifCleared = !afterPickText.includes('Would you like to plan for 5 or 6 travellers?');
    const travellersConfirmed = afterPickText.includes('5 Total');
    console.log(`Clarification cleared after selection: ${clarifCleared}`);
    console.log(`Total travellers updated to 5: ${travellersConfirmed}`);

    testResults.push({
      test: '1 & 2. Typed intake single clarification & 5 travellers chosen',
      passed: hasClarif && originVal === 'Hyderabad' && toCityVal === 'Mumbai' && clarifCleared && travellersConfirmed
    });

    // Close sheet
    const closeBtn = await page.$('div[role="dialog"] button[aria-label="Close"]');
    if (closeBtn) await closeBtn.click();
    await page.evaluate(() => new Promise(r => setTimeout(r, 500)));

    // -----------------------------------------------------------------
    // TEST 3: Voice input flow (No duplicate or nested modal)
    // -----------------------------------------------------------------
    console.log('\n--- Running Test 3: Voice input flow ---');
    await page.goto(`${BASE_URL}/app?demo=true`, { waitUntil: 'domcontentloaded' });

    // Click "Start talking"
    const voiceTrigger = await page.waitForSelector('button ::-p-text(Start talking)');
    await voiceTrigger.click();

    // Voice panel should open
    await page.waitForSelector('div[role="dialog"]');
    const voiceTextarea = await page.waitForSelector('div[role="dialog"] textarea');
    await voiceTextarea.type('Plan a trip to Mumbai for 3 days, 5 to 6 members, budget ₹60,000');

    // Click Plan in voice panel
    const voicePlanBtn = await page.waitForSelector('div[role="dialog"] button ::-p-text(Plan)');
    await voicePlanBtn.click();

    await page.evaluate(() => new Promise(r => setTimeout(r, 600)));

    // Ensure exactly 1 dialog is visible
    const openDialogs = await page.$$('div[role="dialog"]');
    console.log(`Open dialog count after voice submission: ${openDialogs.length}`);
    const sheetText = await page.$eval('div[role="dialog"]', el => el.innerText);
    const voiceClarif = sheetText.includes('Would you like to plan for 5 or 6 travellers?');
    console.log(`Voice intake opened confirmation with single clarification: ${voiceClarif}`);

    testResults.push({
      test: '3. Voice intake no duplicate modal & preserved clarification',
      passed: openDialogs.length === 1 && voiceClarif
    });

    // -----------------------------------------------------------------
    // TEST 4 & 5: Chat assistant "hi" greeting & "Add Old Delhi culinary food trail"
    // -----------------------------------------------------------------
    console.log('\n--- Running Test 4 & 5: Companion chat greeting & add experience ---');
    await page.goto(`${BASE_URL}/app/trip/PMT-0142?demo=true`, { waitUntil: 'domcontentloaded' });

    // Open Companion tab
    const companionTab = await page.waitForSelector('button ::-p-text(Companion (Alexa))');
    await companionTab.click();
    await page.evaluate(() => new Promise(r => setTimeout(r, 500)));

    // 4. Send "hi"
    const chatInput = await page.waitForSelector('form input[type="text"]');
    await chatInput.type('hi');
    const sendBtn = await page.waitForSelector('form button[type="submit"]');
    await sendBtn.click();

    // Wait for response
    await page.evaluate(() => new Promise(r => setTimeout(r, 2000)));

    const messagesText = await page.$eval('div.flex-1.p-6.overflow-y-auto', el => el.innerText);
    const greetingPassed = messagesText.toLowerCase().includes('hello! how can i help you') &&
      !messagesText.includes('Available Tools (5)');
    console.log(`"hi" received short conversational reply: ${greetingPassed}`);

    testResults.push({
      test: '4. "hi" receives short greeting without tools catalogue',
      passed: greetingPassed
    });

    // 5. Send "Add Old Delhi culinary food trail"
    await chatInput.type('Add Old Delhi culinary food trail');
    await sendBtn.click();
    await page.evaluate(() => new Promise(r => setTimeout(r, 2500)));

    const afterAddText = await page.$eval('div.flex-1.p-6.overflow-y-auto', el => el.innerText);
    const addPassed = afterAddText.includes('Old Delhi Midnight Culinary Walk') &&
      afterAddText.includes('Budget Status');
    console.log(`"Add Old Delhi culinary food trail" added experience & updated budget: ${addPassed}`);

    testResults.push({
      test: '5. "Add Old Delhi culinary food trail" updates active itinerary & budget',
      passed: addPassed
    });

    // -----------------------------------------------------------------
    // TEST 6: Active trip alignment & Budget Tool
    // -----------------------------------------------------------------
    console.log('\n--- Running Test 6: Active trip alignment & budget ceiling ---');
    // Check companion header
    const companionHeader = await page.$eval('h3.font-display', el => el.innerText);
    console.log(`Companion header: ${companionHeader}`);
    const isDelhi = companionHeader.includes('New Delhi');

    // Send budget query
    await chatInput.type('What is my current trip budget?');
    await sendBtn.click();
    await page.evaluate(() => new Promise(r => setTimeout(r, 2500)));

    const budgetMsgText = await page.$eval('div.flex-1.p-6.overflow-y-auto', el => el.innerText);
    const budgetPassed = budgetMsgText.includes('15,000') &&
      (budgetMsgText.includes('Delhi Heritage & Haveli Retreat') || budgetMsgText.includes('Hyderabad → New Delhi')) &&
      !budgetMsgText.includes('Jaipur');
    console.log(`Budget calculated for active Delhi trip (₹15,000 ceiling): ${budgetPassed}`);

    testResults.push({
      test: '6. Active trip alignment (Hyderabad → New Delhi) & ₹15,000 budget',
      passed: isDelhi && budgetPassed
    });

    // -----------------------------------------------------------------
    // TEST 7: Train delay disruption assessment
    // -----------------------------------------------------------------
    console.log('\n--- Running Test 7: Train delay disruption assessment ---');
    await chatInput.type('My train is delayed by 2 hours. What should I do?');
    await sendBtn.click();
    await page.evaluate(() => new Promise(r => setTimeout(r, 3000)));

    const trainDisruptText = await page.$eval('div.flex-1.p-6.overflow-y-auto', el => el.innerText);
    const trainDisruptPassed = trainDisruptText.includes('assessed your travel disruption') &&
      (trainDisruptText.includes('Notify') || trainDisruptText.includes('Late Check-in') || trainDisruptText.includes('Station Taxi')) &&
      !trainDisruptText.includes('Switch to Following Express Volvo AC Bus');
    console.log(`Train disruption evaluated with train-relevant recommendations: ${trainDisruptPassed}`);

    testResults.push({
      test: '7. Train delay evaluated with train-relevant options (no Volvo bus recommendation)',
      passed: trainDisruptPassed
    });

    // -----------------------------------------------------------------
    // TEST 8: Recovery action staging, rejection and approval
    // -----------------------------------------------------------------
    console.log('\n--- Running Test 8: Staging, rejection and approval ---');
    await chatInput.type("Prepare a recovery action for my delayed train, but don't book anything until I approve.");
    await sendBtn.click();
    await page.evaluate(() => new Promise(r => setTimeout(r, 3000)));

    const stagedText = await page.$eval('div.flex-1.p-6.overflow-y-auto', el => el.innerText);
    const stagePassed = stagedText.includes('Action Requires Explicit Approval') &&
      stagedText.includes("Don't send") &&
      stagedText.includes('Approve & Send');
    console.log(`Action staged with approval card: ${stagePassed}`);

    // Click "Don't send" (Reject)
    const dontSendBtn = await page.waitForSelector('button ::-p-text(Don\'t send)');
    await dontSendBtn.click();
    await page.evaluate(() => new Promise(r => setTimeout(r, 2500)));

    const rejectText = await page.$eval('div.flex-1.p-6.overflow-y-auto', el => el.innerText);
    const rejectPassed = (rejectText.includes('Cancelled (Unexecuted)') || rejectText.includes('Action Cancelled') || rejectText.includes('was rejected'));
    console.log(`Action rejected without execution: ${rejectPassed}`);

    testResults.push({
      test: '8. Recovery staging and rejection preserves unexecuted safety',
      passed: stagePassed && rejectPassed
    });

    // -----------------------------------------------------------------
    // TEST 9: Unknown Trip ID error banner & refusal to silently switch
    // -----------------------------------------------------------------
    console.log('\n--- Running Test 9: Unknown Trip ID error handling ---');
    await page.goto(`${BASE_URL}/app/trip/nonexistent_xyz_99?demo=true`, { waitUntil: 'domcontentloaded' });

    const compTab2 = await page.waitForSelector('button ::-p-text(Companion (Alexa))');
    await compTab2.click();
    await page.evaluate(() => new Promise(r => setTimeout(r, 500)));

    const pageContent = await page.$eval('body', el => el.innerText);
    const hasUnregisteredBanner = pageContent.includes("is not registered in the backend trip repository");
    console.log(`Shows unregistered trip banner: ${hasUnregisteredBanner}`);

    // Try sending message on unknown trip
    const unknownInput = await page.waitForSelector('form input[type="text"]');
    await unknownInput.type("What should I do?");
    const unknownSend = await page.waitForSelector('form button[type="submit"]');
    await unknownSend.click();
    await page.evaluate(() => new Promise(r => setTimeout(r, 2000)));

    const unknownReply = await page.$eval('div.flex-1.p-6.overflow-y-auto', el => el.innerText);
    const honestRefusal = unknownReply.includes("not found in the backend trip repository") &&
      unknownReply.includes("nonexistent_xyz_99");
    console.log(`Assistant reports honest not-found error rather than silently switching: ${honestRefusal}`);

    testResults.push({
      test: '9. Unknown trip produces clear error banner & honest MCP rejection',
      passed: hasUnregisteredBanner && honestRefusal
    });

  } catch (err) {
    console.error('Browser Test Error:', err);
    testResults.push({
      test: 'Fatal Test Execution Failure',
      passed: false,
      error: err.message
    });
  } finally {
    await browser.close();
  }

  console.log('\n========================================');
  console.log('BROWSER AUTOMATION TEST SUMMARY');
  console.log('========================================');
  let allPassed = true;
  for (const r of testResults) {
    const mark = r.passed ? '✓ PASS' : '✗ FAIL';
    console.log(`${mark} : ${r.test}`);
    if (!r.passed) allPassed = false;
  }
  console.log('========================================');
  process.exit(allPassed ? 0 : 1);
}

runBrowserTests();
