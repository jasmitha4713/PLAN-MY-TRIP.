import puppeteer from 'puppeteer-core';
import { existsSync } from 'fs';

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const browserExecutable = existsSync(EDGE_PATH) ? EDGE_PATH : (existsSync(CHROME_PATH) ? CHROME_PATH : null);

async function runConversationalSafetySuite() {
  console.log('=== STARTING CONVERSATIONAL INTELLIGENCE & BOOKING SAFETY SUITE ===');
  if (!browserExecutable) {
    console.error('No browser executable found!');
    process.exit(1);
  }

  const browser = await puppeteer.launch({
    executablePath: browserExecutable,
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 950 });

  page.on('console', msg => {
    const text = msg.text();
    if (!text.includes('React DevTools') && !text.includes('preloaded using link preload')) {
      console.log('CONSOLE:', msg.type(), text.slice(0, 160));
    }
  });
  page.on('pageerror', err => console.error('PAGE ERROR:', err));

  let passed = 0;
  let total = 0;

  function assert(condition, testName) {
    total++;
    if (condition) {
      console.log(`[PASS] ${testName}`);
      passed++;
    } else {
      console.error(`[FAIL] ${testName}`);
    }
  }

  try {
    console.log('\n--- 1. Navigating to Journey Hub (/app/trip/trip_del_jai_001?tab=companion&demo=true) ---');
    await page.goto('http://localhost:3000/app/trip/trip_del_jai_001?tab=companion&demo=true', {
      waitUntil: 'domcontentloaded',
      timeout: 30000
    });
    await new Promise(r => setTimeout(r, 1500));

    const clickTab = async (label) => {
      const tabBtns = await page.$$('button');
      for (const b of tabBtns) {
        const text = await (await b.getProperty('textContent')).jsonValue();
        if (text.includes(label)) {
          await b.click();
          await new Promise(r => setTimeout(r, 800));
          break;
        }
      }
    };

    // Ensure Companion tab is active
    await clickTab('Companion');

    // Verify Banner Labels
    const bodyText = await page.evaluate(() => document.body.innerText);
    assert(
      bodyText.includes('Itinerary Drafted · Simulated Preview') || bodyText.includes('Pending Explicit Checkout'),
      'Banner clearly displays "Itinerary Drafted · Simulated Preview" and "Pending Explicit Checkout" (No fake confirmed booking)'
    );
    assert(
      !bodyText.includes('Confirmed Booking · Simulated'),
      'Banner does not claim "Confirmed Booking"'
    );

    // Switch to Bookings Tab and verify safety notice
    console.log('\n--- 2. Checking Bookings Tab & Sample Data Disclaimers ---');
    await clickTab('Bookings');
    const bookingsText = await page.evaluate(() => document.body.innerText);
    assert(
      bookingsText.includes('Trip Reservations Preview') && bookingsText.includes('Pending Checkout (Sample)'),
      'Bookings tab clearly marks vouchers as "Pending Checkout (Sample)"'
    );
    assert(
      bookingsText.includes('No automatic booking or payment has been made'),
      'Bookings tab contains explicit notice that no automatic booking or payment has occurred'
    );

    // Switch back to Companion tab
    console.log('\n--- 3. Switching back to Companion (Alexa) Tab ---');
    await clickTab('Companion');

    const sendCompanionMessage = async (msg) => {
      console.log(`\nUser asks: "${msg}"`);
      await page.waitForSelector('input[placeholder*="companion"], input[placeholder*="Speak or type"]', { timeout: 10000 });
      const input = await page.$('input[placeholder*="companion"], input[placeholder*="Speak or type"]');
      await input.click({ clickCount: 3 });
      await input.press('Backspace');
      await input.type(msg);
      await input.press('Enter');

      // Wait for assistant response
      await page.waitForFunction(
        () => !document.querySelector('.animate-spin'),
        { timeout: 15000 }
      );
      await new Promise(r => setTimeout(r, 1200));

      const lastMsgText = await page.evaluate(() => {
        const ps = Array.from(document.querySelectorAll('p.leading-relaxed.whitespace-pre-line'));
        return ps[ps.length - 1]?.innerText || '';
      });
      console.log(`Assistant reply: "${lastMsgText.slice(0, 160)}..."`);
      return lastMsgText;
    };

    // Scenario A: Hotel Switch & Option Picker
    console.log('\n--- Scenario A: Hotel Options / Switch Hotel ---');
    const hotelReply = await sendCompanionMessage('Show me another hotel');
    assert(
      hotelReply.includes('accommodation') || hotelReply.includes('hotel'),
      'Assistant conversational response mentions accommodation options without auto-booking'
    );
    const hasOptionPicker = await page.evaluate(() => {
      return Boolean(document.querySelector('.border-line .font-semibold'));
    });
    const optionCardsText = await page.evaluate(() => document.body.innerText);
    assert(
      optionCardsText.includes('Budget Hostel Room') && optionCardsText.includes('Boutique Hotel'),
      'Option picker renders selectable hotels (Budget Hostel Room, Boutique Hotel) with rates and terms'
    );
    assert(
      optionCardsText.includes('Free cancellation') || optionCardsText.includes('Sample data'),
      'Hotel options display cancellation terms and sample data disclaimers'
    );

    // Scenario B: User Chooses an Option
    console.log('\n--- Scenario B: User Selects Budget Hostel Room ---');
    const selectReply = await sendCompanionMessage('Select stay stay-hostel');
    assert(
      selectReply.includes('Budget Hostel Room') && (selectReply.includes('cushion') || selectReply.includes('total')),
      'Assistant confirms accommodation update to Budget Hostel Room and updates budget cushion'
    );
    assert(
      selectReply.includes('No booking') || selectReply.includes('checkout'),
      'Assistant explicitly clarifies that no booking or payment has been made yet'
    );

    // Scenario C: Transport Comparison ("Find me the cheapest train")
    console.log('\n--- Scenario C: Transport Comparison ("Find me the cheapest train") ---');
    const cheapTrainReply = await sendCompanionMessage('Find me the cheapest train');
    assert(
      cheapTrainReply.includes('Overnight Sleeper Train') && cheapTrainReply.includes('1,050'),
      'Assistant identifies Overnight Sleeper Train at ₹1,050/person as the cheapest rail option'
    );

    // Scenario D: Transport Comparison ("I prefer an overnight bus")
    console.log('\n--- Scenario D: Transport Comparison ("I prefer an overnight bus") ---');
    const busReply = await sendCompanionMessage('I prefer an overnight bus');
    assert(
      busReply.includes('bus') && busReply.includes('07:45 AM'),
      'Assistant presents overnight sleeper bus arriving at 07:45 AM before check-in'
    );

    // Scenario E: Transport Comparison ("Show me options arriving before 9 AM")
    console.log('\n--- Scenario E: Transport Arrival Filter ("Show me options arriving before 9 AM") ---');
    const morningReply = await sendCompanionMessage('Show me options arriving before 9 AM');
    assert(
      morningReply.includes('07:55 AM') || morningReply.includes('07:45 AM') || morningReply.includes('before 9'),
      'Assistant filters transport arriving before 9:00 AM'
    );

    // Scenario F: Safe Alternative Discovery (CRITICAL: NEVER cancel without selection)
    console.log('\n--- Scenario F: Safe Alternative Discovery ("Cancel my current bus and show me alternatives") ---');
    const cancelExploreReply = await sendCompanionMessage('Cancel my current bus and show me alternatives');
    assert(
      cancelExploreReply.includes('keeping your current') || cancelExploreReply.includes('active and confirmed') || cancelExploreReply.includes('intact'),
      'Exploratory query preserves existing reservation intact without premature cancellation'
    );
    const hasDisruptionOrApproval = await page.evaluate(() => {
      // Should NOT have created a pending approval card for immediate cancellation during exploratory query
      const approvalBadges = Array.from(document.querySelectorAll('span')).filter(s => s.innerText.includes('Approval Gate'));
      return approvalBadges.length > 0;
    });
    assert(
      !hasDisruptionOrApproval,
      'Exploratory query did not create a destructive cancellation approval gate before user picked an option'
    );

    // Scenario G: "Can we make it cheaper?"
    console.log('\n--- Scenario G: "Can we make it cheaper?" ---');
    const cheaperReply = await sendCompanionMessage('Can we make it cheaper?');
    assert(
      cheaperReply.includes('reduce') || cheaperReply.includes('cheaper') || cheaperReply.includes('save'),
      'Assistant explains budget-saving trade-offs and savings cushion'
    );

    // Scenario H: "Why did you choose this?"
    console.log('\n--- Scenario H: "Why did you choose this?" ---');
    const whyReply = await sendCompanionMessage('Why did you choose this?');
    assert(
      whyReply.includes('buffer') || whyReply.includes('cutoff') || whyReply.includes('efficiency'),
      'Assistant explains itinerary choice based on arrival buffer and check-in cutoff'
    );

    // Scenario I: Assistant Transparency & Identity
    console.log('\n--- Scenario I: Assistant Transparency ("Who are you?") ---');
    const whoReply = await sendCompanionMessage('Who are you?');
    assert(
      whoReply.includes('Model Context Protocol') || whoReply.includes('MCP') || whoReply.includes('not an Amazon'),
      'Assistant explicitly states it runs on local MCP tools, not an Amazon cloud service'
    );

    console.log(`\n========================================`);
    console.log(`FINAL RESULT: ${passed}/${total} TESTS PASSED`);
    console.log(`========================================`);

    if (passed === total) {
      console.log('SUCCESS: All conversational intelligence and booking safety requirements are satisfied!');
    } else {
      console.error(`FAILURE: ${total - passed} tests failed.`);
      process.exitCode = 1;
    }

  } catch (err) {
    console.error('Test execution failed with error:', err);
    process.exitCode = 1;
  } finally {
    await browser.close();
  }
}

runConversationalSafetySuite();
