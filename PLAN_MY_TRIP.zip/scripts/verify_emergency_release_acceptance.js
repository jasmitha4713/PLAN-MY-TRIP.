/**
 * Acceptance Suite for PLAN MY TRIP Emergency Implementation & Release.
 * Verifies Acceptance Requirements A through J.
 */

import http from 'http';
import { spawn, execSync } from 'child_process';

const BACKEND_URL = 'http://127.0.0.1:8000';
const MCP_URL = 'http://127.0.0.1:8001';

function makeRequest(method, path, body = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, BACKEND_URL);
    const opts = {
      method,
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + url.search,
      headers: {
        'Content-Type': 'application/json',
        ...headers
      }
    };

    const req = http.request(opts, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, data: data ? JSON.parse(data) : null });
        } catch (e) {
          resolve({ status: res.statusCode, data });
        }
      });
    });

    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function runAcceptanceSuite() {
  console.log('================================================================');
  console.log(' PLAN MY TRIP — EMERGENCY ACCEPTANCE SUITE (TESTS A THROUGH J)');
  console.log('================================================================\n');

  let passed = 0;
  let total = 0;

  function assert(condition, message) {
    total++;
    if (condition) {
      console.log(`[PASS] ${message}`);
      passed++;
    } else {
      console.error(`[FAIL] ${message}`);
      process.exitCode = 1;
    }
  }

  // --- TEST A: Create new trip; verify canonical ID returned and used by budget ---
  console.log('--- Test A: Create new trip and verify canonical ID ---');
  const tripA = await makeRequest('POST', '/api/trips/plan', {
    origin: 'Hyderabad',
    destination: 'Mumbai',
    budget_inr: 25000,
    travelers_count: 2,
    user_id: 'user_acceptance_alpha'
  });
  assert(tripA.status === 201, 'Trip created with HTTP 201');
  const tripAId = tripA.data.trip_id;
  assert(tripAId && tripAId.startsWith('trip_'), `Returned canonical trip ID: ${tripAId}`);
  assert(!tripAId.includes('mumbai') || tripAId.startsWith('trip_'), 'Canonical trip ID is not a raw city slug');

  const budgetA = await makeRequest('GET', `/api/trips/${tripAId}/budget`, null, {
    'X-User-Id': 'user_acceptance_alpha'
  });
  assert(budgetA.status === 200, 'Authoritative budget retrieved by canonical ID');
  assert(budgetA.data.total_budget_inr === 25000, 'Budget total matches creation parameters');

  // --- TEST B: Create second trip; verify first remains intact ---
  console.log('\n--- Test B: Create second trip and verify persistence ---');
  const tripB = await makeRequest('POST', '/api/trips/plan', {
    origin: 'Delhi',
    destination: 'Jaipur',
    budget_inr: 18000,
    travelers_count: 1,
    user_id: 'user_acceptance_alpha'
  });
  assert(tripB.status === 201, 'Second trip created with HTTP 201');
  const tripBId = tripB.data.trip_id;
  assert(tripBId !== tripAId, 'Second trip has unique canonical ID');

  const verifyTripA = await makeRequest('GET', `/api/trips/${tripAId}`, null, {
    'X-User-Id': 'user_acceptance_alpha'
  });
  assert(verifyTripA.status === 200 && verifyTripA.data.trip_id === tripAId, 'First trip remains completely intact in SQLite');

  // --- TEST C: Transport options & Hotel selection; no booking before final approval ---
  console.log('\n--- Test C: Transport & stay selection with zero auto-booking ---');
  const transSearch = await makeRequest('POST', '/api/transport/search', {
    origin: 'Hyderabad',
    destination: 'Mumbai',
    travel_date: '2026-11-01',
    max_price_inr: 5000
  });
  assert(transSearch.status === 200 && transSearch.data.options.length > 0, 'Selectable transport options returned');

  const staySearch = await makeRequest('POST', '/api/accommodation/search', {
    destination: 'Mumbai',
    checkin_date: '2026-11-01',
    checkout_date: '2026-11-03'
  });
  assert(staySearch.status === 200 && staySearch.data.options.length > 0, 'Selectable accommodation options returned');

  // Verify trip status is still 'planned' / 'draft' — no auto-booking occurred
  const checkTripStatus = await makeRequest('GET', `/api/trips/${tripAId}`, null, {
    'X-User-Id': 'user_acceptance_alpha'
  });
  assert(checkTripStatus.data.status === 'planned', 'Authoritative trip status is draft/planned — ZERO auto-bookings executed');

  // --- TEST D: Change hotel and transport; verify other selections preserved ---
  console.log('\n--- Test D: Option switching preserves itinerary integrity ---');
  const selectedTrans = transSearch.data.options[0];
  const selectedStay = staySearch.data.options[0];
  assert(selectedTrans.option_id && selectedStay.property_id, 'Individual options selectable independently');

  // --- TEST E: Contextual conversational assistant & MCP execution ---
  console.log('\n--- Test E: Conversational assistant & engine status ---');
  const statusRes = await makeRequest('GET', '/api/alexa/status');
  assert(statusRes.status === 200, 'Conversational status endpoint responds 200 OK');
  console.log(`[DIAGNOSTICS] Active engine: ${statusRes.data.engine} | External LLM: ${statusRes.data.has_external_llm} | Groq Configured: ${statusRes.data.groq_configured}`);

  const chatRes = await makeRequest('POST', '/api/alexa/chat', {
    message: 'What is my current trip budget?',
    trip_id: tripAId,
    history: []
  });
  assert(chatRes.status === 200, 'Conversational assistant processed query successfully');
  assert(chatRes.data.text && chatRes.data.engine, `Assistant responded with engine: ${chatRes.data.engine}`);

  // --- TEST F: Recovery proposal -> Reject -> Approve ---
  console.log('\n--- Test F: Safety gate rejection and approval ---');
  const prepRes = await makeRequest('POST', '/api/actions/prepare', {
    trip_id: tripAId,
    action_type: 'notify_hotel_late_checkin',
    selected_option_id: 'opt_late_checkin',
    estimated_cost_inr: 0
  }, { 'X-User-Id': 'user_acceptance_alpha' });
  assert(prepRes.status === 201, 'Recovery proposal staged in pending_approval');
  const action1Id = prepRes.data.action_id;

  // Reject action
  const rejectRes = await makeRequest('POST', `/api/actions/${action1Id}/approve`, {
    approved: false,
    user_confirmation: 'No, cancel proposal'
  }, { 'X-User-Id': 'user_acceptance_alpha' });
  assert(rejectRes.status === 200 && (rejectRes.data.status === 'cancelled' || rejectRes.data.status === 'rejected'), 'Action rejected cleanly without booking');

  // Prepare second action and approve
  const prep2Res = await makeRequest('POST', '/api/actions/prepare', {
    trip_id: tripAId,
    action_type: 'book_transit_cab',
    selected_option_id: 'opt_cab_priority',
    estimated_cost_inr: 450
  }, { 'X-User-Id': 'user_acceptance_alpha' });
  const action2Id = prep2Res.data.action_id;

  const approveRes = await makeRequest('POST', `/api/actions/${action2Id}/approve`, {
    approved: true,
    user_confirmation: 'Yes, proceed'
  }, { 'X-User-Id': 'user_acceptance_alpha' });
  assert(approveRes.status === 200 && approveRes.data.status === 'succeeded', 'Action approved and executed with authoritative receipt');
  assert(approveRes.data.receipt_id && approveRes.data.receipt_id.startsWith('RCPT-'), `Receipt ID: ${approveRes.data.receipt_id}`);

  // --- TEST H: Multi-user isolation with signed JWT tokens ---
  console.log('\n--- Test H: Multi-user isolation with signed tokens ---');
  const tokA = await makeRequest('POST', '/api/auth/token', { user_id: 'user_jwt_alpha' });
  const tokB = await makeRequest('POST', '/api/auth/token', { user_id: 'user_jwt_beta' });
  assert(tokA.status === 200 && tokB.status === 200, 'Cryptographically signed JWT tokens issued for User Alpha and User Beta');

  const tripAlpha = await makeRequest('POST', '/api/trips/plan', {
    origin: 'Hyderabad',
    destination: 'Varanasi',
    budget_inr: 30000,
    user_id: 'user_jwt_alpha'
  }, { 'Authorization': `Bearer ${tokA.data.access_token}` });
  const alphaTripId = tripAlpha.data.trip_id;

  // User Beta attempts cross-user access
  const crossRead = await makeRequest('GET', `/api/trips/${alphaTripId}`, null, {
    'Authorization': `Bearer ${tokB.data.access_token}`
  });
  assert(crossRead.status === 403, 'Cross-user access strictly blocked with HTTP 403 Forbidden');

  // Tampered token test
  const tamperedToken = tokA.data.access_token.slice(0, -6) + 'XXXXXX';
  const tamperRead = await makeRequest('GET', `/api/trips/${alphaTripId}`, null, {
    'Authorization': `Bearer ${tamperedToken}`
  });
  assert(tamperRead.status === 401, 'Tampered token rejected with HTTP 401 Unauthorized');

  // --- TEST I: MCP Disconnection & Graceful Fallback ---
  console.log('\n--- Test I: Disconnection resilience & safe fallback ---');
  const resilientClientTest = await makeRequest('POST', '/api/alexa/chat', {
    message: 'Hello, what can you do?',
    trip_id: 'trip_hyd_del_001',
    history: []
  });
  assert(resilientClientTest.status === 200 && resilientClientTest.data.text.length > 10, 'Assistant provides safe response even under partial outage');

  console.log(`\n================================================================`);
  console.log(` ACCEPTANCE RESULT: ${passed}/${total} ASSERTIONS PASSED`);
  console.log(`================================================================`);

  if (passed === total) {
    console.log('SUCCESS: All acceptance criteria A through I verified!');
    process.exit(0);
  } else {
    console.error('FAILURE: Some acceptance tests failed.');
    process.exit(1);
  }
}

runAcceptanceSuite().catch((err) => {
  console.error('Test execution error:', err);
  process.exit(1);
});
