import puppeteer from 'puppeteer-core';
import { existsSync } from 'fs';

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const browserExecutable = existsSync(EDGE_PATH) ? EDGE_PATH : (existsSync(CHROME_PATH) ? CHROME_PATH : null);

if (!browserExecutable) {
  console.error('No suitable browser found for automation.');
  process.exit(1);
}

async function runMandatoryRegressionBrowserTests() {
  console.log('================================================================');
  console.log('PLAN MY TRIP — MANDATORY REGRESSION VERIFICATION (TESTS A, B, C, D)');
  console.log('================================================================');

  const browser = await puppeteer.launch({
    executablePath: browserExecutable,
    headless: true,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--use-fake-ui-for-media-stream',
      '--use-fake-device-for-media-stream'
    ]
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 900 });

  const summary = {};

  try {
    // =========================================================================
    // TEST A — Transport cancellation
    // User: "Cancel my bus and get me the next bus."
    // Expected: Identify the bus, explain cancellation confirmation & refund terms,
    // find next available bus using actual supported data source, and obtain approval
    // before consequential action. NEVER respond with unrelated hotel check-in or taxi advice.
    // =========================================================================
    console.log('\n--- TEST A: Transport cancellation ("Cancel my bus and get me the next bus.") ---');
    await page.goto('http://localhost:3000/app/trip/DEMO-JAI-001?demo=true', { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('button', { timeout: 8000 });

    // Switch to Companion tab
    const tabButtons = await page.$$('button');
    for (const btn of tabButtons) {
      const text = await (await btn.getProperty('textContent')).jsonValue();
      if (text.includes('Companion')) {
        await btn.click();
        break;
      }
    }
    await new Promise(r => setTimeout(r, 600));

    // Type "Cancel my bus and get me the next bus."
    const inputSelector = 'input[placeholder*="companion"], input[placeholder*="Waiting"], input[placeholder*="Listening"]';
    await page.waitForSelector(inputSelector);
    await page.click(inputSelector);
    await page.keyboard.type('Cancel my bus and get me the next bus.');
    await page.keyboard.press('Enter');

    // Wait for response
    await new Promise(r => setTimeout(r, 2500));

    let bodyText = await page.evaluate(() => document.body.innerText);
    
    const identifiesBus = bodyText.includes('RSRTC Express') || bodyText.includes('RJ-14-PC-8921') || bodyText.includes('RSRTC-DEL-99231');
    const explainsRefund = bodyText.includes('85%') || bodyText.includes('cancellation') || bodyText.includes('refund');
    const findsNextBus = bodyText.includes('08:30 AM') || bodyText.includes('Express service');
    const stagesApproval = bodyText.includes('Approve & Send') || bodyText.includes('Don\'t send') || bodyText.includes('act_bus_rebook');
    const noUnrelatedHotelTaxi = !bodyText.includes('Old Delhi Haveli') && !bodyText.includes('hotel check-in at risk') && !bodyText.includes('station taxi');

    console.log('Identifies active bus booking (RSRTC Express / RJ-14-PC-8921):', identifiesBus);
    console.log('Explains verified cancellation confirmation & refund terms:', explainsRefund);
    console.log('Finds next available express bus (~08:30 AM):', findsNextBus);
    console.log('Stages recovery action & requests explicit approval before booking:', stagesApproval);
    console.log('Zero unrelated hotel check-in or taxi advice:', noUnrelatedHotelTaxi);

    const testAPass = identifiesBus && explainsRefund && findsNextBus && stagesApproval && noUnrelatedHotelTaxi;
    summary['Test A — Transport cancellation'] = testAPass ? 'PASS' : 'FAIL';
    console.log('TEST A RESULT:', testAPass ? 'PASS' : 'FAIL');

    // =========================================================================
    // TEST B — Follow-up context
    // User: "Plan for 5 travellers."
    // Then: "Actually, make it 3."
    // Expected: Final traveller count must be 3 everywhere, old clarification 5 must not restore.
    // =========================================================================
    console.log('\n--- TEST B: Follow-up context ("Plan for 5 travellers." -> "Actually, make it 3.") ---');
    await page.goto('http://localhost:3000/app/alexa?demo=true', { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('input, textarea', { timeout: 8000 });

    const alexaInput = 'input[placeholder*="Ask Alexa"], input[placeholder*="companion"], input[type="text"]';
    await page.waitForSelector(alexaInput);
    
    // Turn 1: "Plan for 5 travellers."
    await page.click(alexaInput);
    await page.keyboard.type('Plan for 5 travellers.');
    await page.keyboard.press('Enter');
    await new Promise(r => setTimeout(r, 1500));

    let alexaBody1 = await page.evaluate(() => document.body.innerText);
    console.log('Turn 1 responded to 5 travellers:', alexaBody1.includes('5'));

    // Turn 2: "Actually, make it 3."
    await page.click(alexaInput);
    await page.keyboard.type('Actually, make it 3.');
    await page.keyboard.press('Enter');
    await new Promise(r => setTimeout(r, 1500));

    // Get the last assistant message
    const lastMsgText = await page.evaluate(() => {
      const msgs = document.querySelectorAll('.leading-relaxed');
      return msgs.length > 0 ? msgs[msgs.length - 1].innerText : '';
    });
    console.log('Turn 2 assistant message:', lastMsgText);

    const mentions3 = lastMsgText.includes('Updated traveller count to 3') || lastMsgText.includes('3 travellers');
    const doesNotRevertTo5 = !lastMsgText.includes('5 travellers');
    console.log('Turn 2 updated traveller count to 3:', mentions3);
    console.log('Did not revert to 5 in final response:', doesNotRevertTo5);

    const testBPass = mentions3 && doesNotRevertTo5;
    summary['Test B — Follow-up context'] = testBPass ? 'PASS' : 'FAIL';
    console.log('TEST B RESULT:', testBPass ? 'PASS' : 'FAIL');

    // =========================================================================
    // TEST C — Voice conversation
    // User speaks a request, receives a response, and then asks a follow-up without repeating trip details.
    // Expected: Preserved context, appropriate action, natural response.
    // =========================================================================
    console.log('\n--- TEST C: Voice conversation & Context Continuity ---');
    // Turn 1: Destination and duration
    await page.click(alexaInput);
    await page.keyboard.type('Plan a trip to Mumbai for 3 days');
    await page.keyboard.press('Enter');
    await new Promise(r => setTimeout(r, 1500));

    let turn1Text = await page.evaluate(() => document.body.innerText);
    const acknowledgesMumbai = turn1Text.toLowerCase().includes('mumbai') && turn1Text.toLowerCase().includes('budget');
    console.log('Turn 1 captured Mumbai and 3 days, asking for budget:', acknowledgesMumbai);

    // Turn 2: Follow-up budget without repeating "Mumbai" or "3 days"
    await page.click(alexaInput);
    await page.keyboard.type('Keep it under sixty thousand');
    await page.keyboard.press('Enter');
    await new Promise(r => setTimeout(r, 2000));

    let turn2Text = await page.evaluate(() => document.body.innerText);
    const preservesContext = turn2Text.includes('Mumbai') && (turn2Text.includes('60,000') || turn2Text.includes('₹60,000'));
    const generatedBudgetCard = turn2Text.includes('Budget') || turn2Text.includes('Planned Budget');
    console.log('Turn 2 remembered Mumbai context with 60,000 budget:', preservesContext);
    console.log('Multimodal response rendered:', generatedBudgetCard);

    const testCPass = acknowledgesMumbai && preservesContext && generatedBudgetCard;
    summary['Test C — Voice conversation context'] = testCPass ? 'PASS' : 'FAIL';
    console.log('TEST C RESULT:', testCPass ? 'PASS' : 'FAIL');

    // =========================================================================
    // TEST D — Approval and honesty
    // Ask the assistant to cancel or book something.
    // Expected: Requests confirmation when required, executes through supported integration,
    // handles failures honestly, and never fabricates success.
    // =========================================================================
    console.log('\n--- TEST D: Approval Safety Gate & Honesty Disclosures ---');
    await page.goto('http://localhost:3000/app/trip/DEMO-JAI-001?demo=true', { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('button', { timeout: 8000 });

    for (const btn of await page.$$('button')) {
      const text = await (await btn.getProperty('textContent')).jsonValue();
      if (text.includes('Companion')) {
        await btn.click();
        break;
      }
    }
    await new Promise(r => setTimeout(r, 600));

    // Ask to cancel bus
    await page.waitForSelector(inputSelector);
    await page.click(inputSelector);
    await page.keyboard.type('Cancel my bus and get me the next bus.');
    await page.keyboard.press('Enter');
    await new Promise(r => setTimeout(r, 2500));

    let cardText = await page.evaluate(() => document.body.innerText);
    const hasPendingCard = cardText.includes('Awaiting User Approval') || cardText.includes('Simulated') || cardText.includes('Approve & Send');
    const honestDisclosure = cardText.includes('simulated') || cardText.includes('Simulated');
    console.log('Proactive safety gate: requires user approval before execution:', hasPendingCard);
    console.log('Honest disclosure: explicitly identifies simulated inventory:', honestDisclosure);

    // Find and click "Approve & Send"
    const approveButtons = await page.$$('button');
    let clickedApprove = false;
    for (const btn of approveButtons) {
      const bText = await (await btn.getProperty('textContent')).jsonValue();
      if (bText.includes('Approve & Send') || bText.includes('Approve')) {
        await btn.click();
        clickedApprove = true;
        break;
      }
    }
    console.log('Clicked Approve & Send button:', clickedApprove);

    await new Promise(r => setTimeout(r, 2500));
    let postApproveText = await page.evaluate(() => document.body.innerText);
    const executionConfirmed = postApproveText.includes('Executed') || postApproveText.includes('Audit Receipt') || postApproveText.includes('Receipt');
    console.log('Action successfully executed via backend tool with audit receipt:', executionConfirmed);

    const testDPass = hasPendingCard && honestDisclosure && clickedApprove && executionConfirmed;
    summary['Test D — Approval safety & honesty'] = testDPass ? 'PASS' : 'FAIL';
    console.log('TEST D RESULT:', testDPass ? 'PASS' : 'FAIL');

  } catch (err) {
    console.error('Error during mandatory regression verification:', err);
  } finally {
    await browser.close();
  }

  console.log('\n================================================================');
  console.log('MANDATORY REGRESSION TEST SUMMARY:');
  console.log('================================================================');
  for (const [testName, result] of Object.entries(summary)) {
    console.log(`${result === 'PASS' ? '✓' : '×'} ${testName}: ${result}`);
  }

  const allPassed = Object.values(summary).every(r => r === 'PASS') && Object.keys(summary).length === 4;
  console.log(`\nOVERALL STATUS: ${allPassed ? 'ALL 4 MANDATORY TESTS PASSED' : 'SOME TESTS FAILED'}`);
  process.exit(allPassed ? 0 : 1);
}

runMandatoryRegressionBrowserTests();
