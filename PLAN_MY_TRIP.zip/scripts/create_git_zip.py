import os
import zipfile
import sys

def make_zip():
    root_dir = os.path.abspath("E:/PLAN MY TRIP")
    output_zip = os.path.join(root_dir, "PLAN_MY_TRIP.zip")

    if os.path.exists(output_zip):
        os.remove(output_zip)

    excluded_dirs = {
        "node_modules",
        ".venv",
        "venv",
        "dist",
        ".git",
        ".pytest_cache",
        "__pycache__"
    }

    excluded_extensions = {
        ".zip",
        ".pyc",
        ".log"
    }

    print(f"Creating zip archive at: {output_zip}...")
    file_count = 0

    with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zipf:
        for dirpath, dirnames, filenames in os.walk(root_dir):
            # Skip excluded directories in-place
            dirnames[:] = [d for d in dirnames if d not in excluded_dirs]

            for filename in filenames:
                _, ext = os.path.splitext(filename)
                if ext in excluded_extensions or filename == "PLAN_MY_TRIP.zip":
                    continue

                full_path = os.path.join(dirpath, filename)
                rel_path = os.path.relpath(full_path, root_dir)
                zipf.write(full_path, rel_path)
                file_count += 1

    size_mb = os.path.getsize(output_zip) / (1024 * 1024)
    print(f"DONE! Archived {file_count} files into {output_zip}")
    print(f"Final Zip Size: {size_mb:.2f} MB")
    
    if size_mb <= 25.0:
        print(f"SUCCESS: Zip file is under 25 MB limit ({size_mb:.2f} MB <= 25.0 MB)")
    else:
        print(f"WARNING: Zip file exceeds 25 MB: {size_mb:.2f} MB")

if __name__ == "__main__":
    make_zip()
