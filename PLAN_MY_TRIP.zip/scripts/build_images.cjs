const fs = require('fs');
const path = require('path');
const https = require('https');
const sharp = require('sharp');

const IMAGES_DIR = path.join(__dirname, '..', 'public', 'images');
const ARTIFACT_DIR = 'C:\\Users\\RAJEEV KUMAR\\.gemini\\antigravity\\brain\\670243a0-7254-4ed0-b3db-20a8bf4a7d44';

function downloadUrl(url, destPath) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);
    const options = {
      headers: {
        'User-Agent': 'PlanMyTrip/1.0 (travel@planmytrip.demo; educational hackathon demo)'
      }
    };

    function get(u) {
      https.get(u, options, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          return get(res.headers.location);
        }
        if (res.statusCode !== 200) {
          return reject(new Error(`Failed to download ${u}: status code ${res.statusCode}`));
        }
        res.pipe(file);
        file.on('finish', () => {
          file.close(resolve);
        });
      }).on('error', (err) => {
        fs.unlink(destPath, () => {});
        reject(err);
      });
    }

    get(url);
  });
}

async function main() {
  console.log('=== Building Final Verified Photo System ===');

  const downloads = [
    {
      url: 'https://upload.wikimedia.org/wikipedia/commons/5/5c/Sunrise_Train_on_the_Bridge.jpg',
      temp: 'raw_hero.jpg'
    },
    {
      url: 'https://upload.wikimedia.org/wikipedia/commons/5/52/Sunrise_over_Bengal.jpg',
      temp: 'raw_band_1.jpg'
    },
    {
      url: 'https://upload.wikimedia.org/wikipedia/commons/7/74/Jaali_eyes.jpg',
      temp: 'raw_band_2.jpg'
    },
    {
      url: 'https://upload.wikimedia.org/wikipedia/commons/b/be/A_railway_station_in_india.jpg',
      temp: 'raw_rescue_station.jpg'
    },
    {
      url: 'https://upload.wikimedia.org/wikipedia/commons/9/95/Sunrise_Spot%2CWestern_Ghats_of_India.jpg',
      temp: 'raw_cta_sunrise.jpg'
    },
    {
      url: 'https://upload.wikimedia.org/wikipedia/commons/b/bf/Inside_an_Indian_Railways_Train_-_Sleeper_Coach.jpg',
      temp: 'raw_train_sleeper.jpg'
    },
    {
      url: 'https://upload.wikimedia.org/wikipedia/commons/f/f3/Vande_bharat_Express.jpg',
      temp: 'raw_train_ac.jpg'
    },
    {
      url: 'https://upload.wikimedia.org/wikipedia/commons/4/44/A_sea_of_clouds_below_the_plane_wing.jpg',
      temp: 'raw_flight.jpg'
    },
    {
      url: 'https://upload.wikimedia.org/wikipedia/commons/4/4c/KSRTC-Airavat-Club-Class-Volvo-B9R.jpg',
      temp: 'raw_bus.jpg'
    },
    {
      url: 'https://upload.wikimedia.org/wikipedia/commons/9/9f/Courtyard_of_Samode_Haveli%2C_Jaipur.jpg',
      temp: 'raw_stay_haveli.jpg'
    },
    {
      url: 'https://upload.wikimedia.org/wikipedia/commons/a/a9/Delhi_Taxi.JPG',
      temp: 'raw_cab.jpg'
    },
    {
      url: 'https://upload.wikimedia.org/wikipedia/commons/9/9c/Autorickshaw_in_Delhi.jpg',
      temp: 'raw_auto.jpg'
    },
    {
      url: 'https://upload.wikimedia.org/wikipedia/commons/a/ac/Delhi_metro_elevated.jpg',
      temp: 'raw_metro.jpg'
    },
    {
      url: 'https://upload.wikimedia.org/wikipedia/commons/4/45/Scooter_with_a_car_%28India%29.jpeg',
      temp: 'raw_rental.jpg'
    }
  ];

  for (const item of downloads) {
    const dest = path.join(IMAGES_DIR, item.temp);
    if (!fs.existsSync(dest) || fs.statSync(dest).size < 1000) {
      console.log(`Downloading ${item.temp}...`);
      try {
        await downloadUrl(item.url, dest);
        console.log(`✓ Downloaded ${item.temp} (${(fs.statSync(dest).size / 1024).toFixed(1)} KB)`);
      } catch (err) {
        console.error(`✗ Error downloading ${item.temp}:`, err.message);
      }
    }
  }

  // 1. Hero Main: 1920x1080 (Target <= 220KB)
  if (fs.existsSync(path.join(IMAGES_DIR, 'raw_hero.jpg'))) {
    // Generate at quality 65 with effort 6
    await sharp(path.join(IMAGES_DIR, 'raw_hero.jpg'))
      .resize(1920, 1080, { fit: 'cover', position: 'center' })
      .webp({ quality: 66, effort: 6 })
      .toFile(path.join(IMAGES_DIR, 'hero-main.webp'));
    let heroSize = fs.statSync(path.join(IMAGES_DIR, 'hero-main.webp')).size / 1024;
    if (heroSize > 220) {
      await sharp(path.join(IMAGES_DIR, 'raw_hero.jpg'))
        .resize(1920, 1080, { fit: 'cover', position: 'center' })
        .webp({ quality: 60, effort: 6 })
        .toFile(path.join(IMAGES_DIR, 'hero-main.webp'));
      heroSize = fs.statSync(path.join(IMAGES_DIR, 'hero-main.webp')).size / 1024;
    }
    console.log(`✓ hero-main.webp generated: ${heroSize.toFixed(1)} KB (target <= 220KB: ${heroSize <= 220})`);
  }

  // 2. Band 1: 1600x600
  if (fs.existsSync(path.join(IMAGES_DIR, 'raw_band_1.jpg'))) {
    await sharp(path.join(IMAGES_DIR, 'raw_band_1.jpg'))
      .resize(1600, 600, { fit: 'cover', position: 'center' })
      .webp({ quality: 76 })
      .toFile(path.join(IMAGES_DIR, 'band-1.webp'));
    console.log('✓ band-1.webp generated');
  }

  // 3. Band 2: 1600x900 (10% opacity texture on desktop)
  if (fs.existsSync(path.join(IMAGES_DIR, 'raw_band_2.jpg'))) {
    await sharp(path.join(IMAGES_DIR, 'raw_band_2.jpg'))
      .resize(1600, 900, { fit: 'cover', position: 'center' })
      .webp({ quality: 70 })
      .toFile(path.join(IMAGES_DIR, 'band-2.webp'));
    console.log('✓ band-2.webp generated');
  }

  // 4. Rescue Station: 1600x900
  if (fs.existsSync(path.join(IMAGES_DIR, 'raw_rescue_station.jpg'))) {
    await sharp(path.join(IMAGES_DIR, 'raw_rescue_station.jpg'))
      .resize(1600, 900, { fit: 'cover', position: 'center' })
      .webp({ quality: 76 })
      .toFile(path.join(IMAGES_DIR, 'rescue-station.webp'));
    console.log('✓ rescue-station.webp generated');
  }

  // 5. CTA Sunrise: 1920x1080
  if (fs.existsSync(path.join(IMAGES_DIR, 'raw_cta_sunrise.jpg'))) {
    await sharp(path.join(IMAGES_DIR, 'raw_cta_sunrise.jpg'))
      .resize(1920, 1080, { fit: 'cover', position: 'center' })
      .webp({ quality: 76 })
      .toFile(path.join(IMAGES_DIR, 'cta-sunrise.webp'));
    console.log('✓ cta-sunrise.webp generated');
  }

  // 6. Signin Panel from subagent
  const signinSrc = path.join(ARTIFACT_DIR, 'temp_signin_panel_1792212467307.jpg');
  if (fs.existsSync(signinSrc)) {
    await sharp(signinSrc)
      .resize(900, 1200, { fit: 'cover', position: 'center' })
      .webp({ quality: 78 })
      .toFile(path.join(IMAGES_DIR, 'signin-panel.webp'));
    console.log('✓ signin-panel.webp generated');
  }

  // 7. Journey Stages 1..5 (4:3 aspect ratio, 900x675)
  const journey1Src = path.join(ARTIFACT_DIR, 'temp_journey_1_1792212487753.jpg');
  if (fs.existsSync(journey1Src)) {
    await sharp(journey1Src)
      .resize(900, 675, { fit: 'cover', position: 'center' })
      .webp({ quality: 78 })
      .toFile(path.join(IMAGES_DIR, 'journey-1.webp'));

    // Also use as Alexa section backdrop panel
    await sharp(journey1Src)
      .resize(1200, 750, { fit: 'cover', position: 'center' })
      .webp({ quality: 78 })
      .toFile(path.join(IMAGES_DIR, 'alexa-backdrop.webp'));
    console.log('✓ journey-1.webp & alexa-backdrop.webp generated');
  }

  const journey2Src = path.join(ARTIFACT_DIR, 'temp_journey_2_png_1792212772080.jpg');
  if (fs.existsSync(journey2Src)) {
    await sharp(journey2Src)
      .resize(900, 675, { fit: 'cover', position: 'center' })
      .webp({ quality: 78 })
      .toFile(path.join(IMAGES_DIR, 'journey-2.webp'));
    console.log('✓ journey-2.webp generated');
  }

  const stayBoutiqueSrc = path.join(ARTIFACT_DIR, 'temp_stay_boutique_1792212508364.jpg');
  if (fs.existsSync(stayBoutiqueSrc)) {
    // Journey 3: Refine
    await sharp(stayBoutiqueSrc)
      .resize(900, 675, { fit: 'cover', position: 'center' })
      .webp({ quality: 78 })
      .toFile(path.join(IMAGES_DIR, 'journey-3.webp'));

    // Thumb Stay Boutique
    await sharp(stayBoutiqueSrc)
      .resize(480, 480, { fit: 'cover', position: 'center' })
      .webp({ quality: 78 })
      .toFile(path.join(IMAGES_DIR, 'thumb-stay-boutique.webp'));
    console.log('✓ journey-3.webp & thumb-stay-boutique.webp generated');
  }

  const stayBudgetSrc = path.join(ARTIFACT_DIR, 'temp_stay_budget_1792212528609.jpg');
  if (fs.existsSync(stayBudgetSrc)) {
    await sharp(stayBudgetSrc)
      .resize(480, 480, { fit: 'cover', position: 'center' })
      .webp({ quality: 78 })
      .toFile(path.join(IMAGES_DIR, 'thumb-stay-budget.webp'));
    console.log('✓ thumb-stay-budget.webp generated');
  }

  const journey4Src = path.join(ARTIFACT_DIR, 'temp_journey_4_png_1792212792150.jpg');
  if (fs.existsSync(journey4Src)) {
    await sharp(journey4Src)
      .resize(900, 675, { fit: 'cover', position: 'center' })
      .webp({ quality: 78 })
      .toFile(path.join(IMAGES_DIR, 'journey-4.webp'));
    console.log('✓ journey-4.webp generated');
  }

  const journey5Src = path.join(ARTIFACT_DIR, 'temp_journey_5_png_1792212811747.jpg');
  if (fs.existsSync(journey5Src)) {
    await sharp(journey5Src)
      .resize(900, 675, { fit: 'cover', position: 'center' })
      .webp({ quality: 78 })
      .toFile(path.join(IMAGES_DIR, 'journey-5.webp'));
    console.log('✓ journey-5.webp generated');
  }

  // 8. Thumbnails (480x480)
  const thumbs = [
    { src: 'raw_train_sleeper.jpg', out: 'thumb-train-sleeper.webp' },
    { src: 'raw_train_ac.jpg', out: 'thumb-train-ac.webp' },
    { src: 'raw_flight.jpg', out: 'thumb-flight.webp' },
    { src: 'raw_bus.jpg', out: 'thumb-bus.webp' },
    { src: 'raw_stay_haveli.jpg', out: 'thumb-stay-haveli.webp' },
    { src: 'raw_cab.jpg', out: 'thumb-cab.webp' },
    { src: 'raw_auto.jpg', out: 'thumb-auto.webp' },
    { src: 'raw_metro.jpg', out: 'thumb-metro.webp' },
    { src: 'raw_rental.jpg', out: 'thumb-rental.webp' }
  ];

  for (const t of thumbs) {
    const srcPath = path.join(IMAGES_DIR, t.src);
    if (fs.existsSync(srcPath)) {
      await sharp(srcPath)
        .resize(480, 480, { fit: 'cover', position: 'center' })
        .webp({ quality: 78 })
        .toFile(path.join(IMAGES_DIR, t.out));
      console.log(`✓ ${t.out} generated`);
    }
  }

  // 9. Destination Banners (21:9 crop, 1600px wide, ~1600x685) & Cards (4:3 crop, 900px wide, ~900x675)
  const dests = [
    { name: 'delhi', src: 'delhi.webp' },
    { name: 'jaipur', src: 'jaipur.webp' },
    { name: 'hampi', src: 'hampi.webp' },
    { name: 'varanasi', src: 'varanasi.webp' },
    { name: 'alleppey', src: 'kerala.webp' },
    { name: 'coorg', src: 'coorg.webp' }
  ];

  for (const d of dests) {
    const srcPath = path.join(IMAGES_DIR, d.src);
    if (fs.existsSync(srcPath)) {
      await sharp(srcPath)
        .resize(1600, 685, { fit: 'cover', position: 'center' })
        .webp({ quality: 78 })
        .toFile(path.join(IMAGES_DIR, `dest-${d.name}-banner.webp`));

      await sharp(srcPath)
        .resize(900, 675, { fit: 'cover', position: 'center' })
        .webp({ quality: 78 })
        .toFile(path.join(IMAGES_DIR, `dest-${d.name}-card.webp`));

      console.log(`✓ dest-${d.name}-banner.webp & dest-${d.name}-card.webp generated`);
    }
  }

  // 10. Experience Thumbs
  if (fs.existsSync(path.join(IMAGES_DIR, 'street-food.webp'))) {
    await sharp(path.join(IMAGES_DIR, 'street-food.webp'))
      .resize(480, 480, { fit: 'cover', position: 'center' })
      .webp({ quality: 78 })
      .toFile(path.join(IMAGES_DIR, 'thumb-exp-culinary.webp'));
    console.log('✓ thumb-exp-culinary.webp generated');
  }

  if (fs.existsSync(path.join(IMAGES_DIR, 'qutub-minar.webp'))) {
    await sharp(path.join(IMAGES_DIR, 'qutub-minar.webp'))
      .resize(480, 480, { fit: 'cover', position: 'center' })
      .webp({ quality: 78 })
      .toFile(path.join(IMAGES_DIR, 'thumb-exp-heritage.webp'));
    console.log('✓ thumb-exp-heritage.webp generated');
  }

  console.log('--- Computing Dominant Tones for Zero Blank Flash ---');
  const imageFiles = fs.readdirSync(IMAGES_DIR).filter(f => f.endsWith('.webp'));
  const colorMap = {};

  for (const f of imageFiles) {
    try {
      const stats = await sharp(path.join(IMAGES_DIR, f)).stats();
      const dom = stats.dominant;
      const hex = '#' + [dom.r, dom.g, dom.b].map(x => x.toString(16).padStart(2, '0')).join('');
      colorMap[f] = hex;
    } catch (e) {
      colorMap[f] = '#F3E9D8';
    }
  }

  fs.writeFileSync(
    path.join(__dirname, '..', 'src', 'data', 'imageColors.json'),
    JSON.stringify(colorMap, null, 2)
  );
  console.log('✓ src/data/imageColors.json written with', Object.keys(colorMap).length, 'colors');

  console.log('=== All Imagery Sourced and Built Successfully ===');
}

main().catch(console.error);
