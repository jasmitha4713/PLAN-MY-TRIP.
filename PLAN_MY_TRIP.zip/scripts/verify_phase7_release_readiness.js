import puppeteer from 'puppeteer-core';
import { existsSync } from 'fs';

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const browserExecutable = existsSync(EDGE_PATH) ? EDGE_PATH : (existsSync(CHROME_PATH) ? CHROME_PATH : null);

async function runPhase7AcceptanceSuite() {
  console.log('=== STARTING PHASE 7 REAL-BROWSER ACCEPTANCE SUITE ===');
  if (!browserExecutable) {
    console.error('No browser executable found!');
    process.exit(1);
  }

  const browser = await puppeteer.launch({
    executablePath: browserExecutable,
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 950 });

  page.on('console', msg => {
    const text = msg.text();
    if (!text.includes('React DevTools') && !text.includes('preloaded using link preload') && !text.includes('Images loaded lazily')) {
      console.log('BROWSER CONSOLE:', msg.type(), text.slice(0, 160));
    }
  });
  page.on('pageerror', err => console.error('BROWSER PAGE ERROR:', err));

  let passed = 0;
  let total = 0;

  function assert(condition, name, details = '') {
    total++;
    if (condition) {
      console.log(`[PASS] ${total}. ${name}`);
      passed++;
    } else {
      console.error(`[FAIL] ${total}. ${name}${details ? ` -> ${details}` : ''}`);
    }
  }

  try {
    // -------------------------------------------------------------
    // SCENARIO 1 & 15: Typed Trip Planning & Traveller Clarification (No Loop)
    // -------------------------------------------------------------
    console.log('\n--- 1. Testing Typed Planning & Clarification Modal ---');
    await page.goto('http://localhost:3000/app?demo=true', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await new Promise(r => setTimeout(r, 1500));

    const textarea = await page.$('textarea[placeholder*="Mumbai"]');
    assert(Boolean(textarea), 'Dashboard rendered with trip intake prompt');

    await textarea.type('Plan a trip to Mumbai for 3 days, 5 to 6 members, budget ₹60,000');
    const planSubmitBtn = await page.$('button[type="submit"]');
    await planSubmitBtn.click();
    await new Promise(r => setTimeout(r, 1000));

    // Confirm sheet visible
    const sheetVisible = await page.evaluate(() => Boolean(document.querySelector('form.p-6.space-y-5')));
    assert(sheetVisible, 'Confirmation sheet opened with parsed intake');

    // Resolve clarification: Click "Plan for 5 travellers"
    const clarifyBtnClicked = await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const b = btns.find(el => el.innerText.includes('Plan for 5'));
      if (b) { b.click(); return true; }
      return false;
    });
    assert(clarifyBtnClicked, 'Resolved traveller clarification by selecting 5 travellers');
    await new Promise(r => setTimeout(r, 800));

    // Click "Plan trip"
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const b = btns.find(el => el.innerText.includes('Plan trip'));
      if (b) b.click();
    });
    await new Promise(r => setTimeout(r, 2500));

    // Must navigate to options flow /app/plan/mumbai and NOT loop modal
    const finalUrl = page.url();
    assert(finalUrl.includes('/app/plan/mumbai'), 'Successfully generated draft and navigated to options flow (/app/plan/mumbai)', finalUrl);
    const modalClosed = await page.evaluate(() => !document.querySelector('form.p-6.space-y-5'));
    assert(modalClosed, 'Confirmation modal closed cleanly without looping');

    // -------------------------------------------------------------
    // SCENARIO 2: Booking Transparency & Non-Auto-Booking Labels
    // -------------------------------------------------------------
    console.log('\n--- 2. Verifying Honest Disclaimers & Booking Labels ---');
    const plannerBodyText = await page.evaluate(() => document.body.innerText);
    assert(
      plannerBodyText.includes('Getting there') && (plannerBodyText.includes('Select') || plannerBodyText.includes('Choose')),
      'Options flow displays selectable transport choices (Step 1: Getting there)'
    );

    // -------------------------------------------------------------
    // SCENARIOS 3, 4, 5: Conversational Assistant & Option Pickers
    // -------------------------------------------------------------
    console.log('\n--- 3. Testing Conversational Option Pickers & Travel Comparison ---');
    // Navigate to Trip Companion hub
    await page.goto('http://localhost:3000/app/trip/PMT-0142?demo=true', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await new Promise(r => setTimeout(r, 1500));

    // Ensure on Companion Tab
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const b = btns.find(el => el.innerText.includes('Companion'));
      if (b) b.click();
    });
    await new Promise(r => setTimeout(r, 1000));

    const sendChat = async (msg) => {
      console.log(`User sends: "${msg}"`);
      await page.waitForSelector('input[placeholder*="companion"], input[placeholder*="Speak or type"]', { timeout: 10000 });
      const input = await page.$('input[placeholder*="companion"], input[placeholder*="Speak or type"]');
      await input.click({ clickCount: 3 });
      await input.press('Backspace');
      await input.type(msg);
      await input.press('Enter');

      await page.waitForFunction(
        () => !document.querySelector('.animate-spin'),
        { timeout: 15000 }
      );
      await new Promise(r => setTimeout(r, 1200));

      const reply = await page.evaluate(() => {
        const ps = Array.from(document.querySelectorAll('p.leading-relaxed.whitespace-pre-line'));
        return ps[ps.length - 1]?.innerText || '';
      });
      console.log(`Assistant reply: "${reply.slice(0, 140)}..."`);
      return reply;
    };

    // Interaction 1: User asks for initial plan
    const planConversation = await sendChat('Plan a three-day trip to Mumbai for five people with a budget of ₹60,000.');
    assert(
      planConversation.includes('60,000') && (planConversation.includes('travel dates') || planConversation.includes('comparing transport')),
      'Assistant answers with conversational prompt: "Sure. I\'ll help you plan it within ₹60,000..."'
    );

    // Interaction 2: User asks to take cheapest train
    const cheapestTrainReply = await sendChat('Take the cheapest train.');
    assert(
      cheapestTrainReply.includes("I'll compare the available train options first") || cheapestTrainReply.includes('Overnight Sleeper Train'),
      'Assistant compares train options first before proceeding to book'
    );
    const hasTrainCard = await page.evaluate(() => {
      return document.body.innerText.includes('Overnight Sleeper Train') && document.body.innerText.includes('₹1,050/person');
    });
    assert(hasTrainCard, 'Option picker renders selectable train cards with fares and cancellation terms');

    // Interaction 3: User says "Actually, I prefer a bus."
    const preferBusReply = await sendChat('Actually, I prefer a bus.');
    assert(
      preferBusReply.includes("switch the transport comparison to buses") || preferBusReply.includes('buses'),
      'Assistant recognizes user preference shift and switches comparison to buses'
    );
    const hasBusCard = await page.evaluate(() => {
      return document.body.innerText.includes('Overnight AC Sleeper Bus') || document.body.innerText.includes('Express Volvo');
    });
    assert(hasBusCard, 'Option picker dynamically renders selectable bus alternatives');

    // Interaction 4: User says "Show me another hotel."
    const hotelReply = await sendChat('Show me another hotel.');
    assert(
      hotelReply.includes("I'll keep your selected transport and show alternative accommodation") || hotelReply.includes('accommodation options'),
      'Assistant preserves transport selection and presents hotel options'
    );
    const hasHotelCard = await page.evaluate(() => {
      return document.body.innerText.includes('Budget Hostel Room') && document.body.innerText.includes('Boutique Hotel');
    });
    assert(hasHotelCard, 'Option picker renders selectable hotels with room tiers and cancellation policies');

    // Interaction 5: User selects an option
    const selectHotelReply = await sendChat('Select stay stay-hostel');
    assert(
      selectHotelReply.includes('Budget Hostel Room') && selectHotelReply.includes('cushion'),
      'Selecting option updates trip draft and recalculates budget cushion without placing fake booking'
    );

    // Interaction 6: User asks "What happens if my bus is cancelled?"
    const cancelExplainReply = await sendChat('What happens if my bus is cancelled?');
    assert(
      cancelExplainReply.includes('refund') && cancelExplainReply.includes('explicit approval'),
      'Assistant provides concise explanation of cancellation policy and safety rules'
    );

    // Interaction 7: Exploratory query "Cancel my current bus and show me alternatives"
    const exploreCancelReply = await sendChat('Cancel my current bus and show me alternatives');
    assert(
      exploreCancelReply.includes('keeping your current') || exploreCancelReply.includes('active and confirmed'),
      'Exploratory query leaves existing ticket intact and does not trigger destructive cancellation'
    );

    // -------------------------------------------------------------
    // SCENARIO 8 & 9: Action Approval Gate & Rejection
    // -------------------------------------------------------------
    console.log('\n--- 4. Testing Action Approval Gate, Rejection & Execution ---');
    // Prepare a recovery action explicitly
    await sendChat('Prepare recovery action for priority cab');
    await new Promise(r => setTimeout(r, 1000));

    const approvalCardVisible = await page.evaluate(() => {
      return Boolean(document.querySelector('button') && document.body.innerText.includes("Don't send"));
    });
    assert(approvalCardVisible, 'Approval gate card rendered with explicit "Don\'t send" and "Approve & Send" buttons');

    // Click "Don't send" / Reject
    const rejectedClicked = await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const b = btns.find(el => el.innerText.includes("Don't send"));
      if (b) { b.click(); return true; }
      return false;
    });
    assert(rejectedClicked, 'Clicked "Don\'t send" to reject staged action');
    await new Promise(r => setTimeout(r, 1500));

    const rejectionText = await page.evaluate(() => document.body.innerText);
    assert(
      rejectionText.includes('rejected') || rejectionText.includes('Cancelled') || rejectionText.includes('Proposal Rejected'),
      'Staged action was rejected cleanly without executing any booking changes'
    );

    // -------------------------------------------------------------
    // SCENARIO 10: Food & Activity Customization
    // -------------------------------------------------------------
    console.log('\n--- 5. Testing Food & Activity Preferences ---');
    const foodReply = await sendChat('What about food and dining for this trip?');
    assert(
      foodReply.includes('food') || foodReply.includes('dining'),
      'Food & dining advice provided with real-time budget cushion tracking and no auto-reservations'
    );

    // -------------------------------------------------------------
    // SCENARIO 12: Voice Settings Configuration Modal
    // -------------------------------------------------------------
    console.log('\n--- 6. Testing Voice Configuration & Persistence ---');
    const voiceSettingsBtn = await page.$('button[title*="Voice assistant settings"], button[title*="Configure voice"]');
    assert(Boolean(voiceSettingsBtn), 'Voice settings configuration button is visible in companion interface');

    if (voiceSettingsBtn) {
      await voiceSettingsBtn.click();
      await new Promise(r => setTimeout(r, 800));

      const voiceModalVisible = await page.evaluate(() => {
        return Boolean(document.body.innerText.includes('Voice Assistant Settings') && document.body.innerText.includes('Speech Speed'));
      });
      assert(voiceModalVisible, 'Voice settings modal opens with speech speed and browser voice selector');

      // Click "Done" on voice settings
      await page.evaluate(() => {
        const btns = Array.from(document.querySelectorAll('button'));
        const b = btns.find(el => el.innerText.trim() === 'Done');
        if (b) b.click();
      });
      await new Promise(r => setTimeout(r, 600));
    }

    // -------------------------------------------------------------
    // SCENARIO 16: Saved Trip Persistence Across Reload
    // -------------------------------------------------------------
    console.log('\n--- 7. Testing State Persistence Across Page Refresh ---');
    await page.reload({ waitUntil: 'domcontentloaded' });
    await new Promise(r => setTimeout(r, 1500));

    const postReloadUrl = page.url();
    assert(postReloadUrl.includes('/app/trip/'), 'Active trip URL preserved across full browser reload');
    const reloadedText = await page.evaluate(() => document.body.innerText);
    assert(reloadedText.includes('Journey Hub') || reloadedText.includes('Itinerary'), 'Trip state restored cleanly from storage');

    console.log(`\n======================================================`);
    console.log(`PHASE 7 ACCEPTANCE RESULT: ${passed}/${total} SCENARIOS VERIFIED`);
    console.log(`======================================================`);

    if (passed === total) {
      console.log('SUCCESS: All Phase 7 release acceptance requirements verified in real browser!');
    } else {
      console.error(`FAILURE: ${total - passed} scenarios failed.`);
      process.exitCode = 1;
    }

  } catch (err) {
    console.error('Phase 7 test execution error:', err);
    process.exitCode = 1;
  } finally {
    await browser.close();
  }
}

runPhase7AcceptanceSuite();
