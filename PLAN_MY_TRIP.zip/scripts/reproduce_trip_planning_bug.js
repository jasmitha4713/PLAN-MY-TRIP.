import puppeteer from 'puppeteer-core';
import { existsSync } from 'fs';

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const browserExecutable = existsSync(EDGE_PATH) ? EDGE_PATH : (existsSync(CHROME_PATH) ? CHROME_PATH : null);

async function reproduceTripPlanningBug() {
  console.log('--- REPRODUCING TRIP PLANNING FLOW IN REAL BROWSER ---');
  const browser = await puppeteer.launch({
    executablePath: browserExecutable,
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 950 });

  const consoleLogs = [];
  page.on('console', msg => {
    consoleLogs.push({ type: msg.type(), text: msg.text() });
    console.log(`BROWSER CONSOLE [${msg.type()}]:`, msg.text());
  });

  const networkRequests = [];
  page.on('request', req => {
    if (req.url().includes('localhost')) {
      networkRequests.push({ method: req.method(), url: req.url(), postData: req.postData() });
      console.log(`NETWORK REQ: ${req.method()} ${req.url()}`, req.postData() || '');
    }
  });

  page.on('response', async res => {
    if (res.url().includes('localhost') && !res.url().endsWith('.js') && !res.url().endsWith('.css')) {
      try {
        const text = await res.text();
        console.log(`NETWORK RES: ${res.status()} ${res.url()}`, text.slice(0, 200));
      } catch {}
    }
  });

  try {
    console.log('Step 1: Navigating to http://localhost:3000/app?demo=true');
    await page.goto('http://localhost:3000/app?demo=true', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await new Promise(r => setTimeout(r, 1500));

    console.log('Current URL:', page.url());

    console.log('Step 2: Typing prompt into textarea');
    const textarea = await page.$('textarea[placeholder*="Mumbai"]');
    if (!textarea) {
      console.error('Could not find textarea on /app!');
      return;
    }
    await textarea.type('Plan a trip to Mumbai for 3 days, 5 to 6 members, budget ₹60,000');
    await new Promise(r => setTimeout(r, 500));

    console.log('Step 3: Clicking "Plan" button to submit');
    const planBtn = await page.$('button[type="submit"]');
    await planBtn.click();
    await new Promise(r => setTimeout(r, 1500));

    console.log('Step 4: Checking if ConfirmTripSheet opened');
    const modalVisible = await page.evaluate(() => {
      const modal = document.querySelector('form.p-6.space-y-5');
      return Boolean(modal);
    });
    console.log('Modal visible:', modalVisible);

    const modalText = await page.evaluate(() => {
      const sheet = document.querySelector('.bg-paper.w-full.max-w-2xl');
      return sheet ? sheet.innerText : 'NO MODAL FOUND';
    });
    console.log('Modal text preview:\n', modalText.slice(0, 300));

    console.log('Step 5: Clicking "Plan for 5 travellers" clarification button if present');
    const clarificationClicked = await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const clarifyBtn = btns.find(b => b.innerText.includes('Plan for 5'));
      if (clarifyBtn) {
        clarifyBtn.click();
        return true;
      }
      return false;
    });
    console.log('Clarification button clicked:', clarificationClicked);
    await new Promise(r => setTimeout(r, 1000));

    console.log('Step 6: Clicking bottom "Plan trip" button');
    const submitClicked = await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const planTripBtn = btns.find(b => b.innerText.includes('Plan trip'));
      if (planTripBtn) {
        planTripBtn.click();
        return true;
      }
      return false;
    });
    console.log('Bottom "Plan trip" button clicked:', submitClicked);
    await new Promise(r => setTimeout(r, 3000));

    console.log('Step 7: Checking final URL and modal state');
    console.log('Final URL after submit:', page.url());

    const isModalStillOpen = await page.evaluate(() => {
      const modal = document.querySelector('form.p-6.space-y-5');
      return Boolean(modal);
    });
    console.log('Is modal still open?', isModalStillOpen);

  } catch (err) {
    console.error('Error in reproduction:', err);
  } finally {
    await browser.close();
  }
}

reproduceTripPlanningBug();
