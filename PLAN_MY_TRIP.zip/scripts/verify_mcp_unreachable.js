import puppeteer from 'puppeteer-core';
import { existsSync } from 'fs';

const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const browserExecutable = existsSync(EDGE_PATH) ? EDGE_PATH : (existsSync(CHROME_PATH) ? CHROME_PATH : null);

async function testMcpUnreachable() {
  console.log('--- TEST E: Verifying Clean Connection Error when MCP is Stopped ---');
  const browser = await puppeteer.launch({
    executablePath: browserExecutable,
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 900 });

  let pageError = null;
  page.on('pageerror', err => {
    pageError = err.message;
    console.error('BROWSER PAGE ERROR:', err);
  });

  try {
    await page.goto('http://localhost:3000/app/trip/trip_del_jai_001?tab=companion&demo=true', {
      waitUntil: 'domcontentloaded',
      timeout: 30000
    });

    await page.waitForSelector('input[placeholder*="companion"], input[placeholder*="Speak or type"]', { timeout: 15000 });

    console.log('\nSending request when MCP is stopped...');
    const inputEl = await page.$('input[placeholder*="companion"], input[placeholder*="Speak or type"]');
    await inputEl.click();
    await inputEl.type('What is my current trip budget?');
    await page.keyboard.press('Enter');

    await new Promise(r => setTimeout(r, 3500));

    const result = await page.evaluate(() => {
      const text = document.body.innerText;
      return {
        hasConnectionNotice: text.includes('unreachable') || text.includes('Connection refused') || text.includes('MCP Server'),
        hasNullPropertyCrash: text.includes('Cannot read properties of null') || text.includes('TypeError'),
        hasFakeSuccess: text.includes('Retrieved live')
      };
    });

    console.log('Test E Result:', result);
    console.log('Page JavaScript Error:', pageError);

    if (result.hasConnectionNotice && !result.hasNullPropertyCrash) {
      console.log('TEST E PASSED: Clean connection error displayed without null-property crash!');
    } else {
      console.log('TEST E RESULT FAILED:', result);
    }
  } catch (e) {
    console.error('Test E Error:', e);
  } finally {
    await browser.close();
  }
}

testMcpUnreachable();
