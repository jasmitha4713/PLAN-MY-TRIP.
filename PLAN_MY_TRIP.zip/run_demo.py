"""One-click demonstration runner for PLAN MY TRIP Alexa+ MCP Integration.

Executes the complete India-first travel disruption and recovery workflow
strictly through the Model Context Protocol (MCP Spec 2025-11-25+)
over Streamable HTTP (/mcp) using tools/list and tools/call:
1. Session Initialization & Tool Discovery (tools/list)
2. Trip Planning & Itinerary Generation via tools/call (plan_trip)
3. Saved Trip Retrieval via tools/call (get_saved_trip)
4. Proactive Disruption Impact Assessment via tools/call (assess_disruption)
5. Action Preparation & Safety Approval Gate via tools/call (prepare_recovery_action)
6. Action Execution Confirmation & Audit Receipt via tools/call (approve_recovery_action)
7. Safety Rejection Verification via tools/call (approve_recovery_action with approved=False)
"""

import asyncio
import io
import json
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent))

# Ensure UTF-8 output on Windows consoles
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
import httpx
import uvicorn

from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamable_http_client
from alexa_mcp.server import app as mcp_app
from mock_backend.app import app as mock_app
from alexa_mcp.backend_client import BackendClient, set_backend_client


class Colors:
    CYAN = "\033[96m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    BOLD = "\033[1m"
    MAGENTA = "\033[95m"
    RESET = "\033[0m"


async def main():
    print(f"\n{Colors.BOLD}{Colors.CYAN}" + "=" * 76)
    print("  PLAN MY TRIP — Alexa+ Track MCP Server Live Demonstration")
    print("  MCP Protocol: Spec 2025-11-25+ | Transport: Streamable HTTP (/mcp)")
    print("=" * 76 + f"{Colors.RESET}\n")

    # Ensure backend client routes to mock app in-memory
    transport = httpx.ASGITransport(app=mock_app)
    set_backend_client(BackendClient(base_url="http://testbackend", transport=transport))

    # Check if a server is already running on port 8001
    server_task = None
    mcp_url = "http://127.0.0.1:8001/mcp"
    already_running = False

    try:
        async with httpx.AsyncClient(timeout=0.4) as client:
            resp = await client.get("http://127.0.0.1:8001/health")
            if resp.status_code == 200:
                already_running = True
                print(f"{Colors.GREEN}✓ Connected to running MCP server at {mcp_url}{Colors.RESET}")
    except Exception:
        already_running = False

    if not already_running:
        print(f"{Colors.YELLOW}ℹ Starting MCP Streamable HTTP server on 127.0.0.1:8001...{Colors.RESET}")
        config = uvicorn.Config(mcp_app, host="127.0.0.1", port=8001, log_level="warning")
        server = uvicorn.Server(config)
        server_task = asyncio.create_task(server.serve())
        await asyncio.sleep(0.6)

    try:
        async with streamable_http_client(mcp_url) as (read_stream, write_stream):
            async with ClientSession(read_stream, write_stream) as session:
                # --- Step 0: Initialize MCP Session ---
                print(f"{Colors.BOLD}[Phase 0] Initializing MCP Session over Streamable HTTP...{Colors.RESET}")
                init_res = await session.initialize()
                print(f"  {Colors.GREEN}✓ Protocol Handshake Success: Spec {init_res.protocol_version}{Colors.RESET}")
                print(f"  {Colors.GREEN}✓ Server Name: {init_res.server_info.name} v{init_res.server_info.version}{Colors.RESET}")

                # --- Tool Discovery via tools/list ---
                print(f"\n{Colors.BOLD}[Phase 1] Discovering Registered Tools via MCP 'tools/list'...{Colors.RESET}")
                tools_res = await session.list_tools()
                tool_names = [t.name for t in tools_res.tools]
                print(f"  {Colors.GREEN}✓ Discovered {len(tool_names)} Registered MCP Tools:{Colors.RESET}")
                for t in tools_res.tools:
                    print(f"    • {Colors.BOLD}{t.name}{Colors.RESET}: {t.description[:60]}...")

                # --- Step 1: tools/call -> plan_trip ---
                print(f"\n{Colors.BOLD}[Step 1] Invoking 'tools/call' -> 'plan_trip' (Delhi to Jaipur, Budget ₹5,000)...{Colors.RESET}")
                plan_call = await session.call_tool(
                    name="plan_trip",
                    arguments={
                        "origin": "Delhi",
                        "destination": "Jaipur",
                        "budget_inr": 5000.0,
                        "start_date": "2026-11-01",
                        "end_date": "2026-11-03",
                        "travelers_count": 1,
                        "preferences": ["budget", "heritage", "veg_food"],
                    },
                )
                plan_raw = json.loads(plan_call.content[0].text)
                if plan_raw.get("status") == "success":
                    data = plan_raw["data"]
                    print(f"  {Colors.GREEN}✓ Tool 'plan_trip' Succeeded via MCP!{Colors.RESET}")
                    print(f"    Trip ID: {data['trip_id']}")
                    print(f"    Estimated Total: Rs. {data['estimated_cost_inr']} (Budget: Rs. {data['total_budget_inr']})")
                    print(f"    Transport: {data['transport']['mode'].upper()} - Rs. {data['transport']['cost_inr']}")
                    print(f"    Hotel: {data['accommodation']['name']} - Rs. {data['accommodation']['cost_inr']}")
                else:
                    print(f"  {Colors.RED}✗ Planning failed: {plan_raw.get('error')}{Colors.RESET}")
                    sys.exit(1)

                # --- Step 2: tools/call -> get_saved_trip ---
                print(f"\n{Colors.BOLD}[Step 2] Invoking 'tools/call' -> 'get_saved_trip' (trip_del_jai_001)...{Colors.RESET}")
                saved_call = await session.call_tool(
                    name="get_saved_trip",
                    arguments={"trip_id": "trip_del_jai_001"},
                )
                saved_raw = json.loads(saved_call.content[0].text)
                if saved_raw.get("status") == "success":
                    trip = saved_raw["data"]
                    print(f"  {Colors.GREEN}✓ Retrieved Trip via MCP: '{trip['title']}'{Colors.RESET}")
                    print(f"    Bus: {trip['transport']['operator']} ({trip['transport']['bus_number']})")
                    print(f"    Departure: {trip['transport']['departure_time']} | Scheduled Arrival: {trip['transport']['scheduled_arrival_time']}")
                    print(f"    Hotel: {trip['accommodation']['name']} (Scheduled check-in: {trip['accommodation']['check_in_time']})")
                else:
                    print(f"  {Colors.RED}✗ Retrieval failed: {saved_raw.get('error')}{Colors.RESET}")
                    sys.exit(1)

                # --- Step 3: tools/call -> assess_disruption ---
                print(f"\n{Colors.BOLD}[Step 3] Invoking 'tools/call' -> 'assess_disruption' (180-minute bus breakdown)...{Colors.RESET}")
                disrupt_call = await session.call_tool(
                    name="assess_disruption",
                    arguments={
                        "trip_id": "trip_del_jai_001",
                        "disruption_type": "bus_delay",
                        "delay_minutes": 180,
                        "notes": "Engine breakdown on Delhi-Jaipur highway",
                    },
                )
                disrupt_raw = json.loads(disrupt_call.content[0].text)
                if disrupt_raw.get("status") == "success":
                    disrupt = disrupt_raw["data"]
                    impact = disrupt["impact"]
                    print(f"  {Colors.YELLOW}⚠ Disruption Analyzed via MCP: Severity = {disrupt['disruption']['severity'].upper()}{Colors.RESET}")
                    print(f"    Hotel Impact: {'CRITICAL - Late Check-in Required' if impact['hotel_check_in_affected'] else 'OK'}")
                    print(f"    Impact Details: {impact['check_in_notes']}")
                    print(f"\n    Recovery Options Generated by Proactive Engine:")
                    for idx, opt in enumerate(disrupt["recovery_options"], 1):
                        cost_str = "Free" if opt["cost_inr"] == 0 else f"Rs. {opt['cost_inr']}"
                        print(f"      {idx}. {opt['title']} [{cost_str}]")
                else:
                    print(f"  {Colors.RED}✗ Disruption assessment failed: {disrupt_raw.get('error')}{Colors.RESET}")
                    sys.exit(1)

                # --- Step 4: tools/call -> prepare_recovery_action ---
                print(f"\n{Colors.BOLD}[Step 4] Invoking 'tools/call' -> 'prepare_recovery_action' (Safety Gate)...{Colors.RESET}")
                prep_call = await session.call_tool(
                    name="prepare_recovery_action",
                    arguments={
                        "trip_id": "trip_del_jai_001",
                        "action_type": "notify_hotel_late_checkin",
                        "selected_option_id": "opt_reschedule_checkin",
                        "estimated_cost_inr": 0.0,
                    },
                )
                prep_raw = json.loads(prep_call.content[0].text)
                if prep_raw.get("status") == "success":
                    action = prep_raw["data"]
                    action_id = action["action_id"]
                    print(f"  {Colors.CYAN}🔒 Safety Gate Enforced: Action Staged ({action_id}){Colors.RESET}")
                    print(f"    Status: {action['status'].upper()} (Execution Blocked until User Confirms)")
                    print(f"    Requires Approval: {action['requires_user_approval']}")
                    print(f"    Spoken Approval Prompt for Alexa+: \"{action['approval_prompt']}\"")
                else:
                    print(f"  {Colors.RED}✗ Preparation failed: {prep_raw.get('error')}{Colors.RESET}")
                    sys.exit(1)

                # --- Step 5: tools/call -> approve_recovery_action ---
                print(f"\n{Colors.BOLD}[Step 5] Invoking 'tools/call' -> 'approve_recovery_action' (User Approves)...{Colors.RESET}")
                appr_call = await session.call_tool(
                    name="approve_recovery_action",
                    arguments={
                        "action_id": action_id,
                        "approved": True,
                        "user_confirmation": "Yes Alexa, confirm notice",
                    },
                )
                appr_raw = json.loads(appr_call.content[0].text)
                if appr_raw.get("status") == "success":
                    result = appr_raw["data"]
                    print(f"  {Colors.GREEN}✓ Action Executed Successfully via MCP!{Colors.RESET}")
                    print(f"    Status: {result['status'].upper()}")
                    print(f"    Audit Receipt ID: {result['receipt_id']}")
                    print(f"    Confirmation: {result['message']}")
                else:
                    print(f"  {Colors.RED}✗ Approval failed: {appr_raw.get('error')}{Colors.RESET}")
                    sys.exit(1)

                # --- Step 6: Verify Safety Gate Rejection ---
                print(f"\n{Colors.BOLD}[Step 6] Verifying Safety Gate Rejection via MCP...{Colors.RESET}")
                prep_call2 = await session.call_tool(
                    name="prepare_recovery_action",
                    arguments={
                        "trip_id": "trip_del_jai_001",
                        "action_type": "book_cab",
                        "selected_option_id": "opt_express_cab",
                        "estimated_cost_inr": 1200.0,
                    },
                )
                prep_raw2 = json.loads(prep_call2.content[0].text)
                action_id2 = prep_raw2["data"]["action_id"]

                reject_call = await session.call_tool(
                    name="approve_recovery_action",
                    arguments={
                        "action_id": action_id2,
                        "approved": False,
                        "user_confirmation": "No, cancel that",
                    },
                )
                reject_raw = json.loads(reject_call.content[0].text)
                print(f"  {Colors.GREEN}✓ Rejection Handled Safely via MCP: Status = '{reject_raw['status']}'{Colors.RESET}")
                print(f"    Message: {reject_raw['message']}")

                print(f"\n{Colors.BOLD}{Colors.GREEN}" + "=" * 76)
                print("  ALL DEMO PHASES PASSED 100% OVER STREAMABLE HTTP MCP (tools/list & tools/call)!")
                print("=" * 76 + f"{Colors.RESET}\n")

    finally:
        if server_task is not None:
            server.should_exit = True
            await server_task


if __name__ == "__main__":
    asyncio.run(main())
