export type TransportType = 'bus' | 'train' | 'flight';

export interface TransportOption {
  id: string;
  type: TransportType;
  operator: string;
  serviceName: string;
  vehicleNumber?: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  origin: string;
  destination: string;
  boardingPoint: string;
  dropPoint: string;
  pricePerPerson: number;
  rating: number;
  reviewCount: number;
  amenities: string[];
  cancellationPolicy: string;
  image: string;
  sourceLabel: 'DEMO DATA' | 'ESTIMATED';
  seatType?: string;
}

export interface AccommodationOption {
  id: string;
  name: string;
  location: string;
  city: string;
  roomType: string;
  pricePerNight: number;
  rating: number;
  reviewCount: number;
  amenities: string[];
  cancellationPolicy: string;
  checkInTime: string;
  checkOutTime: string;
  image: string;
  sourceLabel: 'DEMO DATA' | 'ESTIMATED';
}

export interface TransferOption {
  id: string;
  title: string;
  type: 'arrival_transfer' | 'departure_transfer' | 'round_trip';
  vehicleType: string;
  capacity: string;
  pickupPoint: string;
  dropPoint: string;
  price: number;
  estimatedMinutes: number;
  operator: string;
  image?: string;
}

export interface LocalCabPackage {
  id: string;
  name: string;
  vehicleType: string;
  hours: number;
  kmIncluded: number;
  price: number;
  idealFor: string;
}

export interface RentalVehicleOption {
  id: string;
  name: string;
  vehicleType: 'scooter' | 'car' | 'bike';
  transmission: 'manual' | 'automatic';
  dailyRate: number;
  pickupLocation: string;
  securityDeposit: number;
  fuelPolicy: string;
  image: string;
}

export interface ActivityOption {
  id: string;
  title: string;
  category: 'heritage' | 'nature' | 'food' | 'culture' | 'experience';
  location: string;
  city: string;
  duration: string;
  price: number;
  rating: number;
  image: string;
  description: string;
  isCustom?: boolean;
  assignedDay?: number;
  transitOption?: 'walking' | 'auto_rickshaw' | 'cab_transfer' | 'included_in_pass';
  transitPrice?: number;
}

export interface TripDraft {
  id: string;
  title: string;
  origin: string;
  destination: string;
  departureDate: string;
  returnDate: string;
  durationDays: number;
  travellersCount: number;
  totalBudget: number;
  travelStyle: 'budget' | 'comfortable' | 'fast';
  foodPreference: 'all' | 'vegetarian' | 'vegan' | 'local_specialties';
  interests: string[];
  accessibilityNotes?: string;
  customPrompt?: string;
}

export interface BudgetSummary {
  totalBudget: number;
  transportCost: number;
  accommodationCost: number;
  transfersCost: number;
  localCabsCost: number;
  rentalCost: number;
  activitiesCost: number;
  foodEstimateCost: number;
  emergencyBuffer: number;
  totalCalculatedCost: number;
  remainingBudget: number;
  isOverBudget: boolean;
  overBudgetAmount: number;
}

export interface TravellerDetail {
  id: string;
  isPrimary: boolean;
  fullName: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  email?: string;
  phone?: string;
  idProofType?: 'none' | 'passport' | 'voter_id' | 'driving_license';
  idProofNumber?: string;
}

export interface SavedTrip {
  id: string;
  userId: string;
  title: string;
  draft: TripDraft;
  selectedTransport?: TransportOption | null;
  selectedAccommodation?: AccommodationOption | null;
  selectedTransfers: TransferOption[];
  selectedCabPackage?: LocalCabPackage | null;
  selectedRental?: RentalVehicleOption | null;
  selectedActivities: ActivityOption[];
  foodEstimatePerDay: number;
  budgetSummary: BudgetSummary;
  travellers: TravellerDetail[];
  bookingReference: string;
  bookingStatus: 'DRAFT' | 'CONFIRMED' | 'DEMO_CONFIRMED' | 'COMPLETED' | 'CANCELLED';
  paymentStatus: 'UNPAID' | 'SIMULATED_SUCCESS';
  paymentMethod?: string;
  createdAt: string;
  updatedAt: string;
}

export interface RescueDisruption {
  id: string;
  tripId: string;
  issueType: 'bus_delay' | 'train_delay' | 'flight_disruption' | 'hotel_issue' | 'weather' | 'custom';
  description: string;
  reportedAt: string;
  delayMinutes: number;
  affectedItems: {
    title: string;
    detail: string;
    severity: 'high' | 'medium' | 'low';
  }[];
  alternatives: {
    id: string;
    title: string;
    actionDescription: string;
    extraCost: number;
    newArrivalTime: string;
    recommendationNote: string;
    reliability: 'High' | 'Medium' | 'Subject to availability';
  }[];
  selectedAlternativeId?: string;
  approvalStatus: 'NOT_SUBMITTED' | 'PENDING' | 'CONFIRMED' | 'FAILED';
  approvalMessage?: string;
}
