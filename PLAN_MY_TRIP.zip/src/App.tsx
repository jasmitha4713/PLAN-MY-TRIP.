import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import CreditsPage from './pages/CreditsPage';
import AppLayout from './components/app/AppLayout';
import DashboardPage from './pages/app/DashboardPage';
import PlannerPage from './pages/app/PlannerPage';
import PlanTripPage from './pages/app/PlanTripPage';
import CheckoutPage from './pages/app/CheckoutPage';
import BookedTripPage from './pages/app/BookedTripPage';
import MyTripsPage from './pages/app/MyTripsPage';
import JourneyRescuePage from './pages/app/JourneyRescuePage';
import AlexaPage from './pages/app/AlexaPage';
import AlexaDebugPage from './pages/app/AlexaDebugPage';
import ProfilePage from './pages/app/ProfilePage';
import { AuthProvider } from './context/AuthContext';
import { TripProvider } from './context/TripContext';
import AuthModal from './components/AuthModal';

export default function App() {
  return (
    <AuthProvider>
      <TripProvider>
        <BrowserRouter>
          <Routes>
            {/* Public Landing & Attribution */}
            <Route path="/" element={<LandingPage />} />
            <Route path="/credits" element={<CreditsPage />} />

            {/* Authenticated Workspace */}
            <Route path="/app" element={<AppLayout />}>
              <Route index element={<DashboardPage />} />
              <Route path="planner" element={<PlannerPage />} />
              <Route path="plan" element={<PlanTripPage />} />
              <Route path="plan/:id" element={<PlanTripPage />} />
              <Route path="plan/:id/:subStep" element={<CheckoutPage />} />
              <Route path="trip/:id" element={<BookedTripPage />} />
              <Route path="trips" element={<MyTripsPage />} />
              <Route path="rescue" element={<JourneyRescuePage />} />
              <Route path="alexa" element={<AlexaPage />} />
              <Route path="alexa-debug" element={<AlexaDebugPage />} />
              <Route path="profile" element={<ProfilePage />} />
            </Route>

            {/* Catch-all redirect */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
          <AuthModal />
        </BrowserRouter>
      </TripProvider>
    </AuthProvider>
  );
}
