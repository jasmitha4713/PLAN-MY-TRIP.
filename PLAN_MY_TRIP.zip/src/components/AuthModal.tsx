import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  X, 
  Mail, 
  Phone, 
  Sparkles, 
  AlertCircle, 
  Loader2, 
  Compass,
  ArrowRight
} from 'lucide-react';
import { useAuth, formatAuthError } from '../context/AuthContext';
import { useTrip } from '../context/TripContext';

export default function AuthModal() {
  const {
    isAuthModalOpen,
    closeAuthModal,
    signInWithGoogle,
    signInWithEmail,
    signUpWithEmail,
    setupRecaptcha,
    sendPhoneOtp,
    confirmPhoneOtp,
    signInWithDemoUser,
    authError,
    clearError
  } = useAuth();

  const { resetTrip } = useTrip();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState<'google' | 'email' | 'phone'>('google');
  const [emailMode, setEmailMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  const [phoneNumber, setPhoneNumber] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [confirmationResult, setConfirmationResult] = useState<any>(null);
  const [otpSent, setOtpSent] = useState(false);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);

  useEffect(() => {
    if (!isAuthModalOpen) {
      setEmail('');
      setPassword('');
      setName('');
      setPhoneNumber('');
      setVerificationCode('');
      setConfirmationResult(null);
      setOtpSent(false);
      setLocalError(null);
      setIsSubmitting(false);
      clearError();
    }
  }, [isAuthModalOpen, clearError]);

  if (!isAuthModalOpen) return null;

  const handleSuccess = () => {
    closeAuthModal();
    navigate('/app');
  };

  // 1. Instant Guest Demo Login (Zero Firebase Network Call)
  const handleGuestDemo = async () => {
    setLocalError(null);
    clearError();
    setIsSubmitting(true);
    try {
      await signInWithDemoUser();
      // Ensure default demo trip is ready
      resetTrip('New Delhi', 15000, 3, 2);
      handleSuccess();
    } catch (err: any) {
      setLocalError('Failed to initialize guest demo session.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // 2. Google Sign In
  const handleGoogleSignIn = async () => {
    setLocalError(null);
    clearError();
    setIsSubmitting(true);
    try {
      const user = await signInWithGoogle();
      if (user) handleSuccess();
    } catch (err: any) {
      console.error('Google sign in error in modal:', err);
      const friendly = formatAuthError(err?.code || err?.message || '');
      setLocalError(friendly);
    } finally {
      setIsSubmitting(false);
    }
  };

  // 3. Email & Password Sign In / Sign Up
  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    clearError();

    if (!email || !password) {
      setLocalError('Please fill in both email and password.');
      return;
    }
    if (password.length < 6) {
      setLocalError('Password must be at least 6 characters long.');
      return;
    }

    setIsSubmitting(true);
    try {
      let user;
      if (emailMode === 'signup') {
        user = await signUpWithEmail(email, password, name.trim() || undefined);
      } else {
        user = await signInWithEmail(email, password);
      }
      if (user) handleSuccess();
    } catch (err: any) {
      const friendly = formatAuthError(err?.code || err?.message || '');
      setLocalError(friendly);
    } finally {
      setIsSubmitting(false);
    }
  };

  // 4. Phone Auth
  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    clearError();

    const cleanPhone = phoneNumber.trim();
    if (!cleanPhone || cleanPhone.length < 10) {
      setLocalError('Please enter a valid phone number (e.g. +91 9876543210).');
      return;
    }

    const formattedPhone = cleanPhone.startsWith('+') ? cleanPhone : `+91${cleanPhone}`;

    setIsSubmitting(true);
    try {
      const verifier = setupRecaptcha('recaptcha-container');
      const confirmation = await sendPhoneOtp(formattedPhone, verifier);
      setConfirmationResult(confirmation);
      setOtpSent(true);
    } catch (err: any) {
      const friendly = formatAuthError(err?.code || err?.message || '');
      setLocalError(friendly);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);
    clearError();

    if (!verificationCode || verificationCode.trim().length !== 6) {
      setLocalError('Please enter the 6-digit verification code.');
      return;
    }

    if (!confirmationResult) {
      setLocalError('Session expired. Please request a new code.');
      setOtpSent(false);
      return;
    }

    setIsSubmitting(true);
    try {
      const user = await confirmPhoneOtp(confirmationResult, verificationCode.trim());
      if (user) handleSuccess();
    } catch (err: any) {
      const friendly = formatAuthError(err?.code || err?.message || '');
      setLocalError(friendly);
    } finally {
      setIsSubmitting(false);
    }
  };

  const displayedError = localError || authError;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-ink/75 font-sans"
      aria-modal="true"
      role="dialog"
      aria-labelledby="auth-modal-title"
    >
      <div id="recaptcha-container" />

      {/* Modal Card */}
      <div 
        className="relative w-full max-w-4xl bg-paper border border-line rounded-[20px] shadow-floating overflow-hidden grid grid-cols-1 md:grid-cols-12 max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Left Column: Photography (Desktop only) */}
        <div className="hidden md:flex md:col-span-5 relative flex-col justify-end p-8 text-paper overflow-hidden select-none">
          <img
            src="/images/signin-panel.webp"
            alt="Traveler on railway platform at dawn"
            className="absolute inset-0 w-full h-full object-cover pointer-events-none"
            style={{ backgroundColor: '#182028' }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0B1B2B]/95 via-[#0B1B2B]/65 to-[#0B1B2B]/35 pointer-events-none" />
          
          <div className="relative z-10 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-marigold flex items-center justify-center text-marigold-ink mb-3 shadow-sm">
              <Compass className="w-4.5 h-4.5" />
            </div>
            <h3 className="font-display text-2xl font-semibold tracking-tight text-paper leading-tight">
              One conversation.<br />One budget.
            </h3>
            <p className="text-xs text-cream/80 leading-relaxed">
              Your entire journey coordinates seamlessly within your strict spending ceiling.
            </p>
          </div>
        </div>

        {/* Right Column: Auth Form */}
        <div className="col-span-12 md:col-span-7 p-6 sm:p-8 bg-paper overflow-y-auto relative">
          {/* Close Button */}
          <button
            type="button"
            onClick={closeAuthModal}
            className="absolute top-4 right-4 p-2 text-ink-2 hover:text-ink transition-colors rounded-btn cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" strokeWidth={1.75} />
          </button>

        {/* Wordmark Header */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-6 h-6 rounded-full bg-ink text-marigold flex items-center justify-center">
              <Compass className="w-4 h-4" strokeWidth={2} />
            </span>
            <span className="font-display font-semibold text-lg text-ink">Plan My Trip</span>
          </div>
          <h2 id="auth-modal-title" className="text-2xl font-display font-semibold text-ink">
            Sign in to your journey
          </h2>
          <p className="text-sm text-ink-2 mt-1">
            Access your saved trip, budget allocations, and journey rescue.
          </p>
        </div>

        {/* Presentation-Ready Guest Demo Banner */}
        <div className="mb-6 p-4 rounded-card bg-cream border border-line">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-bold text-ink uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-marigold" />
              Judges & Presenter Access
            </span>
            <span className="text-[11px] font-medium text-ink-2 bg-cream-2 px-2 py-0.5 rounded">
              Instant · No popup
            </span>
          </div>
          <p className="text-xs text-ink-2 mb-3">
            Enter immediately with preloaded demo trip (Hyderabad to New Delhi, ₹15,000 budget).
          </p>
          <button
            type="button"
            onClick={handleGuestDemo}
            disabled={isSubmitting}
            className="w-full h-11 px-4 rounded-btn font-medium text-sm bg-marigold text-marigold-ink hover:opacity-95 transition-all flex items-center justify-center gap-2"
          >
            <span>Continue as guest (demo)</span>
            <ArrowRight className="w-4 h-4 stroke-[2]" />
          </button>
        </div>

        {/* Tabs for Real Firebase Sign-In */}
        <div className="flex border-b border-line mb-5 gap-4">
          <button
            type="button"
            onClick={() => { setActiveTab('google'); clearError(); setLocalError(null); }}
            className={`pb-2 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'google'
                ? 'border-ink text-ink font-bold'
                : 'border-transparent text-ink-2 hover:text-ink'
            }`}
          >
            Google
          </button>
          <button
            type="button"
            onClick={() => { setActiveTab('email'); clearError(); setLocalError(null); }}
            className={`pb-2 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'email'
                ? 'border-ink text-ink font-bold'
                : 'border-transparent text-ink-2 hover:text-ink'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            Email
          </button>
          <button
            type="button"
            onClick={() => { setActiveTab('phone'); clearError(); setLocalError(null); }}
            className={`pb-2 text-xs font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'phone'
                ? 'border-ink text-ink font-bold'
                : 'border-transparent text-ink-2 hover:text-ink'
            }`}
          >
            <Phone className="w-3.5 h-3.5" />
            Phone
          </button>
        </div>

        {/* Error Alert */}
        {displayedError && (
          <div className="mb-4 p-3 rounded-card bg-coral-soft border border-coral/30 text-coral text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <div className="flex-1">{displayedError}</div>
          </div>
        )}

        {/* Tab 1: Google */}
        {activeTab === 'google' && (
          <div className="space-y-4">
            <p className="text-xs text-ink-2 leading-relaxed">
              Sign in with your Google account. We will never charge your account or access personal data.
            </p>
            <button
              type="button"
              disabled={isSubmitting}
              onClick={handleGoogleSignIn}
              className="w-full h-12 px-4 rounded-btn font-medium text-sm border border-line bg-paper text-ink hover:bg-cream transition-colors flex items-center justify-center gap-3 disabled:opacity-60"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-ink" />
                  <span>Connecting...</span>
                </>
              ) : (
                <>
                  <svg className="w-4 h-4 flex-shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>Continue with Google</span>
                </>
              )}
            </button>
          </div>
        )}

        {/* Tab 2: Email */}
        {activeTab === 'email' && (
          <form onSubmit={handleEmailSubmit} className="space-y-3.5">
            {emailMode === 'signup' && (
              <div>
                <label className="block text-xs font-medium text-ink mb-1" htmlFor="auth-name">
                  Full Name
                </label>
                <input
                  id="auth-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Aarav Sharma"
                  className="w-full h-11 px-3.5 rounded-btn border border-line bg-cream text-ink text-sm focus:bg-paper"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-ink mb-1" htmlFor="auth-email">
                Email Address
              </label>
              <input
                id="auth-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                required
                className="w-full h-11 px-3.5 rounded-btn border border-line bg-cream text-ink text-sm focus:bg-paper"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-ink mb-1" htmlFor="auth-password">
                Password
              </label>
              <input
                id="auth-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full h-11 px-3.5 rounded-btn border border-line bg-cream text-ink text-sm focus:bg-paper"
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full h-12 rounded-btn font-medium text-sm bg-ink text-cream hover:bg-ink-2 transition-colors flex items-center justify-center gap-2 mt-2"
            >
              {isSubmitting && <Loader2 className="w-4 h-4 animate-spin text-cream" />}
              <span>{emailMode === 'signin' ? 'Sign in with Email' : 'Create account'}</span>
            </button>

            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => setEmailMode(m => m === 'signin' ? 'signup' : 'signin')}
                className="text-xs text-ink-2 hover:text-ink underline"
              >
                {emailMode === 'signin' ? "Don't have an account? Sign up" : 'Already have an account? Sign in'}
              </button>
            </div>
          </form>
        )}

        {/* Tab 3: Phone */}
        {activeTab === 'phone' && (
          <div className="space-y-4">
            {!otpSent ? (
              <form onSubmit={handleSendOtp} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-medium text-ink mb-1" htmlFor="auth-phone">
                    Phone Number
                  </label>
                  <input
                    id="auth-phone"
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="+91 98765 43210"
                    required
                    className="w-full h-11 px-3.5 rounded-btn border border-line bg-cream text-ink text-sm focus:bg-paper"
                  />
                  <span className="text-[11px] text-ink-2 mt-1 block">Include country code (+91)</span>
                </div>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full h-12 rounded-btn font-medium text-sm bg-ink text-cream hover:bg-ink-2 transition-colors flex items-center justify-center gap-2"
                >
                  {isSubmitting && <Loader2 className="w-4 h-4 animate-spin text-cream" />}
                  <span>Send OTP</span>
                </button>
              </form>
            ) : (
              <form onSubmit={handleVerifyOtp} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-medium text-ink mb-1" htmlFor="auth-otp">
                    Enter 6-digit Code
                  </label>
                  <input
                    id="auth-otp"
                    type="text"
                    maxLength={6}
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, ''))}
                    placeholder="123456"
                    required
                    className="w-full h-11 px-3.5 rounded-btn border border-line bg-cream text-ink text-center tracking-widest text-lg font-mono"
                  />
                </div>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full h-12 rounded-btn font-medium text-sm bg-marigold text-marigold-ink hover:opacity-95 transition-opacity flex items-center justify-center gap-2"
                >
                  {isSubmitting && <Loader2 className="w-4 h-4 animate-spin text-marigold-ink" />}
                  <span>Verify and Sign in</span>
                </button>
              </form>
            )}
          </div>
        )}
        </div>
      </div>
    </div>
  );
}
