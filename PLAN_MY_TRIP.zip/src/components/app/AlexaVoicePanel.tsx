import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Mic, 
  MicOff, 
  RotateCcw, 
  ArrowRight, 
  AlertCircle,
  Volume2,
  Settings2
} from 'lucide-react';
import VoiceSettingsModal from './VoiceSettingsModal';

interface AlexaVoicePanelProps {
  isOpen: boolean;
  onClose: () => void;
  onPlan: (transcript: string) => void;
}

// Window type augmentation for Web Speech API
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export default function AlexaVoicePanel({
  isOpen,
  onClose,
  onPlan
}: AlexaVoicePanelProps) {
  const [voiceState, setVoiceState] = useState<'idle' | 'listening' | 'processing'>('idle');
  const [finalTranscript, setFinalTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [speechSupported, setSpeechSupported] = useState(true);
  const [showVoiceSettings, setShowVoiceSettings] = useState(false);

  const fullTranscript = (finalTranscript + (interimTranscript ? ` ${interimTranscript}` : '')).trim();

  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Check speech recognition support
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setSpeechSupported(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-IN';

      recognition.onstart = () => {
        setVoiceState('listening');
        setErrorMessage(null);
      };

      recognition.onresult = (event: any) => {
        let currentInterim = '';
        let currentFinal = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const item = event.results[i];
          if (item.isFinal) {
            currentFinal += item[0].transcript + ' ';
          } else {
            currentInterim += item[0].transcript;
          }
        }

        if (currentFinal) {
          setFinalTranscript(prev => (prev ? `${prev} ${currentFinal}` : currentFinal).trim());
        }
        setInterimTranscript(currentInterim);
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        if (event.error === 'aborted' || event.error === 'no-speech') {
          setVoiceState('idle');
          return;
        }
        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          setErrorMessage('Microphone access was denied. You can type your request directly in the text box below.');
          setVoiceState('idle');
        } else {
          setErrorMessage(`Audio input notice (${event.error}). You can type or try again.`);
          setVoiceState('idle');
        }
      };

      recognition.onend = () => {
        // Only set idle if we were not actively processing
        setVoiceState(prev => (prev === 'listening' ? 'idle' : prev));
      };

      recognitionRef.current = recognition;
    } catch (e) {
      console.warn('Failed to initialize speech recognition:', e);
      setSpeechSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (e) {}
      }
    };
  }, []);

  // Auto start listening when modal opens if supported
  useEffect(() => {
    if (isOpen && speechSupported && voiceState === 'idle' && !finalTranscript) {
      startListening();
    }
    if (!isOpen) {
      stopListening();
    }
  }, [isOpen, speechSupported]);

  const startListening = () => {
    if (!recognitionRef.current) return;
    try {
      setErrorMessage(null);
      recognitionRef.current.start();
      setVoiceState('listening');
    } catch (e) {
      // recognition may already be started
      setVoiceState('listening');
    }
  };

  const stopListening = () => {
    if (!recognitionRef.current) return;
    try {
      recognitionRef.current.stop();
      setVoiceState('idle');
    } catch (e) {
      setVoiceState('idle');
    }
  };

  const handleClear = () => {
    setFinalTranscript('');
    setInterimTranscript('');
    setErrorMessage(null);
  };

  const handlePlanSubmit = () => {
    const textToSubmit = (finalTranscript.trim() || interimTranscript.trim());
    if (!textToSubmit || textToSubmit.length < 3) return;
    setVoiceState('processing');
    stopListening();
    setInterimTranscript('');
    onPlan(textToSubmit);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-ink/80 backdrop-blur-xs flex items-center justify-center p-0 md:p-4">
      <div 
        className="relative w-full h-full md:h-auto md:max-w-xl bg-paper border-0 md:border md:border-line md:rounded-card shadow-floating flex flex-col justify-between overflow-hidden animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Top bar */}
        <div className="bg-cream/70 px-6 py-4 border-b border-line flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-marigold flex items-center justify-center text-marigold-ink font-semibold">
              <Mic className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-display text-base font-semibold text-ink leading-tight">
                Talk to Alexa
              </h2>
              <p className="text-xs text-ink-3">Voice-First Travel Intake</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setShowVoiceSettings(true)}
              className="w-8 h-8 rounded-full hover:bg-cream border border-transparent hover:border-line flex items-center justify-center text-ink-3 hover:text-ink transition-colors cursor-pointer"
              aria-label="Voice settings"
              title="Voice settings"
            >
              <Settings2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full hover:bg-cream border border-transparent hover:border-line flex items-center justify-center text-ink-3 hover:text-ink transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Voice Settings Modal */}
        <VoiceSettingsModal
          isOpen={showVoiceSettings}
          onClose={() => setShowVoiceSettings(false)}
        />

        {/* Content Body */}
        <div className="p-6 md:p-8 flex-1 flex flex-col items-center justify-center space-y-6">
          {/* Big Voice Orb */}
          <div className="relative flex items-center justify-center my-2">
            {voiceState === 'listening' && (
              <>
                <div className="absolute w-36 h-36 rounded-full bg-marigold/20 animate-ping duration-1000" />
                <div className="absolute w-28 h-28 rounded-full bg-marigold/35 animate-pulse" />
              </>
            )}
            {voiceState === 'processing' && (
              <div className="absolute w-28 h-28 rounded-full bg-teal/30 animate-spin" />
            )}
            
            <button
              type="button"
              onClick={voiceState === 'listening' ? stopListening : startListening}
              className={`relative z-10 w-24 h-24 rounded-full flex items-center justify-center transition-all shadow-md cursor-pointer ${
                voiceState === 'listening'
                  ? 'bg-marigold text-marigold-ink scale-105 ring-4 ring-marigold/40'
                  : voiceState === 'processing'
                  ? 'bg-teal text-paper'
                  : 'bg-ink text-cream hover:bg-ink-2'
              }`}
            >
              {voiceState === 'listening' ? (
                <Mic className="w-10 h-10 animate-bounce" />
              ) : voiceState === 'processing' ? (
                <Volume2 className="w-10 h-10 animate-pulse" />
              ) : (
                <MicOff className="w-9 h-9" />
              )}
            </button>
          </div>

          {/* Voice State Status Line */}
          <div className="text-center">
            <span className="text-xs font-semibold uppercase tracking-wider text-ink-3 block mb-1">
              {voiceState === 'listening' && 'Listening in en-IN · Speak naturally'}
              {voiceState === 'idle' && 'Microphone Paused · Tap orb to speak or edit text'}
              {voiceState === 'processing' && 'Processing your request...'}
            </span>
            <p className="text-xs text-ink-2">
              "e.g. Plan a trip to Mumbai for 3 days, 5 to 6 members, budget ₹60,000"
            </p>
          </div>

          {/* Error / Fallback alert */}
          {(errorMessage || !speechSupported) && (
            <div className="w-full p-3.5 bg-amber/10 border border-amber/30 rounded-xl flex items-start gap-3 text-xs text-ink">
              <AlertCircle className="w-4 h-4 text-amber shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold block text-amber">
                  {!speechSupported ? 'Speech recognition not supported in this browser' : 'Audio input note:'}
                </span>
                <span>{errorMessage || 'You can type your request directly in the box below.'}</span>
              </div>
            </div>
          )}

          {/* Live Transcript Box (Editable at any time) */}
          <div className="w-full space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-ink-2">
              <span>Live Transcript</span>
              {fullTranscript && (
                <span className="text-[11px] text-ink-3">Editable at any time</span>
              )}
            </div>

            <div className="relative w-full bg-cream border border-line rounded-xl p-4 min-h-[110px] focus-within:border-marigold transition-colors">
              <textarea
                value={finalTranscript}
                onChange={(e) => {
                  setFinalTranscript(e.target.value);
                  setInterimTranscript('');
                }}
                placeholder="Your spoken words will appear here in real time. Or type your journey prompt here..."
                rows={3}
                className="w-full bg-transparent resize-none text-sm text-ink placeholder:text-ink-3 focus:outline-none leading-relaxed font-sans"
              />

              {interimTranscript && (
                <div className="text-xs text-ink-2/65 italic mt-1 font-sans">
                  {interimTranscript}...
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="bg-cream/70 px-6 py-4 border-t border-line flex items-center justify-between">
          <div className="flex items-center gap-2">
            {voiceState === 'listening' ? (
              <button
                type="button"
                onClick={stopListening}
                className="px-3.5 py-2 bg-paper hover:bg-cream border border-line rounded-btn text-xs font-medium text-ink transition-colors cursor-pointer"
              >
                Stop
              </button>
            ) : (
              <button
                type="button"
                onClick={startListening}
                className="px-3.5 py-2 bg-paper hover:bg-cream border border-line rounded-btn text-xs font-medium text-ink transition-colors cursor-pointer"
              >
                Resume Mic
              </button>
            )}

            {fullTranscript && (
              <button
                type="button"
                onClick={handleClear}
                className="px-3 py-2 text-xs font-medium text-ink-3 hover:text-ink transition-colors flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Clear</span>
              </button>
            )}
          </div>

          <button
            type="button"
            disabled={!fullTranscript.trim()}
            onClick={handlePlanSubmit}
            className={`px-6 py-2.5 rounded-btn font-semibold text-xs flex items-center gap-2 transition-all cursor-pointer ${
              fullTranscript.trim()
                ? 'bg-marigold hover:bg-marigold-hover text-marigold-ink shadow-sm'
                : 'bg-line text-ink-3 cursor-not-allowed opacity-50'
            }`}
          >
            <span>Plan</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
