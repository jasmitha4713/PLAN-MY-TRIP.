import React, { useState, useEffect } from 'react';
import { X, Volume2, Play, Check, Settings2, Sparkles } from 'lucide-react';
import { voiceService } from '../../lib/alexa/voiceService';

interface VoiceSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function VoiceSettingsModal({ isOpen, onClose }: VoiceSettingsModalProps) {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceName, setSelectedVoiceName] = useState<string>('');
  const [rate, setRate] = useState<number>(1.0);
  const [isPlayingPreview, setIsPlayingPreview] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    const load = () => {
      const vList = voiceService.getAvailableVoices();
      setVoices(vList);
      const current = voiceService.getSelectedVoice();
      if (current) {
        setSelectedVoiceName(current.name);
      }
      const settings = voiceService.getVoiceSettings();
      setRate(settings.rate);
    };

    load();
    const unsubscribe = voiceService.onVoicesLoaded(load);
    return () => unsubscribe();
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSelectVoice = (name: string) => {
    setSelectedVoiceName(name);
    voiceService.setSelectedVoice(name);
  };

  const handleRateChange = (newRate: number) => {
    setRate(newRate);
    voiceService.setVoiceSettings({ rate: newRate });
  };

  const handlePreview = (name: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setIsPlayingPreview(name);
    voiceService.previewVoice(name, () => {
      setIsPlayingPreview(null);
    });
  };

  const englishVoices = voices.filter(v => v.lang.toLowerCase().startsWith('en'));
  const otherVoices = voices.filter(v => !v.lang.toLowerCase().startsWith('en'));

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-ink/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-paper border border-line rounded-card w-full max-w-lg shadow-floating overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in duration-200">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-line flex items-center justify-between bg-cream/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-marigold/20 flex items-center justify-center text-marigold-ink">
              <Settings2 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-display text-base font-semibold text-ink leading-tight">
                Voice Assistant Settings
              </h2>
              <p className="text-[11px] text-ink-3">
                Configure voice and pronunciation preferences
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-ink-3 hover:text-ink rounded-lg hover:bg-cream transition-colors cursor-pointer"
            aria-label="Close voice settings"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-5 text-xs">
          
          {/* Speech Rate Controls */}
          <div className="space-y-2">
            <label className="font-semibold text-ink text-xs block">
              Speech Speed
            </label>
            <div className="flex items-center gap-2">
              {[0.85, 1.0, 1.15].map((speed) => (
                <button
                  key={speed}
                  type="button"
                  onClick={() => handleRateChange(speed)}
                  className={`flex-1 py-1.5 px-3 rounded-btn border text-xs font-semibold transition-colors cursor-pointer ${
                    Math.abs(rate - speed) < 0.05
                      ? 'bg-marigold text-marigold-ink border-marigold'
                      : 'bg-cream text-ink-2 border-line hover:border-ink/30'
                  }`}
                >
                  {speed === 1.0 ? 'Normal (1.0x)' : `${speed}x`}
                </button>
              ))}
            </div>
          </div>

          {/* Voice List */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-semibold text-ink text-xs block">
                Available Voices ({voices.length})
              </label>
              <span className="text-[10px] text-ink-3">Persisted locally</span>
            </div>

            {voices.length === 0 ? (
              <div className="p-4 bg-cream rounded-xl text-center text-ink-3 text-xs">
                Loading available browser voices...
              </div>
            ) : (
              <div className="space-y-1.5 max-h-64 overflow-y-auto pr-1">
                {englishVoices.map((v) => {
                  const isSelected = v.name === selectedVoiceName;
                  const isIndian = v.lang.toLowerCase().includes('en-in') || v.name.toLowerCase().includes('india');
                  const isNatural = v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Heera') || v.name.includes('Neerja');

                  return (
                    <div
                      key={v.name}
                      onClick={() => handleSelectVoice(v.name)}
                      className={`p-2.5 rounded-lg border transition-all flex items-center justify-between gap-2 cursor-pointer ${
                        isSelected
                          ? 'bg-marigold/10 border-marigold shadow-2xs'
                          : 'bg-cream/40 border-line/60 hover:bg-cream hover:border-line'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div
                          className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                            isSelected
                              ? 'border-marigold bg-marigold text-marigold-ink'
                              : 'border-line bg-paper'
                          }`}
                        >
                          {isSelected && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-medium text-ink truncate text-xs">
                              {v.name.replace(/Microsoft |Google /g, '')}
                            </span>
                            {isIndian && (
                              <span className="px-1.5 py-0.2 bg-teal/15 text-teal text-[9px] font-semibold rounded">
                                Indian English
                              </span>
                            )}
                            {isNatural && (
                              <span className="px-1.5 py-0.2 bg-amber/15 text-amber text-[9px] font-semibold rounded">
                                Natural
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-ink-3 block font-mono">
                            {v.lang}
                          </span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => handlePreview(v.name, e)}
                        className={`p-1.5 rounded-btn border text-[11px] font-semibold flex items-center gap-1 transition-colors shrink-0 cursor-pointer ${
                          isPlayingPreview === v.name
                            ? 'bg-marigold text-marigold-ink border-marigold'
                            : 'bg-paper text-ink-2 hover:text-ink border-line hover:bg-cream'
                        }`}
                        title="Preview this voice"
                      >
                        <Play className="w-3 h-3 fill-current" />
                        <span className="hidden sm:inline">Preview</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="p-3 bg-cream/70 rounded-lg border border-line text-[11px] text-ink-3 space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-ink">
              <Sparkles className="w-3.5 h-3.5 text-marigold" />
              <span>Voice Playback Transparency</span>
            </div>
            <p>
              Speech uses your operating system and browser's speech synthesis engine. We never invent simulated voice options that are not installed on your system.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-line bg-cream/40 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold rounded-btn text-xs shadow-2xs cursor-pointer transition-colors"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
}
