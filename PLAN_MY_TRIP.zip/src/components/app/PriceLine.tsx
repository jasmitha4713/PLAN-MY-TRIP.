import React from 'react';
import { formatINR } from '../../lib/budget';

interface PriceLineProps {
  pricePerPerson: number;
  travellers: number;
  multiplier?: number;
  multiplierLabel?: string;
  subtext?: string;
  isFree?: boolean;
  className?: string;
}

export default function PriceLine({
  pricePerPerson,
  travellers,
  multiplier = 1,
  multiplierLabel,
  subtext,
  isFree = false,
  className = ''
}: PriceLineProps) {
  if (isFree || pricePerPerson === 0) {
    return (
      <div className={`space-y-0.5 ${className}`}>
        <div className="font-display text-base font-semibold text-teal flex items-center gap-1.5">
          <span>Free</span>
        </div>
        <div className="text-[11px] text-ink-3">
          {subtext || 'No entry fee / included'}
        </div>
      </div>
    );
  }

  const effectiveTotal = Math.round(pricePerPerson * travellers * multiplier);

  return (
    <div className={`space-y-0.5 ${className}`}>
      {/* Big per-person price first */}
      <div className="font-display text-base font-semibold text-ink leading-tight">
        {formatINR(pricePerPerson)}
        <span className="text-xs font-normal text-ink-2 font-sans ml-1">/ person</span>
      </div>

      {/* Beneath: equation showing multiplication */}
      <div className="text-[11px] text-ink-3 font-mono">
        × {travellers} {travellers === 1 ? 'traveller' : 'travellers'}
        {multiplier > 1 && multiplierLabel ? ` ${multiplierLabel}` : multiplier > 1 ? ` × ${multiplier}` : ''}
        {' = '}
        <span className="font-semibold text-ink">{formatINR(effectiveTotal)}</span>
      </div>

      {subtext && (
        <div className="text-[10px] text-ink-3 pt-0.5">
          {subtext}
        </div>
      )}
    </div>
  );
}
