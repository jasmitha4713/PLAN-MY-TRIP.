import React, { useState } from 'react';
import { 
  CheckCircle2, 
  AlertTriangle, 
  Calendar, 
  MapPin, 
  DollarSign, 
  ShieldCheck, 
  XCircle,
  Clock, 
  Compass, 
  Users, 
  Train, 
  Bus, 
  Building2, 
  ChevronRight 
} from 'lucide-react';
import { AlexaCard, BudgetCardPayload, ApprovalCardPayload, OptionPickerPayload } from '../../lib/alexa/types';
import { ItineraryCardPayload, DisruptionCardPayload } from '../../lib/alexa/conversationEngine';
import { formatINR } from '../../lib/budget';

interface MultimodalCardsProps {
  cards?: AlexaCard[];
  onApproveAction?: (actionId: string) => void;
  onRejectAction?: (actionId: string) => void;
  onSelectOption?: (optionId: string, category: string) => void;
  disabled?: boolean;
}

export default function AlexaMultimodalCards({
  cards,
  onApproveAction,
  onRejectAction,
  onSelectOption,
  disabled
}: MultimodalCardsProps) {
  const [actionStatuses, setActionStatuses] = useState<Record<string, 'pending' | 'submitting' | 'approved' | 'declined'>>({});

  if (!cards || cards.length === 0) return null;

  return (
    <div className="space-y-3 my-2 w-full max-w-xl">
      {cards.map((card, idx) => {
        // 1. BUDGET SUMMARY CARD
        if (card.type === 'budget_summary') {
          const b = (card as BudgetCardPayload).budget;
          if (!b) return null;
          const ceiling = b.totalBudget || (b as any).totalCost || 15000;
          const spent = b.totalCost || (b as any).spent?.total || 0;
          const buffer = b.unallocatedBuffer !== undefined ? b.unallocatedBuffer : Math.max(0, ceiling - spent);
          const percentSpent = Math.min(100, Math.round((spent / ceiling) * 100));

          return (
            <div
              key={`card-b-${idx}`}
              className="bg-paper border border-line rounded-xl p-4 shadow-2xs space-y-3 text-xs"
            >
              <div className="flex items-center justify-between border-b border-line pb-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-teal/10 flex items-center justify-center text-teal">
                    <DollarSign className="w-3.5 h-3.5" />
                  </div>
                  <span className="font-semibold text-ink">
                    {card.title || 'Verified Budget Breakdown'}
                  </span>
                </div>
                <span className="font-mono text-ink-2 font-bold">
                  {formatINR(ceiling)} Ceiling
                </span>
              </div>

              {/* Progress bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px] text-ink-3">
                  <span>Allocated: {formatINR(spent)}</span>
                  <span>Cushion: {formatINR(buffer)}</span>
                </div>
                <div className="w-full bg-cream rounded-full h-2 overflow-hidden border border-line/60">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      b.isOverBudget ? 'bg-ruby' : 'bg-forest'
                    }`}
                    style={{ width: `${percentSpent}%` }}
                  />
                </div>
              </div>

              {/* Itemized Categories */}
              {b.spent && (
                <div className="grid grid-cols-2 gap-2 pt-1 text-[11px]">
                  <div className="bg-cream/60 p-2 rounded-lg border border-line/40 flex justify-between">
                    <span className="text-ink-3">Transit:</span>
                    <span className="font-mono font-medium text-ink">{formatINR(b.spent.transport || 0)}</span>
                  </div>
                  <div className="bg-cream/60 p-2 rounded-lg border border-line/40 flex justify-between">
                    <span className="text-ink-3">Stay:</span>
                    <span className="font-mono font-medium text-ink">{formatINR(b.spent.stay || 0)}</span>
                  </div>
                  <div className="bg-cream/60 p-2 rounded-lg border border-line/40 flex justify-between">
                    <span className="text-ink-3">Activities:</span>
                    <span className="font-mono font-medium text-ink">
                      {formatINR((b.spent.experiences || 0) + (b.spent.local || 0))}
                    </span>
                  </div>
                  <div className="bg-cream/60 p-2 rounded-lg border border-line/40 flex justify-between">
                    <span className="text-ink-3">Reserve:</span>
                    <span className="font-mono font-semibold text-forest">{formatINR(buffer)}</span>
                  </div>
                </div>
              )}
            </div>
          );
        }

        // 2. ITINERARY CARD
        if (card.type === 'itinerary_card') {
          const itin = card as unknown as ItineraryCardPayload;
          return (
            <div
              key={`card-itin-${idx}`}
              className="bg-paper border border-line rounded-xl p-4 shadow-2xs space-y-3 text-xs"
            >
              <div className="flex items-center justify-between border-b border-line pb-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-marigold/10 flex items-center justify-center text-marigold-ink">
                    <Compass className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <span className="font-semibold text-ink block leading-tight">
                      {itin.title || `${itin.destination} Travel Itinerary`}
                    </span>
                    <span className="text-[10px] text-ink-3">
                      {itin.durationDays} Days · {itin.travelersCount} Travellers
                    </span>
                  </div>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-pill bg-teal/10 text-teal font-medium border border-teal/20">
                  Verified Route
                </span>
              </div>

              {/* Day items */}
              <div className="space-y-2">
                {itin.days?.map((day) => (
                  <div
                    key={`itin-day-${day.day}`}
                    className="p-2.5 bg-cream/50 rounded-lg border border-line/60 space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-ink text-[11px]">
                        Day {day.day}: {day.title}
                      </span>
                      {day.costEstimate && (
                        <span className="text-[10px] font-mono text-ink-2 bg-paper px-1.5 py-0.5 rounded border border-line/50">
                          {day.costEstimate}
                        </span>
                      )}
                    </div>
                    <ul className="text-[11px] text-ink-2 space-y-0.5 list-disc list-inside">
                      {day.highlights?.map((h, hIdx) => (
                        <li key={hIdx} className="leading-tight">{h}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          );
        }

        // 3. DISRUPTION ASSESSMENT CARD
        if (card.type === 'disruption_card') {
          const dis = card as unknown as DisruptionCardPayload;
          const isTrain = dis.transportMode === 'train';

          return (
            <div
              key={`card-dis-${idx}`}
              className="bg-paper border border-ruby/30 rounded-xl p-4 shadow-2xs space-y-3 text-xs"
            >
              <div className="flex items-center justify-between border-b border-line pb-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-ruby-bg flex items-center justify-center text-ruby">
                    {isTrain ? <Train className="w-3.5 h-3.5" /> : <Bus className="w-3.5 h-3.5" />}
                  </div>
                  <div>
                    <span className="font-semibold text-ink block leading-tight">
                      {dis.title || 'Disruption Assessment'}
                    </span>
                    <span className="text-[10px] text-ruby font-medium">
                      {dis.delayMinutes} Minutes Delay Reported
                    </span>
                  </div>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-pill bg-ruby-bg text-ruby font-semibold border border-ruby/20">
                  Impact Active
                </span>
              </div>

              <p className="text-ink-2 leading-relaxed bg-cream/60 p-2 rounded-lg border border-line/50 text-[11px]">
                {dis.impactSummary}
              </p>

              {/* Options */}
              <div className="space-y-1.5 pt-1">
                <span className="text-[11px] font-semibold text-ink block">
                  Recommended Recovery Alternatives:
                </span>
                {dis.options?.map((opt) => (
                  <div
                    key={opt.id}
                    className="p-2.5 bg-paper rounded-lg border border-line hover:border-marigold/60 transition-colors flex items-start justify-between gap-2"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-ink text-[11px]">{opt.title}</span>
                        {opt.recommended && (
                          <span className="text-[9px] px-1.5 py-0.2 bg-teal/15 text-teal rounded font-medium">
                            Recommended
                          </span>
                        )}
                      </div>
                      <p className="text-[10px] text-ink-3 leading-snug">{opt.description}</p>
                    </div>
                    <span className="font-mono text-xs font-bold text-ink self-center whitespace-nowrap">
                      {opt.cost === 0 ? 'Free' : formatINR(opt.cost)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          );
        }

        // 4. APPROVAL GATE CARD
        if (card.type === 'approval_card') {
          const app = card as ApprovalCardPayload;
          const currentStatus = actionStatuses[app.actionId] || (app as any).status || 'pending';
          const isPending = currentStatus === 'pending';
          const isApproved = currentStatus === 'approved';
          const isDeclined = currentStatus === 'declined';

          return (
            <div
              key={`card-app-${idx}`}
              className="bg-paper border-2 border-marigold/70 rounded-xl p-4 shadow-sm space-y-3 text-xs"
            >
              <div className="flex items-center justify-between border-b border-line pb-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-marigold/20 flex items-center justify-center text-marigold-ink">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold text-ink block leading-tight">
                      {app.title || 'Recovery Action Approval Gate'}
                    </span>
                    <span className="text-[10px] text-ink-3">
                      Recipient: {app.recipient} · <span className="font-medium text-amber">Simulated Action</span>
                    </span>
                  </div>
                </div>
                <span className="font-mono text-xs font-bold text-marigold-ink bg-marigold/15 px-2 py-0.5 rounded border border-marigold/30">
                  {app.extraCostLabel || (app.extraCost ? formatINR(app.extraCost) : '₹0')}
                </span>
              </div>

              <div className="p-3 bg-cream/70 rounded-lg border border-line font-mono text-[11px] text-ink">
                "{app.explanation}"
              </div>

              {app.caveat && (
                <p className="text-[10px] text-ink-3 italic">
                  Note: {app.caveat}
                </p>
              )}

              {/* Action Buttons or Status Badge */}
              <div className="flex items-center justify-end gap-2 pt-1">
                {isApproved ? (
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 text-forest text-xs font-semibold rounded-btn border border-forest/30">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Approved &amp; Executed (Simulated Demo Action)</span>
                  </div>
                ) : isDeclined ? (
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-ruby-bg text-ruby text-xs font-semibold rounded-btn border border-ruby/30">
                    <XCircle className="w-4 h-4" />
                    <span>Proposal Rejected (No bookings made)</span>
                  </div>
                ) : (
                  <>
                    <button
                      type="button"
                      disabled={disabled || !isPending}
                      onClick={() => {
                        setActionStatuses(prev => ({ ...prev, [app.actionId]: 'declined' }));
                        onRejectAction && onRejectAction(app.actionId);
                      }}
                      className="px-3 py-1.5 bg-paper hover:bg-cream border border-line rounded-btn text-xs font-semibold text-ink-2 cursor-pointer disabled:opacity-50"
                    >
                      Don't send
                    </button>
                    <button
                      type="button"
                      disabled={disabled || !isPending}
                      onClick={() => {
                        setActionStatuses(prev => ({ ...prev, [app.actionId]: 'approved' }));
                        onApproveAction && onApproveAction(app.actionId);
                      }}
                      className="px-4 py-1.5 bg-marigold hover:bg-marigold-hover text-marigold-ink rounded-btn text-xs font-semibold shadow-2xs cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
                    >
                      <ShieldCheck className="w-3.5 h-3.5" />
                      Approve &amp; Send
                    </button>
                  </>
                )}
              </div>
            </div>
          );
        }

        // 5. OPTION PICKER CARD (Hotel / Transport / Experience Selection)
        if (card.type === 'option_picker') {
          const picker = card as OptionPickerPayload;
          const CategoryIcon =
            picker.category === 'transport' ? Train :
            picker.category === 'stay' ? Building2 :
            picker.category === 'experience' ? Compass : Users;

          return (
            <div
              key={`card-opt-${idx}`}
              className="bg-paper border border-line rounded-xl p-4 shadow-2xs space-y-3 text-xs"
            >
              <div className="flex items-center justify-between border-b border-line pb-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-teal/10 flex items-center justify-center text-teal">
                    <CategoryIcon className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <span className="font-semibold text-ink block leading-tight">
                      {picker.title}
                    </span>
                    <span className="text-[10px] text-ink-3">
                      Selectable Options · No Automatic Booking
                    </span>
                  </div>
                </div>
                <span className="text-[10px] uppercase font-semibold tracking-wider text-teal bg-teal/10 px-2 py-0.5 rounded border border-teal/20">
                  {picker.category}
                </span>
              </div>

              <div className="space-y-2">
                {picker.options?.map((opt) => (
                  <div
                    key={opt.id}
                    className="p-3 bg-cream/50 rounded-lg border border-line hover:border-teal/60 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold text-ink text-xs">{opt.title}</span>
                        {opt.tag && (
                          <span className="text-[9px] px-1.5 py-0.2 bg-teal/15 text-teal rounded font-medium">
                            {opt.tag}
                          </span>
                        )}
                        <span className="text-[9px] px-1.5 py-0.2 bg-amber/10 text-amber font-mono rounded">
                          Sample data
                        </span>
                      </div>
                      {opt.details && (
                        <p className="text-[11px] text-ink-2 leading-relaxed">{opt.details}</p>
                      )}
                      {opt.terms && (
                        <p className="text-[10px] text-ink-3 italic">{opt.terms}</p>
                      )}
                    </div>
                    <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 shrink-0">
                      <span className="font-mono text-xs font-bold text-ink">
                        {opt.priceLabel}
                      </span>
                      <button
                        type="button"
                        disabled={disabled}
                        onClick={() => onSelectOption && onSelectOption(opt.id, picker.category)}
                        className="px-3 py-1.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold rounded-btn text-xs shadow-2xs transition-colors cursor-pointer disabled:opacity-50"
                      >
                        Select option
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-2 border-t border-line/60 text-[10px] text-ink-3 flex items-center justify-between">
                <span>Selecting an option updates your trip draft &amp; budget cushion.</span>
                <span className="font-semibold text-ink-2">Explicit checkout required</span>
              </div>
            </div>
          );
        }

        return null;
      })}
    </div>
  );
}
