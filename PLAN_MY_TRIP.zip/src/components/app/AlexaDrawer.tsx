import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Mic,
  Send,
  Volume2,
  VolumeX,
  Sparkles,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Settings2
} from 'lucide-react';
import { getAlexaClient } from '../../lib/alexa/client';
import { AlexaReply, ApprovalCardPayload, BudgetCardPayload, OptionPickerPayload } from '../../lib/alexa/types';
import { useTrip } from '../../context/TripContext';
import { useAuth } from '../../context/AuthContext';
import { formatINR } from '../../lib/budget';
import { sanitizeSpeechText } from '../../lib/alexa/speechSanitizer';
import { voiceService } from '../../lib/alexa/voiceService';
import VoiceSettingsModal from './VoiceSettingsModal';

interface AlexaDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Message {
  id: string;
  sender: 'user' | 'alexa';
  text: string;
  reply?: AlexaReply;
  timestamp: string;
}

export default function AlexaDrawer({ isOpen, onClose }: AlexaDrawerProps) {
  const { currentTrip, applyPatch } = useTrip();
  const { user } = useAuth();

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'init-1',
      sender: 'alexa',
      text: "Hello! I'm your Plan My Trip companion. Tell me where you'd like to travel, adjust your budget, or test Journey Rescue.",
      timestamp: 'Just now'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [voiceState, setVoiceState] = useState<'idle' | 'listening' | 'thinking' | 'speaking'>('idle');
  const [voiceAudioEnabled, setVoiceAudioEnabled] = useState(false);
  const [showVoiceSettings, setShowVoiceSettings] = useState(false);
  const [micNotice, setMicNotice] = useState<string | null>(null);
  const [showToolsForMsg, setShowToolsForMsg] = useState<Record<string, boolean>>({});

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const isSendingRef = useRef(false);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, voiceState]);

  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-IN';

      recognition.onstart = () => {
        setMicNotice(null);
        setVoiceState('listening');
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          handleSendMessage(transcript);
        }
      };

      recognition.onerror = (event: any) => {
        setVoiceState('idle');
        if (event?.error === 'aborted' || event?.error === 'no-speech') {
          return;
        }
        if (event?.error === 'not-allowed' || event?.error === 'service-not-allowed') {
          setMicNotice('Microphone access was denied. Please allow microphone access or use text input.');
        } else {
          setMicNotice(`Voice input notice (${event?.error || 'interrupted'}). You can type below.`);
        }
      };

      recognition.onend = () => {
        if (voiceState === 'listening') {
          setVoiceState('idle');
        }
      };

      recognitionRef.current = recognition;
    }
  }, []);

  const toggleMic = () => {
    setMicNotice(null);
    if (!recognitionRef.current) {
      setMicNotice('Speech recognition is not supported in this browser. Please use text input.');
      return;
    }

    if (voiceState === 'listening') {
      recognitionRef.current.stop();
      setVoiceState('idle');
    } else {
      try {
        recognitionRef.current.start();
      } catch (err: any) {
        console.error('Speech recognition start error:', err);
        setMicNotice('Could not start microphone. You can type your request directly.');
      }
    }
  };

  const speakText = (text: string) => {
    if (!voiceAudioEnabled) return;
    voiceService.speak(text, {
      onStart: () => setVoiceState('speaking'),
      onEnd: () => setVoiceState('idle'),
      onError: () => setVoiceState('idle')
    });
  };

  const handleSendMessage = async (textToSend?: string) => {
    if (isSendingRef.current) return;
    const text = (textToSend || inputText).trim();
    if (!text) return;
    isSendingRef.current = true;

    setInputText('');
    const userMsgId = `user-${Date.now()}`;
    setMessages((prev) => [
      ...prev,
      {
        id: userMsgId,
        sender: 'user',
        text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);

    setVoiceState('thinking');

    try {
      const client = getAlexaClient();
      const canonicalId = currentTrip.backendTripId || (currentTrip.id?.startsWith('trip_') ? currentTrip.id : undefined);
      const reply = await client.send(text, {
        userId: user?.uid || 'demo-traveler-001',
        tripId: canonicalId || currentTrip.id,
        draft: currentTrip
      });

      // If reply carries immediate patch
      if (reply.tripPatch) {
        applyPatch(reply.tripPatch);
      }

      const alexaMsgId = `alexa-${Date.now()}`;
      setMessages((prev) => [
        ...prev,
        {
          id: alexaMsgId,
          sender: 'alexa',
          text: reply.text,
          reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);

      if (voiceAudioEnabled) {
        speakText(reply.text);
      } else {
        setVoiceState('idle');
      }
    } catch (err) {
      console.error('Alexa error:', err);
      setMessages((prev) => [
        ...prev,
        {
          id: `alexa-${Date.now()}`,
          sender: 'alexa',
          text: "I encountered an issue processing that request. Let's try again.",
          timestamp: 'Now'
        }
      ]);
      setVoiceState('idle');
    } finally {
      isSendingRef.current = false;
    }
  };

  const handleApprove = (approval: ApprovalCardPayload, reply?: AlexaReply) => {
    if (reply?.tripPatch) {
      applyPatch(reply.tripPatch);
    }
    setMessages((prev) => [
      ...prev,
      {
        id: `sys-${Date.now()}`,
        sender: 'alexa',
        text: `✓ Approved: ${approval.title} has been applied to your trip.`,
        timestamp: 'Just now'
      }
    ]);
  };

  const toggleTools = (msgId: string) => {
    setShowToolsForMsg((prev) => ({ ...prev, [msgId]: !prev[msgId] }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-ink/40 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Drawer Container */}
      <div className="relative w-full max-w-md bg-paper border-l border-line shadow-2xl flex flex-col h-full z-10 font-sans">
        {/* Header */}
        <div className="px-5 py-4 border-b border-line bg-cream/70 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Animated Orb indicator */}
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                voiceState === 'listening'
                  ? 'bg-marigold text-marigold-ink ring-4 ring-marigold/30'
                  : voiceState === 'thinking'
                  ? 'bg-ink text-cream animate-pulse'
                  : voiceState === 'speaking'
                  ? 'bg-teal text-paper ring-4 ring-teal/30'
                  : 'bg-marigold/20 text-marigold-ink'
              }`}
            >
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="font-display font-semibold text-sm text-ink flex items-center gap-2">
                <span>Alexa Travel Companion</span>
                <span className="text-[10px] font-mono font-medium px-1.5 py-0.2 bg-paper border border-line rounded text-ink-3">
                  Simulation
                </span>
              </div>
              <div className="text-[11px] text-ink-3">
                {voiceState === 'listening' && 'Listening to your voice...'}
                {voiceState === 'thinking' && 'Evaluating budget and tools...'}
                {voiceState === 'speaking' && 'Speaking response...'}
                {voiceState === 'idle' && 'Ready to plan or adjust'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {voiceState === 'speaking' && (
              <button
                type="button"
                onClick={() => {
                  voiceService.stopSpeaking();
                  setVoiceState('idle');
                }}
                className="px-2 py-1 bg-ruby-bg text-ruby border border-ruby/30 rounded text-[11px] font-medium flex items-center gap-1 animate-pulse cursor-pointer"
                title="Stop speaking"
              >
                <span>Stop</span>
              </button>
            )}
            <button
              onClick={() => setShowVoiceSettings(true)}
              title="Voice assistant settings"
              className="p-2 rounded-btn border border-line bg-cream hover:bg-cream-2 text-ink-2 hover:text-ink transition-colors cursor-pointer"
            >
              <Settings2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setVoiceAudioEnabled(!voiceAudioEnabled)}
              title={voiceAudioEnabled ? 'Mute speech audio' : 'Enable spoken voice'}
              className={`p-2 rounded-btn border transition-colors ${
                voiceAudioEnabled
                  ? 'bg-teal/10 border-teal/30 text-teal'
                  : 'bg-paper border-line text-ink-3 hover:text-ink'
              }`}
            >
              {voiceAudioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-btn text-ink-3 hover:text-ink hover:bg-cream transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Conversation Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-cream/30">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl p-3.5 text-sm ${
                  msg.sender === 'user'
                    ? 'bg-ink text-cream rounded-tr-xs'
                    : 'bg-paper text-ink border border-line rounded-tl-xs shadow-2xs'
                }`}
              >
                <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>

                {/* Inline Cards from Alexa Reply */}
                {msg.reply?.cards && msg.reply.cards.length > 0 && (
                  <div className="mt-3 space-y-2.5 pt-2 border-t border-line/60">
                    {msg.reply.cards.map((card, cIdx) => {
                      if (card.type === 'budget_summary') {
                        const bCard = card as BudgetCardPayload;
                        return (
                          <div
                            key={cIdx}
                            className="bg-cream p-3 rounded-xl border border-line text-xs space-y-1.5"
                          >
                            <div className="flex justify-between font-semibold text-ink">
                              <span>{bCard.title || 'Budget Snapshot'}</span>
                              <span className="font-mono text-teal">
                                {formatINR(bCard.budget.totalCost)} / {formatINR(bCard.budget.totalBudget)}
                              </span>
                            </div>
                            <div className="flex justify-between text-[11px] text-ink-3">
                              <span>Safe: {formatINR(bCard.budget.safeToSpend)}</span>
                              <span>Buffer left: {formatINR(bCard.budget.bufferRemaining)}</span>
                            </div>
                          </div>
                        );
                      }

                      if (card.type === 'approval_card') {
                        const approval = card as ApprovalCardPayload;
                        return (
                          <div
                            key={cIdx}
                            className="bg-amber/10 border border-amber/30 p-3 rounded-xl text-xs space-y-2"
                          >
                            <div className="flex items-center gap-1.5 font-semibold text-amber">
                              <AlertTriangle className="w-3.5 h-3.5" />
                              <span>{approval.title}</span>
                            </div>
                            <p className="text-ink-2 leading-relaxed text-[11px]">{approval.explanation}</p>
                            <div className="flex justify-between font-mono text-[11px] text-ink">
                              <span>Cost: {approval.extraCostLabel}</span>
                              <span className="text-ink-3">Recipient: {approval.recipient}</span>
                            </div>
                            <div className="grid grid-cols-2 gap-2 pt-1">
                              <button
                                onClick={() => handleSendMessage(`Approve action ${approval.actionId}`)}
                                className="py-1.5 px-2 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold rounded-btn transition-colors flex items-center justify-center gap-1 cursor-pointer text-xs"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>Approve</span>
                              </button>
                              <button
                                onClick={() => handleSendMessage(`Reject action ${approval.actionId}`)}
                                className="py-1.5 px-2 bg-cream hover:bg-cream-2 border border-line text-ink-2 hover:text-ink font-semibold rounded-btn transition-colors flex items-center justify-center gap-1 cursor-pointer text-xs"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                <span>Reject</span>
                              </button>
                            </div>
                          </div>
                        );
                      }

                      if (card.type === 'option_picker') {
                        const picker = card as OptionPickerPayload;
                        return (
                          <div key={cIdx} className="bg-paper border border-line rounded-xl p-3 text-xs space-y-2">
                            <div className="flex items-center justify-between border-b border-line pb-1.5">
                              <span className="font-semibold text-ink">{picker.title}</span>
                              <span className="text-[10px] text-teal font-mono uppercase bg-teal/10 px-1.5 py-0.5 rounded">
                                {picker.category}
                              </span>
                            </div>
                            <div className="space-y-1.5">
                              {picker.options?.map((opt) => (
                                <div key={opt.id} className="p-2 bg-cream/60 rounded-lg border border-line/60 flex items-center justify-between gap-2">
                                  <div className="space-y-0.5 flex-1 min-w-0">
                                    <div className="flex items-center gap-1.5">
                                      <span className="font-medium text-ink truncate">{opt.title}</span>
                                      {opt.tag && (
                                        <span className="text-[9px] bg-teal/15 text-teal px-1 rounded">{opt.tag}</span>
                                      )}
                                    </div>
                                    {opt.details && <p className="text-[10px] text-ink-3 truncate">{opt.details}</p>}
                                  </div>
                                  <div className="flex items-center gap-2 shrink-0">
                                    <span className="font-mono text-ink font-bold text-[11px]">{opt.priceLabel}</span>
                                    <button
                                      type="button"
                                      onClick={() => handleSendMessage(`Select ${picker.category} ${opt.id}`)}
                                      className="px-2 py-1 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold rounded text-[11px] cursor-pointer"
                                    >
                                      Select
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>
                            <p className="text-[9px] text-ink-3 italic">Sample options · Selection updates trip draft without auto-booking</p>
                          </div>
                        );
                      }

                      return null;
                    })}
                  </div>
                )}

                {/* Tool trace accordion */}
                {msg.reply?.toolCalls && msg.reply.toolCalls.length > 0 && (
                  <div className="mt-2 pt-2 border-t border-line/40">
                    <button
                      onClick={() => toggleTools(msg.id)}
                      className="text-[11px] font-mono text-ink-3 flex items-center gap-1 hover:text-ink cursor-pointer"
                    >
                      <span>Tools executed ({msg.reply.toolCalls.length})</span>
                      {showToolsForMsg[msg.id] ? (
                        <ChevronUp className="w-3 h-3" />
                      ) : (
                        <ChevronDown className="w-3 h-3" />
                      )}
                    </button>
                    {showToolsForMsg[msg.id] && (
                      <div className="mt-1.5 p-2 bg-cream rounded border border-line text-[10px] font-mono text-ink-2 space-y-1">
                        {msg.reply.toolCalls.map((t, tIdx) => (
                          <div key={tIdx} className="flex justify-between">
                            <span className="text-teal font-medium">{t.name}()</span>
                            <span className="text-ink-3">{t.status}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Timestamp & Replay Button */}
              <div className="flex items-center gap-1.5 mt-1 px-1">
                <span className="text-[10px] text-ink-3">{msg.timestamp}</span>
                {msg.sender === 'alexa' && (
                  <button
                    type="button"
                    onClick={() => speakText(msg.text)}
                    className="p-0.5 text-ink-3 hover:text-ink cursor-pointer"
                    title="Replay speech"
                    aria-label="Replay speech"
                  >
                    <Volume2 className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Composer */}
        <div className="p-3 bg-paper border-t border-line space-y-2">
          {/* Quick Prompts */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
            <button
              onClick={() => handleSendMessage('Plan 2 days in Delhi under ₹15,000')}
              className="px-2 py-0.5 bg-cream hover:bg-cream-2 border border-line rounded-full text-ink-2 whitespace-nowrap cursor-pointer"
            >
              Delhi under ₹15k
            </button>
            <button
              onClick={() => handleSendMessage('Add Old Delhi culinary food trail')}
              className="px-2 py-0.5 bg-cream hover:bg-cream-2 border border-line rounded-full text-ink-2 whitespace-nowrap cursor-pointer"
            >
              Add food trail
            </button>
            <button
              onClick={() => handleSendMessage('Train 12015 is delayed by 45 minutes')}
              className="px-2 py-0.5 bg-amber/10 hover:bg-amber/20 border border-amber/30 rounded-full text-amber whitespace-nowrap cursor-pointer"
            >
              45m train delay
            </button>
          </div>

          {micNotice && (
            <div className="p-2 bg-amber/10 border border-amber/30 rounded-lg text-[11px] text-amber flex items-center justify-between">
              <span>{micNotice}</span>
              <button
                type="button"
                onClick={() => setMicNotice(null)}
                className="text-amber hover:text-ink ml-2 cursor-pointer"
              >
                ×
              </button>
            </div>
          )}

          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <button
              type="button"
              onClick={toggleMic}
              title={voiceState === 'listening' ? 'Stop listening' : 'Start voice input'}
              className={`p-2.5 rounded-btn border transition-all cursor-pointer ${
                voiceState === 'listening'
                  ? 'bg-marigold text-marigold-ink border-marigold ring-2 ring-marigold/40'
                  : 'bg-cream hover:bg-cream-2 border-line text-ink'
              }`}
            >
              {voiceState === 'listening' ? (
                <Mic className="w-4 h-4 animate-pulse" />
              ) : (
                <Mic className="w-4 h-4" />
              )}
            </button>

            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask Alexa or type your travel requirements..."
              className="flex-1 bg-cream border border-line rounded-btn px-3 py-2 text-xs md:text-sm text-ink placeholder:text-ink-3 focus:outline-none focus:border-marigold transition-colors"
            />

            <button
              type="submit"
              disabled={!inputText.trim()}
              className="p-2.5 bg-marigold hover:bg-marigold-hover disabled:opacity-40 text-marigold-ink font-semibold rounded-btn transition-colors shadow-2xs cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>

      <VoiceSettingsModal
        isOpen={showVoiceSettings}
        onClose={() => setShowVoiceSettings(false)}
      />
    </div>
  );
}
