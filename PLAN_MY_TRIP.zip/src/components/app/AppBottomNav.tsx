import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Compass, Calendar, AlertTriangle, User } from 'lucide-react';

export default function AppBottomNav() {
  const location = useLocation();

  const items = [
    { to: '/app', label: 'Home', icon: Compass, exact: true },
    { to: '/app/trips', label: 'Trips', icon: Calendar },
    { to: '/app/rescue', label: 'Rescue', icon: AlertTriangle },
    { to: '/app/profile', label: 'Profile', icon: User }
  ];

  const isActive = (to: string, exact?: boolean) => {
    if (exact) return location.pathname === to;
    return location.pathname.startsWith(to);
  };

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-paper/95 backdrop-blur-md border-t border-line py-2 px-6 flex items-center justify-between font-sans">
      {items.map((item) => {
        const Icon = item.icon;
        const active = isActive(item.to, item.exact);
        return (
          <Link
            key={item.to}
            to={item.to}
            className={`flex flex-col items-center gap-1 text-[11px] font-medium transition-colors ${
              active ? 'text-marigold-ink font-semibold' : 'text-ink-3 hover:text-ink'
            }`}
          >
            <div
              className={`p-1 rounded-md transition-colors ${
                active ? 'bg-marigold text-marigold-ink' : ''
              }`}
            >
              <Icon className="w-5 h-5" />
            </div>
            <span>{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
