import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  Compass,
  Mic,
  User as UserIcon,
  LogOut,
  ChevronDown,
  Info,
  Calendar,
  AlertTriangle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface AppNavbarProps {
  onOpenAlexa: () => void;
}

export default function AppNavbar({ onOpenAlexa }: AppNavbarProps) {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const handleSignOut = async () => {
    try {
      await logout();
      navigate('/');
    } catch (err) {
      console.error('Sign out error:', err);
    }
  };

  const navLinks = [
    { to: '/app', label: 'Home', exact: true },
    { to: '/app/trips', label: 'My Trips' },
    { to: '/app/rescue', label: 'Journey Rescue' }
  ];

  const isActive = (to: string, exact?: boolean) => {
    if (exact) return location.pathname === to;
    return location.pathname.startsWith(to);
  };

  return (
    <header className="sticky top-0 z-30 bg-paper/95 backdrop-blur-md border-b border-line font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand & Nav */}
        <div className="flex items-center gap-8">
          <Link
            to="/app"
            className="flex items-center gap-2.5 font-display text-lg tracking-tight text-ink group"
          >
            <div className="w-8 h-8 rounded-lg bg-marigold flex items-center justify-center text-marigold-ink shadow-2xs group-hover:scale-105 transition-transform">
              <Compass className="w-4.5 h-4.5" />
            </div>
            <span className="font-semibold text-base">Plan My Trip</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1.5 text-xs font-semibold">
            {navLinks.map((link) => {
              const active = isActive(link.to, link.exact);
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`px-3.5 py-2 rounded-btn transition-colors ${
                    active
                      ? 'bg-cream text-ink border border-line'
                      : 'text-ink-2 hover:text-ink hover:bg-cream/60'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Right side controls */}
        <div className="flex items-center gap-3">
          {/* Sample Data Notice Pill */}
          <div className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 bg-cream-2 border border-line rounded-full text-[11px] font-medium text-ink-3">
            <span className="w-1.5 h-1.5 rounded-full bg-teal" />
            <span>Sample data · no real bookings</span>
          </div>

          {/* Quick Alexa Trigger */}
          <button
            onClick={onOpenAlexa}
            className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-marigold hover:bg-marigold-hover text-marigold-ink text-xs font-semibold rounded-btn transition-colors shadow-2xs cursor-pointer"
          >
            <Mic className="w-3.5 h-3.5" />
            <span>Ask Alexa</span>
          </button>

          {/* User Avatar Menu */}
          <div className="relative">
            <button
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="flex items-center gap-2 p-1.5 rounded-btn border border-line hover:bg-cream transition-colors cursor-pointer"
              aria-label="User account menu"
            >
              {user?.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.displayName || 'User'}
                  className="w-7 h-7 rounded-full object-cover border border-line"
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-cream-2 border border-line text-ink flex items-center justify-center text-xs font-bold font-display">
                  {user?.displayName ? user.displayName.charAt(0).toUpperCase() : 'G'}
                </div>
              )}
              <ChevronDown className="w-3.5 h-3.5 text-ink-3" />
            </button>

            {dropdownOpen && (
              <>
                <div
                  className="fixed inset-0 z-10"
                  onClick={() => setDropdownOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-56 bg-paper border border-line rounded-card shadow-lg py-2 z-20 text-xs">
                  <div className="px-4 py-2 border-b border-line">
                    <div className="font-semibold text-ink truncate">
                      {user?.displayName || 'Demo Guest Traveler'}
                    </div>
                    <div className="text-[11px] text-ink-3 truncate mt-0.5">
                      {user?.email || 'guest@planmytrip.demo'}
                    </div>
                  </div>

                  <Link
                    to="/app/profile"
                    onClick={() => setDropdownOpen(false)}
                    className="flex items-center gap-2 px-4 py-2.5 text-ink hover:bg-cream transition-colors"
                  >
                    <UserIcon className="w-4 h-4 text-ink-3" />
                    <span>View Profile & Settings</span>
                  </Link>

                  <div className="border-t border-line my-1" />

                  <button
                    onClick={() => {
                      setDropdownOpen(false);
                      handleSignOut();
                    }}
                    className="w-full flex items-center gap-2 px-4 py-2 text-coral hover:bg-coral/10 transition-colors text-left font-medium cursor-pointer"
                  >
                    <LogOut className="w-4 h-4 text-coral" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
