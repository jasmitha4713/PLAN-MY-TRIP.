import { describe, it, expect, vi, beforeEach } from 'vitest';
import { parseTripIntake } from '../../lib/intakeParser';

describe('Trip Planning Confirmation & Clarification State (Regression Tests)', () => {
  const samplePrompt = 'Plan a trip to Mumbai for 3 days, 5 to 6 members, budget ₹60,000';

  it('1. Parses range and stores unresolved traveller count as clarification, not completed count', () => {
    const intake = parseTripIntake(samplePrompt, 'Hyderabad');

    expect(intake.destination).toBe('Mumbai');
    expect(intake.origin).toBe('Hyderabad');
    expect(intake.days).toBe(3);
    expect(intake.budget).toBe(60000);
    // Travellers must NOT be guessed
    expect(intake.travellers).toBeNull();
    expect(intake.travellerRange).toEqual([5, 6]);
    expect(intake.clarifications.travellers).toBe('Would you like to plan for 5 or 6 travellers?');
  });

  it('2. Resolving to 5 travellers marks clarification resolved and delivers exact parameters', () => {
    const intake = parseTripIntake(samplePrompt, 'Hyderabad');
    const resolvedCount = 5;

    // Simulate resolving traveller count
    intake.travellers = resolvedCount;
    delete (intake.clarifications as any).travellers;

    expect(intake.travellers).toBe(5);
    expect(intake.clarifications.travellers).toBeUndefined();

    // Verify backend payload structure
    const payload = {
      origin: intake.origin,
      destination: intake.destination,
      budget_inr: intake.budget,
      travelers_count: intake.travellers,
      start_date: '2026-11-01',
      end_date: '2026-11-04',
      preferences: ['sightseeing', 'budget']
    };

    expect(payload.travelers_count).toBe(5);
    expect(payload.budget_inr).toBe(60000);
    expect(payload.origin).toBe('Hyderabad');
    expect(payload.destination).toBe('Mumbai');
  });

  it('3. Resolving to 6 travellers marks clarification resolved and delivers 6 travellers', () => {
    const intake = parseTripIntake(samplePrompt, 'Hyderabad');
    const resolvedCount = 6;

    intake.travellers = resolvedCount;
    delete (intake.clarifications as any).travellers;

    expect(intake.travellers).toBe(6);
    expect(intake.clarifications.travellers).toBeUndefined();

    const payload = {
      origin: intake.origin,
      destination: intake.destination,
      budget_inr: intake.budget,
      travelers_count: intake.travellers,
      start_date: '2026-11-01',
      end_date: '2026-11-04',
      preferences: ['sightseeing', 'budget']
    };

    expect(payload.travelers_count).toBe(6);
    expect(payload.budget_inr).toBe(60000);
  });

  it('4. Re-rendering does not resurrect resolved clarification if marked resolved', () => {
    const intake = parseTripIntake(samplePrompt, 'Hyderabad');
    const resolvedSet = new Set<string>();

    // User selects 5 travellers
    resolvedSet.add('travellers');
    delete (intake.clarifications as any).travellers;

    // If a re-render evaluates clarifications
    const shouldShowNotice = Boolean(intake.clarifications.travellers && !resolvedSet.has('travellers'));
    expect(shouldShowNotice).toBe(false);
  });

  it('5. Single submission guard blocks duplicate simultaneous backend calls', async () => {
    let callCount = 0;
    let isSubmitting = false;

    const mockApiCall = vi.fn().mockImplementation(async () => {
      callCount++;
      await new Promise(r => setTimeout(r, 50));
      return { trip_id: 'trip_hyd_mum_test' };
    });

    const submit = async () => {
      if (isSubmitting) return;
      isSubmitting = true;
      try {
        await mockApiCall();
      } finally {
        isSubmitting = false;
      }
    };

    // User double-clicks "Plan trip"
    await Promise.all([submit(), submit(), submit()]);

    expect(callCount).toBe(1);
    expect(mockApiCall).toHaveBeenCalledTimes(1);
  });

  it('6. On backend failure, preserves user draft and provides actionable error without modal loop', async () => {
    const userDraft = {
      fromCity: 'Hyderabad',
      toCity: 'Mumbai',
      days: 3,
      totalBudget: '60000',
      totalTravellers: 5
    };

    let submitError: string | null = null;
    let isSubmitting = false;

    const failingApiCall = vi.fn().mockRejectedValue(new Error('Backend timeout: Trip service unavailable'));

    const submit = async () => {
      if (isSubmitting) return;
      isSubmitting = true;
      submitError = null;
      try {
        await failingApiCall();
      } catch (err: any) {
        submitError = err.message;
      } finally {
        isSubmitting = false;
      }
    };

    await submit();

    // Verify error was captured
    expect(submitError).toBe('Backend timeout: Trip service unavailable');
    expect(isSubmitting).toBe(false);

    // Verify user draft inputs are NOT wiped
    expect(userDraft.fromCity).toBe('Hyderabad');
    expect(userDraft.toCity).toBe('Mumbai');
    expect(userDraft.days).toBe(3);
    expect(userDraft.totalBudget).toBe('60000');
    expect(userDraft.totalTravellers).toBe(5);
  });

  it('7. BUG A Regression: Normalizes "Planet trip" and extracts "five members" + "around 60k"', () => {
    const spokenTranscript = 'Planet trip to Mumbai for 3 days For five members around 60k';
    const intake = parseTripIntake(spokenTranscript, 'Hyderabad');

    expect(intake.destination).toBe('Mumbai');
    expect(intake.days).toBe(3);
    expect(intake.travellers).toBe(5);
    expect(intake.adults).toBe(5);
    // Preserves 60000 as approximate budget for confirmation without silent loss
    expect(intake.budget || intake.approximateBudget).toBe(60000);
    expect(intake.clarifications.travellers).toBeUndefined();
  });

  it('8. Number words and currency expressions: "sixty thousand", "under 60 thousand", "five members"', () => {
    const prompt1 = 'Plan a trip to Mumbai for 3 days for five members with budget sixty thousand';
    const intake1 = parseTripIntake(prompt1, 'Hyderabad');
    expect(intake1.travellers).toBe(5);
    expect(intake1.budget).toBe(60000);

    const prompt2 = 'Plan a trip to Mumbai for 3 days for 4 people under 60 thousand';
    const intake2 = parseTripIntake(prompt2, 'Hyderabad');
    expect(intake2.travellers).toBe(4);
    expect(intake2.budget).toBe(60000);
  });

  it('9. Missing budget: asks for budget explicitly while preserving destination, origin, days, travellers', () => {
    const promptNoBudget = 'Plan a trip to Mumbai for 3 days for five members';
    const intake = parseTripIntake(promptNoBudget, 'Hyderabad');

    expect(intake.destination).toBe('Mumbai');
    expect(intake.origin).toBe('Hyderabad');
    expect(intake.days).toBe(3);
    expect(intake.travellers).toBe(5);
    expect(intake.budget).toBeNull();
    expect(intake.clarifications.budget).toBe('What is your total budget in rupees (₹)?');
  });

  it('10. Edited transcript controls parsed values', () => {
    const initialTranscript = 'Planet trip to Mumbai for 3 days for 2 members around 30k';
    const editedTranscript = 'Plan a trip to Mumbai for 3 days for five members around 60k';

    const initialIntake = parseTripIntake(initialTranscript, 'Hyderabad');
    expect(initialIntake.travellers).toBe(2);
    expect(initialIntake.budget || initialIntake.approximateBudget).toBe(30000);

    const editedIntake = parseTripIntake(editedTranscript, 'Hyderabad');
    expect(editedIntake.travellers).toBe(5);
    expect(editedIntake.budget || editedIntake.approximateBudget).toBe(60000);
  });
});

