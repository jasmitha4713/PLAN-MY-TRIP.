import React, { useState, useEffect } from 'react';
import { Navigate, Outlet, useSearchParams } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import AppNavbar from './AppNavbar';
import AppBottomNav from './AppBottomNav';
import AlexaDrawer from './AlexaDrawer';
import { Mic, Loader2 } from 'lucide-react';

export default function AppLayout() {
  const { user, loading, openAuthModal, signInWithDemoUser } = useAuth();
  const [searchParams] = useSearchParams();
  const [alexaOpen, setAlexaOpen] = useState(false);

  useEffect(() => {
    if (searchParams.get('demo') === 'true' && !user) {
      signInWithDemoUser();
    }
  }, [searchParams, user, signInWithDemoUser]);

  // If unauthenticated and not in demo query, prompt modal and redirect to landing
  if (!user && searchParams.get('demo') !== 'true') {
    if (loading) {
      return (
        <div className="min-h-screen bg-cream flex flex-col items-center justify-center p-4 font-sans text-ink">
          <Loader2 className="w-8 h-8 animate-spin text-marigold mb-3" />
          <p className="text-sm font-medium text-ink-2">Opening Plan My Trip workspace...</p>
        </div>
      );
    }
    setTimeout(() => openAuthModal(), 100);
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-cream text-ink flex flex-col font-sans selection:bg-marigold selection:text-marigold-ink">
      <AppNavbar onOpenAlexa={() => setAlexaOpen(true)} />

      <main className="flex-1 pb-20 md:pb-12">
        <Outlet />
      </main>

      <AppBottomNav />

      {/* Floating Alexa Button (Bottom Right) */}
      <button
        onClick={() => setAlexaOpen(true)}
        className="fixed bottom-20 md:bottom-6 right-6 z-40 w-13 h-13 rounded-full bg-marigold hover:bg-marigold-hover text-marigold-ink flex items-center justify-center shadow-lg transition-transform hover:scale-105 active:scale-95 cursor-pointer ring-4 ring-marigold/20"
        aria-label="Open Alexa travel assistant"
      >
        <Mic className="w-6 h-6 text-marigold-ink" />
      </button>

      {/* Persistent Alexa Drawer */}
      <AlexaDrawer isOpen={alexaOpen} onClose={() => setAlexaOpen(false)} />
    </div>
  );
}
