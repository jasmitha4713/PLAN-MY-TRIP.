import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  MapPin, 
  Calendar, 
  Users, 
  IndianRupee, 
  ArrowRight, 
  AlertCircle, 
  Compass,
  Loader2
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { SUPPORTED_CITIES } from '../../data/destinations';
import { ParsedTripIntake } from '../../lib/intakeParser';
import { useAuth } from '../../context/AuthContext';
import { useTrip } from '../../context/TripContext';
import { formatINR } from '../../lib/budget';
import { getAlexaClient } from '../../lib/alexa/client';
import { getFixturesForDestination, TripDraft } from '../../data/fixtures';

interface ConfirmTripSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  parsedIntake?: ParsedTripIntake | null;
  defaultOrigin?: string;
}

export default function ConfirmTripSheet({
  isOpen,
  onClose,
  onSuccess,
  parsedIntake,
  defaultOrigin = 'Hyderabad'
}: ConfirmTripSheetProps) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { setAuthoritativeTrip } = useTrip();

  // Form Fields
  const [fromCity, setFromCity] = useState('');
  const [toCity, setToCity] = useState('');
  const [startDate, setStartDate] = useState('');
  const [days, setDays] = useState(3);
  const [adults, setAdults] = useState(2);
  const [children, setChildren] = useState(0);
  const [totalBudget, setTotalBudget] = useState<string>('15000');

  // Clarification tracking
  const [clarificationNotice, setClarificationNotice] = useState<string | null>(null);
  const [resolvedClarifications, setResolvedClarifications] = useState<Set<string>>(new Set());
  const [unsupportedNotice, setUnsupportedNotice] = useState<{ name: string; suggestions: string[] } | null>(null);

  // Submission & error handling
  const [isSubmitting, setIsSubmitting] = useState(false);
  const isSubmittingRef = useRef(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Track sheet open transitions to avoid clobbering user edits on re-renders
  const wasOpenRef = useRef(false);

  useEffect(() => {
    if (!isOpen) {
      wasOpenRef.current = false;
      return;
    }

    // Only populate fields on fresh open or when parsedIntake specifically changes
    if (!wasOpenRef.current) {
      wasOpenRef.current = true;
      setSubmitError(null);
      setIsSubmitting(false);

      if (parsedIntake) {
        setFromCity(parsedIntake.origin || defaultOrigin);
        setToCity(parsedIntake.destination || '');
        setStartDate(parsedIntake.startDate || new Date().toISOString().split('T')[0]);
        setDays(parsedIntake.days || 3);

        if (parsedIntake.travellerRange) {
          if (!resolvedClarifications.has('travellers')) {
            setAdults(parsedIntake.travellerRange[0]);
            setChildren(0);
          }
        } else if (parsedIntake.travellers) {
          setAdults(parsedIntake.travellers);
          setChildren(parsedIntake.children || 0);
        } else if (parsedIntake.adults && parsedIntake.adults > 0) {
          setAdults(parsedIntake.adults);
          setChildren(parsedIntake.children || 0);
        } else {
          setAdults(1);
          setChildren(0);
        }

        if (parsedIntake.budget) {
          setTotalBudget(String(parsedIntake.budget));
        } else if (parsedIntake.approximateBudget) {
          setTotalBudget(String(parsedIntake.approximateBudget));
        } else {
          setTotalBudget('');
        }

        // Clarifications: ONLY show if not previously marked resolved
        if (parsedIntake.clarifications.travellers && !resolvedClarifications.has('travellers')) {
          setClarificationNotice(parsedIntake.clarifications.travellers);
        } else if (parsedIntake.clarifications.budget && !resolvedClarifications.has('budget')) {
          setClarificationNotice(parsedIntake.clarifications.budget);
        } else if (parsedIntake.clarifications.origin && !resolvedClarifications.has('origin')) {
          setClarificationNotice(parsedIntake.clarifications.origin);
        } else {
          setClarificationNotice(null);
        }

        // Check unsupported destination
        if (parsedIntake.isUnsupportedDestination && parsedIntake.unsupportedDestinationName) {
          setUnsupportedNotice({
            name: parsedIntake.unsupportedDestinationName,
            suggestions: parsedIntake.suggestedDestinations
          });
        } else {
          setUnsupportedNotice(null);
        }
      } else {
        // Empty fill mode
        setFromCity(defaultOrigin);
        setToCity('');
        setStartDate(new Date().toISOString().split('T')[0]);
        setDays(3);
        setAdults(2);
        setChildren(0);
        setTotalBudget('15000');
        setClarificationNotice(null);
        setUnsupportedNotice(null);
        setResolvedClarifications(new Set());
      }
    }
  }, [isOpen, parsedIntake, defaultOrigin, resolvedClarifications]);

  if (!isOpen) return null;

  const totalTravellers = adults + children;
  const numBudget = parseInt(totalBudget.replace(/,/g, ''), 10) || 0;

  // Validation
  const isFromValid = Boolean(fromCity.trim());
  const isToValid = Boolean(toCity.trim()) && !unsupportedNotice;
  const isDateValid = Boolean(startDate);
  const isDaysValid = days >= 1 && days <= 21;
  const isTravellersValid = totalTravellers >= 1;
  const isBudgetValid = numBudget >= 3000;

  const isValid = isFromValid && isToValid && isDateValid && isDaysValid && isTravellersValid && isBudgetValid;

  const handleSelectSuggestedCity = (cityName: string) => {
    setToCity(cityName);
    setUnsupportedNotice(null);
    setClarificationNotice(null);
  };

  const handleResolveTravellers = (count: number) => {
    setAdults(count);
    setChildren(0);
    setClarificationNotice(null);
    setResolvedClarifications(prev => {
      const next = new Set(prev);
      next.add('travellers');
      return next;
    });

    if (parsedIntake) {
      parsedIntake.travellers = count;
      if (parsedIntake.clarifications) {
        delete (parsedIntake.clarifications as any).travellers;
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValid || isSubmittingRef.current) return;

    isSubmittingRef.current = true;
    setIsSubmitting(true);
    setSubmitError(null);

    const sDate = startDate || new Date().toISOString().split('T')[0];
    const sDateObj = new Date(sDate);
    const eDateObj = new Date(sDateObj);
    eDateObj.setDate(eDateObj.getDate() + (days || 3));
    const eDate = eDateObj.toISOString().split('T')[0];

    const toolArgs = {
      origin: fromCity.trim(),
      destination: toCity.trim(),
      budget_inr: numBudget,
      start_date: sDate,
      end_date: eDate,
      travelers_count: totalTravellers,
      preferences: ['sightseeing', 'budget'],
      user_id: user?.uid || 'demo-traveler-001'
    };

    let tripData: any = null;
    let backendErr: string | null = null;

    // 1. Try MCP tool first
    try {
      const client = getAlexaClient();
      if ('callMcpTool' in client && typeof (client as any).callMcpTool === 'function') {
        const mcpRes = await (client as any).callMcpTool('plan_trip', toolArgs);
        if (mcpRes && mcpRes.status === 'success' && mcpRes.data) {
          tripData = mcpRes.data;
        } else if (mcpRes && mcpRes.trip_id) {
          tripData = mcpRes;
        } else if (mcpRes && mcpRes.status === 'error' && mcpRes.error) {
          backendErr = mcpRes.error;
        }
      }
    } catch (err: any) {
      console.warn('MCP call error, attempting backend directly:', err);
    }

    // 2. Fallback to direct backend API call
    if (!tripData && !backendErr) {
      try {
        const resp = await fetch('http://localhost:8000/api/trips/plan', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(toolArgs)
        });
        if (resp.ok) {
          tripData = await resp.json();
        } else {
          const errJson = await resp.json().catch(() => ({}));
          backendErr = errJson.detail || `Backend request failed with status ${resp.status}`;
        }
      } catch (err: any) {
        backendErr = err.message || 'Failed to connect to backend server';
      }
    }

    // Handle success or fallback: build authoritative DRAFT trip and navigate to options flow
    const destSlug = toCity.trim().toLowerCase().replace(/\s+/g, '-');
    const tripId = tripData?.trip_id || `trip_${fromCity.toLowerCase().slice(0, 3)}_${destSlug.slice(0, 3)}_${Date.now().toString(36)}`;

    const draftTrip: TripDraft = {
      id: tripId,
      backendTripId: tripId,
      userId: user?.uid || 'demo-traveler-001',
      origin: fromCity.trim(),
      destination: toCity.trim(),
      days: days,
      travellers: totalTravellers,
      totalBudget: numBudget,
      status: 'draft',
      selections: {
        transport: null, // User selects on Step 1
        stay: null,      // User selects on Step 2
        localTravel: [],
        experiences: [],
        foodPerPersonPerDay: 400
      },
      schedule: {
        plannedArrival: '01:30 PM',
        stayCutoff: '08:00 PM',
        checkInTime: '02:00 PM',
        checkOutTime: '11:00 AM'
      },
      itineraryData: tripData?.itinerary || [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setAuthoritativeTrip(draftTrip);
    isSubmittingRef.current = false;
    setIsSubmitting(false);
    onSuccess?.();
    onClose();

    if (!window.location.pathname.startsWith('/app/plan')) {
      navigate(`/app/plan/${destSlug}`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-ink/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        className="relative w-full max-w-xl bg-paper border border-line rounded-card shadow-floating overflow-hidden transition-all animate-in fade-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="bg-cream/70 px-6 py-4 border-b border-line flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-marigold flex items-center justify-center text-marigold-ink font-semibold">
              <Compass className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-display text-base font-semibold text-ink leading-tight">
                Confirm your trip
              </h2>
              <p className="text-xs text-ink-3">Verify all details before we assemble your itinerary</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-cream border border-transparent hover:border-line flex items-center justify-center text-ink-3 hover:text-ink transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Submission Failure Callout */}
          {submitError && (
            <div className="p-3 bg-coral/10 border border-coral/30 rounded-xl flex items-center justify-between gap-2 text-xs text-coral">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{submitError}</span>
              </div>
              <button
                type="button"
                onClick={() => setSubmitError(null)}
                className="font-medium underline hover:text-ink cursor-pointer text-[11px]"
              >
                Dismiss
              </button>
            </div>
          )}

          {/* Plain language clarification callout */}
          {clarificationNotice && (
            <div className="p-3.5 bg-amber/10 border border-amber/30 rounded-xl flex items-start gap-3 text-xs text-ink">
              <AlertCircle className="w-4 h-4 text-amber shrink-0 mt-0.5" />
              <div className="flex-1 space-y-2">
                <span className="font-semibold block text-amber">Clarification needed:</span>
                <p className="font-medium">{clarificationNotice}</p>
                {parsedIntake?.travellerRange && (
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => handleResolveTravellers(parsedIntake.travellerRange![0])}
                      className="px-3.5 py-1.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold rounded-btn transition-colors cursor-pointer text-xs shadow-2xs"
                    >
                      Plan for {parsedIntake.travellerRange[0]} travellers
                    </button>
                    <button
                      type="button"
                      onClick={() => handleResolveTravellers(parsedIntake.travellerRange![1])}
                      className="px-3.5 py-1.5 bg-cream hover:bg-cream-2 border border-line hover:border-marigold text-ink font-semibold rounded-btn transition-colors cursor-pointer text-xs shadow-2xs"
                    >
                      Plan for {parsedIntake.travellerRange[1]} travellers
                    </button>
                  </div>
                )}

                {!parsedIntake?.travellerRange && parsedIntake?.clarifications.travellers && !resolvedClarifications.has('travellers') && (
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    {[1, 2, 4, 5].map((cnt) => (
                      <button
                        key={cnt}
                        type="button"
                        onClick={() => handleResolveTravellers(cnt)}
                        className="px-3 py-1 bg-cream hover:bg-cream-2 border border-line hover:border-marigold text-ink font-medium rounded-btn transition-colors cursor-pointer text-xs shadow-2xs"
                      >
                        {cnt === 1 ? 'Solo (1)' : cnt === 2 ? 'Couple (2)' : cnt === 4 ? 'Family (4)' : `${cnt} travellers`}
                      </button>
                    ))}
                  </div>
                )}

                {parsedIntake?.clarifications.budget && (
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    {[15000, 30000, 60000].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => {
                          setTotalBudget(String(amt));
                          setClarificationNotice(null);
                          setResolvedClarifications(prev => new Set([...prev, 'budget']));
                        }}
                        className="px-3 py-1 bg-cream hover:bg-cream-2 border border-line hover:border-marigold text-ink font-medium rounded-btn transition-colors cursor-pointer text-xs shadow-2xs"
                      >
                        ₹{amt.toLocaleString('en-IN')}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Unsupported Destination Callout */}
          {unsupportedNotice && (
            <div className="p-4 bg-coral/10 border border-coral/30 rounded-xl space-y-2 text-xs text-ink">
              <div className="flex items-center gap-2 text-coral font-semibold">
                <AlertCircle className="w-4 h-4" />
                <span>We don't have sample data for {unsupportedNotice.name} yet.</span>
              </div>
              <p className="text-ink-2">
                In this presentation prototype, we only use verified sample data. Please choose one of the nearest supported destinations below:
              </p>
              <div className="flex flex-wrap gap-2 pt-1">
                {unsupportedNotice.suggestions.map((city) => (
                  <button
                    key={city}
                    type="button"
                    onClick={() => handleSelectSuggestedCity(city)}
                    className="px-3 py-1 bg-paper hover:bg-cream border border-line hover:border-marigold rounded-full font-medium text-ink transition-colors cursor-pointer shadow-2xs"
                  >
                    Select {city}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* 1. Origin & Destination */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-ink mb-1.5 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-marigold" />
                <span>From (Origin City) *</span>
              </label>
              <select
                value={fromCity}
                onChange={(e) => setFromCity(e.target.value)}
                className="w-full bg-cream border border-line rounded-btn px-3 py-2.5 text-sm text-ink focus:outline-none focus:border-marigold"
                required
              >
                <option value="">Select departure city</option>
                {SUPPORTED_CITIES.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name} ({c.state})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-ink mb-1.5 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-teal" />
                <span>To (Destination) *</span>
              </label>
              <select
                value={toCity}
                onChange={(e) => {
                  setToCity(e.target.value);
                  setUnsupportedNotice(null);
                }}
                className={`w-full bg-cream border ${!isToValid && toCity ? 'border-coral' : 'border-line'} rounded-btn px-3 py-2.5 text-sm text-ink focus:outline-none focus:border-marigold`}
                required
              >
                <option value="">Select destination</option>
                {SUPPORTED_CITIES.map((c) => (
                  <option key={c.id} value={c.name} disabled={c.name === fromCity}>
                    {c.name} ({c.state})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* 2. Start Date & Duration */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-ink mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-marigold" />
                <span>Start Date *</span>
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                className="w-full bg-cream border border-line rounded-btn px-3 py-2 text-sm text-ink focus:outline-none focus:border-marigold"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-ink mb-1.5">
                <span>Duration (Days) *</span>
              </label>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setDays(Math.max(1, days - 1))}
                  className="w-9 h-9 bg-cream border border-line rounded-btn font-bold text-ink hover:bg-cream-2 transition-colors cursor-pointer"
                >
                  -
                </button>
                <span className="flex-1 text-center font-display font-semibold text-base text-ink py-1 bg-cream rounded-btn border border-line">
                  {days} {days === 1 ? 'Day' : 'Days'} ({Math.max(1, days - 1)} Nights)
                </span>
                <button
                  type="button"
                  onClick={() => setDays(Math.min(14, days + 1))}
                  className="w-9 h-9 bg-cream border border-line rounded-btn font-bold text-ink hover:bg-cream-2 transition-colors cursor-pointer"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          {/* 3. Travellers Stepper (Adults + Children) */}
          <div>
            <label className="block text-xs font-semibold text-ink mb-1.5 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-marigold" />
              <span>Travellers ({totalTravellers} Total) *</span>
            </label>
            <div className="grid grid-cols-2 gap-3 p-3 bg-cream/60 rounded-xl border border-line">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-ink">Adults</div>
                  <div className="text-[11px] text-ink-3">Age 12+</div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setAdults(Math.max(1, adults - 1))}
                    className="w-7 h-7 bg-paper border border-line rounded-btn text-xs font-bold hover:bg-cream transition-colors"
                  >
                    -
                  </button>
                  <span className="w-6 text-center text-xs font-semibold">{adults}</span>
                  <button
                    type="button"
                    onClick={() => setAdults(Math.min(10, adults + 1))}
                    className="w-7 h-7 bg-paper border border-line rounded-btn text-xs font-bold hover:bg-cream transition-colors"
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between border-l border-line pl-3">
                <div>
                  <div className="text-xs font-semibold text-ink">Children</div>
                  <div className="text-[11px] text-ink-3">Age 2-11</div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setChildren(Math.max(0, children - 1))}
                    className="w-7 h-7 bg-paper border border-line rounded-btn text-xs font-bold hover:bg-cream transition-colors"
                  >
                    -
                  </button>
                  <span className="w-6 text-center text-xs font-semibold">{children}</span>
                  <button
                    type="button"
                    onClick={() => setChildren(Math.min(6, children + 1))}
                    className="w-7 h-7 bg-paper border border-line rounded-btn text-xs font-bold hover:bg-cream transition-colors"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* 4. Total Budget */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-ink flex items-center gap-1.5">
                <IndianRupee className="w-3.5 h-3.5 text-marigold" />
                <span>Total Budget (₹) *</span>
              </label>
              {numBudget > 0 && totalTravellers > 0 && (
                <span className="text-[11px] text-teal font-medium">
                  ~{formatINR(Math.round(numBudget / totalTravellers))} per person
                </span>
              )}
            </div>
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 text-ink-3 font-semibold text-sm">₹</span>
              <input
                type="number"
                step="500"
                min="3000"
                max="250000"
                value={totalBudget}
                onChange={(e) => setTotalBudget(e.target.value)}
                placeholder="e.g. 60000"
                className={`w-full bg-cream border ${!isBudgetValid && totalBudget ? 'border-coral' : 'border-line'} rounded-btn pl-8 pr-4 py-2.5 text-sm text-ink font-mono font-medium focus:outline-none focus:border-marigold`}
                required
              />
            </div>
            {numBudget < 3000 && totalBudget !== '' && (
              <p className="text-[11px] text-coral mt-1">
                Minimum budget is ₹3,000 to cover travel and stay.
              </p>
            )}
          </div>

          {/* Actions */}
          <div className="pt-2 border-t border-line flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2.5 text-xs font-medium text-ink-2 hover:text-ink transition-colors cursor-pointer disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!isValid || isSubmitting}
              className={`px-6 py-2.5 rounded-btn font-semibold text-xs flex items-center gap-2 transition-all cursor-pointer ${
                isValid && !isSubmitting
                  ? 'bg-marigold hover:bg-marigold-hover text-marigold-ink shadow-sm'
                  : 'bg-line text-ink-3 cursor-not-allowed opacity-60'
              }`}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-marigold-ink" />
                  <span>Planning trip...</span>
                </>
              ) : (
                <>
                  <span>Plan trip</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
