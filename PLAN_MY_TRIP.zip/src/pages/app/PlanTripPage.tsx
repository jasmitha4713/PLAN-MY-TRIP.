import React, { useState, useMemo, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Clock,
  MapPin,
  Calendar,
  Users,
  IndianRupee,
  ShieldCheck,
  Plane,
  Train,
  Bus,
  Car,
  Bike,
  Utensils,
  Camera,
  Info,
  ChevronDown,
  ChevronUp,
  X,
  Undo2,
  Sparkles,
  HelpCircle
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTrip } from '../../context/TripContext';
import { 
  SUPPORTED_CITIES, 
  findCityByName, 
  generateTransportOptions, 
  GeneratedTransportOption,
  AttractionData,
  StayData,
  BikeModel,
  FoodExperienceData 
} from '../../data/destinations';
import { formatINR } from '../../lib/budget';
import PriceLine from '../../components/app/PriceLine';
import ConfirmTripSheet from '../../components/app/ConfirmTripSheet';
import imageColorsData from '../../data/imageColors.json';

const imageColors: Record<string, string> = imageColorsData;

type PlanStep = 'transport' | 'stay' | 'places' | 'local' | 'food';

const STEPS: { id: PlanStep; label: string; num: number }[] = [
  { id: 'transport', label: 'Getting there', num: 1 },
  { id: 'stay', label: 'Stay', num: 2 },
  { id: 'places', label: 'Places to visit', num: 3 },
  { id: 'local', label: 'Getting around', num: 4 },
  { id: 'food', label: 'Food', num: 5 }
];

export default function PlanTripPage() {
  const { id: routeId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { currentTrip, updateTrip, updateSelections } = useTrip();

  // Resolve Destination
  const destData = useMemo(() => {
    let dest = findCityByName(currentTrip.destination);
    if (!dest && routeId) {
      const cityPart = routeId.split('-')[0];
      dest = findCityByName(cityPart);
    }
    return dest || SUPPORTED_CITIES[0];
  }, [currentTrip.destination, routeId]);

  // Ensure an authoritative canonical backend trip ID exists in SQLite
  useEffect(() => {
    const hasCanonicalId = currentTrip.backendTripId?.startsWith('trip_') || currentTrip.id?.startsWith('trip_');
    if (!hasCanonicalId) {
      const orig = currentTrip.origin || 'Hyderabad';
      const dest = destData.name || currentTrip.destination || 'Mumbai';
      fetch('http://localhost:8000/api/trips/plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          origin: orig,
          destination: dest,
          budget_inr: currentTrip.totalBudget || 15000,
          travelers_count: currentTrip.travellers || 2,
          user_id: user?.uid || 'demo-traveler-001',
          start_date: '2026-11-01',
          end_date: '2026-11-03'
        })
      })
        .then((r) => (r.ok ? r.json() : null))
        .then((data) => {
          if (data?.trip_id) {
            updateTrip({ id: data.trip_id, backendTripId: data.trip_id });
          }
        })
        .catch(() => {});
    }
  }, [destData.name]);

  const originCity = currentTrip.origin || 'New Delhi';
  const travellers = Math.max(1, currentTrip.travellers || 2);
  const days = Math.max(1, currentTrip.days || 3);
  const nights = Math.max(1, days - 1);
  const totalBudget = Math.max(3000, currentTrip.totalBudget || 15000);

  // Stepper State
  const [currentStep, setCurrentStep] = useState<PlanStep>('transport');
  const [showConfirmSheet, setShowConfirmSheet] = useState(false);

  // STEP 1: TRANSPORT STATE
  const [transportMode, setTransportMode] = useState<'train' | 'flight' | 'bus'>('train');
  const [isRoundTrip, setIsRoundTrip] = useState(true);
  const [transportSort, setTransportSort] = useState<'price' | 'duration' | 'departure'>('price');
  const [showMoreTransport, setShowMoreTransport] = useState(false);
  const [selectedTransport, setSelectedTransport] = useState<GeneratedTransportOption | null>(null);
  const [transportDetailsDrawer, setTransportDetailsDrawer] = useState<GeneratedTransportOption | null>(null);

  // STEP 2: STAY STATE
  const [stayOccupancy, setStayOccupancy] = useState<number>(2); // guests per room
  const [roomsCount, setRoomsCount] = useState<number>(Math.ceil(travellers / 2));
  const [selectedStay, setSelectedStay] = useState<StayData | null>(null);
  const [stayDetailsDrawer, setStayDetailsDrawer] = useState<StayData | null>(null);

  // STEP 3: PLACES TO VISIT STATE
  const [selectedPlaces, setSelectedPlaces] = useState<AttractionData[]>([]);

  // STEP 4: GETTING AROUND STATE
  const [selectedLocalModes, setSelectedLocalModes] = useState<{
    cabFullDayDays: number;
    hasAutoPass: boolean;
    autoRidesCount: number;
    hasMetroPass: boolean;
    selectedBikeModelId?: string;
    bikeDays: number;
    selectedCarType?: 'self_drive' | 'with_driver';
    carDays: number;
    hasAirportPickup: boolean;
    hasStationPickup: boolean;
  }>({
    cabFullDayDays: 0,
    hasAutoPass: false,
    autoRidesCount: 0,
    hasMetroPass: false,
    bikeDays: 0,
    carDays: 0,
    hasAirportPickup: false,
    hasStationPickup: false
  });

  // STEP 5: FOOD STATE
  const [foodRatePerDay, setFoodRatePerDay] = useState<number>(400); // slider ₹250 - ₹1,200
  const [selectedFoodExperiences, setSelectedFoodExperiences] = useState<FoodExperienceData[]>([]);

  // Inline Budget Alert State
  const [budgetAlert, setBudgetAlert] = useState<{
    show: boolean;
    overBy: number;
    lastAction?: () => void;
  } | null>(null);

  // Available Transport Options from Generator
  const transportData = useMemo(() => {
    return generateTransportOptions(originCity, destData.name);
  }, [originCity, destData.name]);

  // Sync rooms count when travellers or occupancy changes
  useEffect(() => {
    setRoomsCount(Math.ceil(travellers / stayOccupancy));
  }, [travellers, stayOccupancy]);

  // Sync state with authoritative currentTrip.selections
  useEffect(() => {
    if (currentTrip.selections?.transport) {
      const match = transportData.options.find(
        o => o.id === currentTrip.selections.transport?.id || 
             o.serviceName === currentTrip.selections.transport?.title ||
             o.operator === currentTrip.selections.transport?.provider
      );
      if (match) {
        setSelectedTransport(match);
      }
    }
  }, [currentTrip.selections?.transport, transportData.options]);

  useEffect(() => {
    if (currentTrip.selections?.stay) {
      const match = destData.stays.find(
        s => s.id === currentTrip.selections.stay?.id || 
             s.name === currentTrip.selections.stay?.name
      );
      if (match) {
        setSelectedStay(match);
      }
    }
  }, [currentTrip.selections?.stay, destData.stays]);

  // Initial sights (top 3)
  useEffect(() => {
    if (selectedPlaces.length === 0 && destData.attractions.length > 0) {
      const initialSights = destData.attractions.slice(0, 3);
      setSelectedPlaces(initialSights);
    }
  }, [destData]);

  // -------------------------------------------------------------
  // PURE BUDGET CALCULATIONS
  // -------------------------------------------------------------
  const buffer = Math.round(0.08 * totalBudget);
  const spendableTarget = totalBudget - buffer;

  // Category targets
  const categoryTargets = {
    transport: Math.round(spendableTarget * 0.35),
    stay: Math.round(spendableTarget * 0.30),
    food: Math.round(spendableTarget * 0.15),
    local: Math.round(spendableTarget * 0.10),
    places: Math.round(spendableTarget * 0.10)
  };

  // 1. Transport Cost: farePerPerson * travellers * legs
  const transportCost = useMemo(() => {
    if (!selectedTransport) return 0;
    const unitFare = isRoundTrip ? selectedTransport.roundTripFarePerPerson : selectedTransport.farePerPerson;
    return Math.round(unitFare * travellers);
  }, [selectedTransport, isRoundTrip, travellers]);

  // 2. Stay Cost: ratePerNight * roomsCount * nights
  const stayCost = useMemo(() => {
    if (!selectedStay) return 0;
    return Math.round(selectedStay.ratePerNight * roomsCount * nights);
  }, [selectedStay, roomsCount, nights]);

  // 3. Places Cost: sum(ticketPricePerPerson * travellers)
  const placesCost = useMemo(() => {
    return selectedPlaces.reduce((sum, p) => sum + Math.round(p.ticketPricePerPerson * travellers), 0);
  }, [selectedPlaces, travellers]);

  // 4. Local Transit Cost
  const bikesNeeded = Math.ceil(travellers / 2);
  const cabsNeeded = Math.ceil(travellers / 4);

  const localCost = useMemo(() => {
    let cost = 0;
    // Cabs
    if (selectedLocalModes.cabFullDayDays > 0) {
      cost += destData.localTransit.cabFullDay * selectedLocalModes.cabFullDayDays * cabsNeeded;
    }
    // Auto
    if (selectedLocalModes.autoRidesCount > 0) {
      cost += destData.localTransit.autoPerRide * selectedLocalModes.autoRidesCount * cabsNeeded;
    }
    // Metro pass
    if (selectedLocalModes.hasMetroPass && destData.localTransit.hasMetro) {
      cost += (destData.localTransit.metroPassPerDay || 100) * days * travellers;
    }
    // Bikes
    if (selectedLocalModes.selectedBikeModelId && selectedLocalModes.bikeDays > 0) {
      const bike = destData.localTransit.bikeModels.find(b => b.id === selectedLocalModes.selectedBikeModelId);
      if (bike) {
        cost += bike.dailyRate * selectedLocalModes.bikeDays * bikesNeeded;
      }
    }
    // Car
    if (selectedLocalModes.selectedCarType && selectedLocalModes.carDays > 0) {
      const dailyRate = selectedLocalModes.selectedCarType === 'with_driver' 
        ? destData.localTransit.carWithDriverDaily 
        : destData.localTransit.carSelfDriveDaily;
      cost += dailyRate * selectedLocalModes.carDays * cabsNeeded;
    }
    // Pickups
    if (selectedLocalModes.hasStationPickup) {
      cost += destData.localTransit.stationPickupCab * cabsNeeded;
    }
    if (selectedLocalModes.hasAirportPickup) {
      cost += destData.localTransit.airportPickupCab * cabsNeeded;
    }
    return Math.round(cost);
  }, [selectedLocalModes, destData.localTransit, days, travellers, bikesNeeded, cabsNeeded]);

  // 5. Food Cost: foodRatePerDay * travellers * days + experiences
  const foodCost = useMemo(() => {
    const baseFood = Math.round(foodRatePerDay * travellers * days);
    const expFood = selectedFoodExperiences.reduce((sum, exp) => sum + Math.round(exp.pricePerPerson * travellers), 0);
    return baseFood + expFood;
  }, [foodRatePerDay, travellers, days, selectedFoodExperiences]);

  // Total Spent
  const totalSpent = transportCost + stayCost + placesCost + localCost + foodCost;
  const remaining = totalBudget - totalSpent;
  const safeToSpend = spendableTarget - totalSpent;

  // Budget State
  let budgetState: 'within' | 'using_buffer' | 'over' = 'within';
  let stateMessage = '';
  if (totalSpent <= spendableTarget) {
    budgetState = 'within';
    stateMessage = `Within budget · ${formatINR(safeToSpend)} safe to spend`;
  } else if (totalSpent <= totalBudget) {
    budgetState = 'using_buffer';
    stateMessage = `Using ${formatINR(totalSpent - spendableTarget)} of your buffer`;
  } else {
    budgetState = 'over';
    stateMessage = `${formatINR(totalSpent - totalBudget)} above budget`;
  }

  // Trigger Budget Alert on over-budget action
  const checkBudgetImpact = (newTotalSpent: number, undoCallback: () => void) => {
    if (newTotalSpent > totalBudget) {
      setBudgetAlert({
        show: true,
        overBy: newTotalSpent - totalBudget,
        lastAction: undoCallback
      });
    } else {
      setBudgetAlert(null);
    }
  };

  // Filter transport options by mode
  const currentModeOptions = useMemo(() => {
    let list = transportData.options.filter(o => o.mode === transportMode);
    if (transportSort === 'price') {
      list.sort((a, b) => a.farePerPerson - b.farePerPerson);
    } else if (transportSort === 'duration') {
      list.sort((a, b) => parseInt(a.duration) - parseInt(b.duration));
    } else if (transportSort === 'departure') {
      list.sort((a, b) => a.departureTime.localeCompare(b.departureTime));
    }
    return list;
  }, [transportData.options, transportMode, transportSort]);

  // Stepper handlers
  const handleNextStep = () => {
    const stepIdx = STEPS.findIndex(s => s.id === currentStep);
    if (stepIdx < STEPS.length - 1) {
      setCurrentStep(STEPS[stepIdx + 1].id);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      // Proceed to review & payment (Part 4)
      navigate(`/app/plan/${routeId || destData.id}/review`);
    }
  };

  const handlePrevStep = () => {
    const stepIdx = STEPS.findIndex(s => s.id === currentStep);
    if (stepIdx > 0) {
      setCurrentStep(STEPS[stepIdx - 1].id);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Toggle Attraction
  const handleTogglePlace = (place: AttractionData) => {
    const exists = selectedPlaces.some(p => p.id === place.id);
    if (exists) {
      setSelectedPlaces(prev => prev.filter(p => p.id !== place.id));
    } else {
      const previous = [...selectedPlaces];
      const nextList = [...selectedPlaces, place];
      setSelectedPlaces(nextList);
      
      const placeExtraCost = Math.round(place.ticketPricePerPerson * travellers);
      checkBudgetImpact(totalSpent + placeExtraCost, () => {
        setSelectedPlaces(previous);
      });
    }
  };

  // Toggle Food Experience
  const handleToggleFoodExp = (exp: FoodExperienceData) => {
    const exists = selectedFoodExperiences.some(e => e.id === exp.id);
    if (exists) {
      setSelectedFoodExperiences(prev => prev.filter(e => e.id !== exp.id));
    } else {
      const previous = [...selectedFoodExperiences];
      setSelectedFoodExperiences(prev => [...prev, exp]);
      const expCost = Math.round(exp.pricePerPerson * travellers);
      checkBudgetImpact(totalSpent + expCost, () => {
        setSelectedFoodExperiences(previous);
      });
    }
  };

  // Calculate circular SVG progress
  const spendPercentage = Math.min(100, Math.round((totalSpent / totalBudget) * 100));
  const strokeDashoffset = 283 - (283 * Math.min(100, spendPercentage)) / 100;

  return (
    <div className="min-h-screen bg-cream font-sans pb-24">
      {/* 1. TOP DESTINATION BANNER */}
      <div className="relative h-48 md:h-56 w-full bg-ink overflow-hidden">
        <img
          src={destData.bannerImage}
          alt={destData.name}
          width={1600}
          height={685}
          className="absolute inset-0 w-full h-full object-cover"
          style={{ backgroundColor: imageColors[destData.bannerImage.replace('/images/', '')] || '#0B1B2B' }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0B1B2B]/90 via-[#0B1B2B]/75 to-[#0B1B2B]/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-cream via-cream/20 to-transparent pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-full flex flex-col justify-center relative z-10 text-paper">
          <div className="flex items-center gap-2 mb-2">
            <Link
              to="/app"
              className="text-xs font-semibold text-cream/80 hover:text-marigold inline-flex items-center gap-1 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to home</span>
            </Link>
            <span className="text-cream/50">•</span>
            <span className="text-xs text-marigold font-medium">Trip Assembly Workspace</span>
          </div>

          <h1 className="font-display text-2xl sm:text-3xl md:text-4xl font-semibold tracking-tight text-paper">
            {originCity} to {destData.name}
          </h1>

          <p className="text-xs sm:text-sm text-cream/90 mt-1 max-w-xl">
            {destData.description}
          </p>
        </div>
      </div>

      {/* 2. TRIP BAR WITH EDITABLE CHIPS */}
      <div className="bg-paper border-y border-line sticky top-14 z-30 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setShowConfirmSheet(true)}
              className="px-2.5 py-1 bg-cream hover:bg-cream-2 border border-line rounded-md text-ink font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <MapPin className="w-3.5 h-3.5 text-marigold" />
              <span>From: <strong>{originCity}</strong></span>
            </button>

            <button
              onClick={() => setShowConfirmSheet(true)}
              className="px-2.5 py-1 bg-cream hover:bg-cream-2 border border-line rounded-md text-ink font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <MapPin className="w-3.5 h-3.5 text-teal" />
              <span>To: <strong>{destData.name}</strong></span>
            </button>

            <button
              onClick={() => setShowConfirmSheet(true)}
              className="px-2.5 py-1 bg-cream hover:bg-cream-2 border border-line rounded-md text-ink font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Calendar className="w-3.5 h-3.5 text-marigold" />
              <span>{days} Days ({nights} Nights)</span>
            </button>

            <button
              onClick={() => setShowConfirmSheet(true)}
              className="px-2.5 py-1 bg-cream hover:bg-cream-2 border border-line rounded-md text-ink font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Users className="w-3.5 h-3.5 text-marigold" />
              <span>{travellers} {travellers === 1 ? 'Traveller' : 'Travellers'}</span>
            </button>

            <button
              onClick={() => setShowConfirmSheet(true)}
              className="px-2.5 py-1 bg-cream hover:bg-cream-2 border border-line rounded-md text-ink font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <IndianRupee className="w-3.5 h-3.5 text-marigold" />
              <span>Budget: <strong>{formatINR(totalBudget)}</strong></span>
            </button>
          </div>

          <button
            onClick={() => setShowConfirmSheet(true)}
            className="text-[11px] font-semibold text-marigold-ink underline underline-offset-2 hover:text-ink transition-colors cursor-pointer"
          >
            Edit Trip Basics
          </button>
        </div>
      </div>

      {/* 3. MAIN WORKSPACE: TWO COLUMNS */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* =========================================================
              LEFT COLUMN: STEPPER & CURRENT STEP CONTENT (8 cols)
             ========================================================= */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Horizontal Stepper Indicator */}
            <div className="bg-paper border border-line rounded-card p-3 shadow-2xs overflow-x-auto">
              <div className="flex items-center justify-between min-w-[560px] px-2">
                {STEPS.map((s, idx) => {
                  const isActive = s.id === currentStep;
                  const isCompleted = STEPS.findIndex(st => st.id === currentStep) > idx;

                  return (
                    <React.Fragment key={s.id}>
                      <button
                        onClick={() => setCurrentStep(s.id)}
                        className={`flex items-center gap-2 text-xs font-semibold py-1.5 px-3 rounded-btn transition-colors cursor-pointer ${
                          isActive
                            ? 'bg-marigold text-marigold-ink'
                            : isCompleted
                            ? 'bg-teal/10 text-teal hover:bg-teal/20'
                            : 'text-ink-3 hover:text-ink'
                        }`}
                      >
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                          isActive
                            ? 'bg-marigold-ink text-marigold'
                            : isCompleted
                            ? 'bg-teal text-paper'
                            : 'bg-line text-ink-3'
                        }`}>
                          {isCompleted ? '✓' : s.num}
                        </span>
                        <span>{s.label}</span>
                      </button>

                      {idx < STEPS.length - 1 && (
                        <div className="w-6 h-0.5 bg-line mx-1" />
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            </div>

            {/* Inline Budget Alert (Appears near action if exceeding budget) */}
            {budgetAlert?.show && (
              <div className="p-4 bg-coral/10 border border-coral/30 rounded-xl flex items-center justify-between gap-4 text-xs animate-in fade-in duration-200">
                <div className="flex items-center gap-2.5 text-coral">
                  <AlertCircle className="w-5 h-5 shrink-0" />
                  <div>
                    <span className="font-semibold block">Above budget by {formatINR(budgetAlert.overBy)} after adding this</span>
                    <span className="text-ink-2">You can undo this selection or pick a cheaper alternative.</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {budgetAlert.lastAction && (
                    <button
                      onClick={() => {
                        budgetAlert.lastAction?.();
                        setBudgetAlert(null);
                      }}
                      className="px-3 py-1.5 bg-paper hover:bg-cream border border-coral/40 text-coral rounded-btn font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Undo2 className="w-3.5 h-3.5" />
                      <span>Undo</span>
                    </button>
                  )}
                  <button
                    onClick={() => setBudgetAlert(null)}
                    className="px-3 py-1.5 bg-coral text-paper hover:bg-coral/90 rounded-btn font-semibold transition-colors cursor-pointer"
                  >
                    Continue anyway
                  </button>
                </div>
              </div>
            )}

            {/* Buffer Notice if dipping into buffer */}
            {budgetState === 'using_buffer' && !budgetAlert?.show && (
              <div className="p-3 bg-amber/10 border border-amber/30 rounded-xl flex items-center gap-2.5 text-xs text-amber font-medium">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>Using {formatINR(totalSpent - spendableTarget)} of your {formatINR(buffer)} protection buffer.</span>
              </div>
            )}

            {/* -------------------------------------------------------
                STEP 1: GETTING THERE (origin -> destination)
               ------------------------------------------------------- */}
            {currentStep === 'transport' && (
              <div className="space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h2 className="font-display text-xl font-semibold text-ink">
                      Step 1: Choose Transit to {destData.name}
                    </h2>
                    <p className="text-xs text-ink-2">
                      Distance: ~{transportData.distanceKm} km · Estimated routes with real departure schedules
                    </p>
                  </div>

                  {/* Round trip toggle */}
                  <label className="inline-flex items-center gap-2 bg-paper border border-line rounded-btn px-3 py-1.5 cursor-pointer select-none text-xs font-semibold text-ink shadow-2xs">
                    <input
                      type="checkbox"
                      checked={isRoundTrip}
                      onChange={(e) => setIsRoundTrip(e.target.checked)}
                      className="w-4 h-4 accent-marigold"
                    />
                    <span>Return journey included</span>
                  </label>
                </div>

                {/* Mode Tabs */}
                <div className="flex items-center gap-2 border-b border-line pb-2 text-xs">
                  {(['train', 'flight', 'bus'] as const).map(mode => {
                    const count = transportData.options.filter(o => o.mode === mode).length;
                    const isHidden = count === 0;

                    return (
                      <button
                        key={mode}
                        type="button"
                        onClick={() => !isHidden && setTransportMode(mode)}
                        disabled={isHidden}
                        className={`px-4 py-2 rounded-btn font-semibold flex items-center gap-2 transition-colors cursor-pointer ${
                          transportMode === mode
                            ? 'bg-ink text-cream'
                            : isHidden
                            ? 'bg-cream text-ink-3/40 cursor-not-allowed'
                            : 'bg-paper hover:bg-cream border border-line text-ink'
                        }`}
                      >
                        {mode === 'train' && <Train className="w-3.5 h-3.5" />}
                        {mode === 'flight' && <Plane className="w-3.5 h-3.5" />}
                        {mode === 'bus' && <Bus className="w-3.5 h-3.5" />}
                        <span className="capitalize">{mode}</span>
                        {!isHidden && <span className="text-[11px] opacity-75">({count})</span>}
                      </button>
                    );
                  })}
                </div>

                {/* Hidden mode explanation callout */}
                {transportData.hiddenModesReason && transportData.hiddenModesReason.length > 0 && (
                  <div className="space-y-1.5">
                    {transportData.hiddenModesReason.map((hr, i) => (
                      <div key={i} className="p-3 bg-cream border border-line rounded-lg text-xs text-ink-2 flex items-start gap-2">
                        <Info className="w-4 h-4 text-ink-3 shrink-0 mt-0.5" />
                        <span>{hr.reason}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Sorting toolbar */}
                <div className="flex items-center justify-between text-xs text-ink-2 pt-1">
                  <span>Showing {currentModeOptions.length} estimated options</span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-ink-3">Sort by:</span>
                    {(['price', 'duration', 'departure'] as const).map(s => (
                      <button
                        key={s}
                        onClick={() => setTransportSort(s)}
                        className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                          transportSort === s ? 'bg-ink text-cream font-semibold' : 'hover:bg-cream text-ink-2'
                        }`}
                      >
                        {s.charAt(0).toUpperCase() + s.slice(1)}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Transport Cards List */}
                <div className="space-y-3.5">
                  {currentModeOptions.slice(0, showMoreTransport ? 10 : 4).map(opt => {
                    const isSelected = selectedTransport?.id === opt.id;
                    const farePerPerson = isRoundTrip ? opt.roundTripFarePerPerson : opt.farePerPerson;

                    return (
                      <div
                        key={opt.id}
                        className={`bg-paper border rounded-card p-5 transition-all shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-5 ${
                          isSelected ? 'border-marigold ring-2 ring-marigold/30' : 'border-line hover:border-ink/30'
                        }`}
                      >
                        <div className="flex items-start gap-4 flex-1">
                          {/* Thumbnail */}
                          <div className="w-14 h-14 rounded-xl overflow-hidden bg-cream-2 border border-line shrink-0">
                            <img
                              src={opt.thumbnail}
                              alt={opt.serviceName}
                              width={96}
                              height={96}
                              className="w-full h-full object-cover"
                            />
                          </div>

                          <div className="space-y-1.5 flex-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-semibold text-sm text-ink">{opt.operator}</span>
                              <span className="text-xs text-ink-2">· {opt.serviceName}</span>
                              {opt.tag && (
                                <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${
                                  opt.tag === 'Best fit'
                                    ? 'bg-teal/15 text-teal border border-teal/30'
                                    : opt.tag === 'Cheapest'
                                    ? 'bg-cream text-ink font-mono border border-line'
                                    : 'bg-marigold/15 text-marigold-ink border border-marigold/30'
                                }`}>
                                  {opt.tag}
                                </span>
                              )}
                              <span className="text-[10px] font-mono text-ink-3 uppercase bg-cream px-1.5 py-0.5 rounded">
                                {opt.sourceLabel}
                              </span>
                            </div>

                            {/* Schedule Times */}
                            <div className="flex items-center gap-4 text-xs text-ink">
                              <div>
                                <span className="font-bold text-base text-ink">{opt.departureTime}</span>
                                <div className="text-[11px] text-ink-3">{opt.origin}</div>
                              </div>

                              <div className="flex flex-col items-center">
                                <span className="text-[10px] text-ink-3">{opt.duration}</span>
                                <div className="w-16 h-0.5 bg-line relative my-1">
                                  <div className="w-1.5 h-1.5 rounded-full bg-ink absolute -top-0.5 right-0" />
                                </div>
                                <span className="text-[10px] text-teal">Direct</span>
                              </div>

                              <div>
                                <span className="font-bold text-base text-ink">{opt.arrivalTime}</span>
                                <div className="text-[11px] text-ink-3">{opt.destination}</div>
                              </div>
                            </div>

                            {/* Amenities & Cancellation */}
                            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-ink-3 pt-1">
                              <span>Boarding: {opt.boardingPoint}</span>
                              <span>•</span>
                              <span>Drop: {opt.dropPoint}</span>
                              <span>•</span>
                              <span className="text-teal font-medium">{opt.cancellationPolicy}</span>
                            </div>
                          </div>
                        </div>

                        {/* Right: Price & Selection */}
                        <div className="flex md:flex-col items-center md:items-end justify-between md:justify-center border-t md:border-t-0 pt-3 md:pt-0 border-line shrink-0 min-w-[160px]">
                          <PriceLine
                            pricePerPerson={farePerPerson}
                            travellers={travellers}
                            multiplier={1}
                            multiplierLabel={isRoundTrip ? '(Round trip)' : '(One-way)'}
                            className="text-left md:text-right"
                          />

                          <div className="pt-2 flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => setTransportDetailsDrawer(opt)}
                              className="text-xs text-ink-3 hover:text-ink underline"
                            >
                              Details
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                const previous = selectedTransport;
                                setSelectedTransport(opt);
                                updateSelections({
                                  transport: {
                                    id: opt.id,
                                    mode: opt.mode,
                                    title: opt.serviceName,
                                    provider: opt.operator,
                                    from: opt.boardingPoint,
                                    to: opt.dropPoint,
                                    departureTime: opt.departureTime,
                                    arrivalTime: opt.arrivalTime,
                                    cost: isRoundTrip ? opt.roundTripFarePerPerson : opt.farePerPerson,
                                    totalCost: (isRoundTrip ? opt.roundTripFarePerPerson : opt.farePerPerson) * travellers,
                                    refundable: true
                                  }
                                });
                                const extraCost = (isRoundTrip ? opt.roundTripFarePerPerson : opt.farePerPerson) * travellers;
                                checkBudgetImpact(totalSpent - transportCost + extraCost, () => {
                                  setSelectedTransport(previous);
                                });
                              }}
                              className={`px-4 py-2 rounded-btn font-semibold text-xs transition-colors cursor-pointer ${
                                isSelected
                                  ? 'bg-teal text-paper'
                                  : 'bg-marigold hover:bg-marigold-hover text-marigold-ink shadow-2xs'
                              }`}
                            >
                              {isSelected ? 'Selected' : 'Select'}
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {currentModeOptions.length > 4 && (
                  <button
                    type="button"
                    onClick={() => setShowMoreTransport(!showMoreTransport)}
                    className="w-full py-2.5 bg-paper hover:bg-cream border border-line rounded-btn text-xs font-semibold text-ink transition-colors"
                  >
                    {showMoreTransport ? 'Show fewer options' : `Show more options (${currentModeOptions.length - 4} more)`}
                  </button>
                )}
              </div>
            )}

            {/* -------------------------------------------------------
                STEP 2: STAY (hotels & verified boutique homestays)
               ------------------------------------------------------- */}
            {currentStep === 'stay' && (
              <div className="space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h2 className="font-display text-xl font-semibold text-ink">
                      Step 2: Where to Stay in {destData.name}
                    </h2>
                    <p className="text-xs text-ink-2">
                      {travellers} Guests · {roomsCount} Rooms · {nights} Nights
                    </p>
                  </div>

                  {/* Occupancy selector */}
                  <div className="flex items-center gap-3 bg-paper border border-line rounded-btn px-3 py-1.5 text-xs shadow-2xs">
                    <span className="font-semibold text-ink">Occupancy:</span>
                    <select
                      value={stayOccupancy}
                      onChange={(e) => setStayOccupancy(Number(e.target.value))}
                      className="bg-cream border border-line rounded px-2 py-0.5 text-xs font-semibold focus:outline-none"
                    >
                      <option value={1}>1 guest / room</option>
                      <option value={2}>2 guests / room (Standard)</option>
                      <option value={3}>3 guests / room</option>
                      <option value={4}>4 guests / room</option>
                    </select>

                    <span className="text-ink-3">|</span>
                    <div className="flex items-center gap-1">
                      <span className="text-ink-3">Rooms:</span>
                      <button
                        onClick={() => setRoomsCount(Math.max(1, roomsCount - 1))}
                        className="w-5 h-5 bg-cream border rounded text-[11px] font-bold"
                      >
                        -
                      </button>
                      <span className="font-bold px-1">{roomsCount}</span>
                      <button
                        onClick={() => setRoomsCount(roomsCount + 1)}
                        className="w-5 h-5 bg-cream border rounded text-[11px] font-bold"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>

                {/* Stays List */}
                <div className="space-y-4">
                  {destData.stays.map(stay => {
                    const isSelected = selectedStay?.id === stay.id;
                    const totalStayPrice = stay.ratePerNight * roomsCount * nights;
                    const perPersonPrice = Math.round(totalStayPrice / travellers);

                    return (
                      <div
                        key={stay.id}
                        className={`bg-paper border rounded-card p-5 transition-all shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-5 ${
                          isSelected ? 'border-marigold ring-2 ring-marigold/30' : 'border-line hover:border-ink/30'
                        }`}
                      >
                        <div className="flex items-start gap-4 flex-1">
                          <div className="w-20 h-20 rounded-xl overflow-hidden bg-cream-2 border border-line shrink-0">
                            <img
                              src={stay.image}
                              alt={stay.name}
                              width={96}
                              height={96}
                              className="w-full h-full object-cover"
                            />
                          </div>

                          <div className="space-y-1.5 flex-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <h3 className="font-semibold text-base text-ink">{stay.name}</h3>
                              <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-cream border border-line uppercase text-ink-2">
                                {stay.tier}
                              </span>
                              <span className="text-xs text-amber font-semibold">★ {stay.rating}</span>
                            </div>

                            <div className="text-xs text-ink-2">
                              <MapPin className="w-3.5 h-3.5 inline mr-1 text-marigold" />
                              <span>{stay.area} · Room: <strong>{stay.roomType}</strong></span>
                            </div>

                            <div className="flex flex-wrap gap-2 pt-1 text-[11px] text-ink-3">
                              {stay.inclusions.map((inc, i) => (
                                <span key={i} className="px-2 py-0.5 bg-cream rounded-full border border-line">
                                  ✓ {inc}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Price breakdown */}
                        <div className="flex md:flex-col items-center md:items-end justify-between md:justify-center border-t md:border-t-0 pt-3 md:pt-0 border-line shrink-0 min-w-[200px]">
                          <div className="text-left md:text-right space-y-0.5">
                            <div className="font-display text-base font-semibold text-ink">
                              {formatINR(perPersonPrice)}
                              <span className="text-xs font-normal text-ink-2 font-sans ml-1">/ person</span>
                            </div>
                            <div className="text-[11px] text-ink-3 font-mono">
                              {formatINR(stay.ratePerNight)}/rm × {roomsCount} rms × {nights} nts
                            </div>
                            <div className="text-[11px] font-semibold text-ink">
                              = {formatINR(totalStayPrice)} total
                            </div>
                          </div>

                          <div className="pt-2 flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => setStayDetailsDrawer(stay)}
                              className="text-xs text-ink-3 hover:text-ink underline"
                            >
                              Details
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                const previous = selectedStay;
                                setSelectedStay(stay);
                                updateSelections({
                                  stay: {
                                    id: stay.id,
                                    tier: stay.tier,
                                    name: stay.name,
                                    area: stay.area,
                                    ratePerNight: stay.ratePerNight,
                                    totalCost: stay.ratePerNight * roomsCount * nights,
                                    cutoff: '08:00 PM',
                                    amenities: stay.inclusions
                                  }
                                });
                                checkBudgetImpact(totalSpent - stayCost + totalStayPrice, () => {
                                  setSelectedStay(previous);
                                });
                              }}
                              className={`px-4 py-2 rounded-btn font-semibold text-xs transition-colors cursor-pointer ${
                                isSelected
                                  ? 'bg-teal text-paper'
                                  : 'bg-marigold hover:bg-marigold-hover text-marigold-ink shadow-2xs'
                              }`}
                            >
                              {isSelected ? 'Selected' : 'Select Stay'}
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* -------------------------------------------------------
                STEP 3: PLACES TO VISIT (6-10 attractions)
               ------------------------------------------------------- */}
            {currentStep === 'places' && (
              <div className="space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h2 className="font-display text-xl font-semibold text-ink">
                      Step 3: Places to Visit in {destData.name}
                    </h2>
                    <p className="text-xs text-ink-2">
                      {selectedPlaces.length} added · {formatINR(placesCost)} total ticket estimate for {travellers} travellers
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {destData.attractions.map(attraction => {
                    const isAdded = selectedPlaces.some(p => p.id === attraction.id);

                    return (
                      <div
                        key={attraction.id}
                        className={`bg-paper border rounded-card p-4 transition-all shadow-2xs flex flex-col justify-between ${
                          isAdded ? 'border-marigold ring-2 ring-marigold/30' : 'border-line'
                        }`}
                      >
                        <div className="space-y-2">
                          <div className="flex items-start justify-between gap-2">
                            <h3 className="font-semibold text-sm text-ink">{attraction.name}</h3>
                            {attraction.isHeritage && (
                              <span className="text-[10px] font-bold px-1.5 py-0.5 bg-amber/15 text-amber rounded border border-amber/30 shrink-0">
                                Heritage
                              </span>
                            )}
                          </div>

                          <div className="text-xs text-ink-3 flex items-center gap-2">
                            <span className="font-medium text-ink-2">{attraction.area}</span>
                            <span>•</span>
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              <span>{attraction.typicalVisitTime}</span>
                            </span>
                          </div>

                          <p className="text-xs text-ink-2 line-clamp-2 leading-relaxed">
                            {attraction.description}
                          </p>
                        </div>

                        <div className="pt-3 border-t border-line mt-3 flex items-center justify-between">
                          <PriceLine
                            pricePerPerson={attraction.ticketPricePerPerson}
                            travellers={travellers}
                            isFree={attraction.ticketPricePerPerson === 0}
                          />

                          <button
                            type="button"
                            onClick={() => handleTogglePlace(attraction)}
                            className={`px-3.5 py-1.5 rounded-btn text-xs font-semibold transition-colors cursor-pointer ${
                              isAdded
                                ? 'bg-teal text-paper'
                                : 'bg-cream hover:bg-marigold text-ink hover:text-marigold-ink border border-line'
                            }`}
                          >
                            {isAdded ? '✓ Added' : '+ Add to list'}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* -------------------------------------------------------
                STEP 4: GETTING AROUND (Cabs, Autos, Bikes, Metro)
               ------------------------------------------------------- */}
            {currentStep === 'local' && (
              <div className="space-y-5">
                <div>
                  <h2 className="font-display text-xl font-semibold text-ink">
                    Step 4: Getting Around {destData.name}
                  </h2>
                  <p className="text-xs text-ink-2">
                    Vehicles calculated automatically for {travellers} travellers: {cabsNeeded} cab(s) or {bikesNeeded} bike(s) needed.
                  </p>
                </div>

                <div className="space-y-4">
                  {/* Option 1: Full-Day Cab */}
                  <div className="bg-paper border border-line rounded-card p-4 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="font-semibold text-sm text-ink flex items-center gap-2">
                        <Car className="w-4 h-4 text-marigold" />
                        <span>Private Dedicated AC Cab ({cabsNeeded} vehicle{cabsNeeded > 1 ? 's' : ''})</span>
                      </div>
                      <p className="text-xs text-ink-3">
                        8 hours / 80 km per day included · Capacity: up to 4 guests per cab
                      </p>
                    </div>

                    <div className="flex items-center gap-4">
                      <PriceLine
                        pricePerPerson={Math.round((destData.localTransit.cabFullDay * Math.max(1, selectedLocalModes.cabFullDayDays) * cabsNeeded) / travellers)}
                        travellers={travellers}
                        subtext={`${formatINR(destData.localTransit.cabFullDay)}/day × ${selectedLocalModes.cabFullDayDays} days`}
                      />

                      <div className="flex items-center gap-1.5">
                        <select
                          value={selectedLocalModes.cabFullDayDays}
                          onChange={(e) => setSelectedLocalModes(prev => ({ ...prev, cabFullDayDays: Number(e.target.value) }))}
                          className="bg-cream border border-line rounded px-2.5 py-1 text-xs font-semibold focus:outline-none"
                        >
                          <option value={0}>0 days</option>
                          {Array.from({ length: days }, (_, i) => i + 1).map(d => (
                            <option key={d} value={d}>{d} {d === 1 ? 'day' : 'days'}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Option 2: Rented Bikes */}
                  <div className="bg-paper border border-line rounded-card p-4 shadow-2xs space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="font-semibold text-sm text-ink flex items-center gap-2">
                        <Bike className="w-4 h-4 text-marigold" />
                        <span>Rented Two-Wheelers ({bikesNeeded} bike{bikesNeeded > 1 ? 's' : ''} for {travellers} guests)</span>
                      </div>
                      <select
                        value={selectedLocalModes.bikeDays}
                        onChange={(e) => setSelectedLocalModes(prev => ({ ...prev, bikeDays: Number(e.target.value) }))}
                        className="bg-cream border border-line rounded px-2.5 py-1 text-xs font-semibold focus:outline-none"
                      >
                        <option value={0}>Not needed</option>
                        {Array.from({ length: days }, (_, i) => i + 1).map(d => (
                          <option key={d} value={d}>{d} {d === 1 ? 'day' : 'days'}</option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                      {destData.localTransit.bikeModels.map(bike => {
                        const isChosen = selectedLocalModes.selectedBikeModelId === bike.id && selectedLocalModes.bikeDays > 0;
                        const totalBikeCost = bike.dailyRate * Math.max(1, selectedLocalModes.bikeDays) * bikesNeeded;

                        return (
                          <button
                            key={bike.id}
                            type="button"
                            onClick={() => {
                              setSelectedLocalModes(prev => ({
                                ...prev,
                                selectedBikeModelId: isChosen ? undefined : bike.id,
                                bikeDays: prev.bikeDays === 0 ? 1 : prev.bikeDays
                              }));
                            }}
                            className={`p-3 rounded-xl border text-left transition-colors cursor-pointer ${
                              isChosen ? 'border-marigold bg-marigold/10' : 'border-line hover:border-ink/30 bg-cream/40'
                            }`}
                          >
                            <div className="font-semibold text-xs text-ink">{bike.name}</div>
                            <div className="text-[11px] text-ink-3">{bike.engineCc} · {bike.category}</div>
                            <div className="font-display font-bold text-xs text-ink pt-2">
                              {formatINR(bike.dailyRate)} <span className="font-normal font-sans text-[10px]">/ day</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Option 3: Metro Pass (if applicable) */}
                  {destData.localTransit.hasMetro && (
                    <div className="bg-paper border border-line rounded-card p-4 shadow-2xs flex items-center justify-between">
                      <div>
                        <div className="font-semibold text-sm text-ink">Unlimited Metro Transit Pass</div>
                        <p className="text-xs text-ink-3">Covers all lines for {days} days</p>
                      </div>
                      <div className="flex items-center gap-4">
                        <PriceLine
                          pricePerPerson={(destData.localTransit.metroPassPerDay || 100) * days}
                          travellers={travellers}
                        />
                        <button
                          type="button"
                          onClick={() => setSelectedLocalModes(prev => ({ ...prev, hasMetroPass: !prev.hasMetroPass }))}
                          className={`px-3 py-1.5 rounded-btn text-xs font-semibold transition-colors cursor-pointer ${
                            selectedLocalModes.hasMetroPass ? 'bg-teal text-paper' : 'bg-cream border border-line text-ink'
                          }`}
                        >
                          {selectedLocalModes.hasMetroPass ? '✓ Added' : '+ Add'}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Option 4: Airport or Station Pickup */}
                  <div className="bg-paper border border-line rounded-card p-4 shadow-2xs flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-sm text-ink">Station or Airport Arrival Cab</div>
                      <p className="text-xs text-ink-3">Dedicated driver meets at platform/gate</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <PriceLine
                        pricePerPerson={Math.round((destData.localTransit.stationPickupCab * cabsNeeded) / travellers)}
                        travellers={travellers}
                        subtext={`${formatINR(destData.localTransit.stationPickupCab)}/cab`}
                      />
                      <button
                        type="button"
                        onClick={() => setSelectedLocalModes(prev => ({ ...prev, hasStationPickup: !prev.hasStationPickup }))}
                        className={`px-3 py-1.5 rounded-btn text-xs font-semibold transition-colors cursor-pointer ${
                          selectedLocalModes.hasStationPickup ? 'bg-teal text-paper' : 'bg-cream border border-line text-ink'
                        }`}
                      >
                        {selectedLocalModes.hasStationPickup ? '✓ Added' : '+ Add'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* -------------------------------------------------------
                STEP 5: FOOD (Daily slider + Curated experiences)
               ------------------------------------------------------- */}
            {currentStep === 'food' && (
              <div className="space-y-6">
                <div>
                  <h2 className="font-display text-xl font-semibold text-ink">
                    Step 5: Food & Culinary Budget
                  </h2>
                  <p className="text-xs text-ink-2">
                    Adjust daily dining allocation and add authentic guided food experiences
                  </p>
                </div>

                {/* Food Slider */}
                <div className="bg-paper border border-line rounded-card p-6 shadow-2xs space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-sm text-ink">Daily Food Allocation</span>
                      <p className="text-xs text-ink-3">Covers breakfast, lunch, street food, and dinner</p>
                    </div>
                    <div className="text-right">
                      <span className="font-display text-2xl font-bold text-ink">{formatINR(foodRatePerDay)}</span>
                      <span className="text-xs text-ink-3 block">per person / day</span>
                    </div>
                  </div>

                  <input
                    type="range"
                    min="250"
                    max="1200"
                    step="50"
                    value={foodRatePerDay}
                    onChange={(e) => setFoodRatePerDay(Number(e.target.value))}
                    className="w-full accent-marigold cursor-pointer h-2 bg-cream rounded-lg"
                  />

                  <div className="flex justify-between text-[11px] text-ink-3">
                    <span>₹250 (Street food & Thalis)</span>
                    <span>₹600 (Comfort dining)</span>
                    <span>₹1,200 (Heritage royal cuisine)</span>
                  </div>

                  <div className="pt-2 border-t border-line flex items-center justify-between text-xs">
                    <span className="text-ink-2">Total Food Estimate ({travellers} travellers × {days} days):</span>
                    <strong className="text-ink font-display text-base font-semibold">
                      {formatINR(foodRatePerDay * travellers * days)}
                    </strong>
                  </div>
                </div>

                {/* Curated Food Experiences */}
                {destData.foodExperiences.length > 0 && (
                  <div className="space-y-3">
                    <h3 className="font-semibold text-sm text-ink">Optional Curated Food Walks</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {destData.foodExperiences.map(exp => {
                        const isSelected = selectedFoodExperiences.some(e => e.id === exp.id);

                        return (
                          <div
                            key={exp.id}
                            className={`bg-paper border rounded-card p-4 transition-all shadow-2xs flex flex-col justify-between ${
                              isSelected ? 'border-marigold ring-2 ring-marigold/30' : 'border-line'
                            }`}
                          >
                            <div className="space-y-1.5">
                              <h4 className="font-semibold text-sm text-ink">{exp.name}</h4>
                              <p className="text-xs text-ink-2 leading-relaxed">{exp.description}</p>
                              <div className="text-[11px] text-ink-3">Duration: {exp.duration}</div>
                            </div>

                            <div className="pt-3 border-t border-line mt-3 flex items-center justify-between">
                              <PriceLine
                                pricePerPerson={exp.pricePerPerson}
                                travellers={travellers}
                              />
                              <button
                                type="button"
                                onClick={() => handleToggleFoodExp(exp)}
                                className={`px-3 py-1.5 rounded-btn text-xs font-semibold transition-colors cursor-pointer ${
                                  isSelected ? 'bg-teal text-paper' : 'bg-cream border border-line text-ink hover:bg-marigold hover:text-marigold-ink'
                                }`}
                              >
                                {isSelected ? '✓ Added' : '+ Add'}
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Stepper Navigation Footer Buttons */}
            <div className="pt-6 border-t border-line flex items-center justify-between">
              <button
                type="button"
                onClick={handlePrevStep}
                disabled={currentStep === 'transport'}
                className={`px-4 py-2.5 rounded-btn text-xs font-semibold flex items-center gap-2 transition-colors ${
                  currentStep === 'transport'
                    ? 'text-ink-3 opacity-40 cursor-not-allowed'
                    : 'bg-paper hover:bg-cream border border-line text-ink cursor-pointer'
                }`}
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </button>

              <button
                type="button"
                onClick={handleNextStep}
                className="px-6 py-2.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-all shadow-sm flex items-center gap-2 cursor-pointer"
              >
                <span>{currentStep === 'food' ? 'Review & Pay' : 'Next Step'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* =========================================================
              RIGHT COLUMN: STICKY LIVE BUDGET PANEL (4 cols)
             ========================================================= */}
          <div className="lg:col-span-4 sticky top-28 space-y-4">
            <div className="bg-paper border border-line rounded-card p-6 shadow-floating space-y-5">
              
              {/* Header */}
              <div className="flex items-center justify-between pb-3 border-b border-line">
                <div>
                  <h3 className="font-display text-base font-semibold text-ink">Trip Budget Gauge</h3>
                  <span className="text-[11px] text-ink-3">Live mathematical ceiling</span>
                </div>
                <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider ${
                  budgetState === 'within'
                    ? 'bg-teal/15 text-teal border border-teal/30'
                    : budgetState === 'using_buffer'
                    ? 'bg-amber/15 text-amber border border-amber/30'
                    : 'bg-coral/15 text-coral border border-coral/30'
                }`}>
                  {budgetState === 'within' && 'Within Budget'}
                  {budgetState === 'using_buffer' && 'Using Buffer'}
                  {budgetState === 'over' && 'Over Budget'}
                </span>
              </div>

              {/* Circular Gauge */}
              <div className="flex items-center justify-center py-2">
                <div className="relative w-36 h-36 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      fill="transparent"
                      stroke="#E8E0D2"
                      strokeWidth="8"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      fill="transparent"
                      stroke={budgetState === 'within' ? '#0E7C7B' : budgetState === 'using_buffer' ? '#C77700' : '#D9453D'}
                      strokeWidth="8"
                      strokeDasharray="283"
                      strokeDashoffset={strokeDashoffset}
                      strokeLinecap="round"
                      className="transition-all duration-500 ease-out"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                    <span className="font-display text-xl font-bold text-ink">
                      {spendPercentage}%
                    </span>
                    <span className="text-[10px] text-ink-3 uppercase font-semibold">
                      Allocated
                    </span>
                  </div>
                </div>
              </div>

              {/* Financial Totals */}
              <div className="space-y-1.5 p-3.5 bg-cream/70 rounded-xl border border-line text-xs">
                <div className="flex justify-between text-ink-2">
                  <span>Total Trip Budget:</span>
                  <span className="font-bold text-ink">{formatINR(totalBudget)}</span>
                </div>
                <div className="flex justify-between text-ink-2">
                  <span>8% Emergency Buffer:</span>
                  <span className="font-mono text-ink-3">{formatINR(buffer)}</span>
                </div>
                <div className="flex justify-between text-ink-2">
                  <span>Spendable Target:</span>
                  <span className="font-bold text-ink">{formatINR(spendableTarget)}</span>
                </div>
                <div className="pt-1.5 border-t border-line/60 flex justify-between font-semibold text-sm">
                  <span>Total Selected:</span>
                  <span className={budgetState === 'over' ? 'text-coral' : 'text-ink'}>
                    {formatINR(totalSpent)}
                  </span>
                </div>
                <div className="text-[11px] font-medium pt-0.5 text-center">
                  <span className={budgetState === 'within' ? 'text-teal' : budgetState === 'using_buffer' ? 'text-amber' : 'text-coral'}>
                    {stateMessage}
                  </span>
                </div>
              </div>

              {/* Per-Category Progress Breakdown */}
              <div className="space-y-2.5 text-xs">
                <span className="font-semibold text-ink-2 block text-[11px] uppercase tracking-wider">
                  Category Allocations
                </span>

                {/* Transport */}
                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-ink">Transit</span>
                    <span className="font-mono text-ink-3">
                      {formatINR(transportCost)} of {formatINR(categoryTargets.transport)}
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-cream rounded-full overflow-hidden border border-line">
                    <div
                      className="h-full bg-marigold transition-all"
                      style={{ width: `${Math.min(100, (transportCost / (categoryTargets.transport || 1)) * 100)}%` }}
                    />
                  </div>
                </div>

                {/* Stay */}
                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-ink">Stay</span>
                    <span className="font-mono text-ink-3">
                      {formatINR(stayCost)} of {formatINR(categoryTargets.stay)}
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-cream rounded-full overflow-hidden border border-line">
                    <div
                      className="h-full bg-teal transition-all"
                      style={{ width: `${Math.min(100, (stayCost / (categoryTargets.stay || 1)) * 100)}%` }}
                    />
                  </div>
                </div>

                {/* Places */}
                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-ink">Places & Tickets</span>
                    <span className="font-mono text-ink-3">
                      {formatINR(placesCost)} of {formatINR(categoryTargets.places)}
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-cream rounded-full overflow-hidden border border-line">
                    <div
                      className="h-full bg-marigold transition-all"
                      style={{ width: `${Math.min(100, (placesCost / (categoryTargets.places || 1)) * 100)}%` }}
                    />
                  </div>
                </div>

                {/* Local */}
                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-ink">Local Travel</span>
                    <span className="font-mono text-ink-3">
                      {formatINR(localCost)} of {formatINR(categoryTargets.local)}
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-cream rounded-full overflow-hidden border border-line">
                    <div
                      className="h-full bg-marigold transition-all"
                      style={{ width: `${Math.min(100, (localCost / (categoryTargets.local || 1)) * 100)}%` }}
                    />
                  </div>
                </div>

                {/* Food */}
                <div>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-ink">Food</span>
                    <span className="font-mono text-ink-3">
                      {formatINR(foodCost)} of {formatINR(categoryTargets.food)}
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-cream rounded-full overflow-hidden border border-line">
                    <div
                      className="h-full bg-marigold transition-all"
                      style={{ width: `${Math.min(100, (foodCost / (categoryTargets.food || 1)) * 100)}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Review & Pay CTA */}
              <button
                type="button"
                onClick={() => navigate(`/app/plan/${routeId || destData.id}/review`)}
                className="w-full py-3 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Review & Pay</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* Persistent Honesty Pill */}
              <div className="pt-2 border-t border-line text-center">
                <span className="inline-flex items-center gap-1.5 text-[11px] text-ink-3 font-medium">
                  <ShieldCheck className="w-3.5 h-3.5 text-teal" />
                  <span>Sample data · no real bookings</span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Reusable Confirm Trip Sheet */}
      <ConfirmTripSheet
        isOpen={showConfirmSheet}
        onClose={() => setShowConfirmSheet(false)}
        defaultOrigin={originCity}
      />

      {/* Details Drawers / Modals */}
      {transportDetailsDrawer && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-ink/75 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-paper border border-line rounded-card p-6 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-line">
              <h3 className="font-semibold text-base text-ink">Transit Details</h3>
              <button onClick={() => setTransportDetailsDrawer(null)} className="p-1 text-ink-3 hover:text-ink">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-2 text-xs text-ink-2">
              <div><strong>Operator:</strong> {transportDetailsDrawer.operator}</div>
              <div><strong>Service:</strong> {transportDetailsDrawer.serviceName}</div>
              <div><strong>Boarding:</strong> {transportDetailsDrawer.boardingPoint} at {transportDetailsDrawer.departureTime}</div>
              <div><strong>Arrival:</strong> {transportDetailsDrawer.dropPoint} at {transportDetailsDrawer.arrivalTime}</div>
              <div><strong>Duration:</strong> {transportDetailsDrawer.duration}</div>
              <div><strong>Amenities:</strong> {transportDetailsDrawer.amenities.join(', ')}</div>
              <div><strong>Cancellation:</strong> {transportDetailsDrawer.cancellationPolicy}</div>
            </div>
            <button
              onClick={() => setTransportDetailsDrawer(null)}
              className="w-full py-2 bg-ink text-cream rounded-btn text-xs font-semibold"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {stayDetailsDrawer && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-ink/75 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-paper border border-line rounded-card p-6 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-line">
              <h3 className="font-semibold text-base text-ink">Accommodation Details</h3>
              <button onClick={() => setStayDetailsDrawer(null)} className="p-1 text-ink-3 hover:text-ink">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-2 text-xs text-ink-2">
              <div><strong>Name:</strong> {stayDetailsDrawer.name}</div>
              <div><strong>Tier:</strong> <span className="uppercase">{stayDetailsDrawer.tier}</span></div>
              <div><strong>Location:</strong> {stayDetailsDrawer.area}</div>
              <div><strong>Room Type:</strong> {stayDetailsDrawer.roomType}</div>
              <div><strong>Rate:</strong> {formatINR(stayDetailsDrawer.ratePerNight)} per room / night</div>
              <div><strong>Inclusions:</strong> {stayDetailsDrawer.inclusions.join(', ')}</div>
            </div>
            <button
              onClick={() => setStayDetailsDrawer(null)}
              className="w-full py-2 bg-ink text-cream rounded-btn text-xs font-semibold"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
