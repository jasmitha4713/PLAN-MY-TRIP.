import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Car,
  Building,
  ArrowRight,
  Sparkles,
  MessageSquare,
  Bus,
  Train,
  RotateCcw,
  PlusCircle,
  FileText,
  AlertTriangle
} from 'lucide-react';
import { useTrip } from '../../context/TripContext';
import { formatINR } from '../../lib/budget';
import imageColorsData from '../../data/imageColors.json';

const imageColors: Record<string, string> = imageColorsData;

interface RescueTile {
  id: string;
  title: string;
  subtitle: string;
  icon: any;
  prompt: string;
  badge?: string;
}

const RESCUE_TILES: RescueTile[] = [
  {
    id: 'running-late',
    title: 'Running Late',
    subtitle: 'Group delayed or behind schedule',
    icon: Clock,
    prompt: 'My friends arrived late, I need 30 more minutes before the driver comes.',
    badge: 'Common'
  },
  {
    id: 'transit-delayed',
    title: 'Bus or Train Delayed',
    subtitle: 'Transit running behind expected arrival',
    icon: Train,
    prompt: 'My train is delayed by 45 minutes, will I miss my pickup?'
  },
  {
    id: 'missed-bus',
    title: 'Missed My Bus',
    subtitle: 'Traffic caused a missed departure',
    icon: Bus,
    prompt: "I'm in traffic and my bus leaves in 10 minutes."
  },
  {
    id: 'need-more-time',
    title: 'Need More Time',
    subtitle: 'Extend stay or delay next transit',
    icon: RotateCcw,
    prompt: 'I need 45 more minutes before the cab.'
  },
  {
    id: 'cab-problem',
    title: 'Cab Problem',
    subtitle: 'Driver coordination, re-timing, or meeting point',
    icon: Car,
    prompt: 'Can we move our cab pickup point to the hotel reception?'
  },
  {
    id: 'hotel-problem',
    title: 'Hotel Problem',
    subtitle: 'Late arrival past desk cutoff time',
    icon: Building,
    prompt: "I'm stuck in traffic, I'll reach the hotel late."
  },
  {
    id: 'change-plans',
    title: 'Change Plans',
    subtitle: 'Swap monument, skip sights, add experiences',
    icon: Sparkles,
    prompt: 'Skip Qutub Minar and add a food walk'
  }
];

export default function JourneyRescuePage() {
  const navigate = useNavigate();
  const { currentTrip, savedTrips } = useTrip();

  // If no saved trips or no active trip, show empty state
  const hasActiveTrip = Boolean(currentTrip && currentTrip.destination);

  const handleTileClick = (tile: RescueTile) => {
    // Navigate to booked trip companion with prompt preloaded
    navigate(`/app/trip/${currentTrip.id || 'PMT-0142'}?prompt=${encodeURIComponent(tile.prompt)}`);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-8 font-sans">
      
      {/* 200px Rescue Banner with 0.88 Ink Overlay */}
      <div className="relative h-[200px] w-full overflow-hidden rounded-2xl select-none bg-ink shadow-sm">
        <img
          src="/images/rescue-station.webp"
          alt="Railway station platform at dawn"
          width={1600}
          height={600}
          className="absolute inset-0 w-full h-full object-cover"
          style={{ backgroundColor: imageColors['rescue-station.webp'] || '#101B2B' }}
        />
        <div className="absolute inset-0 bg-[#0B1B2B]/88 pointer-events-none" />

        <div className="relative z-10 h-full p-6 sm:p-8 flex flex-col justify-between text-paper">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-marigold">
              <Sparkles className="w-4 h-4 text-marigold" />
              <span>Journey Rescue Hub</span>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-cream/70 font-mono">
                Active Reference: {currentTrip.id || 'PMT-0142'}
              </span>
            </div>
          </div>

          <div>
            <h1 className="font-display text-2xl sm:text-3xl font-semibold text-paper tracking-tight">
              Journey Rescue Center
            </h1>
            <p className="text-xs sm:text-sm text-cream/85 mt-1">
              One-click disruption recovery. Solve missed departures, cab re-timing, and late check-ins without losing your budget.
            </p>
          </div>
        </div>
      </div>

      {!hasActiveTrip ? (
        /* Empty State */
        <div className="bg-paper border border-line rounded-card p-12 text-center space-y-4 shadow-sm">
          <div className="w-14 h-14 rounded-full bg-cream mx-auto flex items-center justify-center text-ink-3">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h2 className="font-display text-xl font-semibold text-ink">No Booked Journey Active</h2>
          <p className="text-xs text-ink-2 max-w-md mx-auto">
            You do not currently have a confirmed trip to rescue. Plan a trip or load a sample destination to test live companion recovery.
          </p>
          <div className="pt-2">
            <Link
              to="/app"
              className="px-6 py-2.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-colors shadow-sm inline-flex items-center gap-2"
            >
              <span>Plan a trip</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          
          {/* Active Trip Card with Next Upcoming Booking */}
          <div className="bg-paper border border-line rounded-card p-6 shadow-2xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-line">
              <div>
                <span className="text-[11px] font-mono uppercase text-teal font-bold tracking-wider">
                  Monitored Itinerary
                </span>
                <h2 className="font-display text-lg font-semibold text-ink">
                  {currentTrip.origin} to {currentTrip.destination} ({currentTrip.days} Days)
                </h2>
              </div>

              <div className="flex items-center gap-2">
                <Link
                  to={`/app/trip/${currentTrip.id || 'PMT-0142'}`}
                  className="px-4 py-2 bg-cream hover:bg-cream-2 border border-line rounded-btn text-xs font-semibold text-ink transition-colors flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-marigold" />
                  <span>Open Companion</span>
                </Link>
                <Link
                  to={`/app/trip/${currentTrip.id || 'PMT-0142'}`}
                  className="px-4 py-2 bg-marigold hover:bg-marigold-hover text-marigold-ink rounded-btn text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-2xs"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>View Messages</span>
                </Link>
              </div>
            </div>

            {/* Next Booking Highlight */}
            <div className="p-4 bg-cream/60 rounded-xl border border-line flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-paper border border-line flex items-center justify-center text-marigold-ink font-bold shrink-0">
                  <Car className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-bold text-ink">Next Booking: Dedicated Station Pickup Cab</div>
                  <div className="text-ink-3">Scheduled Pickup: <strong>09:30 PM</strong> · Porch Exit 2 (Driver: Ramesh Patel)</div>
                  <div className="text-teal font-medium text-[11px] mt-0.5">Hotel desk cutoff: 11:00 PM (1h 30m safe window)</div>
                </div>
              </div>

              <span className="px-3 py-1 bg-teal/15 text-teal text-xs font-semibold rounded-full border border-teal/20 shrink-0">
                Coordinated & Protected
              </span>
            </div>
          </div>

          {/* "What's Happening?" Disruption Tiles */}
          <div className="space-y-4">
            <div>
              <h2 className="font-display text-xl font-semibold text-ink">What's happening?</h2>
              <p className="text-xs text-ink-2">Select your situation to launch your companion with verified downstream coordination</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {RESCUE_TILES.map(tile => {
                const IconComponent = tile.icon;

                return (
                  <button
                    key={tile.id}
                    onClick={() => handleTileClick(tile)}
                    className="p-5 bg-paper hover:bg-cream border border-line hover:border-marigold rounded-card text-left transition-all shadow-2xs hover:shadow-md flex flex-col justify-between space-y-4 cursor-pointer group"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="w-10 h-10 rounded-xl bg-cream group-hover:bg-marigold text-ink group-hover:text-marigold-ink border border-line flex items-center justify-center transition-colors">
                          <IconComponent className="w-5 h-5" />
                        </div>
                        {tile.badge && (
                          <span className="px-2 py-0.5 bg-amber/15 text-amber text-[10px] font-bold rounded-full">
                            {tile.badge}
                          </span>
                        )}
                      </div>

                      <div>
                        <h3 className="font-semibold text-sm text-ink group-hover:text-marigold-ink transition-colors">
                          {tile.title}
                        </h3>
                        <p className="text-xs text-ink-3 mt-0.5 leading-relaxed">
                          {tile.subtitle}
                        </p>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-line/60 flex items-center justify-between text-xs font-medium text-marigold-ink">
                      <span>Launch companion</span>
                      <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Recent Rescues List from Messages Log */}
          <div className="space-y-4">
            <h2 className="font-display text-lg font-semibold text-ink">Recent Rescues & Dispatches</h2>

            <div className="space-y-3">
              <div className="p-4 bg-paper border border-line rounded-card shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-ink">Cab Re-timing Coordination (SIM-CAB-123)</span>
                    <span className="text-[11px] text-ink-3 font-mono">Today, 09:15 AM</span>
                  </div>
                  <p className="text-ink-2 font-mono text-[11px] bg-cream/70 p-2 rounded-lg border border-line">
                    "Hello, pickup time for booking SIM-CAB-123 has changed from 9:30 PM to 10:00 PM. Please confirm."
                  </p>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  <span className="text-[10px] text-ink-3 uppercase">Simulated Result:</span>
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-teal/15 text-teal border border-teal/30">
                    Acknowledged (+₹0)
                  </span>
                </div>
              </div>

              <div className="p-4 bg-paper border border-line rounded-card shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-ink">Emergency Bus Hold Request (SIM-BUS-456)</span>
                    <span className="text-[11px] text-ink-3 font-mono">Yesterday, 08:50 PM</span>
                  </div>
                  <p className="text-ink-2 font-mono text-[11px] bg-cream/70 p-2 rounded-lg border border-line">
                    "Passenger for seat 12 is on the way and needs 10 more minutes. Can you hold the bus until 09:20 PM?"
                  </p>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  <span className="text-[10px] text-ink-3 uppercase">Simulated Result:</span>
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-teal/15 text-teal border border-teal/30">
                    Held until 09:20 PM
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
