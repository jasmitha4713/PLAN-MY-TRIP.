import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Compass,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Plane,
  Train,
  Building,
  Car,
  UtensilsCrossed,
  MapPin,
  Calendar,
  Users,
  ShieldCheck,
  ChevronRight,
  Info,
  Clock,
  Sparkles,
  Sliders,
  X,
  FileCheck2
} from 'lucide-react';
import { useTrip } from '../../context/TripContext';
import { getFixturesForDestination } from '../../data/fixtures';
import { formatINR, TransportOption, StayOption, LocalTravelOption, ExperienceOption } from '../../lib/budget';
import imageColorsData from '../../data/imageColors.json';

const imageColors: Record<string, string> = imageColorsData;

type TabType = 'overview' | 'transport' | 'stay' | 'local' | 'experiences';

export default function PlannerPage() {
  const navigate = useNavigate();
  const {
    currentTrip,
    budget,
    updateTrip,
    setTransport,
    setStay,
    toggleLocalTravel,
    toggleExperience,
    setFoodPerPersonPerDay,
    saveCurrentTrip,
    travellers,
    addTraveller
  } = useTrip();

  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [showSavedSuccess, setShowSavedSuccess] = useState(false);
  const [selectedDetailItem, setSelectedDetailItem] = useState<any | null>(null);

  // New traveller input state
  const [newTravellerName, setNewTravellerName] = useState('');
  const [newTravellerAge, setNewTravellerAge] = useState(25);

  const fixtures = getFixturesForDestination(currentTrip.destination, currentTrip.origin);

  // Determine destination slug for dynamic banner
  const getDestSlug = (destStr: string) => {
    const lower = (destStr || '').toLowerCase();
    if (lower.includes('jaipur')) return 'jaipur';
    if (lower.includes('hampi')) return 'hampi';
    if (lower.includes('varanasi')) return 'varanasi';
    if (lower.includes('kerala') || lower.includes('alleppey') || lower.includes('kochi')) return 'alleppey';
    if (lower.includes('coorg')) return 'coorg';
    return 'delhi';
  };

  const destSlug = getDestSlug(currentTrip.destination);
  const bannerImgPath = `/images/dest-${destSlug}-banner.webp`;

  const handleSaveTrip = () => {
    saveCurrentTrip('planned');
    setShowReviewModal(false);
    setShowSavedSuccess(true);
  };

  const handleAddTravellerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTravellerName.trim()) {
      addTraveller(newTravellerName.trim(), Number(newTravellerAge));
      setNewTravellerName('');
    }
  };

  // Budget ring calculations
  const totalSpent = budget.totalCost;
  const ceiling = budget.totalBudget;
  const percentage = Math.min(Math.round((totalSpent / ceiling) * 100), 100);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6 font-sans">
      {/* 1. Header Banner (220px) */}
      <div className="relative h-[220px] w-full overflow-hidden rounded-2xl select-none bg-ink shadow-sm">
        <img
          src={bannerImgPath}
          alt={currentTrip.destination}
          width={1600}
          height={685}
          className="absolute inset-0 w-full h-full object-cover"
          style={{ backgroundColor: imageColors[`dest-${destSlug}-banner.webp`] || '#101B2B' }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0B1B2B]/90 via-[#0B1B2B]/75 to-[#0B1B2B]/40" />

        <div className="relative z-10 h-full p-6 sm:p-8 flex flex-col justify-between text-paper">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-marigold">
              <span className="w-2 h-2 rounded-full bg-teal animate-pulse" />
              <span>Trip Workspace</span>
              <span>•</span>
              <span className="font-mono text-cream/90">{currentTrip.id}</span>
            </div>
            <button
              onClick={() => setShowReviewModal(true)}
              className="px-4 py-2 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer"
            >
              <span>Review Itinerary</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div>
            <h1 className="font-display text-2xl sm:text-3xl md:text-4xl font-semibold text-paper tracking-tight">
              {currentTrip.destination} Itinerary
            </h1>
            <p className="text-xs sm:text-sm text-cream/90 mt-1">
              {currentTrip.origin} → {currentTrip.destination} · {currentTrip.days} Days · {currentTrip.travellers} Travellers
            </p>
          </div>
        </div>
      </div>

      {/* 2. Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Segmented Tabs & Content */}
        <div className="lg:col-span-8 space-y-6">
          {/* Segmented Tab Navigation */}
          <div className="flex items-center gap-1.5 p-1 bg-paper border border-line rounded-card overflow-x-auto text-xs font-semibold">
            {[
              { id: 'overview', label: 'Overview' },
              { id: 'transport', label: 'Getting There' },
              { id: 'stay', label: 'Where to Stay' },
              { id: 'local', label: 'Getting Around' },
              { id: 'experiences', label: 'Experiences' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`px-4 py-2 rounded-btn whitespace-nowrap transition-colors cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-ink text-cream shadow-2xs'
                    : 'text-ink-2 hover:text-ink hover:bg-cream'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Daily Food Allowance Slider */}
              <div className="bg-paper border border-line rounded-card p-6 shadow-2xs space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-cream flex items-center justify-center text-marigold">
                      <UtensilsCrossed className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="font-display text-sm font-semibold text-ink">Food & Dining Allowance</h3>
                      <p className="text-[11px] text-ink-3">Daily budget allocated per person</p>
                    </div>
                  </div>
                  <span className="font-display text-lg font-semibold text-ink font-mono">
                    {formatINR(currentTrip.selections.foodPerPersonPerDay)} / day
                  </span>
                </div>

                <input
                  type="range"
                  min={250}
                  max={900}
                  step={50}
                  value={currentTrip.selections.foodPerPersonPerDay}
                  onChange={(e) => setFoodPerPersonPerDay(Number(e.target.value))}
                  className="w-full h-2 bg-cream rounded-lg appearance-none cursor-pointer accent-marigold"
                />

                <div className="flex justify-between text-[11px] text-ink-3 font-mono">
                  <span>₹250 (Local Dhabas & Street Food)</span>
                  <span>₹550 (Casual Dining)</span>
                  <span>₹900 (Fine Dining & Thalis)</span>
                </div>
              </div>

              {/* Day-by-Day Timeline */}
              <div className="bg-paper border border-line rounded-card p-6 shadow-2xs space-y-6">
                <h3 className="font-display text-base font-semibold text-ink">Trip Schedule & Timeline</h3>

                <div className="space-y-6 pl-4 border-l-2 border-line">
                  {/* Day 1 */}
                  <div className="relative pl-6 space-y-3">
                    <span className="absolute -left-[23px] top-1 w-3.5 h-3.5 rounded-full bg-marigold border-2 border-paper" />
                    <div>
                      <span className="text-xs font-mono font-bold text-marigold">DAY 1</span>
                      <h4 className="font-display text-base font-semibold text-ink">Transit & Heritage Check-in</h4>
                    </div>

                    <div className="space-y-2 text-xs text-ink-2">
                      <div className="p-3 bg-cream rounded-xl border border-line flex items-center justify-between">
                        <div>
                          <div className="font-medium text-ink">
                            {currentTrip.selections.transport?.title || 'No transport chosen yet'}
                          </div>
                          <div className="text-[11px] text-ink-3">
                            Arrival expected at {currentTrip.schedule?.plannedArrival || '7:55 PM'}
                          </div>
                        </div>
                        <span className="font-mono font-semibold text-ink">
                          {currentTrip.selections.transport ? formatINR(currentTrip.selections.transport.price) : '—'}
                        </span>
                      </div>

                      <div className="p-3 bg-cream rounded-xl border border-line flex items-center justify-between">
                        <div>
                          <div className="font-medium text-ink">
                            {currentTrip.selections.stay?.title || 'No stay chosen yet'}
                          </div>
                          <div className="text-[11px] text-ink-3">
                            Check-in from {currentTrip.schedule?.checkInTime || '2:00 PM'} · Cutoff {currentTrip.schedule?.stayCutoff || '9:00 PM'}
                          </div>
                        </div>
                        <span className="font-mono font-semibold text-ink">
                          {currentTrip.selections.stay ? formatINR(currentTrip.selections.stay.pricePerNight * currentTrip.days) : '—'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Day 2 */}
                  <div className="relative pl-6 space-y-3">
                    <span className="absolute -left-[23px] top-1 w-3.5 h-3.5 rounded-full bg-teal border-2 border-paper" />
                    <div>
                      <span className="text-xs font-mono font-bold text-teal">DAY 2</span>
                      <h4 className="font-display text-base font-semibold text-ink">Local Exploration & Guided Tours</h4>
                    </div>

                    <div className="space-y-2 text-xs text-ink-2">
                      {currentTrip.selections.experiences.length > 0 ? (
                        currentTrip.selections.experiences.map((exp) => (
                          <div key={exp.id} className="p-3 bg-cream rounded-xl border border-line flex items-center justify-between">
                            <div>
                              <div className="font-medium text-ink">{exp.title}</div>
                              <div className="text-[11px] text-ink-3">{exp.duration} · {exp.timeSlot}</div>
                            </div>
                            <span className="font-mono font-semibold text-ink">{formatINR(exp.price)}</span>
                          </div>
                        ))
                      ) : (
                        <p className="text-xs text-ink-3 italic">No experiences added yet. Switch to Experiences tab to add.</p>
                      )}
                    </div>
                  </div>

                  {/* Day 3 */}
                  <div className="relative pl-6 space-y-3">
                    <span className="absolute -left-[23px] top-1 w-3.5 h-3.5 rounded-full bg-ink-3 border-2 border-paper" />
                    <div>
                      <span className="text-xs font-mono font-bold text-ink-3">DAY 3</span>
                      <h4 className="font-display text-base font-semibold text-ink">Departure & Memories</h4>
                    </div>
                    <p className="text-xs text-ink-2">
                      Check-out by {currentTrip.schedule?.checkOutTime || '11:00 AM'}. Station transfer and safe return.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: TRANSPORT */}
          {activeTab === 'transport' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-display text-lg font-semibold text-ink">Transport Selections</h3>
                  <p className="text-xs text-ink-2">Real schedules and verified fares for {currentTrip.origin} → {currentTrip.destination}</p>
                </div>
              </div>

              <div className="space-y-3">
                {fixtures.transports.map((opt) => {
                  const isSelected = currentTrip.selections.transport?.id === opt.id;
                  const transportImg = opt.image || opt.thumbnail || (opt.mode === 'flight' ? '/images/thumb-flight.webp' : opt.id.includes('ac') ? '/images/thumb-train-ac.webp' : '/images/thumb-train-sleeper.webp');
                  const optPrice = opt.price || (opt.farePerPerson * (opt.roundTripMultiplier || 2) * currentTrip.travellers);
                  return (
                    <div
                      key={opt.id}
                      className={`p-4 rounded-card border transition-all bg-paper flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                        isSelected ? 'border-marigold ring-2 ring-marigold/30 shadow-xs' : 'border-line hover:border-ink-3'
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-24 h-24 rounded-xl overflow-hidden flex-shrink-0 border border-line bg-cream" style={{ backgroundColor: '#182028' }}>
                          <img src={transportImg} alt={opt.name || opt.title} className="w-full h-full object-cover" loading="lazy" />
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-cream border border-line uppercase">
                              {opt.type || opt.mode}
                            </span>
                            <h4 className="font-display text-base font-semibold text-ink">{opt.title || opt.name}</h4>
                          </div>
                          <div className="text-xs text-ink-2 flex flex-wrap items-center gap-2">
                            <span>{opt.operator || opt.operatorType}</span>
                            <span>•</span>
                            <span>{opt.departureTime ? `${opt.departureTime} → ${opt.arrivalTime}` : opt.duration}</span>
                          </div>
                          <div className="text-[11px] text-ink-3 pt-0.5">{opt.details || `Includes return tickets for ${currentTrip.travellers} travelers.`}</div>
                        </div>
                      </div>

                      <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 border-t sm:border-t-0 pt-2 sm:pt-0 border-line">
                        <div className="font-display text-lg font-semibold text-ink">
                          {formatINR(optPrice)}
                        </div>
                        <button
                          onClick={() => setTransport(opt)}
                          className={`px-4 py-2 text-xs font-semibold rounded-btn transition-colors cursor-pointer ${
                            isSelected
                              ? 'bg-marigold text-marigold-ink'
                              : 'bg-cream hover:bg-cream-2 text-ink border border-line'
                          }`}
                        >
                          {isSelected ? 'Selected' : 'Select this'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: STAY */}
          {activeTab === 'stay' && (
            <div className="space-y-4">
              <div>
                <h3 className="font-display text-lg font-semibold text-ink">Where to Stay</h3>
                <p className="text-xs text-ink-2">Boutique heritage properties and hotels in {currentTrip.destination}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {fixtures.stays.map((stay) => {
                  const isSelected = currentTrip.selections.stay?.id === stay.id;
                  const stayImg = stay.image || stay.thumbnail || (stay.tier === 'hostel' ? '/images/thumb-stay-budget.webp' : stay.tier === 'heritage' ? '/images/thumb-stay-haveli.webp' : '/images/thumb-stay-boutique.webp');
                  const stayPrice = stay.pricePerNight || stay.ratePerNight;
                  return (
                    <div
                      key={stay.id}
                      className={`rounded-card border bg-paper overflow-hidden flex flex-col justify-between transition-all ${
                        isSelected ? 'border-marigold ring-2 ring-marigold/30 shadow-xs' : 'border-line hover:border-ink-3'
                      }`}
                    >
                      <div className="p-4 sm:p-5 flex gap-4">
                        <div className="w-24 h-24 rounded-xl overflow-hidden flex-shrink-0 border border-line bg-cream" style={{ backgroundColor: '#182028' }}>
                          <img src={stayImg} alt={stay.name || stay.title} className="w-full h-full object-cover" loading="lazy" />
                        </div>
                        <div className="space-y-1.5 flex-1">
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded bg-cream border border-line">
                              {stay.rating ? `${stay.rating}★ Rating` : stay.tier}
                            </span>
                            <span className="text-xs font-semibold text-teal font-mono">{stay.tier}</span>
                          </div>
                          <div>
                            <h4 className="font-display text-base font-semibold text-ink">{stay.title || stay.name}</h4>
                            <p className="text-xs text-ink-2">{stay.location}</p>
                          </div>
                          <p className="text-[11px] text-ink-3 leading-relaxed line-clamp-2">{stay.details || (stay.inclusions ? stay.inclusions.join(', ') : '')}</p>
                        </div>
                      </div>

                      <div className="p-4 bg-cream/50 border-t border-line flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-ink-3 uppercase block">Per Night</span>
                          <span className="font-display text-base font-semibold text-ink">
                            {formatINR(stayPrice)}
                          </span>
                        </div>

                        <button
                          onClick={() => setStay(stay)}
                          className={`px-4 py-2 text-xs font-semibold rounded-btn transition-colors cursor-pointer ${
                            isSelected
                              ? 'bg-marigold text-marigold-ink'
                              : 'bg-paper hover:bg-cream-2 text-ink border border-line'
                          }`}
                        >
                          {isSelected ? 'Selected' : 'Select Room'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: LOCAL TRAVEL */}
          {activeTab === 'local' && (
            <div className="space-y-4">
              <div>
                <h3 className="font-display text-lg font-semibold text-ink">Getting Around</h3>
                <p className="text-xs text-ink-2">Station pickups, AC cabs, and local transit vouchers</p>
              </div>

              <div className="space-y-3">
                {fixtures.local.map((loc) => {
                  const isSelected = currentTrip.selections.localTravel.some((l) => l.id === loc.id);
                  const locImg = loc.image || loc.thumbnail || (loc.type === 'cab' ? '/images/thumb-cab.webp' : loc.type === 'auto' ? '/images/thumb-auto.webp' : loc.type === 'metro' ? '/images/thumb-metro.webp' : '/images/thumb-rental.webp');
                  const locPrice = loc.price || (loc.unitPrice * (loc.quantity || 1));
                  return (
                    <div
                      key={loc.id}
                      className={`p-4 rounded-card border bg-paper flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all ${
                        isSelected ? 'border-marigold ring-2 ring-marigold/30 shadow-xs' : 'border-line hover:border-ink-3'
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-24 h-24 rounded-xl overflow-hidden flex-shrink-0 border border-line bg-cream" style={{ backgroundColor: '#182028' }}>
                          <img src={locImg} alt={loc.name || loc.title} className="w-full h-full object-cover" loading="lazy" />
                        </div>
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono uppercase px-2 py-0.5 bg-cream rounded border border-line">
                              {loc.type}
                            </span>
                            <h4 className="font-display text-base font-semibold text-ink">{loc.title || loc.name}</h4>
                          </div>
                          <p className="text-xs text-ink-2">{loc.details || `${loc.quantity || 1} ride(s) / allocation included.`}</p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between sm:justify-end gap-3 border-t sm:border-t-0 pt-2 sm:pt-0 border-line">
                        <span className="font-display text-base font-semibold text-ink font-mono">
                          {formatINR(locPrice)}
                        </span>
                        <button
                          onClick={() => toggleLocalTravel(loc)}
                          className={`px-3.5 py-1.5 text-xs font-semibold rounded-btn transition-colors cursor-pointer ${
                            isSelected
                              ? 'bg-marigold text-marigold-ink'
                              : 'bg-cream hover:bg-cream-2 text-ink border border-line'
                          }`}
                        >
                          {isSelected ? 'Remove' : 'Add to trip'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 5: EXPERIENCES */}
          {activeTab === 'experiences' && (
            <div className="space-y-4">
              <div>
                <h3 className="font-display text-lg font-semibold text-ink">Curated Experiences</h3>
                <p className="text-xs text-ink-2">Guided heritage walks, food trails, and monument passes</p>
              </div>

              <div className="space-y-3">
                {fixtures.experiences.map((exp) => {
                  const isSelected = currentTrip.selections.experiences.some((e) => e.id === exp.id);
                  const expImg = exp.image || exp.thumbnail || (exp.category === 'Food' ? '/images/thumb-exp-culinary.webp' : '/images/thumb-exp-heritage.webp');
                  const expPrice = exp.price || (exp.pricePerPerson * currentTrip.travellers);
                  return (
                    <div
                      key={exp.id}
                      className={`p-4 rounded-card border bg-paper flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all ${
                        isSelected ? 'border-marigold ring-2 ring-marigold/30 shadow-xs' : 'border-line hover:border-ink-3'
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-24 h-24 rounded-xl overflow-hidden flex-shrink-0 border border-line bg-cream" style={{ backgroundColor: '#182028' }}>
                          <img src={expImg} alt={exp.name || exp.title} className="w-full h-full object-cover" loading="lazy" />
                        </div>
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono uppercase px-2 py-0.5 bg-cream rounded border border-line">
                              {exp.duration || '2.5h'}
                            </span>
                            <h4 className="font-display text-base font-semibold text-ink">{exp.title || exp.name}</h4>
                          </div>
                          <p className="text-xs text-ink-2">{exp.details || exp.category}</p>
                          <span className="text-[11px] text-teal font-medium block">{exp.timeSlot || exp.timing || 'Morning schedule'}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between sm:justify-end gap-3 border-t sm:border-t-0 pt-2 sm:pt-0 border-line">
                        <span className="font-display text-base font-semibold text-ink font-mono">
                          {formatINR(expPrice)}
                        </span>
                        <button
                          onClick={() => toggleExperience(exp)}
                          className={`px-3.5 py-1.5 text-xs font-semibold rounded-btn transition-colors cursor-pointer ${
                            isSelected
                              ? 'bg-marigold text-marigold-ink'
                              : 'bg-cream hover:bg-cream-2 text-ink border border-line'
                          }`}
                        >
                          {isSelected ? 'Remove' : 'Add to trip'}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Sticky Budget Gauge & Category Breakdown */}
        <div className="lg:col-span-4 sticky top-24 space-y-4">
          <div className="bg-paper border border-line rounded-card p-6 shadow-sm space-y-6">
            {/* Top Budget Header */}
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-semibold uppercase tracking-wider text-ink-3">
                  Live Budget Engine
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                    budget.status === 'within'
                      ? 'bg-teal/10 text-teal border border-teal/20'
                      : budget.status === 'using_buffer'
                      ? 'bg-amber/10 text-amber border border-amber/20'
                      : 'bg-coral/10 text-coral border border-coral/20'
                  }`}
                >
                  {budget.status === 'within' && 'Within Budget'}
                  {budget.status === 'using_buffer' && 'Using Buffer'}
                  {budget.status === 'over' && 'Over Budget'}
                </span>
              </div>

              <div className="mt-3 flex items-baseline justify-between">
                <div>
                  <div className="font-display text-3xl font-semibold text-ink">
                    {formatINR(budget.totalCost)}
                  </div>
                  <div className="text-xs text-ink-3">of {formatINR(budget.totalBudget)} ceiling</div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-mono font-semibold text-teal">
                    {budget.safeToSpend >= 0 ? `Safe: ${formatINR(budget.safeToSpend)}` : 'Over Ceiling'}
                  </div>
                  <div className="text-[11px] text-ink-3">
                    Buffer: {formatINR(budget.bufferRemaining)} left
                  </div>
                </div>
              </div>
            </div>

            {/* Visual Progress Bar */}
            <div className="space-y-1.5">
              <div className="w-full h-3 bg-cream rounded-full overflow-hidden border border-line flex">
                <div
                  className={`h-full transition-all duration-300 ${
                    budget.status === 'within' ? 'bg-teal' : budget.status === 'using_buffer' ? 'bg-amber' : 'bg-coral'
                  }`}
                  style={{ width: `${Math.min(percentage, 100)}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] text-ink-3 font-mono">
                <span>0%</span>
                <span>{percentage}% of Ceiling</span>
                <span>100%</span>
              </div>
            </div>

            {/* Category Breakdown */}
            <div className="space-y-3 pt-3 border-t border-line text-xs">
              <div className="font-semibold text-ink text-[11px] uppercase tracking-wider">
                Category Allocations
              </div>

              {[
                { label: 'Transport', amount: budget.categories.transport, color: 'bg-marigold' },
                { label: 'Stays', amount: budget.categories.stay, color: 'bg-teal' },
                { label: 'Food & Dining', amount: budget.categories.food, color: 'bg-amber' },
                { label: 'Local Transit', amount: budget.categories.local, color: 'bg-blue-400' },
                { label: 'Experiences', amount: budget.categories.experiences, color: 'bg-purple-400' }
              ].map((item, idx) => (
                <div key={idx} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${item.color}`} />
                    <span className="text-ink-2">{item.label}</span>
                  </div>
                  <span className="font-mono font-medium text-ink">{formatINR(item.amount)}</span>
                </div>
              ))}
            </div>

            {/* Review Button */}
            <button
              onClick={() => setShowReviewModal(true)}
              className="w-full py-3 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-colors shadow-2xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>Review & Save Itinerary</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* 3. Review Modal */}
      {showReviewModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-ink/50 backdrop-blur-xs font-sans">
          <div className="bg-paper border border-line rounded-card shadow-2xl max-w-2xl w-full p-6 md:p-8 space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-line">
              <div>
                <h3 className="font-display text-xl font-semibold text-ink">Trip Review & Confirmation</h3>
                <p className="text-xs text-ink-3">Reference: {currentTrip.id} · Sample data prototype</p>
              </div>
              <button
                onClick={() => setShowReviewModal(false)}
                className="p-1.5 text-ink-3 hover:text-ink hover:bg-cream rounded-btn transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Summary items */}
            <div className="space-y-4 max-h-96 overflow-y-auto pr-1">
              <div className="p-3.5 bg-cream rounded-xl border border-line flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-ink">Getting There (Transport)</div>
                  <div className="text-ink-2">{currentTrip.selections.transport?.title || 'None'}</div>
                </div>
                <button
                  onClick={() => {
                    setShowReviewModal(false);
                    setActiveTab('transport');
                  }}
                  className="text-marigold hover:underline font-semibold"
                >
                  Edit
                </button>
              </div>

              <div className="p-3.5 bg-cream rounded-xl border border-line flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-ink">Where to Stay</div>
                  <div className="text-ink-2">{currentTrip.selections.stay?.title || 'None'}</div>
                </div>
                <button
                  onClick={() => {
                    setShowReviewModal(false);
                    setActiveTab('stay');
                  }}
                  className="text-marigold hover:underline font-semibold"
                >
                  Edit
                </button>
              </div>

              <div className="p-3.5 bg-cream rounded-xl border border-line flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-ink">Local Travel ({currentTrip.selections.localTravel.length} items)</div>
                  <div className="text-ink-2">
                    {currentTrip.selections.localTravel.map((l) => l.title).join(', ') || 'None'}
                  </div>
                </div>
                <button
                  onClick={() => {
                    setShowReviewModal(false);
                    setActiveTab('local');
                  }}
                  className="text-marigold hover:underline font-semibold"
                >
                  Edit
                </button>
              </div>

              <div className="p-3.5 bg-cream rounded-xl border border-line flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-ink">Experiences ({currentTrip.selections.experiences.length} items)</div>
                  <div className="text-ink-2">
                    {currentTrip.selections.experiences.map((e) => e.title).join(', ') || 'None'}
                  </div>
                </div>
                <button
                  onClick={() => {
                    setShowReviewModal(false);
                    setActiveTab('experiences');
                  }}
                  className="text-marigold hover:underline font-semibold"
                >
                  Edit
                </button>
              </div>

              {/* Travellers Management */}
              <div className="p-4 bg-cream-2 border border-line rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-xs text-ink">Travellers ({travellers.length})</div>
                </div>

                <div className="space-y-1.5">
                  {travellers.map((t) => (
                    <div key={t.id} className="text-xs text-ink-2 flex justify-between bg-paper p-2 rounded border border-line">
                      <span className="font-medium text-ink">{t.fullName}</span>
                      <span className="text-ink-3 font-mono">{t.age ? `${t.age} yrs` : 'Adult'}</span>
                    </div>
                  ))}
                </div>

                <form onSubmit={handleAddTravellerSubmit} className="flex gap-2 pt-1">
                  <input
                    type="text"
                    value={newTravellerName}
                    onChange={(e) => setNewTravellerName(e.target.value)}
                    placeholder="Add traveller name..."
                    className="flex-1 bg-paper border border-line rounded px-2.5 py-1 text-xs text-ink focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1 bg-ink text-cream rounded text-xs font-semibold hover:bg-ink-2 cursor-pointer"
                  >
                    Add
                  </button>
                </form>
              </div>
            </div>

            {/* Total Footer & Confirm */}
            <div className="pt-4 border-t border-line flex items-center justify-between">
              <div>
                <div className="text-xs text-ink-3">Total Calculated Cost</div>
                <div className="font-display text-2xl font-semibold text-ink">
                  {formatINR(budget.totalCost)}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowReviewModal(false)}
                  className="px-4 py-2 bg-cream hover:bg-cream-2 border border-line text-xs font-semibold rounded-btn text-ink transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveTrip}
                  className="px-6 py-2.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-colors shadow-2xs cursor-pointer flex items-center gap-1.5"
                >
                  <FileCheck2 className="w-4 h-4" />
                  <span>Confirm & Save Trip</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. Saved Success Modal */}
      {showSavedSuccess && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-ink/50 backdrop-blur-xs font-sans">
          <div className="bg-paper border border-line rounded-card shadow-2xl max-w-md w-full p-6 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-teal/15 text-teal flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>

            <h3 className="font-display text-2xl font-semibold text-ink">Trip Saved Successfully</h3>
            <p className="text-xs text-ink-2 leading-relaxed">
              Your itinerary for <strong className="text-ink">{currentTrip.destination}</strong> has been saved under reference <strong className="font-mono text-teal">{currentTrip.id}</strong>.
            </p>

            <div className="p-3 bg-cream rounded-xl border border-line text-xs text-ink-2 font-mono">
              Total Budget: {formatINR(budget.totalCost)} · Buffer Left: {formatINR(budget.bufferRemaining)}
            </div>

            <div className="pt-2 flex flex-col sm:flex-row gap-2">
              <button
                onClick={() => {
                  setShowSavedSuccess(false);
                  navigate('/app/trips');
                }}
                className="flex-1 py-2.5 bg-cream hover:bg-cream-2 border border-line rounded-btn text-xs font-semibold text-ink transition-colors cursor-pointer"
              >
                View in My Trips
              </button>
              <button
                onClick={() => {
                  setShowSavedSuccess(false);
                  navigate('/app/rescue');
                }}
                className="flex-1 py-2.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-colors cursor-pointer"
              >
                Test Journey Rescue
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
