import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Calendar,
  MapPin,
  ArrowRight,
  Plus,
  Trash2,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Compass
} from 'lucide-react';
import { useTrip } from '../../context/TripContext';
import { formatINR } from '../../lib/budget';
import { DESTINATIONS } from '../../data/fixtures';
import imageColorsData from '../../data/imageColors.json';

const imageColors: Record<string, string> = imageColorsData;

export default function MyTripsPage() {
  const navigate = useNavigate();
  const { savedTrips, loadTrip, deleteTrip, resetTrip } = useTrip();
  const [tabFilter, setTabFilter] = useState<'all' | 'upcoming' | 'drafts'>('all');

  const filteredTrips = savedTrips.filter((t) => {
    if (tabFilter === 'all') return true;
    if (tabFilter === 'upcoming') return t.status === 'planned';
    if (tabFilter === 'drafts') return t.status === 'draft';
    return true;
  });

  const handleOpenTrip = (tripId: string) => {
    loadTrip(tripId);
    navigate('/app/planner');
  };

  const handleCreateNew = () => {
    resetTrip('Jaipur', 18000, 3, 2);
    navigate('/app/planner');
  };

  const getDestinationImage = (name: string) => {
    const lower = (name || '').toLowerCase();
    if (lower.includes('jaipur')) return '/images/dest-jaipur-card.webp';
    if (lower.includes('hampi')) return '/images/dest-hampi-card.webp';
    if (lower.includes('varanasi')) return '/images/dest-varanasi-card.webp';
    if (lower.includes('kerala') || lower.includes('alleppey') || lower.includes('kochi')) return '/images/dest-alleppey-card.webp';
    if (lower.includes('coorg')) return '/images/dest-coorg-card.webp';
    return '/images/dest-delhi-card.webp';
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-8 font-sans">
      {/* Slim 160px Banner with band-1.webp */}
      <div className="relative h-[160px] w-full overflow-hidden rounded-2xl select-none bg-ink shadow-sm">
        <img
          src="/images/band-1.webp"
          alt="Moving train across Indian countryside"
          width={1600}
          height={400}
          className="absolute inset-0 w-full h-full object-cover"
          style={{ backgroundColor: imageColors['band-1.webp'] || '#182828' }}
        />
        <div className="absolute inset-0 bg-[#0B1B2B]/85 pointer-events-none" />

        <div className="relative z-10 h-full p-6 sm:p-8 flex items-center justify-between text-paper">
          <div>
            <div className="text-xs font-semibold uppercase tracking-wider text-marigold mb-1">
              Your Living Journeys
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-semibold text-paper tracking-tight">
              My Trips
            </h1>
            <p className="text-xs sm:text-sm text-cream/85 mt-0.5">
              Manage your saved itineraries, active plans, and historical travel simulations.
            </p>
          </div>

          <button
            onClick={handleCreateNew}
            className="hidden sm:flex px-4.5 py-2.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-colors shadow-2xs items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Plan New Trip</span>
          </button>
        </div>
      </div>

      {/* Tabs & Mobile New Trip Button */}
      <div className="flex items-center justify-between border-b border-line pb-3">
        <div className="flex items-center gap-2">
          {[
            { id: 'all', label: `All Trips (${savedTrips.length})` },
            { id: 'upcoming', label: 'Upcoming' },
            { id: 'drafts', label: 'Drafts' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setTabFilter(tab.id as any)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-btn transition-colors cursor-pointer ${
                tabFilter === tab.id
                  ? 'bg-ink text-cream'
                  : 'text-ink-2 hover:text-ink hover:bg-cream'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <button
          onClick={handleCreateNew}
          className="sm:hidden px-3 py-1.5 bg-marigold text-marigold-ink font-semibold text-xs rounded-btn transition-colors flex items-center gap-1 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New</span>
        </button>
      </div>

      {/* Trip Cards Grid */}
      {filteredTrips.length === 0 ? (
        <div className="bg-paper border border-line rounded-card p-12 text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-cream flex items-center justify-center mx-auto text-ink-3">
            <Calendar className="w-6 h-6" />
          </div>
          <h3 className="font-display text-lg font-semibold text-ink">No trips found in this view</h3>
          <p className="text-xs text-ink-2 max-w-sm mx-auto">
            You don't have any itineraries under this filter. Start a new plan with Alexa or choose an Indian destination.
          </p>
          <button
            onClick={handleCreateNew}
            className="px-4 py-2 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-colors cursor-pointer"
          >
            Create New Plan
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredTrips.map((trip) => (
            <div
              key={trip.id}
              className="bg-paper border border-line rounded-card overflow-hidden shadow-2xs hover:shadow-sm transition-all flex flex-col justify-between"
            >
              {/* Destination 16:9 Photo on Top */}
              <div className="relative h-44 w-full overflow-hidden bg-ink" style={{ backgroundColor: '#182028' }}>
                <img
                  src={getDestinationImage(trip.destination)}
                  alt={trip.destination}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
                <div className="absolute top-3 right-3 px-2 py-0.5 bg-ink/80 text-cream text-[11px] font-semibold rounded-full backdrop-blur-sm uppercase">
                  {trip.status}
                </div>
              </div>

              <div className="p-6 space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-mono font-bold text-teal">{trip.id}</span>
                    </div>
                    <h3 className="font-display text-xl font-semibold text-ink">
                      {trip.destination} Journey
                    </h3>
                  </div>

                  <div className="text-right">
                    <span className="text-[11px] text-ink-3 block">Total Budget</span>
                    <span className="font-display text-lg font-semibold text-ink font-mono">
                      {formatINR(trip.totalBudget)}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-xs text-ink-2 pt-2 border-t border-line">
                  <span>{trip.days} Days</span>
                  <span>•</span>
                  <span>{trip.travellers} Travellers</span>
                  <span>•</span>
                  <span>From {trip.origin}</span>
                </div>

                {/* Selections preview */}
                <div className="bg-cream/60 p-3 rounded-xl border border-line text-xs space-y-1 text-ink-2">
                  <div className="truncate">
                    <strong className="text-ink">Transit:</strong> {trip.selections.transport?.name || trip.selections.transport?.id || 'None chosen'}
                  </div>
                  <div className="truncate">
                    <strong className="text-ink">Stay:</strong> {trip.selections.stay?.name || trip.selections.stay?.id || 'None chosen'}
                  </div>
                </div>
              </div>

              {/* Action Footer */}
              <div className="p-4 bg-cream/40 border-t border-line flex items-center justify-between">
                <button
                  onClick={() => deleteTrip(trip.id)}
                  title="Delete trip"
                  className="p-2 text-ink-3 hover:text-coral transition-colors rounded cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      loadTrip(trip.id);
                      navigate('/app/rescue');
                    }}
                    className="px-3 py-1.5 bg-paper hover:bg-cream-2 border border-line text-xs font-semibold rounded-btn text-ink transition-colors cursor-pointer"
                  >
                    Test Rescue
                  </button>
                  <button
                    onClick={() => handleOpenTrip(trip.id)}
                    className="px-4 py-1.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>Open Workspace</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
