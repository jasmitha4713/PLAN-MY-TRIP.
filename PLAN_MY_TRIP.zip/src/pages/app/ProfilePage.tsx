import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  User,
  Mail,
  Phone,
  ShieldCheck,
  LogOut,
  Users,
  Plus,
  Trash2,
  CheckCircle2,
  Sliders
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTrip } from '../../context/TripContext';
import imageColorsData from '../../data/imageColors.json';

const imageColors: Record<string, string> = imageColorsData;

export default function ProfilePage() {
  const { user, logout } = useAuth();
  const { travellers, addTraveller, removeTraveller } = useTrip();
  const navigate = useNavigate();

  const [dietPreference, setDietPreference] = useState('Vegetarian');
  const [transitPreference, setTransitPreference] = useState('Vande Bharat / Express Train');
  const [budgetStyle, setBudgetStyle] = useState('Balanced Explorer');

  const [newTravellerName, setNewTravellerName] = useState('');
  const [newTravellerAge, setNewTravellerAge] = useState(25);
  const [saveNotice, setSaveNotice] = useState(false);

  const handleSignOut = async () => {
    try {
      await logout();
      navigate('/');
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  const handleAddTraveller = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTravellerName.trim()) {
      addTraveller(newTravellerName.trim(), Number(newTravellerAge));
      setNewTravellerName('');
      setSaveNotice(true);
      setTimeout(() => setSaveNotice(false), 2000);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 space-y-8 font-sans">
      {/* Slim 140px Banner */}
      <div className="relative h-[140px] w-full overflow-hidden rounded-2xl select-none bg-ink shadow-sm">
        <img
          src="/images/dest-coorg-banner.webp"
          alt="Coorg misty green valley"
          width={1600}
          height={685}
          className="absolute inset-0 w-full h-full object-cover"
          style={{ backgroundColor: imageColors['dest-coorg-banner.webp'] || '#101B2B' }}
        />
        <div className="absolute inset-0 bg-[#0B1B2B]/75 pointer-events-none" />

        <div className="relative z-10 h-full p-6 flex flex-col justify-end text-paper">
          <h1 className="font-display text-2xl sm:text-3xl font-semibold text-paper tracking-tight">
            Traveler Profile
          </h1>
          <p className="text-xs text-cream/80 mt-0.5">
            Manage your passenger roster, travel preferences, and account credentials.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Left Column: Personal info & Sign out */}
        <div className="space-y-6">
          <div className="bg-paper border border-line rounded-card p-6 shadow-2xs space-y-4 text-center">
            {user?.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'User'}
                className="w-20 h-20 rounded-full mx-auto object-cover border-2 border-line"
              />
            ) : (
              <div className="w-20 h-20 rounded-full bg-cream-2 border border-line text-ink flex items-center justify-center font-display font-semibold text-2xl mx-auto">
                {user?.displayName ? user.displayName.charAt(0).toUpperCase() : 'G'}
              </div>
            )}

            <div>
              <h2 className="font-display text-lg font-semibold text-ink">
                {user?.displayName || 'Demo Guest Traveler'}
              </h2>
              <p className="text-xs text-ink-3">{user?.email || 'guest@planmytrip.demo'}</p>
            </div>

            <div className="pt-2 border-t border-line text-left text-xs space-y-2 text-ink-2">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-teal" />
                <span>Verified Hackathon Session</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-ink-3" />
                <span>{user?.email || 'Session Email'}</span>
              </div>
            </div>

            <button
              onClick={handleSignOut}
              className="w-full py-2.5 bg-coral/10 hover:bg-coral/20 text-coral font-semibold text-xs rounded-btn transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>

        {/* Right 2 Columns: Preferences & Saved Travellers */}
        <div className="md:col-span-2 space-y-6">
          {/* Travel Preferences */}
          <div className="bg-paper border border-line rounded-card p-6 shadow-2xs space-y-5">
            <h3 className="font-display text-base font-semibold text-ink">Traveler Preferences</h3>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-ink-2 mb-1.5">Dietary / Meal Preference</label>
                <div className="flex flex-wrap gap-2">
                  {['Vegetarian', 'Pure Jain', 'Non-Vegetarian', 'Vegan'].map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setDietPreference(opt)}
                      className={`px-3 py-1.5 rounded-btn font-medium transition-colors cursor-pointer ${
                        dietPreference === opt
                          ? 'bg-marigold text-marigold-ink font-semibold'
                          : 'bg-cream border border-line text-ink-2 hover:text-ink'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-ink-2 mb-1.5">Preferred Inbound Mode</label>
                <div className="flex flex-wrap gap-2">
                  {['Vande Bharat / Express Train', 'Domestic Flight', 'Luxury AC Sleeper Bus'].map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setTransitPreference(opt)}
                      className={`px-3 py-1.5 rounded-btn font-medium transition-colors cursor-pointer ${
                        transitPreference === opt
                          ? 'bg-marigold text-marigold-ink font-semibold'
                          : 'bg-cream border border-line text-ink-2 hover:text-ink'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-ink-2 mb-1.5">Budget Allocation Posture</label>
                <div className="flex flex-wrap gap-2">
                  {['Strict Ceiling (8% Buffer)', 'Flexible Buffer (12% Buffer)', 'Aggressive Value'].map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setBudgetStyle(opt)}
                      className={`px-3 py-1.5 rounded-btn font-medium transition-colors cursor-pointer ${
                        budgetStyle === opt
                          ? 'bg-marigold text-marigold-ink font-semibold'
                          : 'bg-cream border border-line text-ink-2 hover:text-ink'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Saved Travellers Roster */}
          <div className="bg-paper border border-line rounded-card p-6 shadow-2xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-display text-base font-semibold text-ink">Saved Passengers ({travellers.length})</h3>
                <p className="text-xs text-ink-3">Pre-fills ticket reservations and passenger lists</p>
              </div>
              {saveNotice && (
                <span className="text-xs font-semibold text-teal flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Added!</span>
                </span>
              )}
            </div>

            <div className="space-y-2">
              {travellers.map((traveller) => (
                <div
                  key={traveller.id}
                  className="p-3 bg-cream rounded-xl border border-line flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="font-semibold text-ink flex items-center gap-2">
                      <span>{traveller.fullName}</span>
                      {traveller.isPrimary && (
                        <span className="px-1.5 py-0.2 bg-marigold/20 text-marigold-ink text-[10px] rounded font-bold">
                          Primary
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-ink-3">
                      {traveller.age ? `${traveller.age} years old` : 'Adult'}
                    </div>
                  </div>

                  {!traveller.isPrimary && (
                    <button
                      onClick={() => removeTraveller(traveller.id)}
                      className="p-1 text-ink-3 hover:text-coral transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>

            {/* Add Traveller Input */}
            <form onSubmit={handleAddTraveller} className="pt-2 border-t border-line flex gap-2">
              <input
                type="text"
                value={newTravellerName}
                onChange={(e) => setNewTravellerName(e.target.value)}
                placeholder="Passenger full name..."
                className="flex-1 bg-cream border border-line rounded-btn px-3 py-2 text-xs text-ink focus:outline-none focus:border-marigold"
              />
              <input
                type="number"
                min={1}
                max={99}
                value={newTravellerAge}
                onChange={(e) => setNewTravellerAge(Number(e.target.value))}
                className="w-16 bg-cream border border-line rounded-btn px-2 py-2 text-xs text-ink focus:outline-none focus:border-marigold"
                placeholder="Age"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-colors cursor-pointer flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
