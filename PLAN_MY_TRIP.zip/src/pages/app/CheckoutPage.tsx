import React, { useState, useMemo } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  CreditCard,
  QrCode,
  Building2,
  Lock,
  Printer,
  Sparkles,
  Info,
  Calendar,
  Users,
  MapPin,
  Clock,
  RotateCcw
} from 'lucide-react';
import { useTrip } from '../../context/TripContext';
import { useAuth } from '../../context/AuthContext';
import { SUPPORTED_CITIES, findCityByName } from '../../data/destinations';
import { formatINR } from '../../lib/budget';
import PriceLine from '../../components/app/PriceLine';
import { 
  mockPaymentProvider, 
  vendorSettlementEngine, 
  SettlementLine 
} from '../../lib/paymentSettlement';

type CheckoutStep = 'review' | 'travellers' | 'pay' | 'done';

export default function CheckoutPage({ initialSubStep }: { initialSubStep?: CheckoutStep }) {
  const { id: tripId, subStep } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { currentTrip, updateTrip, saveCurrentTrip } = useTrip();

  // Active step
  const activeStep: CheckoutStep = (subStep as CheckoutStep) || initialSubStep || 'review';

  // Resolve Destination
  const destData = useMemo(() => {
    let dest = findCityByName(currentTrip.destination);
    if (!dest && tripId) {
      const cityPart = tripId.split('-')[0];
      dest = findCityByName(cityPart);
    }
    return dest || SUPPORTED_CITIES[0];
  }, [currentTrip.destination, tripId]);

  const travellersCount = Math.max(1, currentTrip.travellers || 2);
  const days = Math.max(1, currentTrip.days || 3);
  const nights = Math.max(1, days - 1);
  const totalBudget = Math.max(3000, currentTrip.totalBudget || 15000);

  // Computed Itemised Costs from authoritative trip selections
  const selectedTransport = currentTrip.selections?.transport;
  const selectedStay = currentTrip.selections?.stay;
  const transportUnitFare = selectedTransport ? selectedTransport.cost : 1800;
  const transportCost = selectedTransport ? selectedTransport.totalCost : (transportUnitFare * travellersCount);
  const stayNightRate = selectedStay ? selectedStay.ratePerNight : 2800;
  const roomsCount = Math.ceil(travellersCount / 2);
  const stayCost = selectedStay ? selectedStay.totalCost : (stayNightRate * roomsCount * nights);
  const localCost = 1600 * cabsNeeded(travellersCount);
  const placesCost = 250 * travellersCount;
  const foodEstimate = (currentTrip.selections?.foodPerPersonPerDay || 400) * travellersCount * days;

  function cabsNeeded(t: number) {
    return Math.ceil(t / 4);
  }

  // Payable Now vs On-trip Estimates
  // Food estimate is paid directly by traveller at restaurants, NOT payable at checkout
  const payableNowTotal = transportCost + stayCost + localCost + placesCost;
  const grandTripEstimate = payableNowTotal + foodEstimate;

  // Travellers List State
  const [passengers, setPassengers] = useState<Array<{ fullName: string; age: number; isPrimary: boolean }>>(() => {
    const list = [
      {
        fullName: user?.displayName || 'Aarav Sharma',
        age: 28,
        isPrimary: true
      }
    ];
    for (let i = 1; i < travellersCount; i++) {
      list.push({
        fullName: i === 1 ? 'Rohan Sharma' : `Traveler ${i + 1}`,
        age: 25,
        isPrimary: false
      });
    }
    return list;
  });

  // Payment Form State
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [simulateFailure, setSimulateFailure] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentError, setPaymentError] = useState<string | null>(null);

  // Confirmed booking data (for 'done' screen)
  const [confirmedData, setConfirmedData] = useState<{
    bookingReference: string;
    transactionId: string;
    settlementLines: SettlementLine[];
    bookings: Array<{
      type: string;
      title: string;
      provider: string;
      reference: string;
      scheduledTime: string;
      contact: string;
    }>;
  } | null>(null);

  // Handle passenger update
  const handlePassengerChange = (index: number, field: 'fullName' | 'age', value: string | number) => {
    setPassengers(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  };

  const arePassengersValid = passengers.every(p => p.fullName.trim() !== '' && p.age > 0);

  // Execute Simulated Payment
  const handleExecutePayment = async () => {
    setIsProcessing(true);
    setPaymentError(null);

    try {
      const order = await mockPaymentProvider.createOrder(payableNowTotal, 'INR');
      const result = await mockPaymentProvider.confirm(order.orderId, simulateFailure);

      if (!result.success) {
        setIsProcessing(false);
        setPaymentError(result.error || 'Payment failed. Please retry.');
        return;
      }

      // Compute split settlement
      const settlements = vendorSettlementEngine.split(payableNowTotal, {
        transport: { operator: selectedTransport?.title ? `${selectedTransport.provider} (${selectedTransport.title})` : 'Indian Railways Express (Vande Bharat CC)', cost: transportCost },
        stay: { name: selectedStay?.name ? `${selectedStay.name} (${selectedStay.tier})` : `${destData.name} Heritage Boutique Residency`, cost: stayCost },
        local: { name: 'Verified City AC Cab Partner', cost: localCost },
        places: { count: 3, cost: placesCost }
      });

      const refNum = `SIM-PMT-${Math.floor(1000 + Math.random() * 9000)}`;

      setConfirmedData({
        bookingReference: refNum,
        transactionId: result.transactionId || 'TXN-SIM-789X',
        settlementLines: settlements,
        bookings: [
          {
            type: selectedTransport?.mode ? `${selectedTransport.mode.toUpperCase()} Transit` : 'Train Transit',
            title: selectedTransport?.title ? `${selectedTransport.title} (${travellersCount} seats)` : `Express Chair Car (${travellersCount} seats)`,
            provider: selectedTransport?.provider || 'Indian Railways Express',
            reference: `SIM-TRN-${Math.floor(1000 + Math.random() * 9000)}`,
            scheduledTime: selectedTransport?.departureTime ? `${selectedTransport.departureTime} Departure` : '06:15 AM Departure Platform 1',
            contact: 'Station Master Helpline 139 / Operator Dispatch'
          },
          {
            type: selectedStay?.tier ? `${selectedStay.tier.toUpperCase()} Stay` : 'Boutique Stay',
            title: selectedStay?.name ? `${selectedStay.name} (${roomsCount} rooms, ${nights} nights)` : `${destData.name} Heritage Residency (${roomsCount} rooms, ${nights} nights)`,
            provider: selectedStay?.name || 'Heritage Hotel Network',
            reference: `SIM-HTL-${Math.floor(1000 + Math.random() * 9000)}`,
            scheduledTime: 'Check-in: 01:00 PM · Cutoff: 09:00 PM',
            contact: 'Front Desk Duty Manager: Rajesh Kumar'
          },
          {
            type: 'Prepaid Cab',
            title: `Station Arrival Pickup & Local Rides (${cabsNeeded(travellersCount)} cab)`,
            provider: 'City Cab Escrow Network',
            reference: `SIM-CAB-${Math.floor(1000 + Math.random() * 9000)}`,
            scheduledTime: '10:15 AM Station Porch Meeting',
            contact: 'Driver: Ramesh Patel (+91 98765 43210)'
          }
        ]
      });

      // Explicit confirmation updates status to 'planned'
      updateTrip({ status: 'planned' });
      saveCurrentTrip('planned');

      setIsProcessing(false);
      navigate(`/app/plan/${tripId || destData.id}/done`);
    } catch (err: any) {
      setIsProcessing(false);
      setPaymentError(err.message || 'Payment processing error');
    }
  };

  return (
    <div className="min-h-screen bg-cream font-sans pb-24">
      
      {/* Top Banner & Progress Header (Hidden on Print) */}
      <div className="bg-paper border-b border-line print:hidden">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link
              to={`/app/plan/${tripId || destData.id}`}
              className="w-8 h-8 rounded-full hover:bg-cream border border-line flex items-center justify-center text-ink-3 hover:text-ink transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
            </Link>
            <div>
              <span className="text-xs font-mono uppercase text-marigold font-bold">Simulated Marketplace Checkout</span>
              <h1 className="font-display text-xl font-semibold text-ink">
                {activeStep === 'review' && '1. Review Trip Breakdown'}
                {activeStep === 'travellers' && '2. Passenger Details'}
                {activeStep === 'pay' && '3. Complete Payment (Simulation)'}
                {activeStep === 'done' && 'Trip Booked (Simulation)'}
              </h1>
            </div>
          </div>

          {/* Stepper pills */}
          <div className="hidden sm:flex items-center gap-2 text-xs font-semibold">
            {(['review', 'travellers', 'pay', 'done'] as const).map((step, idx) => {
              const isCurrent = activeStep === step;
              const isPast = ['review', 'travellers', 'pay', 'done'].indexOf(activeStep) > idx;

              return (
                <div
                  key={step}
                  className={`px-3 py-1 rounded-full capitalize text-xs ${
                    isCurrent
                      ? 'bg-marigold text-marigold-ink font-bold'
                      : isPast
                      ? 'bg-teal/15 text-teal'
                      : 'text-ink-3 bg-cream'
                  }`}
                >
                  {step}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 pt-8">
        
        {/* =========================================================
            STEP 1: REVIEW TRIP ITINERARY & FINANCIAL SPLIT
           ========================================================= */}
        {activeStep === 'review' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="bg-paper border border-line rounded-card p-6 shadow-2xs space-y-6">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-line">
                <div>
                  <h2 className="font-display text-lg font-semibold text-ink">
                    Itemised Journey Summary
                  </h2>
                  <p className="text-xs text-ink-3">
                    {currentTrip.origin} to {destData.name} · {travellersCount} Travellers · {days} Days
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs text-teal font-semibold px-2.5 py-1 bg-teal/10 rounded-full border border-teal/20">
                    Within Budget Ceiling
                  </span>
                </div>
              </div>

              {/* Itemised Services Table */}
              <div className="divide-y divide-line text-xs">
                
                {/* 1. Transit */}
                <div className="py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-ink">
                        Getting There ({selectedTransport?.title || 'Selected Transit'})
                      </span>
                      <Link
                        to={`/app/plan/${tripId || destData.id}`}
                        className="text-[11px] text-marigold-ink hover:underline font-medium"
                      >
                        Change
                      </Link>
                    </div>
                    <p className="text-ink-2">
                      {selectedTransport?.provider || 'Transit Provider'} · {selectedTransport?.from || currentTrip.origin} to {selectedTransport?.to || destData.name} ({selectedTransport?.departureTime || '06:00 AM'} → {selectedTransport?.arrivalTime || '01:00 PM'})
                    </p>
                    <p className="text-[11px] text-teal">
                      Refundable per operator cancellation guidelines
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="font-display text-base font-semibold text-ink">{formatINR(transportCost)}</div>
                    <div className="text-[11px] text-ink-3">{formatINR(transportUnitFare)} / person × {travellersCount}</div>
                  </div>
                </div>

                {/* 2. Stay */}
                <div className="py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-ink">
                        Accommodation ({selectedStay?.name || `${destData.name} Heritage Boutique Stay`})
                      </span>
                      <Link
                        to={`/app/plan/${tripId || destData.id}`}
                        className="text-[11px] text-marigold-ink hover:underline font-medium"
                      >
                        Change
                      </Link>
                    </div>
                    <p className="text-ink-2">
                      {selectedStay?.area || destData.name} · {roomsCount} rooms, {nights} nights
                    </p>
                    <p className="text-[11px] text-teal">
                      Free cancellation until check-in cutoff
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="font-display text-base font-semibold text-ink">{formatINR(stayCost)}</div>
                    <div className="text-[11px] text-ink-3">{formatINR(stayNightRate)}/rm × {roomsCount} rms × {nights} nts</div>
                  </div>
                </div>

                {/* 3. Getting Around */}
                <div className="py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-ink">Local Transit & Cabs</span>
                      <Link
                        to={`/app/plan/${tripId || destData.id}`}
                        className="text-[11px] text-marigold-ink hover:underline font-medium"
                      >
                        Edit
                      </Link>
                    </div>
                    <p className="text-ink-2">
                      Dedicated Station Pickup Cab + Daily City AC Transit ({cabsNeeded(travellersCount)} vehicle)
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="font-display text-base font-semibold text-ink">{formatINR(localCost)}</div>
                    <div className="text-[11px] text-ink-3">Dedicated driver & fuel included</div>
                  </div>
                </div>

                {/* 4. Places & Experiences */}
                <div className="py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-ink">Attraction Entries & Passes</span>
                      <Link
                        to={`/app/plan/${tripId || destData.id}`}
                        className="text-[11px] text-marigold-ink hover:underline font-medium"
                      >
                        Edit
                      </Link>
                    </div>
                    <p className="text-ink-2">
                      Reserved entry passes for 3 monuments & guided cultural walk
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="font-display text-base font-semibold text-ink">{formatINR(placesCost)}</div>
                    <div className="text-[11px] text-ink-3">₹250 / person × {travellersCount}</div>
                  </div>
                </div>
              </div>

              {/* Notice line */}
              <div className="p-3 bg-cream rounded-xl border border-line text-[11px] text-ink-3 flex items-center gap-2">
                <Info className="w-4 h-4 text-ink-3 shrink-0" />
                <span>Taxes and government fees: not included in this prototype. Estimated prices only.</span>
              </div>

              {/* On-trip estimate note (Food) */}
              <div className="p-3.5 bg-paper rounded-xl border border-line/80 flex items-center justify-between text-xs">
                <div>
                  <span className="font-semibold text-ink">Daily Food & Dining Estimate:</span>
                  <span className="text-ink-3 block">Payable on-trip directly at restaurants · Not charged today</span>
                </div>
                <div className="font-display text-base font-semibold text-ink-2">
                  {formatINR(foodEstimate)}
                </div>
              </div>

              {/* Totals Summary */}
              <div className="pt-4 border-t border-line flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <div className="text-xs text-ink-3">Total Payable Today (Simulated Hold):</div>
                  <div className="font-display text-3xl font-bold text-ink">
                    {formatINR(payableNowTotal)}
                  </div>
                  <div className="text-[11px] text-ink-3">
                    Grand trip estimate with food: {formatINR(grandTripEstimate)} of {formatINR(totalBudget)} budget
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => navigate(`/app/plan/${tripId || destData.id}/travellers`)}
                  className="px-6 py-3 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-all shadow-sm flex items-center gap-2 cursor-pointer"
                >
                  <span>Continue to passenger details</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================
            STEP 2: PASSENGERS / TRAVELLERS FORM
           ========================================================= */}
        {activeStep === 'travellers' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="bg-paper border border-line rounded-card p-6 md:p-8 shadow-2xs space-y-6">
              
              <div>
                <h2 className="font-display text-lg font-semibold text-ink">
                  Passenger Roster ({travellersCount} Guests)
                </h2>
                <p className="text-xs text-ink-3">
                  Please provide the names and ages of all travellers for ticket allocation.
                </p>
              </div>

              {/* Notice */}
              <div className="p-3 bg-cream rounded-xl border border-line text-xs text-ink-2 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-teal shrink-0" />
                <span>No ID numbers (Aadhaar, Passport) are collected in this prototype.</span>
              </div>

              <div className="space-y-4">
                {passengers.map((p, idx) => (
                  <div
                    key={idx}
                    className="p-4 bg-cream/50 rounded-xl border border-line space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-ink flex items-center gap-1.5">
                        <Users className="w-3.5 h-3.5 text-marigold" />
                        <span>Passenger {idx + 1} {p.isPrimary && '(Primary Traveller)'}</span>
                      </span>
                      {p.isPrimary && (
                        <span className="text-[10px] bg-teal/15 text-teal px-2 py-0.5 rounded-full font-semibold">
                          Profile Prefilled
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div className="sm:col-span-2">
                        <label className="block text-[11px] font-semibold text-ink-2 mb-1">
                          Full Name *
                        </label>
                        <input
                          type="text"
                          value={p.fullName}
                          onChange={(e) => handlePassengerChange(idx, 'fullName', e.target.value)}
                          placeholder="e.g. Rohan Sharma"
                          className="w-full bg-paper border border-line rounded-btn px-3 py-2 text-xs text-ink focus:outline-none focus:border-marigold"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-ink-2 mb-1">
                          Age (Years) *
                        </label>
                        <input
                          type="number"
                          min={1}
                          max={110}
                          value={p.age}
                          onChange={(e) => handlePassengerChange(idx, 'age', Number(e.target.value))}
                          className="w-full bg-paper border border-line rounded-btn px-3 py-2 text-xs text-ink focus:outline-none focus:border-marigold"
                          required
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-line flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => navigate(`/app/plan/${tripId || destData.id}/review`)}
                  className="px-4 py-2.5 border border-line rounded-btn text-xs font-semibold text-ink hover:bg-cream"
                >
                  Back to Review
                </button>

                <button
                  type="button"
                  disabled={!arePassengersValid}
                  onClick={() => navigate(`/app/plan/${tripId || destData.id}/pay`)}
                  className={`px-6 py-2.5 rounded-btn font-semibold text-xs flex items-center gap-2 transition-all cursor-pointer ${
                    arePassengersValid
                      ? 'bg-marigold hover:bg-marigold-hover text-marigold-ink shadow-sm'
                      : 'bg-line text-ink-3 cursor-not-allowed opacity-50'
                  }`}
                >
                  <span>Continue to payment</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================
            STEP 3: PAYMENT SCREEN (No card/CVV inputs, strictly simulated)
           ========================================================= */}
        {activeStep === 'pay' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Left Column: Payment Methods (8 cols) */}
              <div className="lg:col-span-8 space-y-6">
                <div className="bg-paper border border-line rounded-card p-6 md:p-8 shadow-2xs space-y-6">
                  
                  <div>
                    <h2 className="font-display text-lg font-semibold text-ink">
                      Choose Payment Method
                    </h2>
                    <p className="text-xs text-ink-3">
                      Simulated marketplace checkout · No financial credentials or card numbers collected
                    </p>
                  </div>

                  {/* Payment Method Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    
                    {/* UPI */}
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('upi')}
                      className={`p-4 rounded-xl border text-left transition-colors cursor-pointer space-y-2 ${
                        paymentMethod === 'upi'
                          ? 'border-marigold bg-marigold/10 ring-2 ring-marigold/30'
                          : 'border-line hover:border-ink/30 bg-cream/40'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <QrCode className="w-5 h-5 text-marigold-ink" />
                        <span className="text-[10px] font-bold text-teal">Fastest</span>
                      </div>
                      <div className="font-semibold text-xs text-ink">Instant UPI</div>
                      <div className="text-[11px] text-ink-3">GPay, PhonePe, Paytm, BHIM</div>
                    </button>

                    {/* Cards */}
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('card')}
                      className={`p-4 rounded-xl border text-left transition-colors cursor-pointer space-y-2 ${
                        paymentMethod === 'card'
                          ? 'border-marigold bg-marigold/10 ring-2 ring-marigold/30'
                          : 'border-line hover:border-ink/30 bg-cream/40'
                      }`}
                    >
                      <CreditCard className="w-5 h-5 text-marigold-ink" />
                      <div className="font-semibold text-xs text-ink">Credit / Debit Card</div>
                      <div className="text-[11px] text-ink-3">Visa, Mastercard, RuPay</div>
                    </button>

                    {/* Net Banking */}
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('netbanking')}
                      className={`p-4 rounded-xl border text-left transition-colors cursor-pointer space-y-2 ${
                        paymentMethod === 'netbanking'
                          ? 'border-marigold bg-marigold/10 ring-2 ring-marigold/30'
                          : 'border-line hover:border-ink/30 bg-cream/40'
                      }`}
                    >
                      <Building2 className="w-5 h-5 text-marigold-ink" />
                      <div className="font-semibold text-xs text-ink">Net Banking</div>
                      <div className="text-[11px] text-ink-3">All major Indian banks</div>
                    </button>
                  </div>

                  {/* Strict Honesty Notice */}
                  <div className="p-4 bg-cream rounded-xl border border-line space-y-2 text-xs">
                    <div className="flex items-center gap-2 font-semibold text-ink">
                      <Lock className="w-4 h-4 text-teal" />
                      <span>Security & Marketplace Architecture:</span>
                    </div>
                    <p className="text-ink-2 leading-relaxed">
                      In a production release, clicking Pay redirects to a PCI-DSS certified hosted checkout (such as Razorpay Route or Stripe Connect). In this hackathon simulation, zero real money is transacted and no card inputs are rendered.
                    </p>
                  </div>

                  {/* Presentation Demo Toggle: Simulate Failure */}
                  <div className="p-4 bg-amber/10 border border-amber/30 rounded-xl flex items-center justify-between text-xs">
                    <div>
                      <span className="font-semibold text-amber block">Demo Control:</span>
                      <span className="text-ink-2">Simulate a bank decline to verify error handling & retry flow</span>
                    </div>
                    <label className="flex items-center gap-2 cursor-pointer font-semibold text-ink">
                      <input
                        type="checkbox"
                        checked={simulateFailure}
                        onChange={(e) => setSimulateFailure(e.target.checked)}
                        className="w-4 h-4 accent-amber"
                      />
                      <span>Simulate Failure</span>
                    </label>
                  </div>

                  {/* Payment Error Alert if failed */}
                  {paymentError && (
                    <div className="p-4 bg-coral/10 border border-coral/30 rounded-xl flex items-start gap-3 text-xs text-coral">
                      <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold block">Payment Unsuccessful</span>
                        <span>{paymentError}</span>
                      </div>
                    </div>
                  )}

                  {/* Pay Button */}
                  <div className="pt-2">
                    <button
                      type="button"
                      disabled={isProcessing}
                      onClick={handleExecutePayment}
                      className="w-full py-3.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-bold text-sm rounded-btn transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {isProcessing ? (
                        <>
                          <div className="w-4 h-4 border-2 border-marigold-ink border-t-transparent rounded-full animate-spin" />
                          <span>Processing Simulation...</span>
                        </>
                      ) : (
                        <>
                          <Lock className="w-4 h-4" />
                          <span>Pay {formatINR(payableNowTotal)} (Simulation)</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* Right Column: Order Summary & Where your money goes (4 cols) */}
              <div className="lg:col-span-4 space-y-4">
                <div className="bg-paper border border-line rounded-card p-6 shadow-floating space-y-4">
                  <h3 className="font-display text-base font-semibold text-ink">
                    Where your money goes
                  </h3>
                  <p className="text-[11px] text-ink-3">
                    Transparent marketplace split per verified provider
                  </p>

                  <div className="divide-y divide-line text-xs">
                    <div className="py-2 flex justify-between">
                      <span className="text-ink-2">Train Operator:</span>
                      <span className="font-semibold text-ink">{formatINR(transportCost)}</span>
                    </div>
                    <div className="py-2 flex justify-between">
                      <span className="text-ink-2">Hotel / Stay Provider:</span>
                      <span className="font-semibold text-ink">{formatINR(stayCost)}</span>
                    </div>
                    <div className="py-2 flex justify-between">
                      <span className="text-ink-2">Cab & Transit Escrow:</span>
                      <span className="font-semibold text-ink">{formatINR(localCost)}</span>
                    </div>
                    <div className="py-2 flex justify-between">
                      <span className="text-ink-2">Heritage Monuments Entry:</span>
                      <span className="font-semibold text-ink">{formatINR(placesCost)}</span>
                    </div>
                    <div className="py-2 flex justify-between text-teal font-semibold">
                      <span>Plan My Trip Platform Fee:</span>
                      <span>₹0 (Prototype)</span>
                    </div>
                    <div className="pt-3 flex justify-between font-bold text-base text-ink">
                      <span>Total Amount:</span>
                      <span>{formatINR(payableNowTotal)}</span>
                    </div>
                  </div>

                  <div className="pt-2 text-center">
                    <span className="inline-flex items-center gap-1.5 text-[11px] text-ink-3">
                      <ShieldCheck className="w-3.5 h-3.5 text-teal" />
                      <span>Simulated · nothing charged to real accounts</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================
            STEP 4: CONFIRMATION / DONE SCREEN
           ========================================================= */}
        {activeStep === 'done' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="bg-paper border border-line rounded-card p-6 md:p-8 shadow-floating space-y-6 print:border-none print:shadow-none">
              
              {/* Success Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-line">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-teal/15 text-teal flex items-center justify-center">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <div>
                    <span className="text-xs font-mono uppercase text-teal font-bold tracking-wider">
                      Confirmed Itinerary
                    </span>
                    <h2 className="font-display text-2xl font-bold text-ink">
                      Trip Booked (Simulation)
                    </h2>
                    <p className="text-xs text-ink-3">
                      Booking Reference: <strong>{confirmedData?.bookingReference || 'SIM-PMT-0142'}</strong>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 print:hidden">
                  <button
                    onClick={() => window.print()}
                    className="px-3.5 py-2 bg-cream hover:bg-cream-2 border border-line rounded-btn text-xs font-semibold text-ink flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print Receipt</span>
                  </button>
                </div>
              </div>

              {/* Status Banner */}
              <div className="p-4 bg-teal/10 border border-teal/20 rounded-xl text-xs flex items-center justify-between">
                <div className="flex items-center gap-2 text-teal font-semibold">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Payment Status: Simulated Hold (Nothing charged)</span>
                </div>
                <span className="font-mono text-ink-3 text-[11px]">
                  Txn ID: {confirmedData?.transactionId || 'TXN-SIM-789X'}
                </span>
              </div>

              {/* Provider Bookings Grid */}
              <div className="space-y-3">
                <h3 className="font-semibold text-sm text-ink">Simulated Provider Bookings</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {(confirmedData?.bookings || []).map((b, idx) => (
                    <div key={idx} className="p-4 bg-cream/50 rounded-xl border border-line space-y-2 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-ink">{b.type}</span>
                        <span className="font-mono text-[10px] bg-paper px-1.5 py-0.5 rounded border border-line">
                          {b.reference}
                        </span>
                      </div>
                      <div className="text-ink font-medium">{b.title}</div>
                      <div className="text-ink-3 text-[11px]">{b.scheduledTime}</div>
                      <div className="text-teal text-[11px] font-medium pt-1 border-t border-line/60">
                        {b.contact}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Provider Settlement Splits Table */}
              <div className="space-y-3">
                <h3 className="font-semibold text-sm text-ink">Provider Settlement & Payout Status</h3>
                <div className="border border-line rounded-xl overflow-hidden">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-cream border-b border-line font-semibold text-ink-2">
                      <tr>
                        <th className="p-3">Provider</th>
                        <th className="p-3">Service</th>
                        <th className="p-3">Amount</th>
                        <th className="p-3">Status</th>
                        <th className="p-3">Payout Schedule</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-line">
                      {(confirmedData?.settlementLines || []).map(line => (
                        <tr key={line.id}>
                          <td className="p-3 font-medium text-ink">{line.providerName}</td>
                          <td className="p-3 capitalize text-ink-2">{line.serviceType}</td>
                          <td className="p-3 font-semibold text-ink">{formatINR(line.amount)}</td>
                          <td className="p-3">
                            <span className="px-2 py-0.5 bg-amber/15 text-amber text-[10px] font-bold rounded-full">
                              {line.status}
                            </span>
                          </td>
                          <td className="p-3 text-ink-3 text-[11px]">{line.estimatedPayoutTime}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Next Actions (Print Hidden) */}
              <div className="pt-4 border-t border-line flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 print:hidden">
                <Link
                  to="/app"
                  className="px-4 py-2.5 bg-cream hover:bg-cream-2 border border-line rounded-btn text-xs font-semibold text-ink text-center"
                >
                  Return to Dashboard
                </Link>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      const canonicalTarget = currentTrip.backendTripId || (currentTrip.id?.startsWith('trip_') ? currentTrip.id : null) || 'trip_hyd_del_001';
                      navigate(`/app/trip/${canonicalTarget}`);
                    }}
                    className="px-6 py-2.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Open trip</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
