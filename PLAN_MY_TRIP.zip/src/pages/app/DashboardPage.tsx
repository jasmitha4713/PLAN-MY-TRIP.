import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Mic,
  Send,
  Sparkles,
  ArrowRight,
  Compass,
  MessageSquare
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTrip } from '../../context/TripContext';
import { SUPPORTED_CITIES, findCityByName } from '../../data/destinations';
import { parseTripIntake, ParsedTripIntake } from '../../lib/intakeParser';
import { formatINR } from '../../lib/budget';
import ConfirmTripSheet from '../../components/app/ConfirmTripSheet';
import AlexaVoicePanel from '../../components/app/AlexaVoicePanel';
import imageColorsData from '../../data/imageColors.json';

const imageColors: Record<string, string> = imageColorsData;

export default function DashboardPage() {
  const { user } = useAuth();
  const { currentTrip, budget, resetTrip, updateTrip } = useTrip();
  const navigate = useNavigate();

  // Intake State
  const [typedPrompt, setTypedPrompt] = useState('');
  const [showConfirmSheet, setShowConfirmSheet] = useState(false);
  const [parsedIntake, setParsedIntake] = useState<ParsedTripIntake | null>(null);
  const [showVoicePanel, setShowVoicePanel] = useState(false);

  // Fallback greeting check: if name missing or < 3 chars, fallback to time-of-day greeting only
  const getGreeting = () => {
    const hour = new Date().getHours();
    let timeGreeting = 'Good morning';
    if (hour >= 12 && hour < 17) timeGreeting = 'Good afternoon';
    if (hour >= 17) timeGreeting = 'Good evening';

    const rawName = user?.displayName?.trim();
    if (!rawName || rawName.length < 3 || /^(user|test|guest|demo|null|undefined)$/i.test(rawName)) {
      return `${timeGreeting}.`;
    }
    const firstName = rawName.split(' ')[0];
    return `${timeGreeting}, ${firstName}.`;
  };

  // Determine destination slug for dynamic banner
  const getDestSlug = (destStr: string) => {
    const lower = (destStr || '').toLowerCase();
    if (lower.includes('jaipur')) return 'jaipur';
    if (lower.includes('hampi')) return 'hampi';
    if (lower.includes('varanasi')) return 'varanasi';
    if (lower.includes('kerala') || lower.includes('alleppey') || lower.includes('kochi')) return 'alleppey';
    if (lower.includes('coorg')) return 'coorg';
    return 'delhi';
  };

  const destSlug = getDestSlug(currentTrip.destination);
  const bannerImgPath = `/images/dest-${destSlug}-banner.webp`;

  // Create and persist canonical backend trip before navigating
  const createCanonicalTrip = async (orig: string, dest: string, bgt: number, travs: number, dys: number) => {
    const slug = dest.toLowerCase().replace(/\s+/g, '-');
    let canonicalId = `trip_${orig.slice(0, 3).toLowerCase()}_${slug.slice(0, 3).toLowerCase()}_${Date.now().toString(36)}`;
    try {
      const resp = await fetch('http://localhost:8000/api/trips/plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          origin: orig,
          destination: dest,
          budget_inr: bgt,
          travelers_count: travs,
          user_id: user?.uid || 'demo-traveler-001',
          start_date: '2026-11-01',
          end_date: '2026-11-03'
        })
      });
      if (resp.ok) {
        const data = await resp.json();
        if (data?.trip_id) {
          canonicalId = data.trip_id;
        }
      }
    } catch (e) {
      console.warn('Backend unavailable during direct plan, using canonical fallback:', e);
    }

    updateTrip({
      id: canonicalId,
      backendTripId: canonicalId,
      origin: orig,
      destination: dest,
      days: dys,
      travellers: travs,
      totalBudget: bgt,
      status: 'draft',
      selections: {
        transport: null,
        stay: null,
        localTravel: [],
        experiences: [],
        foodPerPersonPerDay: 400
      }
    });

    return slug;
  };

  // Submit from typed textarea
  const handleTypedSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!typedPrompt.trim()) return;

    const parsed = parseTripIntake(typedPrompt, currentTrip.origin || 'Hyderabad');

    // Check if clarification is genuinely necessary
    const hasAmbiguity = Boolean(
      (parsed.clarifications.travellers && !parsed.travellers) ||
      (parsed.clarifications.budget && !parsed.budget && !parsed.approximateBudget) ||
      parsed.clarifications.destination ||
      parsed.isUnsupportedDestination ||
      !parsed.destination
    );

    if (hasAmbiguity) {
      setParsedIntake(parsed);
      setShowConfirmSheet(true);
    } else {
      // Direct planning flow: all details are clear and complete
      const origin = parsed.origin || currentTrip.origin || 'Hyderabad';
      const destination = parsed.destination || 'Mumbai';
      const days = parsed.days || 3;
      const travellers = parsed.travellers || parsed.adults || 2;
      const budget = parsed.budget || parsed.approximateBudget || 15000;

      const destSlug = await createCanonicalTrip(origin, destination, budget, travellers, days);
      navigate(`/app/plan/${destSlug}`);
    }
  };

  // Open confirm sheet empty
  const handleOpenFillDetails = (e: React.MouseEvent) => {
    e.preventDefault();
    setParsedIntake(null);
    setShowConfirmSheet(true);
  };

  // Handle plan submit from Alexa Voice Panel
  const handleVoicePlan = async (transcript: string) => {
    setShowVoicePanel(false);
    setTypedPrompt(transcript);
    const parsed = parseTripIntake(transcript, currentTrip.origin || 'Hyderabad');

    const hasAmbiguity = Boolean(
      (parsed.clarifications.travellers && !parsed.travellers) ||
      (parsed.clarifications.budget && !parsed.budget && !parsed.approximateBudget) ||
      parsed.clarifications.destination ||
      parsed.isUnsupportedDestination ||
      !parsed.destination
    );

    if (hasAmbiguity) {
      setParsedIntake(parsed);
      setShowConfirmSheet(true);
    } else {
      const origin = parsed.origin || currentTrip.origin || 'Hyderabad';
      const destination = parsed.destination || 'Mumbai';
      const days = parsed.days || 3;
      const travellers = parsed.travellers || parsed.adults || 2;
      const budget = parsed.budget || parsed.approximateBudget || 15000;

      const slug = destination.toLowerCase().replace(/\s+/g, '-');
      let canonicalId = `trip_${origin.slice(0, 3).toLowerCase()}_${slug.slice(0, 3).toLowerCase()}_${Date.now().toString(36)}`;
      try {
        const resp = await fetch('http://localhost:8000/api/trips/plan', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            origin,
            destination,
            budget_inr: budget,
            travelers_count: travellers,
            user_id: user?.uid || 'demo-traveler-001',
            start_date: '2026-11-01',
            end_date: '2026-11-03'
          })
        });
        if (resp.ok) {
          const data = await resp.json();
          if (data?.trip_id) canonicalId = data.trip_id;
        }
      } catch (e) {}

      updateTrip({
        id: canonicalId,
        backendTripId: canonicalId,
        origin,
        destination,
        days,
        travellers,
        totalBudget: budget,
        status: 'draft',
        selections: {
          transport: null,
          stay: null,
          localTravel: [],
          experiences: [],
          foodPerPersonPerDay: 400
        }
      });

      navigate(`/app/plan/${slug}`);
    }
  };

  const handleQuickDestination = async (destId: string) => {
    const d = SUPPORTED_CITIES.find((item) => item.id === destId);
    if (d) {
      const origin = currentTrip.origin || 'Hyderabad';
      const destination = d.name;
      const slug = destination.toLowerCase().replace(/\s+/g, '-');
      let canonicalId = `trip_${origin.slice(0, 3).toLowerCase()}_${slug.slice(0, 3).toLowerCase()}_${Date.now().toString(36)}`;
      try {
        const resp = await fetch('http://localhost:8000/api/trips/plan', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            origin,
            destination,
            budget_inr: 15000,
            travelers_count: 2,
            user_id: user?.uid || 'demo-traveler-001',
            start_date: '2026-11-01',
            end_date: '2026-11-03'
          })
        });
        if (resp.ok) {
          const data = await resp.json();
          if (data?.trip_id) canonicalId = data.trip_id;
        }
      } catch (e) {}

      updateTrip({
        id: canonicalId,
        backendTripId: canonicalId,
        origin,
        destination,
        days: d.defaultDays || 3,
        travellers: 2,
        totalBudget: 15000,
        status: 'draft',
        selections: {
          transport: null,
          stay: null,
          localTravel: [],
          experiences: [],
          foodPerPersonPerDay: 400
        }
      });
      navigate(`/app/plan/${slug}`);
    }
  };

  return (
    <div className="font-sans">
      {/* 1. Full-Width 340px Destination Banner */}
      <div className="relative h-[340px] w-full overflow-hidden bg-ink select-none">
        <img
          src={bannerImgPath}
          alt={currentTrip.destination || 'Destination'}
          width={1600}
          height={685}
          className="absolute inset-0 w-full h-full object-cover"
          style={{ backgroundColor: imageColors[`dest-${destSlug}-banner.webp`] || '#101B2B' }}
        />
        {/* Ink overlay for guaranteed contrast */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#0B1B2B]/90 via-[#0B1B2B]/75 to-[#0B1B2B]/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-cream via-cream/20 to-transparent pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-full flex flex-col justify-center relative z-10 text-paper pb-14">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-marigold mb-2">
            <span className="w-2 h-2 rounded-full bg-teal animate-pulse" />
            <span>Active Itinerary · {currentTrip.origin} → {currentTrip.destination}</span>
          </div>
          <h1 className="font-display text-3xl sm:text-4xl md:text-5xl font-semibold tracking-tight text-paper">
            {getGreeting()}
          </h1>
          <p className="text-sm md:text-base text-cream/90 max-w-xl mt-2 leading-relaxed">
            Where would you like to travel next? Your entire journey coordinates within one budget.
          </p>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8 pb-16">
        
        {/* 2. "Plan a trip" Card (Overlaps Banner by 56px) */}
        <div className="relative z-20 -mt-14 bg-paper border border-line rounded-card p-6 md:p-8 shadow-floating space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-marigold flex items-center justify-center text-marigold-ink font-semibold">
                <Compass className="w-4 h-4" />
              </div>
              <div>
                <h2 className="font-display text-base font-semibold text-ink leading-tight">
                  Plan a trip
                </h2>
                <p className="text-xs text-ink-3">Describe your journey or enter details</p>
              </div>
            </div>
            <button
              onClick={handleOpenFillDetails}
              className="text-xs font-semibold text-marigold-ink hover:text-ink underline underline-offset-4 cursor-pointer"
            >
              Or fill details
            </button>
          </div>

          <form onSubmit={handleTypedSubmit} className="space-y-3">
            <div className="relative bg-cream rounded-btn border border-line p-2 focus-within:border-marigold transition-colors">
              <textarea
                value={typedPrompt}
                onChange={(e) => setTypedPrompt(e.target.value)}
                placeholder="e.g. Plan a trip to Mumbai for 3 days, 5 people, budget ₹60,000"
                rows={2}
                className="w-full bg-transparent p-2 text-sm text-ink placeholder:text-ink-3 focus:outline-none resize-none"
              />
              <div className="flex items-center justify-between pt-1 px-1 border-t border-line/50">
                <span className="text-[11px] text-ink-3">
                  Parsed strictly without guessing numbers
                </span>
                <button
                  type="submit"
                  disabled={!typedPrompt.trim()}
                  className={`px-5 py-2 rounded-btn font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                    typedPrompt.trim()
                      ? 'bg-marigold hover:bg-marigold-hover text-marigold-ink shadow-2xs'
                      : 'bg-line text-ink-3 cursor-not-allowed opacity-50'
                  }`}
                >
                  <span>Plan</span>
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </form>

          {/* Quick suggestions */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="text-ink-3 font-medium text-[11px]">Popular prompts:</span>
            {[
              'Plan a trip to Mumbai for 3 days, 5 to 6 members, budget ₹60,000',
              'Plan a weekend in Jaipur for 2 under ₹15,000',
              'Plan a trip to Goa for 4 days with friends, budget ₹40,000'
            ].map((chip, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setTypedPrompt(chip)}
                className="px-3 py-1 bg-cream hover:bg-cream-2 border border-line rounded-full text-ink-2 hover:text-ink transition-colors cursor-pointer text-[11px]"
              >
                {chip}
              </button>
            ))}
          </div>
        </div>

        {/* 3. "Talk to Alexa" Card (Separate, Full Width, Between Plan and Your Trip) */}
        <div className="bg-gradient-to-r from-[#0B1B2B] to-[#162738] text-cream border border-line/40 rounded-card p-6 md:p-7 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="flex items-start sm:items-center gap-4">
            <div className="relative flex-shrink-0">
              <div className="w-12 h-12 rounded-full bg-marigold flex items-center justify-center text-marigold-ink shadow-md">
                <Mic className="w-6 h-6 animate-pulse" />
              </div>
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-teal border-2 border-ink animate-ping" />
            </div>

            <div>
              <h2 className="font-display text-lg font-semibold text-paper leading-tight">
                Talk to Alexa
              </h2>
              <p className="text-xs sm:text-sm text-cream/80 mt-0.5 leading-relaxed">
                Describe your trip. We'll write what you say and plan it for you.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setShowVoicePanel(true)}
            className="px-6 py-3 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs sm:text-sm rounded-btn transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer self-start sm:self-center shrink-0"
          >
            <Mic className="w-4 h-4" />
            <span>Start talking</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* 4. Your Trip */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl font-semibold text-ink">Your trip</h2>
            <span className="text-xs text-ink-3 font-mono">Reference: {currentTrip.id}</span>
          </div>

          <div className="bg-paper border border-line rounded-card p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2.5">
                <span className="px-2.5 py-0.5 bg-teal/10 text-teal text-xs font-semibold rounded-full border border-teal/20">
                  {budget.status === 'within' && 'Within Budget'}
                  {budget.status === 'using_buffer' && 'Using Buffer'}
                  {budget.status === 'over' && 'Over Budget'}
                </span>
                <span className="text-xs text-ink-3">
                  {currentTrip.days} Days · {currentTrip.travellers} Travellers
                </span>
              </div>

              <h3 className="font-display text-2xl font-semibold text-ink">
                {currentTrip.destination} Journey
              </h3>

              <p className="text-xs text-ink-2">
                From {currentTrip.origin} · Planned {formatINR(budget.totalCost)} of {formatINR(budget.totalBudget)} budget.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <button
                onClick={() => navigate('/app/rescue')}
                className="px-4 py-2.5 bg-cream hover:bg-cream-2 border border-line text-xs font-semibold rounded-btn text-ink transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <span>Journey Rescue</span>
              </button>
              <button
                onClick={() => navigate(`/app/plan/${currentTrip.id}`)}
                className="px-5 py-2.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-colors shadow-2xs cursor-pointer flex items-center justify-center gap-2"
              >
                <span>Open trip</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* 5. Inspirational Destinations */}
        <div className="space-y-4">
          <div>
            <h2 className="font-display text-xl font-semibold text-ink">Destinations</h2>
            <p className="text-xs text-ink-2">Calibrated Indian routes with verified coordinates, attractions, and boutique stays.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {SUPPORTED_CITIES.map((dest) => {
              const cardImgName = dest.cardImage.replace('/images/', '');
              return (
                <div
                  key={dest.id}
                  className="group bg-paper border border-line rounded-card overflow-hidden shadow-2xs hover:shadow-md transition-all flex flex-col"
                >
                  <div
                    className="relative h-44 overflow-hidden"
                    style={{ backgroundColor: imageColors[cardImgName] || '#182028' }}
                  >
                    <img
                      src={dest.cardImage}
                      alt={dest.name}
                      width={900}
                      height={675}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />
                    <div className="absolute top-2.5 right-2.5 px-2 py-0.5 bg-ink/80 text-cream text-[11px] font-medium rounded-full">
                      {dest.defaultDays} Days
                    </div>
                  </div>

                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-display text-lg font-semibold text-ink">{dest.name}</h3>
                        <span className="text-[11px] font-mono text-teal font-medium">{dest.state}</span>
                      </div>
                      <p className="text-xs text-ink-2 line-clamp-2 leading-relaxed mb-4">
                        {dest.description}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-line flex items-center justify-between">
                      <div className="text-xs font-semibold text-ink-3">
                        {dest.attractions.length} Attractions
                      </div>
                      <button
                        onClick={() => handleQuickDestination(dest.id)}
                        className="px-3.5 py-1.5 bg-cream hover:bg-marigold text-ink hover:text-marigold-ink border border-line hover:border-marigold text-xs font-semibold rounded-btn transition-colors cursor-pointer"
                      >
                        Plan this trip
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Confirm Trip Sheet */}
      <ConfirmTripSheet
        isOpen={showConfirmSheet}
        onClose={() => {
          setShowConfirmSheet(false);
          setParsedIntake(null);
        }}
        onSuccess={() => {
          setShowConfirmSheet(false);
          setParsedIntake(null);
          setTypedPrompt('');
        }}
        parsedIntake={parsedIntake}
        defaultOrigin={currentTrip.origin || 'Hyderabad'}
      />

      {/* Focused Alexa Voice Panel */}
      <AlexaVoicePanel
        isOpen={showVoicePanel}
        onClose={() => setShowVoicePanel(false)}
        onPlan={handleVoicePlan}
      />
    </div>
  );
}
