import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Mic,
  Send,
  Volume2,
  VolumeX,
  Sparkles,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  RotateCcw,
  Compass,
  Calendar,
  Users,
  Settings2
} from 'lucide-react';
import { getAlexaClient } from '../../lib/alexa/client';
import { AlexaReply, ApprovalCardPayload, BudgetCardPayload, OptionPickerPayload } from '../../lib/alexa/types';
import { useTrip } from '../../context/TripContext';
import { useAuth } from '../../context/AuthContext';
import { formatINR } from '../../lib/budget';
import { sanitizeSpeechText } from '../../lib/alexa/speechSanitizer';
import { voiceService } from '../../lib/alexa/voiceService';
import VoiceSettingsModal from '../../components/app/VoiceSettingsModal';

export default function AlexaPage() {
  const navigate = useNavigate();
  const { currentTrip, applyPatch, budget } = useTrip();
  const { user } = useAuth();

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'init-1',
      sender: 'alexa',
      text: `Hello! I'm your Plan My Trip companion. We currently have an active itinerary for ${currentTrip.destination} with a budget ceiling of ${formatINR(currentTrip.totalBudget)}. How can I assist you?`,
      timestamp: 'Just now'
    }
  ]);

  const [inputText, setInputText] = useState('');
  const [voiceState, setVoiceState] = useState<'idle' | 'listening' | 'thinking' | 'speaking'>('idle');
  const [voiceAudioEnabled, setVoiceAudioEnabled] = useState(false);
  const [showVoiceSettings, setShowVoiceSettings] = useState(false);
  const [micNotice, setMicNotice] = useState<string | null>(null);
  const [showToolsForMsg, setShowToolsForMsg] = useState<Record<string, boolean>>({});

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const isSendingRef = useRef(false);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, voiceState]);

  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-IN';

      recognition.onstart = () => {
        setMicNotice(null);
        setVoiceState('listening');
      };
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) handleSendMessage(transcript);
      };
      recognition.onerror = (event: any) => {
        setVoiceState('idle');
        if (event?.error === 'aborted' || event?.error === 'no-speech') {
          return;
        }
        if (event?.error === 'not-allowed' || event?.error === 'service-not-allowed') {
          setMicNotice('Microphone access was denied. Please allow microphone access or use text input.');
        } else {
          setMicNotice(`Voice input notice (${event?.error || 'interrupted'}). You can type below.`);
        }
      };
      recognition.onend = () => {
        if (voiceState === 'listening') setVoiceState('idle');
      };

      recognitionRef.current = recognition;
    }
  }, []);

  const toggleMic = () => {
    setMicNotice(null);
    if (!recognitionRef.current) {
      setMicNotice('Speech recognition is not supported in this browser. Please use text input.');
      return;
    }
    if (voiceState === 'listening') {
      recognitionRef.current.stop();
      setVoiceState('idle');
    } else {
      try {
        recognitionRef.current.start();
      } catch (err: any) {
        console.error('Mic start error:', err);
        setMicNotice('Could not start microphone. You can type your request directly.');
      }
    }
  };

  const speakText = (text: string) => {
    if (!voiceAudioEnabled) return;
    voiceService.speak(text, {
      onStart: () => setVoiceState('speaking'),
      onEnd: () => setVoiceState('idle'),
      onError: () => setVoiceState('idle')
    });
  };

  const handleSendMessage = async (textToSend?: string) => {
    if (isSendingRef.current) return;
    const text = (textToSend || inputText).trim();
    if (!text) return;
    isSendingRef.current = true;

    setInputText('');
    const userMsgId = `user-${Date.now()}`;
    setMessages((prev) => [
      ...prev,
      {
        id: userMsgId,
        sender: 'user',
        text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);

    setVoiceState('thinking');

    try {
      const client = getAlexaClient();
      const isKnownTripId = Boolean(
        currentTrip.backendTripId?.startsWith('trip_') ||
        currentTrip.id?.startsWith('trip_') ||
        currentTrip.id?.startsWith('PMT-') ||
        currentTrip.id?.startsWith('DEMO-')
      );
      const canonicalId = currentTrip.backendTripId || (isKnownTripId ? currentTrip.id : undefined);
      const reply = await client.send(text, {
        userId: user?.uid || 'demo-traveler-001',
        tripId: canonicalId,
        draft: currentTrip
      });

      if (reply.tripPatch) {
        applyPatch(reply.tripPatch);
      }

      const alexaMsgId = `alexa-${Date.now()}`;
      setMessages((prev) => [
        ...prev,
        {
          id: alexaMsgId,
          sender: 'alexa',
          text: reply.text,
          reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);

      if (voiceAudioEnabled) {
        speakText(reply.text);
      } else {
        setVoiceState('idle');
      }
    } catch (err) {
      console.error('Alexa error:', err);
      setMessages((prev) => [
        ...prev,
        {
          id: `alexa-${Date.now()}`,
          sender: 'alexa',
          text: "I encountered an issue processing that request. Let's try again.",
          timestamp: 'Now'
        }
      ]);
      setVoiceState('idle');
    } finally {
      isSendingRef.current = false;
    }
  };

  const handleApprove = (approval: ApprovalCardPayload, reply?: AlexaReply) => {
    if (reply?.tripPatch) {
      applyPatch(reply.tripPatch);
    }
    setMessages((prev) => [
      ...prev,
      {
        id: `sys-${Date.now()}`,
        sender: 'alexa',
        text: `✓ Approved: ${approval.title} has been applied to your trip.`,
        timestamp: 'Just now'
      }
    ]);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 font-sans">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start h-[calc(100vh-8.5rem)]">
        {/* Left Column (8 cols): Conversation Canvas */}
        <div className="lg:col-span-8 bg-paper border border-line rounded-card flex flex-col h-full shadow-sm overflow-hidden">
          {/* Header */}
          <div className="px-6 py-4 border-b border-line bg-cream/60 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${
                  voiceState === 'listening'
                    ? 'bg-marigold text-marigold-ink ring-4 ring-marigold/30'
                    : voiceState === 'thinking'
                    ? 'bg-ink text-cream animate-pulse'
                    : voiceState === 'speaking'
                    ? 'bg-teal text-paper ring-4 ring-teal/30'
                    : 'bg-marigold/20 text-marigold-ink'
                }`}
              >
                <Sparkles className="w-4.5 h-4.5" />
              </div>
              <div>
                <h2 className="font-display text-base font-semibold text-ink">
                  Alexa Full-Page Assistant
                </h2>
                <div className="text-[11px] text-ink-3">
                  {voiceState === 'listening' && 'Listening to your voice...'}
                  {voiceState === 'thinking' && 'Evaluating budget and tools...'}
                  {voiceState === 'speaking' && 'Speaking response...'}
                  {voiceState === 'idle' && 'Ready to plan or adjust'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {voiceState === 'speaking' && (
                <button
                  type="button"
                  onClick={() => {
                    voiceService.stopSpeaking();
                    setVoiceState('idle');
                  }}
                  className="px-2.5 py-1.5 bg-ruby-bg text-ruby border border-ruby/30 rounded text-xs font-semibold flex items-center gap-1 animate-pulse cursor-pointer"
                  title="Stop speaking"
                >
                  <span>Stop Speaking</span>
                </button>
              )}
              <button
                onClick={() => setShowVoiceSettings(true)}
                title="Voice assistant settings"
                className="p-2 rounded-btn border border-line bg-paper hover:bg-cream text-ink-2 hover:text-ink text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Settings2 className="w-4 h-4" />
                <span className="hidden sm:inline">Voice Settings</span>
              </button>
              <button
                onClick={() => setVoiceAudioEnabled(!voiceAudioEnabled)}
                title={voiceAudioEnabled ? 'Mute audio' : 'Enable voice audio'}
                className={`p-2 rounded-btn border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  voiceAudioEnabled ? 'bg-teal/10 border-teal/30 text-teal' : 'bg-paper border-line text-ink-3'
                }`}
              >
                {voiceAudioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                <span className="hidden sm:inline">{voiceAudioEnabled ? 'Voice On' : 'Voice Off'}</span>
              </button>
            </div>
          </div>

          {/* Transcript Feed */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-cream/20">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl p-4 text-sm ${
                    msg.sender === 'user'
                      ? 'bg-ink text-cream rounded-tr-xs'
                      : 'bg-paper text-ink border border-line rounded-tl-xs shadow-2xs'
                  }`}
                >
                  <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>

                  {/* Cards */}
                  {msg.reply?.cards && msg.reply.cards.length > 0 && (
                    <div className="mt-3 space-y-2 pt-2 border-t border-line/60">
                      {msg.reply.cards.map((card, cIdx) => {
                        if (card.type === 'budget_summary') {
                          const bCard = card as BudgetCardPayload;
                          return (
                            <div key={cIdx} className="bg-cream p-3 rounded-xl border border-line text-xs space-y-1">
                              <div className="flex justify-between font-semibold text-ink">
                                <span>{bCard.title || 'Budget Snapshot'}</span>
                                <span className="font-mono text-teal">
                                  {formatINR(bCard.budget.totalCost)} / {formatINR(bCard.budget.totalBudget)}
                                </span>
                              </div>
                              <div className="flex justify-between text-[11px] text-ink-3 font-mono">
                                <span>Safe: {formatINR(bCard.budget.safeToSpend)}</span>
                                <span>Buffer: {formatINR(bCard.budget.bufferRemaining)}</span>
                              </div>
                            </div>
                          );
                        }

                        if (card.type === 'approval_card') {
                          const approval = card as ApprovalCardPayload;
                          return (
                            <div key={cIdx} className="bg-amber/10 border border-amber/30 p-3.5 rounded-xl text-xs space-y-2">
                              <div className="flex items-center gap-1.5 font-semibold text-amber">
                                <AlertTriangle className="w-3.5 h-3.5" />
                                <span>{approval.title}</span>
                              </div>
                              <p className="text-ink-2 text-[11px]">{approval.explanation}</p>
                              <div className="flex justify-between font-mono text-[11px] text-ink">
                                <span>Cost: {approval.extraCostLabel}</span>
                                <span>Action: {approval.recipient}</span>
                              </div>
                              <div className="grid grid-cols-2 gap-2 pt-1">
                                <button
                                  onClick={() => handleSendMessage(`Approve action ${approval.actionId}`)}
                                  className="py-1.5 px-3 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold rounded-btn transition-colors cursor-pointer flex items-center justify-center gap-1 text-xs"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span>Approve</span>
                                </button>
                                <button
                                  onClick={() => handleSendMessage(`Reject action ${approval.actionId}`)}
                                  className="py-1.5 px-3 bg-cream hover:bg-cream-2 border border-line text-ink-2 hover:text-ink font-semibold rounded-btn transition-colors cursor-pointer flex items-center justify-center gap-1 text-xs"
                                >
                                  <XCircle className="w-3.5 h-3.5" />
                                  <span>Reject</span>
                                </button>
                              </div>
                            </div>
                          );
                        }

                        if (card.type === 'option_picker') {
                          const picker = card as OptionPickerPayload;
                          return (
                            <div key={cIdx} className="bg-paper border border-line rounded-xl p-3.5 text-xs space-y-2">
                              <div className="flex items-center justify-between border-b border-line pb-1.5">
                                <span className="font-semibold text-ink">{picker.title}</span>
                                <span className="text-[10px] text-teal font-mono uppercase bg-teal/10 px-1.5 py-0.5 rounded">
                                  {picker.category}
                                </span>
                              </div>
                              <div className="space-y-2">
                                {picker.options?.map((opt) => (
                                  <div key={opt.id} className="p-2.5 bg-cream/60 rounded-lg border border-line/60 flex items-center justify-between gap-2">
                                    <div className="space-y-0.5 flex-1 min-w-0">
                                      <div className="flex items-center gap-1.5">
                                        <span className="font-semibold text-ink text-xs truncate">{opt.title}</span>
                                        {opt.tag && (
                                          <span className="text-[9px] bg-teal/15 text-teal px-1 rounded">{opt.tag}</span>
                                        )}
                                      </div>
                                      {opt.details && <p className="text-[11px] text-ink-3 truncate">{opt.details}</p>}
                                      {opt.terms && <p className="text-[10px] text-ink-3 italic truncate">{opt.terms}</p>}
                                    </div>
                                    <div className="flex items-center gap-2 shrink-0">
                                      <span className="font-mono text-ink font-bold text-xs">{opt.priceLabel}</span>
                                      <button
                                        type="button"
                                        onClick={() => handleSendMessage(`Select ${picker.category} ${opt.id}`)}
                                        className="px-2.5 py-1 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold rounded-btn text-xs cursor-pointer shadow-2xs"
                                      >
                                        Select
                                      </button>
                                    </div>
                                  </div>
                                ))}
                              </div>
                              <p className="text-[10px] text-ink-3 italic">Sample options · Selection updates trip draft without auto-booking</p>
                            </div>
                          );
                        }

                        return null;
                      })}
                    </div>
                  )}

                  {/* Tools */}
                  {msg.reply?.toolCalls && msg.reply.toolCalls.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-line/40 text-[10px] font-mono text-ink-3">
                      <span>Tools: </span>
                      {msg.reply.toolCalls.map((t, idx) => (
                        <span key={idx} className="mr-2 text-teal font-medium">
                          {t.name}()
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-1.5 mt-1 px-1">
                  <span className="text-[10px] text-ink-3">{msg.timestamp}</span>
                  {msg.sender === 'alexa' && (
                    <button
                      type="button"
                      onClick={() => speakText(msg.text)}
                      className="p-0.5 text-ink-3 hover:text-ink cursor-pointer"
                      title="Replay speech"
                      aria-label="Replay speech"
                    >
                      <Volume2 className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Composer */}
          <div className="p-4 bg-paper border-t border-line space-y-2">
            <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
              <button
                onClick={() => handleSendMessage('Plan 2 days in Delhi under ₹15,000')}
                className="px-2.5 py-1 bg-cream hover:bg-cream-2 border border-line rounded-full text-ink-2 whitespace-nowrap cursor-pointer"
              >
                Delhi under ₹15k
              </button>
              <button
                onClick={() => handleSendMessage('Add Old Delhi culinary food trail')}
                className="px-2.5 py-1 bg-cream hover:bg-cream-2 border border-line rounded-full text-ink-2 whitespace-nowrap cursor-pointer"
              >
                Add food trail
              </button>
              <button
                onClick={() => handleSendMessage('Train 12015 is delayed by 45 minutes')}
                className="px-2.5 py-1 bg-amber/10 hover:bg-amber/20 border border-amber/30 rounded-full text-amber whitespace-nowrap cursor-pointer"
              >
                45m delay scenario
              </button>
            </div>

            {micNotice && (
              <div className="p-2.5 bg-amber/10 border border-amber/30 rounded-lg text-xs text-amber flex items-center justify-between">
                <span>{micNotice}</span>
                <button
                  type="button"
                  onClick={() => setMicNotice(null)}
                  className="text-amber hover:text-ink ml-2 cursor-pointer text-sm"
                >
                  ×
                </button>
              </div>
            )}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2"
            >
              <button
                type="button"
                onClick={toggleMic}
                className={`p-3 rounded-btn border transition-all cursor-pointer ${
                  voiceState === 'listening'
                    ? 'bg-marigold text-marigold-ink border-marigold ring-2 ring-marigold/30'
                    : 'bg-cream hover:bg-cream-2 border-line text-ink'
                }`}
              >
                <Mic className="w-4 h-4" />
              </button>

              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Talk to Alexa or enter instructions..."
                className="flex-1 bg-cream border border-line rounded-btn px-4 py-2.5 text-xs md:text-sm text-ink placeholder:text-ink-3 focus:outline-none focus:border-marigold"
              />

              <button
                type="submit"
                disabled={!inputText.trim()}
                className="px-5 py-2.5 bg-marigold hover:bg-marigold-hover disabled:opacity-40 text-marigold-ink font-semibold text-xs rounded-btn transition-colors shadow-2xs cursor-pointer flex items-center gap-1.5"
              >
                <span>Send</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>

        {/* Right Column (4 cols): What Alexa Knows */}
        <div className="lg:col-span-4 bg-paper border border-line rounded-card p-6 shadow-sm space-y-6 h-full overflow-y-auto">
          <div>
            <div className="text-[11px] font-mono uppercase tracking-wider text-ink-3">Session State</div>
            <h3 className="font-display text-lg font-semibold text-ink mt-0.5">What Alexa Knows</h3>
          </div>

          <div className="space-y-4 text-xs">
            {/* Trip Specs */}
            <div className="p-3.5 bg-cream rounded-xl border border-line space-y-2">
              <div className="flex justify-between font-semibold text-ink">
                <span>Destination</span>
                <span>{currentTrip.destination}</span>
              </div>
              <div className="flex justify-between text-ink-2">
                <span>Origin City</span>
                <span>{currentTrip.origin}</span>
              </div>
              <div className="flex justify-between text-ink-2">
                <span>Duration</span>
                <span>{currentTrip.days} Days / 2 Nights</span>
              </div>
              <div className="flex justify-between text-ink-2">
                <span>Travellers</span>
                <span>{currentTrip.travellers} Adults</span>
              </div>
            </div>

            {/* Live Financial State */}
            <div className="p-3.5 bg-cream rounded-xl border border-line space-y-2">
              <div className="flex justify-between font-semibold text-ink">
                <span>Total Ceiling</span>
                <span className="font-mono">{formatINR(budget.totalBudget)}</span>
              </div>
              <div className="flex justify-between text-ink-2">
                <span>Allocated</span>
                <span className="font-mono">{formatINR(budget.totalCost)}</span>
              </div>
              <div className="flex justify-between text-teal font-semibold">
                <span>Safe to Spend</span>
                <span className="font-mono">{formatINR(budget.safeToSpend)}</span>
              </div>
              <div className="flex justify-between text-ink-3">
                <span>Reserved Buffer (8%)</span>
                <span className="font-mono">{formatINR(budget.bufferRemaining)}</span>
              </div>
            </div>

            {/* Confirmed Selections */}
            <div className="space-y-2">
              <span className="font-semibold text-ink text-[11px] uppercase tracking-wider block">
                Committed Segments
              </span>
              <div className="p-2.5 bg-paper rounded border border-line space-y-1">
                <div className="font-medium text-ink">Transit:</div>
                <div className="text-ink-2 text-[11px] truncate">
                  {currentTrip.selections.transport?.title || 'None chosen'}
                </div>
              </div>
              <div className="p-2.5 bg-paper rounded border border-line space-y-1">
                <div className="font-medium text-ink">Stay:</div>
                <div className="text-ink-2 text-[11px] truncate">
                  {currentTrip.selections.stay?.title || 'None chosen'}
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="pt-2 border-t border-line space-y-2">
              <button
                onClick={() => navigate('/app/planner')}
                className="w-full py-2.5 bg-ink text-cream hover:bg-ink-2 rounded-btn font-semibold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Open Visual Workspace</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <VoiceSettingsModal
        isOpen={showVoiceSettings}
        onClose={() => setShowVoiceSettings(false)}
      />
    </div>
  );
}
