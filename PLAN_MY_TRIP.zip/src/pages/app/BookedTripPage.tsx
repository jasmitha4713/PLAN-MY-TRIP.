import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useParams, Link, useSearchParams, useNavigate } from 'react-router-dom';
import {
  Calendar,
  Clock,
  MapPin,
  Users,
  CheckCircle2,
  AlertCircle,
  FileText,
  MessageSquare,
  CreditCard,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Send,
  Phone,
  HelpCircle,
  Printer,
  ChevronRight,
  RotateCcw,
  Loader2,
  Mic,
  Volume2,
  VolumeX,
  Square,
  Settings2
} from 'lucide-react';
import { useTrip } from '../../context/TripContext';
import { useAuth } from '../../context/AuthContext';
import { getAlexaClient } from '../../lib/alexa/client';
import { formatINR } from '../../lib/budget';
import { SUPPORTED_CITIES, findCityByName } from '../../data/destinations';
import { useAlexaVoice } from '../../lib/alexa/useAlexaVoice';
import AlexaMultimodalCards from '../../components/app/AlexaMultimodalCards';
import VoiceSettingsModal from '../../components/app/VoiceSettingsModal';
import imageColorsData from '../../data/imageColors.json';

const imageColors: Record<string, string> = imageColorsData;

type TripTab = 'itinerary' | 'bookings' | 'companion' | 'messages' | 'payments';

interface SimulatedMessage {
  id: string;
  timestamp: string;
  sender: 'User' | 'Alexa' | 'Vendor';
  recipient: string;
  vendorRole?: string;
  text: string;
  status: 'Drafted' | 'Sent' | 'Delivered' | 'Acknowledged' | 'Declined' | 'No reply';
  actionRequiresApproval?: boolean;
}

export default function BookedTripPage() {
  const { id: tripId } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { currentTrip, savedTrips, applyPatch, updateTrip } = useTrip();
  const { user } = useAuth();
  const paramTab = searchParams.get('tab') as TripTab | null;
  const [activeTab, setActiveTab] = useState<TripTab>(paramTab || 'itinerary');
  const [vendorNextReply, setVendorNextReply] = useState<'Accept' | 'Decline' | 'No reply'>('Accept');
  const [showDemoControls, setShowDemoControls] = useState(false);

  // Authoritative Backend Trip State
  const [backendTripData, setBackendTripData] = useState<any>(null);
  const [backendFetchFailed, setBackendFetchFailed] = useState(false);

  // Authoritative Trip Fetching Effect
  useEffect(() => {
    let isMounted = true;
    const fetchTrip = async () => {
      const targetQuery = tripId || 'PMT-0142';
      try {
        const resp = await fetch(`http://localhost:8000/api/trips/${targetQuery}`, {
          headers: { 'X-User-Id': user?.uid || 'demo-traveler-001' }
        });
        if (resp.ok) {
          const data = await resp.json();
          if (isMounted) {
            setBackendTripData(data);
            setBackendFetchFailed(false);
            const client = getAlexaClient();
            if ('setActiveTripId' in client) {
              (client as any).setActiveTripId(data.trip_id);
            }
          }
        } else {
          if (isMounted) {
            setBackendTripData(null);
            setBackendFetchFailed(true);
          }
        }
      } catch (e) {
        if (isMounted) {
          setBackendTripData(null);
          setBackendFetchFailed(true);
        }
      }
    };
    fetchTrip();
    return () => { isMounted = false; };
  }, [tripId, user?.uid]);

  // Active trip resolution
  const activeTrip = useMemo(() => {
    if (backendTripData) return backendTripData;
    if (tripId) {
      const found = savedTrips?.find(t => t.id === tripId || (t as any).backendTripId === tripId);
      if (found) return found;
      if (tripId === 'PMT-0142' || tripId === 'trip_del_jai_001' || tripId === 'trip_hyd_del_001') {
        return currentTrip;
      }
      return null;
    }
    return currentTrip;
  }, [backendTripData, tripId, savedTrips, currentTrip]);

  // Canonical Backend Trip ID resolution
  const canonicalTripId: string | null = useMemo(() => {
    if (backendTripData?.trip_id) return backendTripData.trip_id;
    if (tripId === 'PMT-0142') return 'trip_hyd_del_001';
    if (tripId === 'trip_del_jai_001') return 'trip_del_jai_001';
    if (tripId?.startsWith('trip_')) return tripId;
    if ((activeTrip as any)?.backendTripId?.startsWith('trip_')) {
      return (activeTrip as any).backendTripId;
    }
    if (activeTrip?.id?.startsWith('trip_')) {
      return activeTrip.id;
    }
    return null;
  }, [backendTripData, activeTrip, tripId]);

  // Destination resolution
  const destCityName = useMemo(() => {
    if (backendTripData?.destination) return backendTripData.destination;
    if (tripId === 'trip_del_jai_001') return 'Jaipur';
    if (tripId === 'PMT-0142') return 'New Delhi';
    if (tripId && findCityByName(tripId)) return findCityByName(tripId)!.name;
    if (activeTrip?.destination) return activeTrip.destination;
    return backendFetchFailed ? `Unregistered (${tripId})` : 'New Delhi';
  }, [backendTripData, tripId, activeTrip, backendFetchFailed]);

  const displayRef = useMemo(() => {
    return backendTripData?.display_id || backendTripData?.reference_id || canonicalTripId || tripId || 'PMT-0142';
  }, [backendTripData, canonicalTripId, tripId]);

  const destData = findCityByName(destCityName) || SUPPORTED_CITIES[0];
  const bannerImg = destData.bannerImage;

  // Interactive handler to switch trip cleanly
  const handleSwitchToActiveTrip = async (targetRef = 'PMT-0142') => {
    try {
      const resp = await fetch(`http://localhost:8000/api/trips/${targetRef}`, {
        headers: { 'X-User-Id': user?.uid || 'demo-traveler-001' }
      });
      if (resp.ok) {
        const data = await resp.json();
        setBackendTripData(data);
        setBackendFetchFailed(false);
        updateTrip({
          id: data.display_id || data.trip_id,
          backendTripId: data.trip_id,
          origin: data.origin,
          destination: data.destination,
          totalBudget: data.total_budget_inr,
          travellers: data.travelers_count,
          status: data.status,
        });
        const client = getAlexaClient();
        if ('setActiveTripId' in client) {
          (client as any).setActiveTripId(data.trip_id);
        }
        navigate(`/app/trip/${data.display_id || data.trip_id}`);
      } else {
        navigate(`/app/trip/${targetRef}`);
      }
    } catch (e) {
      navigate(`/app/trip/${targetRef}`);
    }
  };

  // Companion Chat state
  const [companionInput, setCompanionInput] = useState('');
  const [isSending, setIsSending] = useState(false);
  const isSendingRef = useRef(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const initialPromptHandled = useRef(false);

  // Full Alexa Multimodal Voice Interaction Loop
  const {
    voiceState,
    voiceAudioEnabled,
    toggleVoiceAudio,
    isSpeechSupported,
    interimTranscript,
    editableTranscript,
    errorMessage: voiceError,
    startListening,
    stopListening,
    toggleListening,
    clearTranscript,
    speakText,
    stopSpeaking,
    replayMessage
  } = useAlexaVoice({
    lang: 'en-IN',
    autoSpeak: true,
    continuousConversationalMode: true,
    onTranscriptReady: (spokenText) => {
      if (!spokenText.trim() || isSendingRef.current) return;
      handleCompanionSendMessage(spokenText.trim());
    }
  });

  const [dismissedVoiceError, setDismissedVoiceError] = useState(false);
  const [showVoiceSettings, setShowVoiceSettings] = useState(false);

  // Live transcript review & editing
  useEffect(() => {
    if (editableTranscript) {
      setCompanionInput(editableTranscript);
      setDismissedVoiceError(false);
    }
  }, [editableTranscript]);

  const [chatMessages, setChatMessages] = useState<Array<{
    id: string;
    sender: 'user' | 'companion' | 'alexa';
    text: string;
    time: string;
    cards?: any[];
    pendingApprovalAction?: {
      target: string;
      draftedMessage: string;
      status?: 'pending' | 'approved' | 'declined';
      onApprove: () => void;
      onDecline: () => void;
    };
  }>>([
    {
      id: 'msg-init-1',
      sender: 'companion',
      text: `Hello! I am your live companion for trip ${tripId || 'PMT-0142'} to ${destData.name}. I monitor your bookings, evaluate disruptions via MCP, and coordinate vendor adjustments with your explicit approval. How can I assist you?`,
      time: '10:00 AM'
    }
  ]);

  // Messages Log
  const [messageLogs, setMessageLogs] = useState<SimulatedMessage[]>([
    {
      id: 'log-001',
      timestamp: 'Today, 06:00 AM',
      sender: 'Vendor',
      recipient: 'Passenger',
      vendorRole: 'Indian Railways Express Duty Officer',
      text: 'Train 12004 Vande Bharat CC Platform 1 on time. Boarding begins at 06:00 AM.',
      status: 'Delivered'
    }
  ]);

  // Refund Records
  const [refunds, setRefunds] = useState<Array<{
    id: string;
    bookingId: string;
    provider: string;
    amount: number;
    reason: string;
    status: 'Requested' | 'Processing' | 'Credited';
    requestedAt: string;
  }>>([]);

  // Timings
  const [cabPickupTime, setCabPickupTime] = useState('09:30 PM');
  const hotelCutoffTime = '11:00 PM';

  // Auto-scroll companion messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, isSending]);

  // Main real companion message sender via MCP
  const handleCompanionSendMessage = async (textToSend?: string) => {
    if (isSendingRef.current) return;

    const text = (textToSend || companionInput).trim();
    if (!text) return;

    isSendingRef.current = true;
    setIsSending(true);

    setCompanionInput('');
    clearTranscript();
    const userMsgId = `usr-${Date.now()}`;
    const nowTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // 1. Wake phrase intercept ("Hello Alexa", "Hey Alexa", "Alexa")
    const wakeMatch = text.match(/^\s*(?:hello|hey|ok|okay)?\s*alexa\b[,:\s]*(.*)$/i);
    if (wakeMatch && !wakeMatch[1].trim()) {
      const alexaReplyId = `alx-${Date.now()}`;
      setChatMessages(prev => [
        ...prev,
        { id: userMsgId, sender: 'user', text, time: nowTime },
        { id: alexaReplyId, sender: 'companion', text: "I'm here. What can I help you with?", time: nowTime }
      ]);
      speakText("I'm here. What can I help you with?");
      isSendingRef.current = false;
      setIsSending(false);
      return;
    }

    setChatMessages(prev => [
      ...prev,
      { id: userMsgId, sender: 'user', text, time: nowTime }
    ]);

    try {
      const targetCanonicalId = canonicalTripId || (tripId === 'PMT-0142' ? 'trip_hyd_del_001' : null);
      if (!targetCanonicalId) {
        isSendingRef.current = false;
        setIsSending(false);
        const errReply = {
          id: `alx-${Date.now()}`,
          sender: 'alexa' as const,
          text: `Trip '${tripId}' is not registered in the backend trip repository. Please click 'Switch to Active Trip (PMT-0142 · New Delhi)' above to load your active booking, or plan a new trip.`,
          time: nowTime
        };
        setChatMessages(prev => [...prev, errReply]);
        speakText(errReply.text);
        return;
      }

      const client = getAlexaClient();
      const reply = await client.send(text, {
        userId: user?.uid || 'demo-traveler-001',
        tripId: targetCanonicalId,
        draft: backendTripData || activeTrip || ({ id: targetCanonicalId, backendTripId: targetCanonicalId } as any)
      });

      if (reply.tripPatch) {
        applyPatch(reply.tripPatch);
      }

      // Check for approval cards
      const alexaReplyId = `alx-${Date.now()}`;
      const approvalCard = reply.cards?.find(c => c.type === 'approval_card');
      let pendingApprovalAction: {
        target: string;
        draftedMessage: string;
        status?: 'pending' | 'approved' | 'declined';
        onApprove: () => void;
        onDecline: () => void;
      } | undefined = undefined;

      if (approvalCard) {
        const cardTitle = approvalCard.title || 'Recovery Action';
        const cardRecipient = approvalCard.recipient || 'Vendor Dispatch / Front Desk';
        const cardExplanation = approvalCard.explanation || '';
        const cardCost = approvalCard.extraCostLabel || (approvalCard.extraCost ? `₹${approvalCard.extraCost}` : '₹0');
        const actionId = approvalCard.actionId;

        pendingApprovalAction = {
          target: cardRecipient,
          draftedMessage: `${cardTitle} — ${cardExplanation} (Estimated Cost: ${cardCost})`,
          status: 'pending',
          onApprove: () => {
            setChatMessages(prev => prev.map(m => m.id === alexaReplyId && m.pendingApprovalAction ? {
              ...m,
              pendingApprovalAction: { ...m.pendingApprovalAction, status: 'approved' }
            } : m));
            handleCompanionSendMessage(actionId ? `Approve action ${actionId}` : 'Approve the recovery action I just reviewed');
          },
          onDecline: () => {
            setChatMessages(prev => prev.map(m => m.id === alexaReplyId && m.pendingApprovalAction ? {
              ...m,
              pendingApprovalAction: { ...m.pendingApprovalAction, status: 'declined' }
            } : m));
            handleCompanionSendMessage(actionId ? `Reject action ${actionId}` : 'Reject that action');
          }
        };

        setMessageLogs(prev => [
          ...prev,
          {
            id: `log-${Date.now()}`,
            timestamp: 'Just now',
            sender: 'Alexa',
            recipient: cardRecipient,
            vendorRole: 'Recovery Dispatch',
            text: `[Drafted for Approval] ${cardTitle}: ${cardExplanation}`,
            status: 'Drafted',
            actionRequiresApproval: true
          }
        ]);
      }

      if (reply.action?.status === 'confirmed') {
        setMessageLogs(prev => [
          ...prev,
          {
            id: `log-${Date.now()}`,
            timestamp: 'Just now',
            sender: 'Alexa',
            recipient: 'Vendor Network',
            vendorRole: 'Operations Dispatch',
            text: `[Executed] ${reply.action.label || reply.action.id}`,
            status: 'Acknowledged'
          }
        ]);
      }

      setChatMessages(prev => [
        ...prev,
        {
          id: alexaReplyId,
          sender: 'companion',
          text: reply.text,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          cards: reply.cards,
          pendingApprovalAction
        }
      ]);

      if (voiceAudioEnabled) {
        speakText(reply.text);
      }
    } catch (err: any) {
      console.error('Companion message error:', err);
      setChatMessages(prev => [
        ...prev,
        {
          id: `alx-err-${Date.now()}`,
          sender: 'companion',
          text: `I encountered an issue contacting the MCP assistant: ${err?.message || 'Connection error'}. Please verify the Alexa MCP server is running.`,
          time: 'Just now'
        }
      ]);
    } finally {
      isSendingRef.current = false;
      setIsSending(false);
    }
  };

  // Handle URL query parameter 'prompt' (e.g. redirected from Rescue page)
  useEffect(() => {
    const promptParam = searchParams.get('prompt');
    if (promptParam && !initialPromptHandled.current) {
      initialPromptHandled.current = true;
      setActiveTab('companion');
      handleCompanionSendMessage(promptParam);
    }
  }, [searchParams]);

  // Demo Scenarios triggered via explicit quick buttons
  const triggerScenarioS1 = () => {
    handleCompanionSendMessage('My friends arrived late, I need 30 more minutes before the driver comes.');
  };

  const triggerScenarioS3 = () => {
    handleCompanionSendMessage('What happens if my bus is cancelled?');
  };

  const handleDeclineMessage = () => {
    handleCompanionSendMessage('Reject that action');
  };

  const handleSendCustomText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!companionInput.trim() || isSendingRef.current) return;
    stopListening();
    clearTranscript();
    handleCompanionSendMessage();
  };

  return (
    <div className="min-h-screen bg-cream font-sans pb-24">
      
      {/* 1. TOP BANNER */}
      <div className="relative h-48 md:h-56 w-full bg-ink overflow-hidden">
        <img
          src={bannerImg}
          alt={destData.name}
          width={1600}
          height={685}
          className="absolute inset-0 w-full h-full object-cover"
          style={{ backgroundColor: imageColors[bannerImg.replace('/images/', '')] || '#0B1B2B' }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0B1B2B]/90 via-[#0B1B2B]/75 to-[#0B1B2B]/40" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-full flex flex-col justify-center relative z-10 text-paper">
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <span className="px-2.5 py-0.5 bg-amber/20 text-amber border border-amber/40 rounded-full text-xs font-semibold">
              Itinerary Drafted · Simulated Preview
            </span>
            <span className="px-2.5 py-0.5 bg-cream/15 text-cream border border-cream/30 rounded-full text-xs font-medium">
              Pending Explicit Checkout
            </span>
            <span className="text-xs text-cream/70 font-mono">
              Ref: {tripId || 'SIM-PMT-0142'}
            </span>
          </div>

          <h1 className="font-display text-2xl sm:text-3xl md:text-4xl font-semibold tracking-tight text-paper">
            {destData.name} Journey Hub
          </h1>

          <p className="text-xs sm:text-sm text-cream/90 mt-1 max-w-xl">
            {currentTrip.days} Days · {currentTrip.travellers} Travellers · All bookings coordinated with your live companion
          </p>
        </div>
      </div>

      {/* 2. TAB NAVIGATION BAR */}
      <div className="bg-paper border-b border-line sticky top-14 z-20 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between overflow-x-auto">
          <div className="flex items-center gap-1 sm:gap-2 text-xs font-semibold py-2">
            {[
              { id: 'itinerary', label: 'Itinerary' },
              { id: 'bookings', label: 'Bookings' },
              { id: 'companion', label: 'Companion (Alexa)' },
              { id: 'messages', label: `Messages (${messageLogs.length})` },
              { id: 'payments', label: 'Payments & Splits' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TripTab)}
                className={`px-3.5 py-2 rounded-btn transition-colors cursor-pointer whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-ink text-cream'
                    : 'text-ink-2 hover:text-ink hover:bg-cream'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Demo Controls Popover Toggle */}
          <div className="relative shrink-0">
            <button
              onClick={() => setShowDemoControls(!showDemoControls)}
              className="px-2.5 py-1 bg-amber/15 hover:bg-amber/25 border border-amber/30 rounded text-[11px] font-semibold text-amber flex items-center gap-1 cursor-pointer"
            >
              <span>Demo Reply: <strong>{vendorNextReply}</strong></span>
              <ChevronRight className="w-3 h-3" />
            </button>

            {showDemoControls && (
              <div className="absolute right-0 top-8 w-56 bg-paper border border-line rounded-xl shadow-floating p-3 z-30 space-y-2 text-xs text-ink">
                <span className="font-semibold block text-[11px] text-ink-3">
                  Simulate Next Vendor Reply:
                </span>
                {(['Accept', 'Decline', 'No reply'] as const).map(opt => (
                  <button
                    key={opt}
                    onClick={() => {
                      setVendorNextReply(opt);
                      setShowDemoControls(false);
                    }}
                    className={`w-full text-left px-2 py-1.5 rounded transition-colors ${
                      vendorNextReply === opt ? 'bg-marigold text-marigold-ink font-semibold' : 'hover:bg-cream'
                    }`}
                  >
                    {opt === 'Accept' && '✓ Accept (Confirms request)'}
                    {opt === 'Decline' && '✗ Decline (Triggers alternatives)'}
                    {opt === 'No reply' && '⏳ No reply (Simulates timeout)'}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 3. MAIN TAB CONTENT */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-6">
        
        {/* TAB 1: ITINERARY */}
        {activeTab === 'itinerary' && (
          <div className="space-y-6">
            {/* Budget Summary Card */}
            <div className="bg-paper border border-line rounded-card p-6 shadow-2xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-display text-lg font-semibold text-ink">Trip Budget Summary</h2>
                  <p className="text-xs text-ink-3">Transparent financial allocation for your entire group</p>
                </div>
                <div className="text-right">
                  <div className="text-xs text-ink-3">Total Group Budget</div>
                  <div className="font-display text-xl font-bold text-ink">
                    {formatINR((activeTrip || currentTrip).totalBudget || 60000)}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-line text-xs">
                <div className="p-3 bg-cream/70 rounded-xl border border-line">
                  <span className="text-ink-3 block text-[11px]">Travellers</span>
                  <span className="font-semibold text-ink text-sm">
                    {(activeTrip || currentTrip).travellers || 2} People
                  </span>
                </div>
                <div className="p-3 bg-cream/70 rounded-xl border border-line">
                  <span className="text-ink-3 block text-[11px]">Duration</span>
                  <span className="font-semibold text-ink text-sm">
                    {(activeTrip || currentTrip).days || 3} Days ({Math.max(1, ((activeTrip || currentTrip).days || 3) - 1)} Nights)
                  </span>
                </div>
                <div className="p-3 bg-cream/70 rounded-xl border border-line">
                  <span className="text-ink-3 block text-[11px]">Estimated Spend</span>
                  <span className="font-semibold text-ink text-sm">
                    {formatINR(Math.round(((activeTrip || currentTrip).totalBudget || 60000) * 0.85))}
                  </span>
                </div>
                <div className="p-3 bg-teal/10 rounded-xl border border-teal/20">
                  <span className="text-teal block text-[11px] font-semibold">Unallocated Cushion</span>
                  <span className="font-bold text-teal text-sm">
                    {formatINR(Math.round(((activeTrip || currentTrip).totalBudget || 60000) * 0.15))}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-paper border border-line rounded-card p-6 shadow-2xs space-y-6">
              <div>
                <h2 className="font-display text-lg font-semibold text-ink">Trip Timeline & Schedule</h2>
                <p className="text-xs text-ink-3">Live chronological schedule synchronized across all services</p>
              </div>

              <div className="relative border-l-2 border-line pl-6 ml-3 space-y-6 text-xs">
                {activeTrip?.itineraryData && activeTrip.itineraryData.length > 0 ? (
                  activeTrip.itineraryData.map((item: any, idx: number) => (
                    <div key={idx} className="relative space-y-1">
                      <div className="w-3.5 h-3.5 rounded-full bg-teal absolute -left-[31px] top-0.5 border-2 border-paper" />
                      <span className="text-[11px] font-bold text-teal">
                        Day {item.day} · {item.time}
                      </span>
                      <div className="font-semibold text-sm text-ink">{item.activity}</div>
                      {item.cost_inr > 0 && (
                        <div className="text-ink-2 font-mono text-[11px]">
                          Allocated: {formatINR(item.cost_inr)}
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <>
                    {/* Day 1 Item 1 */}
                    <div className="relative space-y-1">
                      <div className="w-3.5 h-3.5 rounded-full bg-teal absolute -left-[31px] top-0.5 border-2 border-paper" />
                      <span className="text-[11px] font-bold text-teal">06:15 AM · On Time</span>
                      <div className="font-semibold text-sm text-ink">Departure: Vande Bharat Express Platform 1</div>
                      <div className="text-ink-2">Reserved AC Chair Car seats 14A, 14B · Ref: SIM-TRN-1004</div>
                    </div>

                    {/* Day 1 Item 2 */}
                    <div className="relative space-y-1">
                      <div className="w-3.5 h-3.5 rounded-full bg-marigold absolute -left-[31px] top-0.5 border-2 border-paper" />
                      <span className="text-[11px] font-bold text-marigold-ink">
                        {cabPickupTime} (Updated via Companion)
                      </span>
                      <div className="font-semibold text-sm text-ink">Station Arrival Pickup · Dedicated AC Cab</div>
                      <div className="text-ink-2">Driver Ramesh Patel meets at Station Exit 2 · Ref: SIM-CAB-123</div>
                    </div>

                    {/* Day 1 Item 3 */}
                    <div className="relative space-y-1">
                      <div className="w-3.5 h-3.5 rounded-full bg-ink absolute -left-[31px] top-0.5 border-2 border-paper" />
                      <span className="text-[11px] font-bold text-ink-3">01:00 PM · Hotel Check-in</span>
                      <div className="font-semibold text-sm text-ink">{destData.name} Heritage Boutique Stay</div>
                      <div className="text-ink-2">Front desk open until {hotelCutoffTime} · Ref: SIM-HTL-890</div>
                    </div>

                    {/* Day 1 Item 4 */}
                    <div className="relative space-y-1">
                      <div className="w-3.5 h-3.5 rounded-full bg-line absolute -left-[31px] top-0.5 border-2 border-paper" />
                      <span className="text-[11px] font-bold text-ink-3">04:30 PM · Cultural Sights</span>
                      <div className="font-semibold text-sm text-ink">Guided Heritage & Culinary Walk</div>
                      <div className="text-ink-2">Meeting at Central Monument gate · Digital voucher passes active</div>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: BOOKINGS */}
        {activeTab === 'bookings' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-semibold text-ink">Trip Reservations Preview</h2>
              <span className="text-xs text-ink-3">Sample data · Explicit payment required</span>
            </div>
            <div className="p-3 bg-cream/70 border border-line rounded-lg text-xs text-ink-2">
              <strong>Notice:</strong> No automatic booking or payment has been made. These sample vouchers represent your drafted itinerary selections awaiting final checkout.
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              
              <div className="bg-paper border border-line rounded-card p-5 shadow-2xs space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-ink text-sm">Train Transit</span>
                  <span className="px-2 py-0.5 bg-amber/15 text-amber text-[10px] font-bold rounded-full">Pending Checkout (Sample)</span>
                </div>
                <div className="font-mono text-[11px] text-ink-3">SIM-TRN-1004</div>
                <div className="text-ink-2">Vande Bharat Express · AC Chair Car</div>
                <div className="text-ink-3">Departure: 06:15 AM · Platform 1</div>
                <div className="pt-2 border-t border-line text-ink-3 font-medium">
                  Contact: Station Master 139
                </div>
              </div>

              <div className="bg-paper border border-line rounded-card p-5 shadow-2xs space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-ink text-sm">Boutique Stay</span>
                  <span className="px-2 py-0.5 bg-amber/15 text-amber text-[10px] font-bold rounded-full">Pending Checkout (Sample)</span>
                </div>
                <div className="font-mono text-[11px] text-ink-3">SIM-HTL-890</div>
                <div className="text-ink-2">{destData.name} Heritage Residency</div>
                <div className="text-ink-3">Check-in: 01:00 PM · Cutoff: {hotelCutoffTime}</div>
                <div className="pt-2 border-t border-line text-ink-3 font-medium">
                  Contact: Duty Manager Rajesh Kumar
                </div>
              </div>

              <div className="bg-paper border border-line rounded-card p-5 shadow-2xs space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-ink text-sm">Prepaid Cab</span>
                  <span className="px-2 py-0.5 bg-amber/15 text-amber text-[10px] font-bold rounded-full">Pending Checkout (Sample)</span>
                </div>
                <div className="font-mono text-[11px] text-ink-3">SIM-CAB-123</div>
                <div className="text-ink-2">Sedan AC Cab · Station Pickup</div>
                <div className="text-ink-3">Pickup Time: {cabPickupTime}</div>
                <div className="pt-2 border-t border-line text-ink-3 font-medium">
                  Driver: Ramesh Patel (+91 98765 43210)
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: COMPANION (Core Feature: Scoped to ONE trip) */}
        {activeTab === 'companion' && (
          <div className="space-y-4">
            {/* Unregistered Trip Notice Banner if trip ID not in backend */}
            {!canonicalTripId && (
              <div className="p-4 bg-amber/10 border border-amber/30 rounded-xl text-xs space-y-2">
                <div className="flex items-center gap-2 font-semibold text-amber">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>Trip reference '{tripId}' is not registered in the backend trip repository</span>
                </div>
                <p className="text-ink-2 leading-relaxed text-[11px]">
                  The live MCP disruption engine evaluates disruptions against stored backend bookings. For full live MCP disruption simulation and recovery action staging, you can switch to the verified active trip (<span className="font-mono font-medium">PMT-0142</span>) or plan a new trip.
                </p>
                <div className="pt-1 flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => handleSwitchToActiveTrip('PMT-0142')}
                    className="px-3 py-1.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold rounded-btn text-xs inline-flex items-center gap-1 shadow-2xs cursor-pointer"
                  >
                    <span>Switch to Active Trip (PMT-0142 · New Delhi)</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <Link
                    to="/app/planner"
                    className="px-3 py-1.5 bg-paper hover:bg-cream border border-line text-ink font-semibold rounded-btn text-xs inline-flex items-center gap-1"
                  >
                    Plan New Trip
                  </Link>
                </div>
              </div>
            )}

            <div className="bg-paper border border-line rounded-card shadow-floating overflow-hidden flex flex-col h-[600px]">
              
              {/* Header */}
              <div className="bg-cream/70 px-6 py-4 border-b border-line flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-marigold flex items-center justify-center text-marigold-ink font-bold">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-display text-base font-semibold text-ink">
                      Trip Companion ({canonicalTripId ? destCityName : (tripId ? `Unregistered (${tripId})` : 'Unregistered')})
                    </h3>
                    <span className="text-[11px] text-teal font-medium">
                      {tripId === 'trip_del_jai_001'
                        ? 'Sample Demo Scenario: Jaipur Heritage Explorer'
                        : canonicalTripId
                          ? `Scoped to trip ${displayRef} (${destCityName}) · Live booking context`
                          : `Unregistered scope: ${tripId} · Switch to verified active trip for live booking actions`}
                    </span>
                  </div>
                </div>

                <div className="flex items-center flex-wrap gap-2">
                  {/* Voice Audio Toggle Button */}
                  <button
                    type="button"
                    onClick={toggleVoiceAudio}
                    className={`px-2.5 py-1 rounded text-[11px] font-medium border flex items-center gap-1.5 transition-colors cursor-pointer ${
                      voiceAudioEnabled
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                        : 'bg-paper text-ink-3 border-line hover:bg-cream'
                    }`}
                    title={voiceAudioEnabled ? "Alexa Voice Output: Enabled (Click to Mute)" : "Alexa Voice Output: Muted (Click to Enable)"}
                  >
                    {voiceAudioEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
                    <span>{voiceAudioEnabled ? 'Voice: ON' : 'Voice: Muted'}</span>
                  </button>

                  {/* Voice Settings Button */}
                  <button
                    type="button"
                    onClick={() => setShowVoiceSettings(true)}
                    className="p-1 rounded text-ink-3 hover:text-ink hover:bg-cream border border-line transition-colors cursor-pointer"
                    title="Configure voice & pronunciation"
                  >
                    <Settings2 className="w-3.5 h-3.5" />
                  </button>

                  {/* Stop speaking indicator */}
                  {voiceState === 'speaking' && (
                    <button
                      type="button"
                      onClick={stopSpeaking}
                      className="px-2.5 py-1 bg-ruby-bg text-ruby border border-ruby/30 rounded text-[11px] font-medium flex items-center gap-1 animate-pulse cursor-pointer"
                      title="Stop audio playback"
                    >
                      <Square className="w-3 h-3 fill-current" />
                      <span>Stop Speaking</span>
                    </button>
                  )}

                  {/* Listening badge */}
                  {voiceState === 'listening' && (
                    <div className="flex items-center gap-1.5 px-2.5 py-1 bg-marigold/20 text-marigold-ink border border-marigold/40 rounded text-[11px] font-medium animate-pulse">
                      <span className="w-2 h-2 rounded-full bg-marigold animate-ping" />
                      <span>Listening...</span>
                    </div>
                  )}

                  <span className="text-[11px] text-ink-3 hidden sm:inline ml-1">Demo Triggers:</span>
                  <button
                    onClick={triggerScenarioS1}
                    disabled={isSending}
                    className="px-2.5 py-1 bg-paper hover:bg-cream border border-line rounded text-[11px] font-medium text-ink cursor-pointer disabled:opacity-50"
                  >
                    S1: Late Cab
                  </button>
                  <button
                    onClick={triggerScenarioS3}
                    disabled={isSending}
                    className="px-2.5 py-1 bg-paper hover:bg-cream border border-line rounded text-[11px] font-medium text-ink cursor-pointer disabled:opacity-50"
                  >
                    S3: Bus Rush
                  </button>
                </div>
              </div>

              {/* Voice Error Notice */}
              {voiceError && !dismissedVoiceError && (
                <div className="mx-6 mt-3 p-3 bg-ruby-bg/40 border border-ruby/30 rounded-lg text-xs text-ruby flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{voiceError}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setDismissedVoiceError(true)}
                    className="text-[11px] underline font-semibold ml-2 cursor-pointer"
                  >
                    Dismiss
                  </button>
                </div>
              )}

              {/* Chat Messages Log */}
              <div className="flex-1 p-6 overflow-y-auto space-y-4">
                {chatMessages.map(msg => (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                  >
                    <div
                      className={`max-w-xl p-4 rounded-xl text-xs space-y-2 ${
                        msg.sender === 'user'
                          ? 'bg-ink text-cream rounded-br-none'
                          : 'bg-cream border border-line text-ink rounded-bl-none shadow-2xs'
                      }`}
                    >
                      <p className="leading-relaxed whitespace-pre-line">{msg.text}</p>
                      
                      <div className="flex items-center justify-end gap-2 pt-1 border-t border-line/40">
                        <span className={`text-[10px] ${msg.sender === 'user' ? 'text-cream/60' : 'text-ink-3'}`}>
                          {msg.time}
                        </span>
                        {(msg.sender === 'companion' || msg.sender === 'alexa') && (
                          <button
                            type="button"
                            onClick={() => replayMessage(msg.text)}
                            className="p-1 text-ink-3 hover:text-ink rounded hover:bg-paper/80 transition-colors cursor-pointer"
                            title="Replay response speech"
                            aria-label="Replay speech"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Multimodal Response Cards */}
                    {msg.cards && msg.cards.length > 0 && (
                      <AlexaMultimodalCards
                        cards={msg.cards}
                        disabled={isSending}
                        onApproveAction={(id) => handleCompanionSendMessage(`Approve action ${id}`)}
                        onRejectAction={(id) => handleCompanionSendMessage(`Reject action ${id}`)}
                        onSelectOption={(id, category) => handleCompanionSendMessage(`Select ${category} ${id}`)}
                      />
                    )}
                  </div>
                ))}

                {isSending && (
                  <div className="flex flex-col items-start">
                    <div className="p-3 bg-cream border border-line text-ink rounded-xl rounded-bl-none shadow-2xs flex items-center gap-2 text-xs">
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-marigold" />
                      <span className="text-ink-2">Alexa is checking MCP tools and live trip context...</span>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Quick Prompt Chips */}
              <div className="px-6 py-2 bg-cream/30 border-t border-line/60 flex flex-wrap gap-2 text-xs">
                <span className="text-[11px] text-ink-3 self-center">Quick chips:</span>
                {[
                  'I want to cancel my bus. I want to go in the next bus; I have some work.',
                  'What happens if my bus is cancelled?',
                  'Prepare a recovery action for my disrupted journey, but let me review it before applying anything.',
                  'What is my current trip budget?',
                  'My friends arrived late, need 30 mins'
                ].map((chip, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleCompanionSendMessage(chip)}
                    disabled={isSending}
                    className="px-2.5 py-1 bg-paper hover:bg-cream border border-line rounded-full text-[11px] text-ink-2 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    {chip}
                  </button>
                ))}
              </div>

              {/* Chat Input Bar with Microphone & Voice Controls */}
              <form onSubmit={handleSendCustomText} className="p-4 bg-paper border-t border-line flex items-center gap-2.5">
                {/* Microphone Toggle Button */}
                <button
                  type="button"
                  onClick={toggleListening}
                  disabled={isSending}
                  className={`p-2.5 rounded-btn border transition-all cursor-pointer flex items-center justify-center shrink-0 ${
                    voiceState === 'listening'
                      ? 'bg-marigold text-marigold-ink border-marigold ring-2 ring-marigold/60 scale-105 shadow-sm'
                      : 'bg-cream hover:bg-cream/80 text-ink-2 border-line'
                  }`}
                  title={voiceState === 'listening' ? "Stop listening" : "Click to speak (Voice Input)"}
                  aria-label="Toggle voice microphone"
                >
                  <Mic className={`w-4 h-4 ${voiceState === 'listening' ? 'animate-bounce text-marigold-ink' : ''}`} />
                </button>

                <input
                  type="text"
                  value={companionInput}
                  disabled={isSending}
                  onChange={(e) => setCompanionInput(e.target.value)}
                  placeholder={
                    voiceState === 'listening'
                      ? 'Listening... Speak now or edit transcript...'
                      : isSending
                      ? 'Waiting for Alexa...'
                      : 'Speak or type to your companion...'
                  }
                  className="flex-1 bg-cream border border-line rounded-btn px-4 py-2.5 text-xs text-ink focus:outline-none focus:border-marigold disabled:opacity-60"
                />
                <button
                  type="submit"
                  disabled={isSending || !companionInput.trim()}
                  className="px-5 py-2.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-colors flex items-center gap-1.5 shadow-2xs cursor-pointer disabled:opacity-50 shrink-0"
                >
                  {isSending ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Thinking</span>
                    </>
                  ) : (
                    <>
                      <span>Send</span>
                      <Send className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        )}

        {/* TAB 4: MESSAGES LOG */}
        {activeTab === 'messages' && (
          <div className="space-y-4">
            <div>
              <h2 className="font-display text-lg font-semibold text-ink">Third-Party Vendor Messaging Log</h2>
              <p className="text-xs text-ink-3">Every simulated dispatch, driver coordination, and status transition</p>
            </div>

            <div className="space-y-3">
              {messageLogs.map(log => (
                <div
                  key={log.id}
                  className="p-4 bg-paper border border-line rounded-card shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-ink">{log.sender} → {log.recipient}</span>
                      <span className="text-[11px] text-ink-3 font-mono">({log.timestamp})</span>
                    </div>
                    <p className="text-ink-2 font-mono text-[11px] bg-cream/70 p-2 rounded-lg border border-line">
                      "{log.text}"
                    </p>
                  </div>

                  <div className="shrink-0 flex items-center gap-2">
                    <span className="text-[10px] text-ink-3 uppercase">Simulated Status:</span>
                    <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                      log.status === 'Acknowledged'
                        ? 'bg-teal/15 text-teal border border-teal/30'
                        : log.status === 'Declined'
                        ? 'bg-coral/15 text-coral border border-coral/30'
                        : log.status === 'No reply'
                        ? 'bg-amber/15 text-amber border border-amber/30'
                        : 'bg-cream text-ink-2 border border-line'
                    }`}>
                      {log.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: PAYMENTS & SPLITS */}
        {activeTab === 'payments' && (
          <div className="space-y-6">
            <div className="bg-paper border border-line rounded-card p-6 shadow-2xs space-y-6">
              <div>
                <h2 className="font-display text-lg font-semibold text-ink">Marketplace Payments & Payout Split</h2>
                <p className="text-xs text-ink-3">Escrow holds, split disbursements, and refund timelines</p>
              </div>

              {/* Payment Summary */}
              <div className="p-4 bg-cream rounded-xl border border-line flex flex-col sm:flex-row justify-between gap-4 text-xs">
                <div>
                  <span className="text-ink-3">Total Paid at Booking:</span>
                  <div className="font-display text-2xl font-bold text-ink">₹12,700</div>
                  <span className="text-[11px] text-teal font-medium">Payment status: Simulated Hold</span>
                </div>
                <div>
                  <span className="text-ink-3">Remaining Budget Buffer:</span>
                  <div className="font-display text-2xl font-bold text-teal">₹2,300</div>
                  <span className="text-[11px] text-ink-3">Preserved for emergency rescue</span>
                </div>
              </div>

              {/* Active Refunds */}
              {refunds.length > 0 && (
                <div className="space-y-3">
                  <h3 className="font-semibold text-sm text-ink">Simulated Refund Tracking</h3>
                  <div className="space-y-2">
                    {refunds.map(ref => (
                      <div key={ref.id} className="p-3 bg-amber/10 border border-amber/30 rounded-xl text-xs flex items-center justify-between">
                        <div>
                          <div className="font-bold text-ink">{ref.provider} ({formatINR(ref.amount)})</div>
                          <div className="text-ink-3 text-[11px]">{ref.reason} · Requested: {ref.requestedAt}</div>
                          <div className="text-[10px] text-amber mt-1">
                            Sample timeline: a few hours. Real timing depends on your bank and the provider.
                          </div>
                        </div>
                        <span className="px-2.5 py-1 bg-amber text-paper rounded-full text-[10px] font-bold">
                          {ref.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Floating "Trip Companion" Quick Button */}
      {activeTab !== 'companion' && (
        <button
          onClick={() => setActiveTab('companion')}
          className="fixed bottom-6 right-6 z-40 px-5 py-3 bg-marigold hover:bg-marigold-hover text-marigold-ink font-bold text-xs rounded-full shadow-floating flex items-center gap-2 cursor-pointer transition-transform hover:scale-105"
        >
          <Sparkles className="w-4 h-4" />
          <span>Trip companion</span>
        </button>
      )}

      {/* Voice Settings Modal */}
      <VoiceSettingsModal
        isOpen={showVoiceSettings}
        onClose={() => setShowVoiceSettings(false)}
      />
    </div>
  );
}
