import React, { useState } from 'react';
import {
  Terminal,
  Play,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Layers,
  ArrowRight
} from 'lucide-react';
import { getAlexaClient } from '../../lib/alexa/client';
import { useTrip } from '../../context/TripContext';
import { useAuth } from '../../context/AuthContext';

export default function AlexaDebugPage() {
  const { currentTrip } = useTrip();
  const { user } = useAuth();
  const client = getAlexaClient();

  const [activeTab, setActiveTab] = useState<'console' | 'tools' | 'docs'>('console');
  const [testMessage, setTestMessage] = useState('Plan 2 days in Delhi under ₹15,000');
  const [responseLog, setResponseLog] = useState<any | null>(null);
  const [latencyMs, setLatencyMs] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleRunTest = async (msgToRun?: string) => {
    const text = msgToRun || testMessage;
    setIsLoading(true);
    const start = performance.now();

    try {
      const res = await client.send(text, {
        userId: user?.uid || 'demo-traveler-001',
        tripId: currentTrip.id,
        draft: currentTrip
      });
      const end = performance.now();
      setLatencyMs(Math.round(end - start));
      setResponseLog(res);
    } catch (err: any) {
      const end = performance.now();
      setLatencyMs(Math.round(end - start));
      setResponseLog({ error: err.message || 'Invocation failed' });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 space-y-8 font-sans">
      {/* Top Banner */}
      <div className="pb-4 border-b border-line flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-teal">
            <Terminal className="w-4 h-4" />
            <span>Developer Diagnostics & MCP Inspector</span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-semibold text-ink mt-1">
            Alexa+ Engine Debugger
          </h1>
          <p className="text-xs text-ink-2 mt-0.5">
            Test deterministic mock execution, external MCP transport fallbacks, and tool trace transparency.
          </p>
        </div>

        {/* Engine status pills */}
        <div className="flex items-center gap-2">
          <div className="px-3 py-1 bg-cream border border-line rounded-full text-xs font-mono font-medium text-ink flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-teal animate-pulse" />
            <span>Mode: {client.modeName}</span>
          </div>
          <div className="px-3 py-1 bg-cream border border-line rounded-full text-xs font-mono font-medium text-ink">
            Status: {client.connectionStatus}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-line pb-2 text-xs font-semibold">
        {[
          { id: 'console', label: 'Interactive Console' },
          { id: 'tools', label: 'MCP Tools Catalog' },
          { id: 'docs', label: 'Architecture Reference' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3 py-1.5 rounded-btn transition-colors cursor-pointer ${
              activeTab === tab.id ? 'bg-ink text-cream' : 'text-ink-2 hover:bg-cream'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* TAB 1: CONSOLE */}
      {activeTab === 'console' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left: Input & Preset Tests */}
          <div className="lg:col-span-5 bg-paper border border-line rounded-card p-6 shadow-2xs space-y-4">
            <h3 className="font-display text-base font-semibold text-ink">Send Test Prompt</h3>

            <textarea
              rows={3}
              value={testMessage}
              onChange={(e) => setTestMessage(e.target.value)}
              className="w-full bg-cream border border-line rounded-btn p-3 text-xs text-ink font-mono focus:outline-none focus:border-marigold"
              placeholder="Enter test user prompt..."
            />

            <button
              onClick={() => handleRunTest()}
              disabled={isLoading}
              className="w-full py-2.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-xs rounded-btn transition-colors shadow-2xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>{isLoading ? 'Executing...' : 'Invoke Alexa Client'}</span>
            </button>

            {/* Presets */}
            <div className="pt-3 border-t border-line space-y-2">
              <span className="text-[11px] font-mono uppercase tracking-wider text-ink-3 block">
                Standard Demo Scripts
              </span>
              {[
                'Plan 2 days in Delhi under ₹15,000',
                'Add Old Delhi culinary food trail',
                'Train 12015 is delayed by 45 minutes',
                'Show me budget allocation breakdown'
              ].map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setTestMessage(preset);
                    handleRunTest(preset);
                  }}
                  className="w-full text-left p-2 rounded bg-cream hover:bg-cream-2 border border-line text-xs text-ink truncate cursor-pointer transition-colors"
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          {/* Right: Response Inspector */}
          <div className="lg:col-span-7 bg-paper border border-line rounded-card p-6 shadow-2xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-line">
              <h3 className="font-display text-base font-semibold text-ink">Payload Inspector</h3>
              {latencyMs !== null && (
                <span className="text-xs font-mono text-teal font-semibold">
                  Latency: {latencyMs}ms
                </span>
              )}
            </div>

            {responseLog ? (
              <pre className="p-4 bg-ink text-cream-2 rounded-xl text-xs font-mono overflow-x-auto max-h-[500px] leading-relaxed">
                {JSON.stringify(responseLog, null, 2)}
              </pre>
            ) : (
              <div className="p-12 text-center text-xs text-ink-3 font-mono bg-cream rounded-xl border border-line">
                Run an invocation to inspect the resulting AlexaReply and MCP tool trace JSON.
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: TOOLS */}
      {activeTab === 'tools' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            {
              name: 'search_transport',
              desc: 'Queries real schedules for Vande Bharat trains, domestic flights, and luxury buses.',
              params: 'origin: string, destination: string, maxFare?: number'
            },
            {
              name: 'search_stays',
              desc: 'Discovers verified boutique havelis and heritage properties matching budget.',
              params: 'city: string, nights: number, targetTier?: string'
            },
            {
              name: 'search_activities',
              desc: 'Recommends cultural experiences, food trails, and landmark entry passes.',
              params: 'city: string, theme?: string'
            },
            {
              name: 'calculate_budget',
              desc: 'Pure deterministic integer math engine. Computes categories and 8% buffer.',
              params: 'totalBudget: number, days: number, travellers: number'
            },
            {
              name: 'request_budget_approval',
              desc: 'Generates structured approval card whenever additions utilize emergency buffer.',
              params: 'actionId: string, cost: number, reason: string'
            },
            {
              name: 'rescue_journey',
              desc: 'Simulates domino impacts for delays (15–90m) and coordinates cab re-timings.',
              params: 'delayMinutes: number, tripId: string'
            }
          ].map((tool, idx) => (
            <div key={idx} className="bg-paper border border-line rounded-card p-5 space-y-2">
              <div className="font-mono text-sm font-semibold text-teal">{tool.name}()</div>
              <p className="text-xs text-ink-2 leading-relaxed">{tool.desc}</p>
              <div className="text-[11px] font-mono text-ink-3 bg-cream p-2 rounded border border-line">
                Args: {tool.params}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 3: DOCS */}
      {activeTab === 'docs' && (
        <div className="bg-paper border border-line rounded-card p-8 space-y-4 text-xs text-ink-2 leading-relaxed">
          <h3 className="font-display text-lg font-semibold text-ink">Connecting a Live Backend</h3>
          <p>
            Plan My Trip is architected with a decoupled client layer. To route requests to an external MCP agent endpoint or live Alexa+ server, set the following environment variables in <code className="bg-cream px-1.5 py-0.5 rounded border border-line font-mono text-ink">.env</code>:
          </p>
          <pre className="p-4 bg-ink text-cream rounded-xl font-mono text-xs">
{`VITE_ALEXA_MODE=remote
VITE_ALEXA_ENDPOINT=https://your-mcp-server.example.com/api/alexa
VITE_ALEXA_API_KEY=your_token_here`}
          </pre>
          <p>
            If the remote server times out or is unreachable, the client automatically falls back to the deterministic local engine to guarantee zero downtime during live demonstrations.
          </p>
        </div>
      )}
    </div>
  );
}
