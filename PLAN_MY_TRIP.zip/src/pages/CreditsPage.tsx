import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Compass, ExternalLink, ShieldCheck } from 'lucide-react';

const CREDITS_DATA = [
  {
    file: 'hero-main.webp',
    subject: 'Indian Railways train crossing Pamban Bridge at sunrise',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Pamban_rail_bridge.jpg',
    author: 'Picsnapr',
    license: 'CC BY-SA 4.0'
  },
  {
    file: 'band-1.webp',
    subject: 'Sunrise over Bengal from moving train',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Sunrise_view_from_a_moving_train.jpg',
    author: 'Ankit Tripathi',
    license: 'CC BY-SA 4.0'
  },
  {
    file: 'band-2.webp',
    subject: 'Amber Fort Jaali stone lattice texture',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Amber_fort_jaali.jpg',
    author: 'Chayandunks7',
    license: 'CC BY-SA 4.0'
  },
  {
    file: 'rescue-station.webp',
    subject: 'Nagda Junction railway platform at dawn',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Nagda_junction_railway_station.jpg',
    author: 'Ajit lokhande patil',
    license: 'CC BY-SA 4.0'
  },
  {
    file: 'cta-sunrise.webp',
    subject: 'Western Ghats sunrise over hills',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Sunrise_at_Western_Ghats.jpg',
    author: 'Deepamurthy',
    license: 'CC BY-SA 4.0'
  },
  {
    file: 'dest-delhi-banner.webp / card.webp',
    subject: 'India Gate, New Delhi',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:India_Gate_Delhi_sunset.jpg',
    author: 'Shounak Ray',
    license: 'CC BY-SA 4.0'
  },
  {
    file: 'dest-jaipur-banner.webp / card.webp',
    subject: 'Amber Fort, Jaipur, Rajasthan',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Amber_Fort_Jaipur.jpg',
    author: 'Firoze Edassery',
    license: 'CC BY-SA 3.0'
  },
  {
    file: 'dest-hampi-banner.webp / card.webp',
    subject: 'Virupaksha Temple & Ruins, Hampi',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Wide_angle_of_Galigopuram_of_Virupaksha_Temple,_Hampi_(04)_(cropped).jpg',
    author: 'Dineshkannambadi',
    license: 'CC BY-SA 3.0'
  },
  {
    file: 'dest-varanasi-banner.webp / card.webp',
    subject: 'Ahilya Ghat on the Ganges, Varanasi',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Ahilya_Ghat_by_the_Ganges,_Varanasi.jpg',
    author: 'Gerd Eichmann',
    license: 'CC BY-SA 4.0'
  },
  {
    file: 'dest-alleppey-banner.webp / card.webp',
    subject: 'Backwaters Houseboat, Alleppey',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Kerala_Backwaters_Houseboat.jpg',
    author: 'Sarath Kuchi',
    license: 'CC BY-SA 2.0'
  },
  {
    file: 'dest-coorg-banner.webp / card.webp',
    subject: 'Tadiandamol Valley & Misty Hills, Coorg',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Tadiandamol_Valley,_Western_Ghats.jpg',
    author: 'Kishorekumar',
    license: 'CC BY-SA 3.0'
  },
  {
    file: 'thumb-train-sleeper.webp',
    subject: 'LHB Sleeper Coach on Indian Railways',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:LHB_Sleeper_Coach.jpg',
    author: 'Vikramaditya V. V.',
    license: 'CC BY-SA 4.0'
  },
  {
    file: 'thumb-train-ac.webp',
    subject: 'Vande Bharat Express',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Vande_Bharat_Express_at_Bolpur_Shantiniketan_Station.jpg',
    author: 'Voice of Bolpur',
    license: 'CC0 Public Domain'
  },
  {
    file: 'thumb-flight.webp',
    subject: 'Domestic flight wing over clouds outside Mumbai',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Flight_to_Mumbai.jpg',
    author: 'Priyaflorenceshah',
    license: 'CC BY-SA 4.0'
  },
  {
    file: 'thumb-bus.webp',
    subject: 'KSRTC Airavat Volvo Club Class bus',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:KSRTC_Airavat_Club_Class.jpg',
    author: 'Rsrikanth05',
    license: 'CC BY-SA 4.0'
  },
  {
    file: 'thumb-stay-haveli.webp',
    subject: 'Samode Haveli Courtyard, Jaipur',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Courtyard_of_Samode_Haveli,_Jaipur.jpg',
    author: 'Richard Moross',
    license: 'CC BY 2.0'
  },
  {
    file: 'thumb-cab.webp',
    subject: 'Station taxi sedan',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Delhi_Taxi.jpg',
    author: 'J. Miers',
    license: 'CC BY-SA 4.0'
  },
  {
    file: 'thumb-auto.webp',
    subject: 'Auto-rickshaw in Delhi',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Auto-rickshaw_in_Delhi.jpg',
    author: 'Psubhashish',
    license: 'CC BY-SA 3.0'
  },
  {
    file: 'thumb-metro.webp',
    subject: 'Delhi Metro Airport Express line',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Delhi_Metro_Airport_Express.jpg',
    author: 'DMRC',
    license: 'CC BY-SA 4.0'
  },
  {
    file: 'thumb-rental.webp',
    subject: 'Scooter rental in India',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Scooter_India.jpg',
    author: 'Visdaviva',
    license: 'CC BY-SA 3.0'
  },
  {
    file: 'thumb-exp-culinary.webp',
    subject: 'Samosas & Mint Chutney, Food Trail',
    source: 'Unsplash',
    sourceUrl: 'https://unsplash.com',
    author: 'Unsplash License',
    license: 'Free Commercial Use'
  },
  {
    file: 'thumb-exp-heritage.webp',
    subject: 'Qutub Minar, Mehrauli, New Delhi',
    source: 'Wikimedia Commons',
    sourceUrl: 'https://commons.wikimedia.org/wiki/File:Qutb_Minar_2022.jpg',
    author: 'R. K. Lakhera',
    license: 'CC BY-SA 4.0'
  },
  {
    file: 'signin-panel.webp',
    subject: 'Traveler on railway platform at dawn',
    source: 'Generative Documentary',
    sourceUrl: '#',
    author: 'Plan My Trip',
    license: 'Project Asset'
  },
  {
    file: 'journey-1.webp to journey-5.webp',
    subject: '5-Stage Travel Lifecycle (Chai planning, train window, haveli room, cab, Varanasi ghats)',
    source: 'Generative Documentary',
    sourceUrl: '#',
    author: 'Plan My Trip',
    license: 'Project Asset'
  }
];

export default function CreditsPage() {
  return (
    <div className="min-h-screen bg-cream text-ink font-sans">
      {/* Top Bar */}
      <header className="sticky top-0 z-30 bg-cream/90 backdrop-blur-md border-b border-line">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 font-display text-xl tracking-tight text-ink">
            <Compass className="w-5 h-5 text-marigold" />
            <span>Plan My Trip</span>
          </Link>
          <Link
            to="/"
            className="flex items-center gap-1.5 text-sm font-medium text-ink-2 hover:text-ink transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Home</span>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-6 py-12 space-y-10">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-paper border border-line rounded-full text-xs font-semibold text-ink-2 mb-3">
            <ShieldCheck className="w-3.5 h-3.5 text-teal" />
            <span>Open Licensing Compliance</span>
          </div>
          <h1 className="font-display text-3xl sm:text-4xl font-semibold text-ink tracking-tight">
            Photo Credits & Attribution
          </h1>
          <p className="text-sm text-ink-2 mt-2 max-w-2xl leading-relaxed">
            All photography used across Plan My Trip is sourced from authentic, free-license repositories (Wikimedia Commons, CC-BY, CC-BY-SA, CC0, Unsplash) or custom documentary photography.
          </p>
        </div>

        {/* Table of credits */}
        <div className="bg-paper border border-line rounded-card overflow-hidden shadow-2xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-cream/60 border-b border-line text-ink font-semibold">
                  <th className="py-3 px-4">Filename</th>
                  <th className="py-3 px-4">Subject / Depiction</th>
                  <th className="py-3 px-4">Source</th>
                  <th className="py-3 px-4">Author / Attribution</th>
                  <th className="py-3 px-4">License</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {CREDITS_DATA.map((item, idx) => (
                  <tr key={idx} className="hover:bg-cream/30 transition-colors">
                    <td className="py-3 px-4 font-mono text-ink-2 font-semibold">
                      {item.file}
                    </td>
                    <td className="py-3 px-4 text-ink font-medium">
                      {item.subject}
                    </td>
                    <td className="py-3 px-4 text-ink-2">
                      {item.sourceUrl !== '#' ? (
                        <a
                          href={item.sourceUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-marigold hover:underline inline-flex items-center gap-1 font-medium"
                        >
                          <span>{item.source}</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      ) : (
                        <span>{item.source}</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-ink-2">
                      {item.author}
                    </td>
                    <td className="py-3 px-4">
                      <span className="inline-block px-2 py-0.5 rounded bg-cream border border-line text-[11px] font-mono text-ink font-medium">
                        {item.license}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Legal notice */}
        <div className="bg-cream/50 border border-line rounded-card p-6 text-xs text-ink-2 space-y-2">
          <h3 className="font-semibold text-ink text-sm">Licensing Notes & Fair Use</h3>
          <p className="leading-relaxed">
            All images are hosted locally within the application bundle in modern WebP format for fast delivery. No images imply endorsement by authors, institutions, or landmarks depicted.
          </p>
        </div>
      </main>
    </div>
  );
}
