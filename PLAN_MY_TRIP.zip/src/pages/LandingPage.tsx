import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import {
  Compass,
  ArrowRight,
  Mic,
  Sliders,
  ShieldCheck,
  Clock,
  Sparkles,
  ChevronDown,
  ChevronRight,
  CheckCircle2,
  AlertTriangle,
  Plane,
  Building,
  Car,
  UtensilsCrossed,
  MapPin,
  ExternalLink,
  Volume2
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTrip } from '../context/TripContext';
import { calculateBudgetAllocation, formatINR } from '../lib/budget';
import { DESTINATIONS } from '../data/fixtures';
import imageColorsData from '../data/imageColors.json';

const imageColors: Record<string, string> = imageColorsData;

export default function LandingPage() {
  const { user, openAuthModal, loginAsGuest } = useAuth();
  const { resetTrip } = useTrip();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  // Open modal if ?auth=true
  useEffect(() => {
    if (searchParams.get('auth') === 'true') {
      openAuthModal();
    }
  }, [searchParams, openAuthModal]);

  // Scroll state for sticky nav transparent-to-solid transition
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Budget demo state
  const [demoBudget, setDemoBudget] = useState(15000);
  const budgetAllocation = calculateBudgetAllocation(demoBudget);

  // FAQ Accordion state
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  // Alexa demo voice simulation
  const [alexaState, setAlexaState] = useState<'idle' | 'listening' | 'speaking'>('idle');

  const handleStartPlanning = () => {
    if (user) {
      navigate('/app');
    } else {
      openAuthModal();
    }
  };

  const handleDestinationPlan = (destId: string) => {
    if (!user) {
      loginAsGuest();
    }
    const dest = DESTINATIONS.find((d) => d.id === destId);
    if (dest) {
      resetTrip(dest.name, dest.sampleBudget, dest.durationDays || 3, 2);
    }
    navigate('/app');
  };

  // Tier calculation for budget demo
  const getTierInfo = (budget: number) => {
    if (budget < 14000) {
      return {
        tier: 'Budget Explorer',
        desc: 'Comfortable sleeper/AC trains, verified boutique guesthouses, self-guided heritage trails.'
      };
    }
    if (budget < 25000) {
      return {
        tier: 'Comfort Traveler',
        desc: 'Vande Bharat Express / domestic flights, 3-4★ heritage stays, private AC cabs, guided food trails.'
      };
    }
    return {
      tier: 'Heritage & Luxury',
      desc: 'Premium airfare, 4-5★ palace hotels, dedicated private chauffeur, VIP landmark passes.'
    };
  };

  const tierInfo = getTierInfo(demoBudget);

  const getImageColor = (filename: string, fallback: string = '#101B2B') => {
    return imageColors[filename] || fallback;
  };

  return (
    <div className="min-h-screen bg-cream text-ink font-sans selection:bg-marigold selection:text-marigold-ink">
      {/* =========================================================
          SECTION 1: STICKY NAV (Transparent at top, solid on scroll)
         ========================================================= */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-cream/95 backdrop-blur-md border-b border-line shadow-2xs py-3.5 text-ink'
            : 'bg-gradient-to-b from-[#0B1B2B]/75 to-transparent border-b border-transparent py-5 text-cream'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 font-display text-base sm:text-xl tracking-tight group">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-marigold flex items-center justify-center text-marigold-ink shadow-sm transition-transform group-hover:scale-105 shrink-0">
              <Compass className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <span className={`font-semibold text-base sm:text-lg transition-colors whitespace-nowrap ${isScrolled ? 'text-ink' : 'text-paper'}`}>
              Plan My Trip
            </span>
          </Link>

          <nav
            className={`hidden md:flex items-center gap-7 text-sm font-medium transition-colors ${
              isScrolled ? 'text-ink-2' : 'text-cream/80'
            }`}
          >
            <a href="#how-it-works" className={isScrolled ? 'hover:text-ink transition-colors' : 'hover:text-paper transition-colors'}>
              How it works
            </a>
            <a href="#budget" className={isScrolled ? 'hover:text-ink transition-colors' : 'hover:text-paper transition-colors'}>
              Budget demo
            </a>
            <a href="#destinations" className={isScrolled ? 'hover:text-ink transition-colors' : 'hover:text-paper transition-colors'}>
              Destinations
            </a>
            <a href="#rescue" className={isScrolled ? 'hover:text-ink transition-colors' : 'hover:text-paper transition-colors'}>
              Journey Rescue
            </a>
            <a href="#alexa" className={isScrolled ? 'hover:text-ink transition-colors' : 'hover:text-paper transition-colors'}>
              Alexa
            </a>
          </nav>

          <div className="flex items-center gap-3">
            {user ? (
              <Link
                to="/app"
                className="px-4 py-2.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-medium text-sm rounded-btn transition-colors shadow-sm inline-flex items-center gap-2"
              >
                <span>Go to Workspace</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            ) : (
              <>
                <button
                  onClick={openAuthModal}
                  className={`hidden sm:block px-3.5 py-2 text-sm font-medium transition-colors ${
                    isScrolled ? 'text-ink hover:text-marigold' : 'text-cream hover:text-marigold'
                  }`}
                >
                  Sign in
                </button>
                <button
                  onClick={handleStartPlanning}
                  className="px-3 py-1.5 sm:px-4.5 sm:py-2.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-medium text-xs sm:text-sm rounded-btn transition-colors shadow-sm inline-flex items-center gap-1.5 whitespace-nowrap"
                >
                  <span>Start planning</span>
                  <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </button>
              </>
            )}
          </div>
        </div>
      </header>

      {/* =========================================================
          SECTION 2: HERO WITH FULL-BLEED PHOTOGRAPHY
         ========================================================= */}
      <section className="relative min-h-[88vh] flex items-center overflow-hidden pt-28 pb-20 md:pt-32 md:pb-28">
        {/* Full-bleed background photo */}
        <img
          src="/images/hero-main.webp"
          alt="Indian Railways train crossing Pamban Bridge at golden hour sunrise"
          fetchPriority="high"
          width={1920}
          height={1080}
          className="absolute inset-0 w-full h-full object-cover pointer-events-none"
          style={{ backgroundColor: getImageColor('hero-main.webp', '#080808') }}
        />

        {/* Ink contrast overlay: left-to-right gradient ensuring >= 4.5:1 text contrast */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#0B1B2B]/90 via-[#0B1B2B]/75 to-[#0B1B2B]/45 pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B1B2B]/70 via-transparent to-black/30 pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left copy */}
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-paper/15 border border-cream/25 rounded-full text-xs font-semibold text-cream shadow-2xs backdrop-blur-sm">
                <span className="w-2 h-2 rounded-full bg-teal animate-pulse" />
                <span>Voice-First Travel Intelligence</span>
              </div>

              <h1 className="font-display text-3xl sm:text-5xl lg:text-[62px] font-semibold tracking-tight text-paper leading-[1.08]">
                One conversation.{' '}
                <span className="relative inline-block">
                  <span className="relative z-10 text-paper">One budget.</span>
                  <span className="absolute left-0 bottom-1 w-full h-3.5 bg-marigold/65 -z-0 rounded-sm" />
                </span>{' '}
                Your entire journey.
              </h1>

              <p className="font-sans text-lg md:text-xl text-cream/90 max-w-xl leading-relaxed">
                Tell Alexa where you want to go and what you want to spend. We assemble your transport, stays, cabs, and curated experiences within your exact financial ceiling.
              </p>

              <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5">
                <button
                  onClick={handleStartPlanning}
                  className="px-6 py-3.5 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-base rounded-btn transition-all shadow-sm flex items-center justify-center gap-2 group cursor-pointer"
                >
                  <Mic className="w-5 h-5 text-marigold-ink group-hover:scale-110 transition-transform" />
                  <span>Plan a trip with Alexa</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <a
                  href="#budget"
                  className="px-6 py-3.5 bg-paper/20 hover:bg-paper/30 border border-cream/35 text-cream font-medium text-base rounded-btn transition-colors flex items-center justify-center gap-2 shadow-2xs backdrop-blur-sm"
                >
                  <Sliders className="w-4 h-4 text-cream" />
                  <span>Try the budget slider</span>
                </a>
              </div>

              <div className="pt-1 flex flex-wrap items-center gap-4 text-xs text-cream/75">
                <span className="inline-flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-teal" />
                  <span>Strict budget limits</span>
                </span>
                <span>•</span>
                <span>Sample data · No real bookings or payment required</span>
              </div>
            </div>

            {/* Right visual: Alexa Card on Solid Surface */}
            <div className="lg:col-span-5 relative">
              <div className="relative z-10 bg-paper border border-line rounded-card shadow-floating p-6 backdrop-blur-sm">
                <div className="flex items-center justify-between pb-4 border-b border-line">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-marigold/20 text-marigold-ink flex items-center justify-center font-display font-semibold text-xs">
                      A+
                    </div>
                    <div>
                      <div className="font-semibold text-sm text-ink leading-tight">Alexa Travel Assistant</div>
                      <div className="text-[11px] text-teal font-medium flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-teal" />
                        <span>Ready to assist</span>
                      </div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 bg-cream border border-line text-[11px] font-medium text-ink-2 rounded">
                    Demo Mode
                  </span>
                </div>

                {/* Conversation preview snippet */}
                <div className="py-5 space-y-3.5">
                  <div className="bg-cream p-3 rounded-xl border border-line text-xs text-ink-2">
                    <span className="font-semibold text-ink block mb-0.5">You asked:</span>
                    "Plan a weekend in Delhi for 2 under ₹15,000 with heritage walks."
                  </div>

                  <div className="bg-paper p-3.5 rounded-xl border border-marigold/40 text-xs text-ink shadow-2xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-teal flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-teal" />
                        <span>Allocated ₹12,700 of ₹15,000</span>
                      </span>
                      <span className="text-[11px] font-mono text-ink-3">₹1,100 buffer safe</span>
                    </div>
                    <p className="text-ink-2 leading-relaxed">
                      Included: Vande Bharat Express, 2 nights at Haveli Dharampura, Old Delhi Culinary Trail, and prepaid metro passes.
                    </p>
                  </div>
                </div>

                {/* Micro CTA */}
                <button
                  onClick={handleStartPlanning}
                  className="w-full py-2.5 bg-ink text-cream hover:bg-ink-2 rounded-btn text-xs font-medium transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-marigold" />
                  <span>Open interactive trip workspace</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================
          SECTION 3: ONE APP FOR (6-ITEM STRIP)
         ========================================================= */}
      <section className="py-8 bg-paper border-b border-line">
        <div className="max-w-7xl mx-auto px-6">
          <p className="text-xs uppercase font-semibold tracking-wider text-ink-3 mb-5 text-center">
            One unified journey · No separate tabs or disjointed tools
          </p>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {[
              { icon: Plane, label: 'Transport', detail: 'Trains & flights' },
              { icon: Building, label: 'Stays', detail: 'Havelis & hotels' },
              { icon: Car, label: 'Cabs & Rentals', detail: 'Station pickups' },
              { icon: MapPin, label: 'Things to Do', detail: 'Curated heritage' },
              { icon: UtensilsCrossed, label: 'Food & Trails', detail: 'Regional thalis' },
              { icon: ShieldCheck, label: 'Journey Rescue', detail: 'Live delay reroutes' }
            ].map((item, idx) => {
              const Icon = item.icon;
              return (
                <div
                  key={idx}
                  className="p-3.5 rounded-card bg-cream/50 border border-line flex flex-col items-center text-center hover:bg-cream transition-colors"
                >
                  <div className="w-9 h-9 rounded-lg bg-paper border border-line flex items-center justify-center text-ink mb-2">
                    <Icon className="w-4.5 h-4.5 text-marigold" />
                  </div>
                  <span className="font-semibold text-xs text-ink">{item.label}</span>
                  <span className="text-[11px] text-ink-3 mt-0.5">{item.detail}</span>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* =========================================================
          SECTION 4: HOW IT WORKS (#how-it-works)
         ========================================================= */}
      <section id="how-it-works" className="py-20 md:py-28 bg-cream border-b border-line scroll-mt-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-xs uppercase font-semibold tracking-wider text-marigold-ink bg-marigold/20 px-3 py-1 rounded-full">
              Simple 3-Step Protocol
            </span>
            <h2 className="font-display text-3xl md:text-4xl font-semibold tracking-tight text-ink mt-3">
              How Plan My Trip coordinates your journey
            </h2>
            <p className="text-ink-2 text-base mt-3">
              From an initial spoken idea to active on-the-road disruption rescue, everything stays strictly within your budget.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="bg-paper border border-line rounded-card p-6 flex flex-col justify-between shadow-2xs">
              <div>
                <div className="w-9 h-9 rounded-full bg-cream border border-line flex items-center justify-center text-xs font-bold text-ink mb-4">
                  01
                </div>
                <h3 className="font-display text-xl font-semibold text-ink mb-2">
                  Speak or type your vision
                </h3>
                <p className="text-sm text-ink-2 leading-relaxed mb-6">
                  Tell Alexa your destination, dates, companions, and overall budget in natural words. No complex filter forms.
                </p>
              </div>

              {/* Hand-built UI snippet */}
              <div className="bg-cream-2 p-4 rounded-xl border border-line">
                <div className="flex items-center gap-2 text-xs font-semibold text-ink mb-2">
                  <Mic className="w-3.5 h-3.5 text-marigold" />
                  <span>Speech input detected</span>
                </div>
                <div className="bg-paper p-3 rounded-lg border border-line text-xs text-ink-2 italic">
                  "Find a 3-day quiet getaway to Coorg under ₹18,000 with a plantation tour."
                </div>
              </div>
            </div>

            {/* Step 2 */}
            <div className="bg-paper border border-line rounded-card p-6 flex flex-col justify-between shadow-2xs">
              <div>
                <div className="w-9 h-9 rounded-full bg-cream border border-line flex items-center justify-center text-xs font-bold text-ink mb-4">
                  02
                </div>
                <h3 className="font-display text-xl font-semibold text-ink mb-2">
                  Dynamic budget allocation
                </h3>
                <p className="text-sm text-ink-2 leading-relaxed mb-6">
                  Our pure math engine balances travel, stays, food, and local transit. It reserves an 8% buffer so you never overspend.
                </p>
              </div>

              {/* Hand-built UI snippet */}
              <div className="bg-cream-2 p-4 rounded-xl border border-line space-y-2">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="text-ink">Budget Partitioning</span>
                  <span className="text-teal font-mono">100% Fit</span>
                </div>
                <div className="grid grid-cols-5 gap-1 h-3 rounded-full overflow-hidden bg-cream border border-line">
                  <div className="bg-ink" title="Transport (35%)" />
                  <div className="bg-teal" title="Stays (30%)" />
                  <div className="bg-marigold" title="Food (15%)" />
                  <div className="bg-amber" title="Local (10%)" />
                  <div className="bg-ink-3" title="Activities (10%)" />
                </div>
                <div className="flex justify-between text-[11px] text-ink-3 font-mono pt-1">
                  <span>Transport 35%</span>
                  <span>Stay 30%</span>
                  <span>Buffer 8%</span>
                </div>
              </div>
            </div>

            {/* Step 3 */}
            <div className="bg-paper border border-line rounded-card p-6 flex flex-col justify-between shadow-2xs">
              <div>
                <div className="w-9 h-9 rounded-full bg-cream border border-line flex items-center justify-center text-xs font-bold text-ink mb-4">
                  03
                </div>
                <h3 className="font-display text-xl font-semibold text-ink mb-2">
                  Journey Rescue stands by
                </h3>
                <p className="text-sm text-ink-2 leading-relaxed mb-6">
                  If a train is delayed or traffic spikes, Alexa re-times downstream cabs and hotel arrivals using your saved buffer.
                </p>
              </div>

              {/* Hand-built UI snippet */}
              <div className="bg-cream-2 p-4 rounded-xl border border-line">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-amber mb-2">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>45-Min Delay Handled</span>
                </div>
                <div className="bg-paper p-3 rounded-lg border border-line text-[11px] text-ink-2">
                  <div className="font-medium text-ink">Cab driver re-timed</div>
                  <div className="text-teal font-mono mt-0.5">Cost: ₹0 (No penalty fee)</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================
          BAND 1: FULL-WIDTH PHOTO BAND ("Built around how India travels.")
         ========================================================= */}
      <section className="relative h-56 md:h-80 overflow-hidden flex items-center">
        <img
          src="/images/band-1.webp"
          alt="Sunrise over Bengal from moving train"
          width={1600}
          height={400}
          className="absolute inset-0 w-full h-full object-cover pointer-events-none"
          style={{ backgroundColor: getImageColor('band-1.webp', '#182828') }}
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0B1B2B]/90 via-[#0B1B2B]/70 to-[#0B1B2B]/40 pointer-events-none" />

        <div className="max-w-7xl mx-auto px-6 relative z-10 w-full">
          <div className="max-w-2xl space-y-2">
            <span className="text-xs uppercase font-semibold tracking-wider text-marigold">
              Authentic Indian Transit
            </span>
            <h2 className="font-display text-2xl md:text-4xl font-semibold tracking-tight text-paper">
              Built around how India travels.
            </h2>
            <p className="text-sm md:text-base text-cream/90 leading-relaxed">
              From Vande Bharat morning departures and sleeper berths to heritage haveli courtyards and station auto stands. Every route is verified with real timings.
            </p>
          </div>
        </div>
      </section>

      {/* =========================================================
          SECTION 5: BUDGET DEMO (#budget, DARK --INK SECTION)
         ========================================================= */}
      <section id="budget" className="relative py-20 md:py-28 bg-ink text-cream border-b border-line scroll-mt-16 overflow-hidden">
        {/* Subtle stone lattice texture */}
        <img
          src="/images/band-2.webp"
          alt=""
          className="absolute inset-0 w-full h-full object-cover opacity-10 pointer-events-none hidden md:block"
          aria-hidden="true"
          style={{ backgroundColor: getImageColor('band-2.webp', '#281808') }}
        />

        <div className="max-w-6xl mx-auto px-6 relative z-10">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-xs uppercase font-semibold tracking-wider text-marigold bg-marigold/10 border border-marigold/20 px-3 py-1 rounded-full">
              Live Allocation Engine
            </span>
            <h2 className="font-display text-3xl md:text-4xl font-semibold tracking-tight text-paper mt-3">
              Explore your budget ceiling
            </h2>
            <p className="text-cream-2/70 text-sm md:text-base mt-2">
              Slide to test how our pure mathematical engine partitions any total amount across 5 categories with an automatic 8% protection buffer.
            </p>
          </div>

          <div className="bg-[#102438] border border-[#223B54] rounded-card p-6 md:p-10 shadow-2xl">
            {/* Slider control */}
            <div className="mb-10 text-center">
              <label htmlFor="budgetSlider" className="block text-xs uppercase font-mono tracking-wider text-cream-2/60 mb-2">
                Total Travel Budget
              </label>
              <div className="font-display text-4xl md:text-5xl font-semibold text-marigold tracking-tight mb-4">
                {formatINR(demoBudget)}
              </div>
              <input
                id="budgetSlider"
                type="range"
                min={10000}
                max={40000}
                step={1000}
                value={demoBudget}
                aria-label="Total Travel Budget Slider"
                onChange={(e) => setDemoBudget(Number(e.target.value))}
                className="w-full max-w-xl h-2 bg-ink-2 rounded-lg appearance-none cursor-pointer accent-marigold"
              />
              <div className="flex justify-between max-w-xl mx-auto text-xs text-cream-2/50 font-mono mt-2">
                <span>₹10,000</span>
                <span>₹25,000</span>
                <span>₹40,000</span>
              </div>
            </div>

            {/* Category breakdown bars */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center pt-6 border-t border-[#223B54]">
              {/* Left: Category rows */}
              <div className="space-y-4">
                {[
                  { label: 'Transport (35%)', amount: budgetAllocation.categories.transport, color: 'bg-marigold' },
                  { label: 'Stays (30%)', amount: budgetAllocation.categories.stay, color: 'bg-teal' },
                  { label: 'Food & Dining (15%)', amount: budgetAllocation.categories.food, color: 'bg-amber' },
                  { label: 'Local Transit (10%)', amount: budgetAllocation.categories.local, color: 'bg-blue-400' },
                  { label: 'Experiences (10%)', amount: budgetAllocation.categories.experiences, color: 'bg-purple-400' }
                ].map((cat, idx) => {
                  const pct = Math.round((cat.amount / demoBudget) * 100);
                  return (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-xs font-medium">
                        <span className="text-cream-2">{cat.label}</span>
                        <span className="font-mono text-paper">{formatINR(cat.amount)}</span>
                      </div>
                      <div className="w-full h-2 rounded-full bg-ink overflow-hidden">
                        <div className={`h-full ${cat.color} rounded-full transition-all duration-300`} style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Right: Tier summary & buffer */}
              <div className="bg-ink/70 border border-[#223B54] p-6 rounded-card space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-[#223B54]">
                  <span className="text-xs uppercase font-mono text-cream-2/60">Tier Profile</span>
                  <span className="px-2.5 py-0.5 rounded-full bg-marigold/20 text-marigold text-xs font-semibold">
                    {tierInfo.tier}
                  </span>
                </div>

                <p className="text-sm text-cream-2 leading-relaxed">
                  {tierInfo.desc}
                </p>

                <div className="p-4 bg-teal/10 border border-teal/30 rounded-xl space-y-1 text-xs">
                  <div className="flex items-center justify-between font-semibold text-teal">
                    <span>Emergency Protection Buffer (8%)</span>
                    <span className="font-mono">{formatINR(budgetAllocation.buffer)}</span>
                  </div>
                  <p className="text-cream-2/70 text-[11px] leading-relaxed">
                    Automatically reserved in every plan to absorb unexpected delays, surge fares, or last-minute itinerary adjustments.
                  </p>
                </div>

                <button
                  onClick={handleStartPlanning}
                  className="w-full py-3 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-sm rounded-btn transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Build full trip for {formatINR(demoBudget)}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================
          SECTION 6: DESTINATIONS
         ========================================================= */}
      <section id="destinations" className="py-20 md:py-28 bg-cream border-b border-line scroll-mt-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
            <div>
              <span className="text-xs uppercase font-semibold tracking-wider text-ink-3">
                Curated Indian Destinations
              </span>
              <h2 className="font-display text-3xl md:text-4xl font-semibold tracking-tight text-ink mt-2">
                Handcrafted journeys with verified pricing
              </h2>
            </div>
            <p className="text-sm text-ink-2 max-w-md mt-2 md:mt-0">
              Each destination package is pre-calibrated with real train timings, verified boutique stays, and curated local guides.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {DESTINATIONS.map((dest) => {
              const cardImageName = dest.cardImage.replace('/images/', '');
              return (
                <div
                  key={dest.id}
                  className="group bg-paper border border-line rounded-card overflow-hidden shadow-2xs hover:shadow-md transition-all flex flex-col"
                >
                  {/* Photo with credit */}
                  <div
                    className="relative h-48 overflow-hidden"
                    style={{ backgroundColor: getImageColor(cardImageName, '#182028') }}
                  >
                    <img
                      src={dest.cardImage}
                      alt={dest.name}
                      width={900}
                      height={675}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />
                    <div className="absolute top-3 right-3 px-2.5 py-1 bg-ink/80 text-cream text-xs font-medium rounded-full backdrop-blur-sm">
                      {dest.durationDays} Days
                    </div>
                  </div>

                  {/* Details */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <h3 className="font-display text-xl font-semibold text-ink">{dest.name}</h3>
                        <span className="text-xs font-mono font-semibold text-teal">{dest.state}</span>
                      </div>
                      <p className="text-xs text-ink-2 line-clamp-2 leading-relaxed mb-4">
                        {dest.description}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-line flex items-center justify-between">
                      <div>
                        <div className="text-[11px] text-ink-3">Typical 3-day trip from</div>
                        <div className="font-display text-lg font-semibold text-ink">
                          {formatINR(dest.typicalTripPrice)}{' '}
                          <span className="text-xs font-normal text-ink-3 font-sans">(estimated)</span>
                        </div>
                      </div>
                      <button
                        onClick={() => handleDestinationPlan(dest.id)}
                        className="px-3.5 py-2 bg-cream hover:bg-marigold text-ink hover:text-marigold-ink border border-line hover:border-marigold text-xs font-semibold rounded-btn transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <span>Plan this</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* =========================================================
          SECTION 7: JOURNEY RESCUE (#rescue)
         ========================================================= */}
      <section id="rescue" className="py-20 md:py-28 bg-paper border-b border-line scroll-mt-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left explanation + Photo */}
            <div className="lg:col-span-5 space-y-6">
              <div className="overflow-hidden rounded-2xl border border-line shadow-sm" style={{ backgroundColor: getImageColor('rescue-station.webp', '#1b1a1c') }}>
                <img
                  src="/images/rescue-station.webp"
                  alt="Nagda Junction railway platform at dawn"
                  width={900}
                  height={600}
                  className="w-full h-64 md:h-72 object-cover"
                  loading="lazy"
                />
              </div>

              <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber/15 text-amber border border-amber/30 rounded-full text-xs font-semibold">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Active Journey Protection</span>
              </div>

              <h2 className="font-display text-3xl md:text-4xl font-semibold tracking-tight text-ink leading-tight">
                When plans change on the road, Journey Rescue steps in.
              </h2>

              <p className="text-base text-ink-2 leading-relaxed">
                A delayed train shouldn't ruin your evening. Plan My Trip detects downstream disruptions, contacts drivers, and re-sequences appointments using your reserved buffer.
              </p>

              <div className="space-y-3 pt-2">
                {[
                  'Automatic delay detection across Indian Railways and domestic flights',
                  'Calculates domino effects on pre-booked cabs and hotel check-in times',
                  'Provides instant one-tap recovery options with clear financial impact'
                ].map((text, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-sm text-ink-2">
                    <CheckCircle2 className="w-4.5 h-4.5 text-teal flex-shrink-0 mt-0.5" />
                    <span>{text}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Right simulation card */}
            <div className="lg:col-span-7 bg-cream border border-line rounded-card p-6 md:p-8 shadow-sm">
              <div className="flex items-center justify-between pb-4 border-b border-line">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-coral animate-ping" />
                  <span className="font-semibold text-sm text-coral">Disruption Scenario: 45-Min Train Delay</span>
                </div>
                <span className="text-xs font-mono text-ink-3">Train 12015 Ajmer Shatabdi</span>
              </div>

              {/* Timeline strip with domino impact */}
              <div className="py-6 space-y-4">
                <div className="relative pl-6 border-l-2 border-line space-y-6">
                  <div className="relative">
                    <span className="absolute -left-[31px] top-0.5 w-4 h-4 rounded-full bg-coral border-2 border-paper" />
                    <div className="text-xs font-semibold text-ink">10:45 AM (Expected 10:00 AM)</div>
                    <div className="text-sm font-medium text-coral">Arrival delayed by 45 minutes</div>
                  </div>

                  <div className="relative">
                    <span className="absolute -left-[31px] top-0.5 w-4 h-4 rounded-full bg-amber border-2 border-paper" />
                    <div className="text-xs font-semibold text-ink">10:15 AM Scheduled Pickup</div>
                    <div className="text-sm text-ink-2">Station cab driver waiting fee risk: ₹150</div>
                  </div>

                  <div className="relative">
                    <span className="absolute -left-[31px] top-0.5 w-4 h-4 rounded-full bg-teal border-2 border-paper" />
                    <div className="text-xs font-semibold text-ink">11:30 AM Hotel Check-in</div>
                    <div className="text-sm text-ink-2">Haveli Dharampura desk notified</div>
                  </div>
                </div>

                {/* Resolution options */}
                <div className="pt-4 space-y-3">
                  <div className="text-xs uppercase font-mono tracking-wider text-ink-3">Recommended Actions</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="bg-paper p-4 rounded-xl border border-teal/40 space-y-1.5">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-ink">Option A: Re-time Cab</span>
                        <span className="text-xs font-mono text-teal font-semibold">+₹0</span>
                      </div>
                      <p className="text-[11px] text-ink-2 leading-relaxed">
                        Driver notified to arrive at 10:45 AM. Zero cancellation or waiting penalty.
                      </p>
                      <span className="inline-block px-2 py-0.5 bg-teal/10 text-teal text-[10px] font-semibold rounded">
                        Recommended
                      </span>
                    </div>

                    <div className="bg-paper p-4 rounded-xl border border-line space-y-1.5 opacity-80">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-ink">Option B: Switch to Prepaid</span>
                        <span className="text-xs font-mono text-amber font-semibold">+₹250</span>
                      </div>
                      <p className="text-[11px] text-ink-2 leading-relaxed">
                        Release current driver and book station booth cab upon arrival. Absorbed by buffer.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================
          SECTION 8: ALEXA VOICE DEMO (#alexa)
         ========================================================= */}
      <section id="alexa" className="py-20 md:py-28 bg-cream border-b border-line scroll-mt-16">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-xs uppercase font-semibold tracking-wider text-ink-3">
              Alexa+ Voice & Multi-Tool Engine
            </span>
            <h2 className="font-display text-3xl md:text-4xl font-semibold tracking-tight text-ink mt-2">
              Speak or type to plan your entire trip
            </h2>
            <p className="text-sm md:text-base text-ink-2 mt-2">
              Alexa executes verified travel tools in the background while keeping you informed of every decision and budget trade-off.
            </p>
          </div>

          <div className="bg-paper border border-line rounded-card shadow-sm overflow-hidden">
            {/* Voice header */}
            <div className="bg-cream/60 px-6 py-4 border-b border-line flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${alexaState === 'listening' ? 'bg-marigold text-marigold-ink ring-4 ring-marigold/30' : 'bg-ink text-cream'}`}>
                  <Mic className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-semibold text-sm text-ink">Interactive Voice Assistant</div>
                  <div className="text-xs text-ink-3">Deterministic Travel Engine v2.4</div>
                </div>
              </div>
              <button
                onClick={() => setAlexaState(alexaState === 'listening' ? 'idle' : 'listening')}
                className="px-3 py-1.5 bg-paper hover:bg-cream border border-line rounded-btn text-xs font-medium text-ink transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Volume2 className="w-3.5 h-3.5 text-marigold" />
                <span>{alexaState === 'listening' ? 'Stop Listening' : 'Test Voice Pulse'}</span>
              </button>
            </div>

            {/* Transcript simulation */}
            <div className="p-6 md:p-8 space-y-4">
              <div className="flex gap-3">
                <div className="w-7 h-7 rounded-full bg-cream-2 border border-line flex items-center justify-center text-xs font-bold text-ink-2 flex-shrink-0">
                  U
                </div>
                <div className="bg-cream p-3.5 rounded-xl border border-line text-sm text-ink max-w-xl">
                  "Plan a 2-day heritage weekend in Delhi for 2 under ₹15,000."
                </div>
              </div>

              <div className="flex gap-3">
                <div className="w-7 h-7 rounded-full bg-marigold text-marigold-ink flex items-center justify-center text-xs font-bold flex-shrink-0">
                  A
                </div>
                <div className="bg-paper p-4 rounded-xl border border-line text-sm text-ink max-w-xl space-y-2 shadow-2xs">
                  <p>
                    I have assembled a balanced plan totaling <strong className="text-teal">₹12,700</strong>, leaving an emergency buffer of <strong className="text-teal">₹1,100</strong>.
                  </p>
                  <div className="p-3 bg-cream rounded-lg border border-line text-xs text-ink-2 space-y-1">
                    <div className="flex justify-between font-medium text-ink">
                      <span>• Vande Bharat Express (2 AC Chair Car)</span>
                      <span>₹2,400</span>
                    </div>
                    <div className="flex justify-between font-medium text-ink">
                      <span>• Haveli Dharampura (2 Nights)</span>
                      <span>₹6,800</span>
                    </div>
                    <div className="flex justify-between font-medium text-ink">
                      <span>• Red Fort & Qutub Minar Entry + Cab</span>
                      <span>₹3,500</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <div className="w-7 h-7 rounded-full bg-cream-2 border border-line flex items-center justify-center text-xs font-bold text-ink-2 flex-shrink-0">
                  U
                </div>
                <div className="bg-cream p-3.5 rounded-xl border border-line text-sm text-ink max-w-xl">
                  "Add the Old Delhi culinary street food trail."
                </div>
              </div>

              <div className="flex gap-3">
                <div className="w-7 h-7 rounded-full bg-marigold text-marigold-ink flex items-center justify-center text-xs font-bold flex-shrink-0">
                  A
                </div>
                <div className="bg-paper p-4 rounded-xl border border-marigold/40 text-sm text-ink max-w-xl space-y-3 shadow-2xs">
                  <p>
                    Added Old Delhi Culinary Walk (+₹1,800). Your total is now <strong className="text-amber">₹14,500</strong>. This utilizes <strong className="text-amber">₹700</strong> of your emergency buffer, but remains within your ₹15,000 ceiling.
                  </p>
                  <div className="p-3 bg-amber/10 border border-amber/30 rounded-lg text-xs space-y-2">
                    <div className="font-semibold text-amber flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span>Approval required to draw from buffer</span>
                    </div>
                    <button
                      onClick={handleStartPlanning}
                      className="px-3.5 py-1.5 bg-marigold hover:bg-marigold-hover text-marigold-ink text-xs font-semibold rounded-btn transition-colors cursor-pointer"
                    >
                      Approve & Update Trip Draft
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Tool execution trace */}
            <div className="bg-cream-2 px-6 py-4 border-t border-line text-xs font-mono text-ink-3 flex flex-wrap items-center gap-3">
              <span className="font-semibold text-ink-2">Background Tools:</span>
              <span className="px-2 py-0.5 bg-paper rounded border border-line">search_transport()</span>
              <span className="px-2 py-0.5 bg-paper rounded border border-line">calculate_budget(₹15,000)</span>
              <span className="px-2 py-0.5 bg-paper rounded border border-line text-teal">request_budget_approval()</span>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================
          SECTION 9: YOUR ENTIRE JOURNEY (5-STAGE TIMELINE WITH PHOTOS)
         ========================================================= */}
      <section className="py-20 bg-paper border-b border-line">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-xl mx-auto mb-14">
            <h2 className="font-display text-3xl font-semibold tracking-tight text-ink">
              One unbroken lifecycle
            </h2>
            <p className="text-sm text-ink-2 mt-2">
              From the first spark of inspiration to your journey's final saved memories.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5 relative">
            {[
              {
                num: '01',
                title: 'Spark',
                desc: 'Describe your dream trip in natural language over chai',
                image: '/images/journey-1.webp',
                alt: 'Traveler route planning over morning cutting chai'
              },
              {
                num: '02',
                title: 'Plan',
                desc: 'Auto-allocate transport, stays, and budget with strict ceilings',
                image: '/images/journey-2.webp',
                alt: 'Lush countryside view from train window at dawn'
              },
              {
                num: '03',
                title: 'Refine',
                desc: 'Swap hotel rooms or add guided tours in 1 tap',
                image: '/images/journey-3.webp',
                alt: 'Rajasthan heritage boutique hotel room with warm sunlight'
              },
              {
                num: '04',
                title: 'Rescue',
                desc: 'Delay detection and driver rescheduling with buffer',
                image: '/images/journey-4.webp',
                alt: 'Station taxi parked outside portico at dawn'
              },
              {
                num: '05',
                title: 'Memory',
                desc: 'One permanent saved itinerary for your records',
                image: '/images/journey-5.webp',
                alt: 'Varanasi ghats sunrise traveler silhouette'
              }
            ].map((step, idx) => {
              const imgName = step.image.replace('/images/', '');
              return (
                <div
                  key={idx}
                  className="bg-cream/40 rounded-card border border-line overflow-hidden flex flex-col shadow-2xs hover:shadow-md transition-shadow"
                >
                  <div
                    className="h-44 w-full overflow-hidden relative"
                    style={{ backgroundColor: getImageColor(imgName, '#182028') }}
                  >
                    <img
                      src={step.image}
                      alt={step.alt}
                      width={900}
                      height={675}
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                      loading="lazy"
                    />
                    <span className="absolute top-2.5 left-2.5 px-2 py-0.5 bg-ink/85 text-paper text-[11px] font-mono font-bold rounded">
                      {step.num}
                    </span>
                  </div>
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="font-display text-lg font-semibold text-ink mb-1">{step.title}</h3>
                      <p className="text-xs text-ink-2 leading-relaxed">{step.desc}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* =========================================================
          SECTION 10: PROMISES (3 OPEN COLUMNS)
         ========================================================= */}
      <section className="py-20 md:py-28 bg-cream border-b border-line">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center max-w-xl mx-auto mb-14">
            <h2 className="font-display text-3xl font-semibold tracking-tight text-ink">
              Our core commitments
            </h2>
            <p className="text-sm text-ink-2 mt-2">
              Built on mathematical rigor and transparent user consent.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-paper border border-line flex items-center justify-center text-marigold shadow-2xs">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="font-display text-xl font-semibold text-ink">
                Never exceed your ceiling
              </h3>
              <p className="text-sm text-ink-2 leading-relaxed">
                We never suggest packages that break your spending cap. Our pure arithmetic engine treats your budget as an absolute ceiling.
              </p>
            </div>

            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-paper border border-line flex items-center justify-center text-teal shadow-2xs">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <h3 className="font-display text-xl font-semibold text-ink">
                Always ask before spending
              </h3>
              <p className="text-sm text-ink-2 leading-relaxed">
                Alexa never books or charges without your review. Every itinerary adjustment or buffer withdrawal requires your explicit approval click.
              </p>
            </div>

            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-paper border border-line flex items-center justify-center text-marigold shadow-2xs">
                <Clock className="w-5 h-5" />
              </div>
              <h3 className="font-display text-xl font-semibold text-ink">
                Keep one living trip
              </h3>
              <p className="text-sm text-ink-2 leading-relaxed">
                No disjointed spreadsheets or lost confirmation emails. Your tickets, stays, vouchers, and updates live together in one clean workspace.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================
          SECTION 11: FAQ ACCORDION (5 SPECIFIC QUESTIONS)
         ========================================================= */}
      <section className="py-20 md:py-28 bg-paper border-b border-line">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-12">
            <span className="text-xs uppercase font-semibold tracking-wider text-ink-3">
              Questions & Answers
            </span>
            <h2 className="font-display text-3xl font-semibold tracking-tight text-ink mt-2">
              Frequently asked questions
            </h2>
          </div>

          <div className="divide-y divide-line border-y border-line">
            {[
              {
                q: 'Does Plan My Trip actually book and charge cards?',
                a: 'No. In this presentation prototype, all data is sample data. Nothing is booked or charged, and no real credit card numbers or payment methods are requested.'
              },
              {
                q: 'What is the Alexa integration?',
                a: 'Plan My Trip features an Alexa+ simulation powered by our custom deterministic client with full Model Context Protocol (MCP) tool support. It operates fully offline for fail-proof demos and can switch to a live MCP backend via a single environment variable.'
              },
              {
                q: 'How does the 8% emergency buffer work?',
                a: 'Our budget engine automatically holds back 8% of your overall ceiling (e.g. ₹1,200 on a ₹15,000 budget). This buffer absorbs unexpected surge prices, driver waiting fees, or voluntary mid-trip additions without ever exceeding your total budget.'
              },
              {
                q: 'What happens when a train or flight is delayed?',
                a: 'Journey Rescue evaluates the delay length (15 to 90 minutes) and simulates domino effects across connecting station taxis and hotel check-in desks. It offers one-click re-scheduling options that utilize your buffer.'
              },
              {
                q: 'Can I use the app without speaking out loud?',
                a: 'Yes, absolutely. The interface fully supports typing through the central composer, using the interactive budget slider, or selecting options directly from the visual workspace.'
              }
            ].map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div key={idx} className="py-4">
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full text-left flex items-center justify-between py-2 text-base font-semibold text-ink hover:text-marigold transition-colors cursor-pointer"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown className={`w-5 h-5 text-ink-3 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {isOpen && (
                    <div className="mt-2 text-sm text-ink-2 leading-relaxed pr-8">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* =========================================================
          SECTION 12: FINAL CTA WITH FULL-BLEED SUNRISE PHOTO
         ========================================================= */}
      <section className="relative py-24 md:py-32 bg-ink text-cream overflow-hidden">
        {/* Full-bleed background photo */}
        <img
          src="/images/cta-sunrise.webp"
          alt="Western Ghats sunrise over hills"
          width={1600}
          height={600}
          className="absolute inset-0 w-full h-full object-cover pointer-events-none"
          style={{ backgroundColor: getImageColor('cta-sunrise.webp', '#1a191d') }}
          loading="lazy"
        />

        {/* Ink overlay for guaranteed contrast */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#0B1B2B]/90 via-[#0B1B2B]/85 to-[#0B1B2B]/90 pointer-events-none" />

        <div className="max-w-4xl mx-auto px-6 text-center space-y-6 relative z-10">
          <h2 className="font-display text-3xl md:text-5xl font-semibold tracking-tight text-paper">
            Ready to plan your next journey without the spreadsheet chaos?
          </h2>
          <p className="text-base text-cream-2/90 max-w-xl mx-auto leading-relaxed">
            Experience how natural conversation and strict budget limits make travel planning effortless.
          </p>
          <div className="pt-2">
            <button
              onClick={handleStartPlanning}
              className="px-8 py-4 bg-marigold hover:bg-marigold-hover text-marigold-ink font-semibold text-base rounded-btn transition-all shadow-md inline-flex items-center gap-2 cursor-pointer"
            >
              <Mic className="w-5 h-5" />
              <span>Start with Alexa</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* =========================================================
          FOOTER
         ========================================================= */}
      <footer className="bg-[#07131F] text-cream-2/70 py-12 border-t border-[#1C2C3C] text-xs">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2.5 text-paper">
            <div className="w-7 h-7 rounded-md bg-marigold flex items-center justify-center text-marigold-ink">
              <Compass className="w-4 h-4" />
            </div>
            <span className="font-display font-semibold text-sm">Plan My Trip</span>
          </div>

          <div className="flex flex-wrap justify-center gap-6">
            <a href="#how-it-works" className="hover:text-paper transition-colors">How it works</a>
            <a href="#budget" className="hover:text-paper transition-colors">Budget demo</a>
            <a href="#destinations" className="hover:text-paper transition-colors">Destinations</a>
            <a href="#rescue" className="hover:text-paper transition-colors">Journey Rescue</a>
            <Link to="/credits" className="text-marigold hover:underline flex items-center gap-1 font-medium">
              Photo credits & attribution
              <ExternalLink className="w-3 h-3" />
            </Link>
          </div>

          <div className="text-center md:text-right">
            <div>Hackathon Prototype · Sample Data Only</div>
            <div className="text-cream-2/40 text-[11px] mt-1">© 2026 Plan My Trip. Independent voice travel simulation.</div>
          </div>
        </div>
      </footer>
    </div>
  );
}
