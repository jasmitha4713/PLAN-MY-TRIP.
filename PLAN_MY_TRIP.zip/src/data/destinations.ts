/**
 * Plan My Trip - Destination Database & Transport Generator
 * Supported cities: 14 Indian cities with real coordinates, attractions, stays, and transit.
 * All prices are marked "Estimated" in accordance with the Honesty Model.
 */

export interface CityCoordinates {
  lat: number;
  lng: number;
}

export interface AttractionData {
  id: string;
  name: string;
  area: string;
  typicalVisitTime: string;
  ticketPricePerPerson: number; // 0 = Free
  image: string;
  description: string;
  isHeritage?: boolean;
}

export interface StayData {
  id: string;
  name: string;
  tier: 'budget' | 'boutique' | 'luxury';
  area: string;
  roomType: string;
  ratePerNight: number; // In rupees (₹)
  rating: number;
  inclusions: string[];
  image: string;
}

export interface BikeModel {
  id: string;
  name: string;
  category: 'scooter' | 'commuter' | 'cruiser';
  dailyRate: number;
  engineCc: string;
  image: string;
}

export interface LocalTransportData {
  hasMetro: boolean;
  metroPassPerDay?: number;
  autoPerRide: number;
  cabFullDay: number;
  airportPickupCab: number;
  stationPickupCab: number;
  bikeModels: BikeModel[];
  carSelfDriveDaily: number;
  carWithDriverDaily: number;
}

export interface FoodExperienceData {
  id: string;
  name: string;
  type: 'street_food_walk' | 'heritage_thali' | 'curated_dinner';
  pricePerPerson: number;
  duration: string;
  description: string;
  image: string;
}

export interface DestinationInfo {
  id: string;
  name: string;
  state: string;
  coords: CityCoordinates;
  cardImage: string;
  bannerImage: string;
  description: string;
  defaultDays: number;
  attractions: AttractionData[];
  stays: StayData[];
  localTransit: LocalTransportData;
  foodExperiences: FoodExperienceData[];
}

// 14 Supported Indian Destinations / Origins
export const SUPPORTED_CITIES: DestinationInfo[] = [
  {
    id: 'delhi',
    name: 'New Delhi',
    state: 'Delhi NCR',
    coords: { lat: 28.6139, lng: 77.2090 },
    cardImage: '/images/dest-delhi-card.webp',
    bannerImage: '/images/dest-delhi-banner.webp',
    description: 'Monumental Mughal architecture, centuries of imperial history, and bustling Old Delhi markets.',
    defaultDays: 3,
    attractions: [
      { id: 'del-1', name: 'India Gate & Kartavya Path', area: 'Central Delhi', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 0, image: '/images/delhi.webp', description: 'National war memorial arch with open lawns, evening illumination and ice cream vendors.' },
      { id: 'del-2', name: 'Qutub Minar Complex', area: 'Mehrauli', typicalVisitTime: '2 hours', ticketPricePerPerson: 50, image: '/images/qutub-minar.webp', description: '73-meter medieval minaret and UNESCO heritage complex dating to 1192 AD.', isHeritage: true },
      { id: 'del-3', name: "Humayun's Tomb", area: 'Nizamuddin East', typicalVisitTime: '2 hours', ticketPricePerPerson: 50, image: '/images/humayuns-tomb.webp', description: 'Precursor to the Taj Mahal with expansive Persian Charbagh water gardens.', isHeritage: true },
      { id: 'del-4', name: 'Red Fort (Lal Qila)', area: 'Old Delhi', typicalVisitTime: '2.5 hours', ticketPricePerPerson: 50, image: '/images/dest-delhi-card.webp', description: 'Massive red sandstone fortified palace of Mughal emperors overlooking Chandni Chowk.', isHeritage: true },
      { id: 'del-5', name: 'Chandni Chowk & Khari Baoli', area: 'Old Delhi', typicalVisitTime: '3 hours', ticketPricePerPerson: 0, image: '/images/street-food.webp', description: '300-year-old spice market lanes, historic jalebi shops, and heritage havelis.' },
      { id: 'del-6', name: 'Lotus Temple (Baháʼí House of Worship)', area: 'Kalkaji', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 0, image: '/images/dest-delhi-card.webp', description: 'Marble lotus flower temple dedicated to silent meditation and universal peace.' },
      { id: 'del-7', name: 'Lodhi Art District & Gardens', area: 'Lodhi Estate', typicalVisitTime: '2 hours', ticketPricePerPerson: 0, image: '/images/dest-delhi-banner.webp', description: 'Open-air public art street murals alongside 15th-century Sayyid and Lodi tombs.' }
    ],
    stays: [
      { id: 'del-stay-1', name: 'Paharganj Travellers Inn', tier: 'budget', area: 'Paharganj (near Station)', roomType: 'Standard AC Room', ratePerNight: 1200, rating: 4.1, inclusions: ['Free WiFi', 'Breakfast included', '24/7 Front Desk'], image: '/images/thumb-stay-budget.webp' },
      { id: 'del-stay-2', name: 'Haveli Dharampura Heritage', tier: 'boutique', area: 'Chandni Chowk', roomType: 'Courtyard Heritage Suite', ratePerNight: 3400, rating: 4.7, inclusions: ['Rooftop Pigeon Flying View', 'Breakfast included', 'Chai on arrival'], image: '/images/thumb-stay-haveli.webp' },
      { id: 'del-stay-3', name: 'The Claridges Lutyens Wing', tier: 'luxury', area: 'Dr APJ Abdul Kalam Road', roomType: 'Deluxe Heritage Room', ratePerNight: 6800, rating: 4.9, inclusions: ['Buffet Breakfast', 'Airport Transfer', 'Butler Service'], image: '/images/thumb-stay-boutique.webp' }
    ],
    localTransit: {
      hasMetro: true,
      metroPassPerDay: 150,
      autoPerRide: 90,
      cabFullDay: 1800,
      airportPickupCab: 650,
      stationPickupCab: 250,
      bikeModels: [
        { id: 'activa', name: 'Honda Activa 6G', category: 'scooter', dailyRate: 450, engineCc: '110cc', image: '/images/thumb-rental.webp' },
        { id: 'pulsar', name: 'Bajaj Pulsar 150', category: 'commuter', dailyRate: 650, engineCc: '150cc', image: '/images/thumb-rental.webp' },
        { id: 'classic', name: 'Royal Enfield Classic 350', category: 'cruiser', dailyRate: 1100, engineCc: '350cc', image: '/images/thumb-rental.webp' }
      ],
      carSelfDriveDaily: 1900,
      carWithDriverDaily: 2400
    },
    foodExperiences: [
      { id: 'del-food-1', name: 'Old Delhi Midnight Culinary Walk', type: 'street_food_walk', pricePerPerson: 650, duration: '2.5 hours', description: 'Curated taste tour through Paranthe Wali Gali, Natraj Dahi Bhalla, and heritage rabri shops.', image: '/images/thumb-exp-culinary.webp' },
      { id: 'del-food-2', name: 'Purani Dilli Dastarkhwan Heritage Dinner', type: 'heritage_thali', pricePerPerson: 950, duration: '2 hours', description: 'Traditional multi-course Mughlai spread served in a restored rooftop haveli courtyard.', image: '/images/thumb-exp-heritage.webp' }
    ]
  },
  {
    id: 'mumbai',
    name: 'Mumbai',
    state: 'Maharashtra',
    coords: { lat: 19.0760, lng: 72.8777 },
    cardImage: '/images/dest-delhi-card.webp',
    bannerImage: '/images/band-1.webp',
    description: 'Colonial Gothic architecture, breezy Arabian sea promenades, Art Deco precincts, and Bollywood spirit.',
    defaultDays: 3,
    attractions: [
      { id: 'mum-1', name: 'Gateway of India', area: 'Colaba', typicalVisitTime: '1 hour', ticketPricePerPerson: 0, image: '/images/band-1.webp', description: 'Iconic 1924 basalt arch monument overlooking Mumbai Harbour and the Taj Mahal Palace.' },
      { id: 'mum-2', name: 'Marine Drive & Chowpatty', area: 'Nariman Point', typicalVisitTime: '2 hours', ticketPricePerPerson: 0, image: '/images/band-2.webp', description: 'Curved 3.6-kilometer seaside promenade known as the Queen’s Necklace.' },
      { id: 'mum-3', name: 'Chhatrapati Shivaji Maharaj Terminus (CSMT)', area: 'Fort', typicalVisitTime: '1 hour', ticketPricePerPerson: 0, image: '/images/rescue-station.webp', description: 'UNESCO World Heritage Victorian Gothic railway terminus with gargoyles and stained glass.', isHeritage: true },
      { id: 'mum-4', name: 'Elephanta Caves Island Boat Trip', area: 'Mumbai Harbour', typicalVisitTime: '4 hours', ticketPricePerPerson: 280, image: '/images/dest-hampi-card.webp', description: 'Rock-cut Shiva cave temples dating to the 5th century reached by heritage ferry.', isHeritage: true },
      { id: 'mum-5', name: 'Kala Ghoda Art & Heritage Precinct', area: 'Fort', typicalVisitTime: '2 hours', ticketPricePerPerson: 0, image: '/images/dest-delhi-banner.webp', description: 'Historic arts district filled with galleries, indie bookstores, and street cafes.' },
      { id: 'mum-6', name: 'Bandra Bandstand & Castella de Aguada', area: 'Bandra West', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 0, image: '/images/dest-coorg-card.webp', description: 'Portuguese fort ruins overlooking the Arabian Sea and the Bandra-Worli Sea Link.' }
    ],
    stays: [
      { id: 'mum-stay-1', name: 'Colaba Backpackers Haven', tier: 'budget', area: 'Colaba Causeway', roomType: 'Bunk in 4-Bed AC Dorm', ratePerNight: 1350, rating: 4.2, inclusions: ['Free WiFi', 'Locker included', 'Filtered Water'], image: '/images/thumb-stay-budget.webp' },
      { id: 'mum-stay-2', name: 'Fort Heritage Art Deco Residency', tier: 'boutique', area: 'Fort / Kala Ghoda', roomType: 'Heritage Studio', ratePerNight: 3800, rating: 4.6, inclusions: ['Breakfast included', 'Espresso bar access', 'Air Conditioning'], image: '/images/thumb-stay-haveli.webp' },
      { id: 'mum-stay-3', name: 'Sea View Suite at Apollo Bunder', tier: 'luxury', area: 'Apollo Bunder', roomType: 'Grand Harbour View Room', ratePerNight: 7200, rating: 4.9, inclusions: ['Sea view', 'Full breakfast', 'Chauffeur pickup'], image: '/images/thumb-stay-boutique.webp' }
    ],
    localTransit: {
      hasMetro: true,
      metroPassPerDay: 120,
      autoPerRide: 60,
      cabFullDay: 2200,
      airportPickupCab: 750,
      stationPickupCab: 300,
      bikeModels: [
        { id: 'activa', name: 'Honda Activa 6G', category: 'scooter', dailyRate: 500, engineCc: '110cc', image: '/images/thumb-rental.webp' },
        { id: 'pulsar', name: 'Bajaj Pulsar 150', category: 'commuter', dailyRate: 700, engineCc: '150cc', image: '/images/thumb-rental.webp' },
        { id: 'classic', name: 'Royal Enfield Classic 350', category: 'cruiser', dailyRate: 1200, engineCc: '350cc', image: '/images/thumb-rental.webp' }
      ],
      carSelfDriveDaily: 2100,
      carWithDriverDaily: 2800
    },
    foodExperiences: [
      { id: 'mum-food-1', name: 'Girgaon & Chowpatty Chaat Trail', type: 'street_food_walk', pricePerPerson: 500, duration: '2 hours', description: 'Authentic tasting of Sev Puri, Bhel Puri, Pav Bhaji, and Kulfi Falooda.', image: '/images/thumb-exp-culinary.webp' },
      { id: 'mum-food-2', name: 'Coastal Malvani Thali Feast', type: 'heritage_thali', pricePerPerson: 850, duration: '1.5 hours', description: 'Traditional Konkani thali with coconut solkadhi, fried surmai or coastal veg curry.', image: '/images/thumb-exp-heritage.webp' }
    ]
  },
  {
    id: 'jaipur',
    name: 'Jaipur',
    state: 'Rajasthan',
    coords: { lat: 26.9124, lng: 75.7873 },
    cardImage: '/images/dest-jaipur-card.webp',
    bannerImage: '/images/dest-jaipur-banner.webp',
    description: 'Amber sandstone fortresses, geometric astronomical observatories, and royal Pink City bazaars.',
    defaultDays: 3,
    attractions: [
      { id: 'jai-1', name: 'Amber Fort (Amer Palace)', area: 'Amer', typicalVisitTime: '3 hours', ticketPricePerPerson: 100, image: '/images/jaipur.webp', description: 'Majestic hilltop fort with Sheesh Mahal (hall of mirrors) and Maota Lake views.', isHeritage: true },
      { id: 'jai-2', name: 'Hawa Mahal (Palace of Winds)', area: 'Pink City', typicalVisitTime: '1 hour', ticketPricePerPerson: 50, image: '/images/dest-jaipur-card.webp', description: '953 intricately carved sandstone jharokha honeycomb windows.', isHeritage: true },
      { id: 'jai-3', name: 'Jantar Mantar Observatory', area: 'City Palace Precinct', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 50, image: '/images/dest-jaipur-banner.webp', description: 'UNESCO collection of 19 architectural astronomical instruments built by Sawai Jai Singh II.', isHeritage: true },
      { id: 'jai-4', name: 'City Palace & Mubarak Mahal', area: 'Old City', typicalVisitTime: '2 hours', ticketPricePerPerson: 200, image: '/images/dest-jaipur-card.webp', description: 'Royal Rajput and Mughal courtyard palace complex and museum.', isHeritage: true },
      { id: 'jai-5', name: 'Nahargarh Fort Sunset Point', area: 'Aravalli Hills', typicalVisitTime: '2 hours', ticketPricePerPerson: 50, image: '/images/jaipur.webp', description: 'Hilltop ramparts with panoramic sunset views over the entire Pink City.' },
      { id: 'jai-6', name: 'Johari Bazaar & Bapu Bazaar', area: 'Pink City', typicalVisitTime: '2 hours', ticketPricePerPerson: 0, image: '/images/street-food.webp', description: 'Traditional Rajasthani tie-dye bandhani textiles, mojari shoes, and silver jewellery.' }
    ],
    stays: [
      { id: 'jai-stay-1', name: 'Zostel Jaipur Old City', tier: 'budget', area: 'M.I. Road', roomType: 'Cozy Private Room', ratePerNight: 1100, rating: 4.4, inclusions: ['Rooftop cafe', 'Free WiFi', 'Walking tour'], image: '/images/thumb-stay-budget.webp' },
      { id: 'jai-stay-2', name: 'Arya Niwas Heritage Haveli', tier: 'boutique', area: 'Sansar Chandra Road', roomType: 'Heritage Deluxe Room', ratePerNight: 2800, rating: 4.7, inclusions: ['Lush garden courtyard', 'Breakfast included', 'Purified water'], image: '/images/thumb-stay-haveli.webp' },
      { id: 'jai-stay-3', name: 'Shahpura House Heritage Palace', tier: 'luxury', area: 'Bani Park', roomType: 'Royal Suite', ratePerNight: 5800, rating: 4.8, inclusions: ['Swimming pool', 'Royal breakfast', 'Puppet show'], image: '/images/thumb-stay-boutique.webp' }
    ],
    localTransit: {
      hasMetro: true,
      metroPassPerDay: 100,
      autoPerRide: 70,
      cabFullDay: 1600,
      airportPickupCab: 500,
      stationPickupCab: 200,
      bikeModels: [
        { id: 'activa', name: 'Honda Activa 6G', category: 'scooter', dailyRate: 400, engineCc: '110cc', image: '/images/thumb-rental.webp' },
        { id: 'pulsar', name: 'Bajaj Pulsar 150', category: 'commuter', dailyRate: 600, engineCc: '150cc', image: '/images/thumb-rental.webp' },
        { id: 'classic', name: 'Royal Enfield Classic 350', category: 'cruiser', dailyRate: 1000, engineCc: '350cc', image: '/images/thumb-rental.webp' }
      ],
      carSelfDriveDaily: 1700,
      carWithDriverDaily: 2200
    },
    foodExperiences: [
      { id: 'jai-food-1', name: 'Pink City Sweets & Lassi Walk', type: 'street_food_walk', pricePerPerson: 400, duration: '2 hours', description: 'Lassiwala kulhad lassi, Rawat Pyaz Kachori, and authentic ghevar.', image: '/images/thumb-exp-culinary.webp' },
      { id: 'jai-food-2', name: 'Royal Rajasthani Dal Baati Churma Thali', type: 'heritage_thali', pricePerPerson: 750, duration: '1.5 hours', description: 'Authentic 18-dish Rajasthani thali featuring ghee-soaked baatis and gatte ki sabzi.', image: '/images/thumb-exp-heritage.webp' }
    ]
  },
  {
    id: 'hyderabad',
    name: 'Hyderabad',
    state: 'Telangana',
    coords: { lat: 17.3850, lng: 78.4867 },
    cardImage: '/images/band-1.webp',
    bannerImage: '/images/dest-delhi-banner.webp',
    description: 'Nizami grandeur, 400-year-old Charminar arches, Golconda acoustics, and world-famed biryani.',
    defaultDays: 3,
    attractions: [
      { id: 'hyd-1', name: 'Charminar & Laad Bazaar', area: 'Old City', typicalVisitTime: '2 hours', ticketPricePerPerson: 25, image: '/images/band-1.webp', description: '1591 monument with four 48-meter minarets surrounded by glass lacquer bangle shops.', isHeritage: true },
      { id: 'hyd-2', name: 'Golconda Fort & Sound Show', area: 'Ibrahim Bagh', typicalVisitTime: '3 hours', ticketPricePerPerson: 50, image: '/images/dest-jaipur-card.webp', description: 'Ancient fortress renowned for diamond trade and clapping acoustic architecture.', isHeritage: true },
      { id: 'hyd-3', name: 'Chowmahalla Palace', area: 'Motigallu', typicalVisitTime: '2 hours', ticketPricePerPerson: 100, image: '/images/thumb-stay-haveli.webp', description: 'Magnificent 18th-century palace of the Nizams with Belgian crystal chandeliers.', isHeritage: true },
      { id: 'hyd-4', name: 'Hussain Sagar Lake & Buddha Statue', area: 'Tank Bund', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 80, image: '/images/dest-alleppey-card.webp', description: 'World’s tallest monolithic stone Buddha statue reached by motorboat.' },
      { id: 'hyd-5', name: 'Salar Jung Museum', area: 'Darulshifa', typicalVisitTime: '3 hours', ticketPricePerPerson: 50, image: '/images/dest-delhi-card.webp', description: 'One of India’s top national museums housing the Veiled Rebecca and musical clock.' },
      { id: 'hyd-6', name: 'Qutb Shahi Tombs', area: 'Ibrahim Bagh', typicalVisitTime: '2 hours', ticketPricePerPerson: 40, image: '/images/humayuns-tomb.webp', description: 'Grand domed granite mausoleums of the seven Golconda rulers in serene gardens.' }
    ],
    stays: [
      { id: 'hyd-stay-1', name: 'Nampally Station Lodge', tier: 'budget', area: 'Nampally', roomType: 'Executive AC Room', ratePerNight: 1100, rating: 4.1, inclusions: ['Free WiFi', 'Close to Metro', 'Air Conditioning'], image: '/images/thumb-stay-budget.webp' },
      { id: 'hyd-stay-2', name: 'Banjara Hills Boutique Residency', tier: 'boutique', area: 'Banjara Hills', roomType: 'Courtyard Room', ratePerNight: 2900, rating: 4.7, inclusions: ['Breakfast included', 'Garden view', 'Quiet neighborhood'], image: '/images/thumb-stay-haveli.webp' },
      { id: 'hyd-stay-3', name: 'Taj Krishna Nizami Wing', tier: 'luxury', area: 'Road No. 1, Banjara Hills', roomType: 'Luxury King Suite', ratePerNight: 6500, rating: 4.9, inclusions: ['Breakfast buffet', 'Airport chauffeur', 'Club lounge'], image: '/images/thumb-stay-boutique.webp' }
    ],
    localTransit: {
      hasMetro: true,
      metroPassPerDay: 120,
      autoPerRide: 70,
      cabFullDay: 1700,
      airportPickupCab: 800,
      stationPickupCab: 200,
      bikeModels: [
        { id: 'activa', name: 'Honda Activa 6G', category: 'scooter', dailyRate: 400, engineCc: '110cc', image: '/images/thumb-rental.webp' },
        { id: 'pulsar', name: 'Bajaj Pulsar 150', category: 'commuter', dailyRate: 600, engineCc: '150cc', image: '/images/thumb-rental.webp' },
        { id: 'classic', name: 'Royal Enfield Classic 350', category: 'cruiser', dailyRate: 1000, engineCc: '350cc', image: '/images/thumb-rental.webp' }
      ],
      carSelfDriveDaily: 1800,
      carWithDriverDaily: 2300
    },
    foodExperiences: [
      { id: 'hyd-food-1', name: 'Old City Irani Chai & Osmania Biscuit Walk', type: 'street_food_walk', pricePerPerson: 350, duration: '2 hours', description: 'Historic cafes around Charminar, Nimrah cafe chai, and lukhmi savouries.', image: '/images/thumb-exp-culinary.webp' },
      { id: 'hyd-food-2', name: 'Authentic Nizami Dum Biryani & Haleem Spread', type: 'heritage_thali', pricePerPerson: 700, duration: '1.5 hours', description: 'Woodfire slow-cooked dum biryani, mirchi ka salan, double ka meetha.', image: '/images/thumb-exp-heritage.webp' }
    ]
  },
  {
    id: 'goa',
    name: 'Goa',
    state: 'Goa',
    coords: { lat: 15.2993, lng: 74.1240 },
    cardImage: '/images/dest-alleppey-card.webp',
    bannerImage: '/images/cta-sunrise.webp',
    description: 'Golden sand beaches, whitewashed Portuguese colonial churches, spice plantations, and Konkan cuisine.',
    defaultDays: 4,
    attractions: [
      { id: 'goa-1', name: 'Basilica of Bom Jesus', area: 'Old Goa', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 0, image: '/images/dest-delhi-card.webp', description: 'UNESCO World Heritage baroque church containing the sacred relics of St. Francis Xavier.', isHeritage: true },
      { id: 'goa-2', name: 'Fort Aguada & Lighthouse', area: 'Sinquerim', typicalVisitTime: '2 hours', ticketPricePerPerson: 25, image: '/images/cta-sunrise.webp', description: '17th-century Portuguese fortress commanding panoramic Arabian Sea views.' },
      { id: 'goa-3', name: 'Palolem Beach & Butterfly Island', area: 'South Goa', typicalVisitTime: '3 hours', ticketPricePerPerson: 0, image: '/images/dest-alleppey-banner.webp', description: 'Crescent white-sand bay fringed by coconut palms and gentle warm surf.' },
      { id: 'goa-4', name: 'Fontainhas Latin Quarter Walk', area: 'Panaji', typicalVisitTime: '2 hours', ticketPricePerPerson: 0, image: '/images/dest-coorg-card.webp', description: 'Colorful Portuguese villas with terracotta roofs, wrought iron balconies and bakeries.' },
      { id: 'goa-5', name: 'Dudhsagar Waterfalls Trek', area: 'Sanguem', typicalVisitTime: '5 hours', ticketPricePerPerson: 450, image: '/images/dest-hampi-banner.webp', description: 'Four-tiered sea of milk waterfall cascading 310 meters through dense Western Ghats forest.' },
      { id: 'goa-6', name: 'Anjuna & Vagator Cliffs', area: 'North Goa', typicalVisitTime: '2.5 hours', ticketPricePerPerson: 0, image: '/images/cta-sunrise.webp', description: 'Red laterite cliff lookouts over rocky bays and sunset shacks.' }
    ],
    stays: [
      { id: 'goa-stay-1', name: 'Jungle Hostel Anjuna', tier: 'budget', area: 'Anjuna', roomType: 'Private Bamboo Cabin', ratePerNight: 1200, rating: 4.3, inclusions: ['Breakfast included', 'Hammocks', 'Scooter parking'], image: '/images/thumb-stay-budget.webp' },
      { id: 'goa-stay-2', name: 'Fontainhas Portuguese Heritage Villa', tier: 'boutique', area: 'Panaji Latin Quarter', roomType: 'Colonial Veranda Room', ratePerNight: 3200, rating: 4.8, inclusions: ['Traditional breakfast', 'Courtyard pool', 'Bicycle use'], image: '/images/thumb-stay-haveli.webp' },
      { id: 'goa-stay-3', name: 'Alila Diwa Coastal Resort', tier: 'luxury', area: 'Majorda Beach', roomType: 'Paddy View Suite', ratePerNight: 7500, rating: 4.9, inclusions: ['Infinity pool', 'Breakfast buffet', 'Airport transfer'], image: '/images/thumb-stay-boutique.webp' }
    ],
    localTransit: {
      hasMetro: false,
      autoPerRide: 120,
      cabFullDay: 2400,
      airportPickupCab: 950,
      stationPickupCab: 600,
      bikeModels: [
        { id: 'activa', name: 'Honda Activa 6G', category: 'scooter', dailyRate: 400, engineCc: '110cc', image: '/images/thumb-rental.webp' },
        { id: 'pulsar', name: 'Bajaj Pulsar 150', category: 'commuter', dailyRate: 600, engineCc: '150cc', image: '/images/thumb-rental.webp' },
        { id: 'classic', name: 'Royal Enfield Classic 350', category: 'cruiser', dailyRate: 900, engineCc: '350cc', image: '/images/thumb-rental.webp' }
      ],
      carSelfDriveDaily: 1600,
      carWithDriverDaily: 2500
    },
    foodExperiences: [
      { id: 'goa-food-1', name: 'Panaji Bakery & Bebinca Tasting Trail', type: 'street_food_walk', pricePerPerson: 450, duration: '2 hours', description: 'Traditional Goan poee bread, choris pao, and layered bebinca pastry.', image: '/images/thumb-exp-culinary.webp' },
      { id: 'goa-food-2', name: 'Spice Plantation Tour & Saraswat Thali', type: 'heritage_thali', pricePerPerson: 850, duration: '3 hours', description: 'Freshly harvested vanilla, cardamom, and black pepper walk followed by organic banana-leaf thali.', image: '/images/thumb-exp-heritage.webp' }
    ]
  },
  {
    id: 'agra',
    name: 'Agra',
    state: 'Uttar Pradesh',
    coords: { lat: 27.1767, lng: 78.0081 },
    cardImage: '/images/humayuns-tomb.webp',
    bannerImage: '/images/dest-delhi-banner.webp',
    description: 'Home of the timeless white marble Taj Mahal, red sandstone Agra Fort, and royal Mughal cuisine.',
    defaultDays: 2,
    attractions: [
      { id: 'agr-1', name: 'Taj Mahal Sunrise Visit', area: 'Taj Ganj', typicalVisitTime: '2.5 hours', ticketPricePerPerson: 50, image: '/images/humayuns-tomb.webp', description: 'Ivory-white marble mausoleum on the Yamuna river, UNESCO World Wonder.', isHeritage: true },
      { id: 'agr-2', name: 'Agra Fort (Red Fort of Agra)', area: 'Rakabganj', typicalVisitTime: '2.5 hours', ticketPricePerPerson: 50, image: '/images/dest-delhi-card.webp', description: 'Crescent red sandstone fort where Shah Jahan was held with views of the Taj Mahal.', isHeritage: true },
      { id: 'agr-3', name: 'Mehtab Bagh (Moonlight Garden)', area: 'Yamuna Riverbank', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 25, image: '/images/dest-delhi-banner.webp', description: 'Charbagh garden complex perfectly aligned across the river from the Taj Mahal.' },
      { id: 'agr-4', name: "Itmad-ud-Daulah (Baby Taj)", area: 'Moti Bagh', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 30, image: '/images/dest-jaipur-card.webp', description: 'Delicate marble inlay jewel box tomb on the banks of the Yamuna.' },
      { id: 'agr-5', name: 'Kinari Bazaar & Petha Trail', area: 'Old City', typicalVisitTime: '2 hours', ticketPricePerPerson: 0, image: '/images/street-food.webp', description: 'Narrow lanes renowned for authentic Agra petha, dalmoth, and marble handicrafts.' },
      { id: 'agr-6', name: 'Fatehpur Sikri Excursion', area: 'Fatehpur Sikri', typicalVisitTime: '3.5 hours', ticketPricePerPerson: 50, image: '/images/dest-hampi-card.webp', description: 'Emperor Akbar’s ghost royal capital with Buland Darwaza and Salim Chishti shrine.', isHeritage: true }
    ],
    stays: [
      { id: 'agr-stay-1', name: 'Taj Ganj Backpackers', tier: 'budget', area: 'Taj Ganj East Gate', roomType: 'Standard Room', ratePerNight: 950, rating: 4.1, inclusions: ['Rooftop Taj view', 'Free WiFi', 'Walking distance'], image: '/images/thumb-stay-budget.webp' },
      { id: 'agr-stay-2', name: 'Grand Imperial Heritage Haveli', tier: 'boutique', area: 'Mahatma Gandhi Road', roomType: 'Heritage Suite', ratePerNight: 2700, rating: 4.6, inclusions: ['Breakfast included', 'Colonial gardens', 'Swimming pool'], image: '/images/thumb-stay-haveli.webp' },
      { id: 'agr-stay-3', name: 'ITC Mughal Luxury Quarters', tier: 'luxury', area: 'Taj Ganj', roomType: 'Mughal Chamber', ratePerNight: 6200, rating: 4.9, inclusions: ['Mughal gardens view', 'Breakfast buffet', 'Spa access'], image: '/images/thumb-stay-boutique.webp' }
    ],
    localTransit: {
      hasMetro: false,
      autoPerRide: 60,
      cabFullDay: 1500,
      airportPickupCab: 450,
      stationPickupCab: 180,
      bikeModels: [
        { id: 'activa', name: 'Honda Activa 6G', category: 'scooter', dailyRate: 350, engineCc: '110cc', image: '/images/thumb-rental.webp' },
        { id: 'pulsar', name: 'Bajaj Pulsar 150', category: 'commuter', dailyRate: 500, engineCc: '150cc', image: '/images/thumb-rental.webp' },
        { id: 'classic', name: 'Royal Enfield Classic 350', category: 'cruiser', dailyRate: 900, engineCc: '350cc', image: '/images/thumb-rental.webp' }
      ],
      carSelfDriveDaily: 1600,
      carWithDriverDaily: 2000
    },
    foodExperiences: [
      { id: 'agr-food-1', name: 'Sadar Bazaar Chaat & Petha Walk', type: 'street_food_walk', pricePerPerson: 350, duration: '2 hours', description: 'Panchi Petha tasting, Agra Bedai & Jalebi, and spicy bhalla chaat.', image: '/images/thumb-exp-culinary.webp' },
      { id: 'agr-food-2', name: 'Mughlai Clay Oven Kebab Tasting', type: 'heritage_thali', pricePerPerson: 750, duration: '2 hours', description: 'Tandoori delicacies and rich korma prepared using 17th-century royal recipes.', image: '/images/thumb-exp-heritage.webp' }
    ]
  },
  {
    id: 'varanasi',
    name: 'Varanasi',
    state: 'Uttar Pradesh',
    coords: { lat: 25.3176, lng: 82.9739 },
    cardImage: '/images/dest-varanasi-card.webp',
    bannerImage: '/images/dest-varanasi-banner.webp',
    description: 'Timeless spiritual city, sacred stone ghats, sunrise wooden boat rituals, and ancient silk lanes.',
    defaultDays: 2,
    attractions: [
      { id: 'var-1', name: 'Dashashwamedh Ghat & Evening Aarti', area: 'Ghats', typicalVisitTime: '2 hours', ticketPricePerPerson: 0, image: '/images/varanasi.webp', description: 'Electrifying evening Ganga Aarti ceremony with multi-tiered brass oil lamps and conch shells.' },
      { id: 'var-2', name: 'Subah-e-Banaras Sunrise Boat Ride', area: 'Assi Ghat', typicalVisitTime: '2 hours', ticketPricePerPerson: 180, image: '/images/dest-varanasi-card.webp', description: 'Traditional rowboat glide along 84 ghats at golden dawn while temple bells ring.' },
      { id: 'var-3', name: 'Kashi Vishwanath Temple Corridor', area: 'Godowlia', typicalVisitTime: '2 hours', ticketPricePerPerson: 0, image: '/images/dest-varanasi-banner.webp', description: 'Ancient golden-spired Shiva Jyotirlinga shrine reached through open stone corridors.', isHeritage: true },
      { id: 'var-4', name: 'Sarnath Buddhist Deer Park & Stupa', area: 'Sarnath', typicalVisitTime: '3 hours', ticketPricePerPerson: 25, image: '/images/dest-hampi-card.webp', description: 'Dhamek Stupa marking where Gautama Buddha taught his first sermon.', isHeritage: true },
      { id: 'var-5', name: 'Manikarnika & Harishchandra Ghats', area: 'Old Ghats', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 0, image: '/images/varanasi.webp', description: 'Sacred timeless burning ghats and historic stone river towers seen from boat.' },
      { id: 'var-6', name: 'Kashi Alleyways & Silk Weavers Colony', area: 'Madanpura', typicalVisitTime: '2 hours', ticketPricePerPerson: 0, image: '/images/street-food.webp', description: 'Handloom jacquard silk saris woven in family courtyards for generations.' }
    ],
    stays: [
      { id: 'var-stay-1', name: 'Assi Ghat River Backpackers', tier: 'budget', area: 'Assi Ghat', roomType: 'Ghat View Room', ratePerNight: 950, rating: 4.4, inclusions: ['Rooftop chai', 'Free WiFi', 'Sunrise boat link'], image: '/images/thumb-stay-budget.webp' },
      { id: 'var-stay-2', name: 'Palace on Ganges Heritage Stay', tier: 'boutique', area: 'Assi Ghat', roomType: 'Heritage River Suite', ratePerNight: 2600, rating: 4.7, inclusions: ['Breakfast included', 'Yoga deck', 'River facing'], image: '/images/thumb-stay-haveli.webp' },
      { id: 'var-stay-3', name: 'BrijRama Palace on Darbhanga Ghat', tier: 'luxury', area: 'Darbhanga Ghat', roomType: 'Royal Maharaja Room', ratePerNight: 6900, rating: 4.9, inclusions: ['Private boat transfer', 'Classical music recital', 'Gourmet satvik feast'], image: '/images/thumb-stay-boutique.webp' }
    ],
    localTransit: {
      hasMetro: false,
      autoPerRide: 60,
      cabFullDay: 1500,
      airportPickupCab: 650,
      stationPickupCab: 200,
      bikeModels: [
        { id: 'activa', name: 'Honda Activa 6G', category: 'scooter', dailyRate: 350, engineCc: '110cc', image: '/images/thumb-rental.webp' },
        { id: 'pulsar', name: 'Bajaj Pulsar 150', category: 'commuter', dailyRate: 500, engineCc: '150cc', image: '/images/thumb-rental.webp' },
        { id: 'classic', name: 'Royal Enfield Classic 350', category: 'cruiser', dailyRate: 850, engineCc: '350cc', image: '/images/thumb-rental.webp' }
      ],
      carSelfDriveDaily: 1500,
      carWithDriverDaily: 2000
    },
    foodExperiences: [
      { id: 'var-food-1', name: 'Kashi Street Food & Blue Lassi Walk', type: 'street_food_walk', pricePerPerson: 350, duration: '2 hours', description: 'Malaiyyo saffron milk foam, kachori sabzi, tamatar chaat, and Blue Lassi.', image: '/images/thumb-exp-culinary.webp' },
      { id: 'var-food-2', name: 'Banarasi Satvik Thali & Paan Tasting', type: 'heritage_thali', pricePerPerson: 600, duration: '1.5 hours', description: 'Pure satvik culinary feast prepared without onion or garlic, finished with royal Maghai paan.', image: '/images/thumb-exp-heritage.webp' }
    ]
  },
  {
    id: 'hampi',
    name: 'Hampi',
    state: 'Karnataka',
    coords: { lat: 15.3350, lng: 76.4600 },
    cardImage: '/images/dest-hampi-card.webp',
    bannerImage: '/images/dest-hampi-banner.webp',
    description: 'Surreal granite boulder landscapes, 14th-century Vijayanagara capital ruins, and coracle river boats.',
    defaultDays: 3,
    attractions: [
      { id: 'ham-1', name: 'Virupaksha Temple', area: 'Hampi Bazaar', typicalVisitTime: '2 hours', ticketPricePerPerson: 25, image: '/images/hampi.webp', description: '7th-century functioning temple with 50-meter gopuram tower and sacred temple elephant.', isHeritage: true },
      { id: 'ham-2', name: 'Vijaya Vittala Temple & Stone Chariot', area: 'Vittala Complex', typicalVisitTime: '2.5 hours', ticketPricePerPerson: 40, image: '/images/dest-hampi-card.webp', description: 'Iconic stone chariot shrine and 56 musical granite pillars that resonate notes.', isHeritage: true },
      { id: 'ham-3', name: 'Lotus Mahal & Elephant Stables', area: 'Zenana Enclosure', typicalVisitTime: '2 hours', ticketPricePerPerson: 40, image: '/images/dest-hampi-banner.webp', description: 'Indo-Islamic secular palaces and domed chambers for eleven royal elephants.', isHeritage: true },
      { id: 'ham-4', name: 'Matanga Hill Sunrise Trek', area: 'Central Hampi', typicalVisitTime: '2 hours', ticketPricePerPerson: 0, image: '/images/hampi.webp', description: 'Highest hill in Hampi with breathtaking 360-degree sunrise view over endless ruins and rocks.' },
      { id: 'ham-5', name: 'Tungabhadra Coracle River Crossing', area: 'Chakratirtha', typicalVisitTime: '1 hour', ticketPricePerPerson: 100, image: '/images/dest-alleppey-card.webp', description: 'Traditional round woven coracle boat ride through rocky rapids and cliff temples.' },
      { id: 'ham-6', name: 'Sanapur Lake & Bouldering Plateaus', area: 'Anegundi (Hippie Island)', typicalVisitTime: '2.5 hours', ticketPricePerPerson: 0, image: '/images/dest-coorg-card.webp', description: 'Tranquil freshwater reservoir framed by massive orange boulders and palm groves.' }
    ],
    stays: [
      { id: 'ham-stay-1', name: 'Hampi Boulders Eco Shack', tier: 'budget', area: 'Anegundi Island', roomType: 'Riverview Hut', ratePerNight: 900, rating: 4.4, inclusions: ['Breakfast included', 'Bicycle rental', 'Hammock'], image: '/images/thumb-stay-budget.webp' },
      { id: 'ham-stay-2', name: 'Heritage Resort Hampi', tier: 'boutique', area: 'Hospet Road', roomType: 'Cottage Deluxe', ratePerNight: 2600, rating: 4.7, inclusions: ['Swimming pool', 'Buffet breakfast', 'Guided tour option'], image: '/images/thumb-stay-haveli.webp' },
      { id: 'ham-stay-3', name: 'Evolve Back Kamalapura Palace', tier: 'luxury', area: 'Kamalapura', roomType: 'Nivasa Palace Suite', ratePerNight: 7200, rating: 4.9, inclusions: ['Private jacuzzi', 'Royal dining', 'Historical storyteller'], image: '/images/thumb-stay-boutique.webp' }
    ],
    localTransit: {
      hasMetro: false,
      autoPerRide: 80,
      cabFullDay: 1800,
      airportPickupCab: 1200,
      stationPickupCab: 300,
      bikeModels: [
        { id: 'activa', name: 'Honda Activa 6G', category: 'scooter', dailyRate: 350, engineCc: '110cc', image: '/images/thumb-rental.webp' },
        { id: 'pulsar', name: 'Bajaj Pulsar 150', category: 'commuter', dailyRate: 500, engineCc: '150cc', image: '/images/thumb-rental.webp' },
        { id: 'classic', name: 'Royal Enfield Classic 350', category: 'cruiser', dailyRate: 850, engineCc: '350cc', image: '/images/thumb-rental.webp' }
      ],
      carSelfDriveDaily: 1600,
      carWithDriverDaily: 2200
    },
    foodExperiences: [
      { id: 'ham-food-1', name: 'Anegundi Village Millet & Thali Trail', type: 'street_food_walk', pricePerPerson: 350, duration: '2 hours', description: 'Locally grown ragi mudde, jowar roti, and organic farm curries.', image: '/images/thumb-exp-culinary.webp' },
      { id: 'ham-food-2', name: 'Sunset Coracle Chai & Banana Pancake Evening', type: 'heritage_thali', pricePerPerson: 550, duration: '1.5 hours', description: 'Fresh hot ginger chai and traditional sweet dosas served atop Sanapur rocks at dusk.', image: '/images/thumb-exp-heritage.webp' }
    ]
  },
  {
    id: 'alleppey',
    name: 'Alleppey and Kochi',
    state: 'Kerala',
    coords: { lat: 9.4981, lng: 76.3388 },
    cardImage: '/images/dest-alleppey-card.webp',
    bannerImage: '/images/dest-alleppey-banner.webp',
    description: 'Emerald backwaters, thatched wooden houseboats, Fort Kochi colonial streets, and Chinese fishing nets.',
    defaultDays: 3,
    attractions: [
      { id: 'kl-1', name: 'Alleppey Backwaters Houseboat Cruise', area: 'Vembanad Lake', typicalVisitTime: '4 hours', ticketPricePerPerson: 750, image: '/images/kerala.webp', description: 'Glide past palm-shaded canal villages, paddy fields below sea level, and duck farmers.', isHeritage: true },
      { id: 'kl-2', name: 'Fort Kochi Chinese Fishing Nets & Walk', area: 'Fort Kochi', typicalVisitTime: '2 hours', ticketPricePerPerson: 0, image: '/images/dest-alleppey-card.webp', description: 'Cantilevered mechanical fishing nets introduced by 14th-century traders.' },
      { id: 'kl-3', name: 'Mattancherry Palace (Dutch Palace)', area: 'Mattancherry', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 10, image: '/images/dest-delhi-card.webp', description: 'Kerala style murals depicting Ramayana frescoes built by Portuguese in 1555.', isHeritage: true },
      { id: 'kl-4', name: 'Jew Town & Paradesi Synagogue', area: 'Kochi', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 20, image: '/images/dest-jaipur-card.webp', description: 'Oldest active synagogue in the Commonwealth with 18th-century hand-painted Chinese tiles.' },
      { id: 'kl-5', name: 'Marari Beach Quiet Sands', area: 'Mararikulam', typicalVisitTime: '2.5 hours', ticketPricePerPerson: 0, image: '/images/dest-alleppey-banner.webp', description: 'Pristine fishing village beach lined with coconut trees and wooden catamarans.' },
      { id: 'kl-6', name: 'Kathakali Dance Performance Center', area: 'Fort Kochi', typicalVisitTime: '2 hours', ticketPricePerPerson: 350, image: '/images/dest-hampi-banner.webp', description: 'Live classical dance-drama showing the elaborate makeup ritual and facial expressions.' }
    ],
    stays: [
      { id: 'kl-stay-1', name: 'Vembanad Lakeside Homestay', tier: 'budget', area: 'Punnamada', roomType: 'Backwater View Room', ratePerNight: 1200, rating: 4.5, inclusions: ['Homecooked breakfast', 'Canoe ride', 'WiFi'], image: '/images/thumb-stay-budget.webp' },
      { id: 'kl-stay-2', name: 'Heritage Houseboat Suite', tier: 'boutique', area: 'Finishing Point Jetty', roomType: 'Air-Conditioned Cabin', ratePerNight: 3500, rating: 4.8, inclusions: ['Lunch & dinner on boat', 'Captain & cook on board', 'Canal cruise'], image: '/images/thumb-stay-haveli.webp' },
      { id: 'kl-stay-3', name: 'Brunton Boatyard Colonial Haven', tier: 'luxury', area: 'Fort Kochi Harbour', roomType: 'Sea Facing Deluxe', ratePerNight: 7800, rating: 4.9, inclusions: ['Harbour view', 'Seafood dinner buffet', 'Sunset cruise'], image: '/images/thumb-stay-boutique.webp' }
    ],
    localTransit: {
      hasMetro: true, // Kochi Metro
      metroPassPerDay: 100,
      autoPerRide: 70,
      cabFullDay: 1900,
      airportPickupCab: 850,
      stationPickupCab: 250,
      bikeModels: [
        { id: 'activa', name: 'Honda Activa 6G', category: 'scooter', dailyRate: 400, engineCc: '110cc', image: '/images/thumb-rental.webp' },
        { id: 'pulsar', name: 'Bajaj Pulsar 150', category: 'commuter', dailyRate: 600, engineCc: '150cc', image: '/images/thumb-rental.webp' },
        { id: 'classic', name: 'Royal Enfield Classic 350', category: 'cruiser', dailyRate: 950, engineCc: '350cc', image: '/images/thumb-rental.webp' }
      ],
      carSelfDriveDaily: 1700,
      carWithDriverDaily: 2400
    },
    foodExperiences: [
      { id: 'kl-food-1', name: 'Fort Kochi Spice Walk & Appam Breakfast', type: 'street_food_walk', pricePerPerson: 400, duration: '2 hours', description: 'Fresh laced appams with vegetable stew, banana fritters, and spice auction walk.', image: '/images/thumb-exp-culinary.webp' },
      { id: 'kl-food-2', name: 'Traditional Kerala Sadhya on Banana Leaf', type: 'heritage_thali', pricePerPerson: 650, duration: '1.5 hours', description: '24-dish vegetarian feast with red matta rice, avial, sambar, payasam, and papadam.', image: '/images/thumb-exp-heritage.webp' }
    ]
  },
  {
    id: 'coorg',
    name: 'Coorg',
    state: 'Karnataka',
    coords: { lat: 12.3375, lng: 75.8069 },
    cardImage: '/images/dest-coorg-card.webp',
    bannerImage: '/images/dest-coorg-banner.webp',
    description: 'Misty Western Ghats peaks, aromatic Arabica coffee estates, cascading waterfalls, and Kodava culture.',
    defaultDays: 3,
    attractions: [
      { id: 'crg-1', name: 'Abbey Falls (Abbi Falls)', area: 'Madikeri', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 20, image: '/images/coorg.webp', description: 'Cascading waterfall surrounded by private coffee plantations and spice bushes.' },
      { id: 'crg-2', name: 'Raja’s Seat Sunset Garden', area: 'Madikeri Town', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 10, image: '/images/dest-coorg-banner.webp', description: 'Seasonal flower gardens overlooking rolling misty valleys where Kodagu kings relaxed.' },
      { id: 'crg-3', name: 'Namdroling Golden Temple Monastic Complex', area: 'Bylakuppe', typicalVisitTime: '2 hours', ticketPricePerPerson: 0, image: '/images/dest-delhi-card.webp', description: 'Largest Tibetan settlement in South India with three 40-foot gilded Buddha statues.' },
      { id: 'crg-4', name: 'Dubare Elephant Camp', area: 'Cauvery Riverbank', typicalVisitTime: '2.5 hours', ticketPricePerPerson: 100, image: '/images/dest-alleppey-card.webp', description: 'Riverboat crossing to interact with elephants and observe their morning bath.' },
      { id: 'crg-5', name: 'Tadiandamol Peak Trek', area: 'Kakkabe', typicalVisitTime: '5 hours', ticketPricePerPerson: 50, image: '/images/dest-coorg-card.webp', description: 'Highest mountain peak in Kodagu with views extending towards the Arabian Sea coast.' },
      { id: 'crg-6', name: 'Coffee & Pepper Plantation Trail', area: 'Siddapur', typicalVisitTime: '2 hours', ticketPricePerPerson: 150, image: '/images/coorg.webp', description: 'Guided estate walk explaining coffee cherry harvesting, curing, and chicory roasting.' }
    ],
    stays: [
      { id: 'crg-stay-1', name: 'Misty Valley Estate Homestay', tier: 'budget', area: 'Madikeri Rural', roomType: 'Planter Cabin', ratePerNight: 1100, rating: 4.4, inclusions: ['Estate breakfast', 'Coffee walk', 'Campfire'], image: '/images/thumb-stay-budget.webp' },
      { id: 'crg-stay-2', name: 'The Tamara Wilderness Cottages', tier: 'boutique', area: 'Yevakapadi', roomType: 'Luxury Plantation Villa', ratePerNight: 3400, rating: 4.8, inclusions: ['Breakfast included', 'Waterfall view', 'Bird watching walk'], image: '/images/thumb-stay-haveli.webp' },
      { id: 'crg-stay-3', name: 'Evolve Back Kuruba Safari Lodge', tier: 'luxury', area: 'Siddapur', roomType: 'Lily Pool Palace Suite', ratePerNight: 7600, rating: 4.9, inclusions: ['Private pool', 'All meals included', 'Naturalist safari'], image: '/images/thumb-stay-boutique.webp' }
    ],
    localTransit: {
      hasMetro: false,
      autoPerRide: 80,
      cabFullDay: 1900,
      airportPickupCab: 1400,
      stationPickupCab: 900,
      bikeModels: [
        { id: 'activa', name: 'Honda Activa 6G', category: 'scooter', dailyRate: 450, engineCc: '110cc', image: '/images/thumb-rental.webp' },
        { id: 'pulsar', name: 'Bajaj Pulsar 150', category: 'commuter', dailyRate: 650, engineCc: '150cc', image: '/images/thumb-rental.webp' },
        { id: 'classic', name: 'Royal Enfield Classic 350', category: 'cruiser', dailyRate: 1000, engineCc: '350cc', image: '/images/thumb-rental.webp' }
      ],
      carSelfDriveDaily: 1800,
      carWithDriverDaily: 2500
    },
    foodExperiences: [
      { id: 'crg-food-1', name: 'Kodava Estate Filter Coffee & Akki Roti Walk', type: 'street_food_walk', pricePerPerson: 350, duration: '2 hours', description: 'Rice rottis with Coorg honey, bamboo shoot pickle, and dark roast peaberry coffee.', image: '/images/thumb-exp-culinary.webp' },
      { id: 'crg-food-2', name: 'Authentic Kodava Pandi Curry & Kadamputtu Feast', type: 'heritage_thali', pricePerPerson: 750, duration: '1.5 hours', description: 'Slow-cooked Kachampuli spiced delicacies served with steamed rice balls and wild honey.', image: '/images/thumb-exp-heritage.webp' }
    ]
  },
  {
    id: 'udaipur',
    name: 'Udaipur',
    state: 'Rajasthan',
    coords: { lat: 24.5854, lng: 73.7125 },
    cardImage: '/images/dest-jaipur-card.webp',
    bannerImage: '/images/dest-jaipur-banner.webp',
    description: 'City of Lakes, white marble palaces, Lake Pichola boat cruises, and Mewari chivalry.',
    defaultDays: 3,
    attractions: [
      { id: 'uda-1', name: 'City Palace Complex & Museum', area: 'Lake Pichola', typicalVisitTime: '3 hours', ticketPricePerPerson: 300, image: '/images/dest-jaipur-card.webp', description: 'Rajasthan’s largest palace complex overlooking Lake Pichola with mirror mosaics.', isHeritage: true },
      { id: 'uda-2', name: 'Lake Pichola Boat Cruise & Jag Mandir', area: 'Rameshwar Ghat', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 450, image: '/images/dest-alleppey-card.webp', description: 'Boat ride past Taj Lake Palace to the island palace garden of Jag Mandir.' },
      { id: 'uda-3', name: 'Saheliyon-ki-Bari (Courtyard of Maidens)', area: 'Fateh Sagar', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 20, image: '/images/dest-jaipur-banner.webp', description: 'Royal landscaped gardens featuring marble fountains, elephant pools and lotus ponds.' },
      { id: 'uda-4', name: 'Bagore Ki Haveli & Folk Dance', area: 'Gangaur Ghat', typicalVisitTime: '2 hours', ticketPricePerPerson: 100, image: '/images/thumb-stay-haveli.webp', description: '18th-century lakefront haveli hosting the Dharohar Rajasthani puppet and folk show.' },
      { id: 'uda-5', name: 'Sajjangarh Monsoon Palace', area: 'Bansdara Peak', typicalVisitTime: '2 hours', ticketPricePerPerson: 60, image: '/images/jaipur.webp', description: 'Hilltop white palace built to watch monsoon clouds with sunset views.' },
      { id: 'uda-6', name: 'Jagdish Temple & Old City Bazaars', area: 'City Palace Road', typicalVisitTime: '1.5 hours', ticketPricePerPerson: 0, image: '/images/street-food.webp', description: '1651 carved stone temple dedicated to Lord Vishnu in the heart of old handicraft alleys.' }
    ],
    stays: [
      { id: 'uda-stay-1', name: 'Pichola Backpackers Lake Hostel', tier: 'budget', area: 'Lal Ghat', roomType: 'Lake View Dorm', ratePerNight: 950, rating: 4.4, inclusions: ['Rooftop lake view', 'Free WiFi', 'Chai'], image: '/images/thumb-stay-budget.webp' },
      { id: 'uda-stay-2', name: 'Jagat Niwas Heritage Haveli', tier: 'boutique', area: 'Lal Ghat', roomType: 'Jharokha Suite', ratePerNight: 3200, rating: 4.8, inclusions: ['Lake Pichola window seat', 'Breakfast', 'Royal welcome'], image: '/images/thumb-stay-haveli.webp' },
      { id: 'uda-stay-3', name: 'Fateh Prakash Palace Luxury Wing', tier: 'luxury', area: 'City Palace Complex', roomType: 'Grand Heritage Suite', ratePerNight: 7500, rating: 4.9, inclusions: ['Private jetty transfer', 'Palace breakfast', 'Crystal gallery access'], image: '/images/thumb-stay-boutique.webp' }
    ],
    localTransit: {
      hasMetro: false,
      autoPerRide: 70,
      cabFullDay: 1600,
      airportPickupCab: 650,
      stationPickupCab: 200,
      bikeModels: [
        { id: 'activa', name: 'Honda Activa 6G', category: 'scooter', dailyRate: 400, engineCc: '110cc', image: '/images/thumb-rental.webp' },
        { id: 'pulsar', name: 'Bajaj Pulsar 150', category: 'commuter', dailyRate: 600, engineCc: '150cc', image: '/images/thumb-rental.webp' },
        { id: 'classic', name: 'Royal Enfield Classic 350', category: 'cruiser', dailyRate: 950, engineCc: '350cc', image: '/images/thumb-rental.webp' }
      ],
      carSelfDriveDaily: 1700,
      carWithDriverDaily: 2300
    },
    foodExperiences: [
      { id: 'uda-food-1', name: 'Old Udaipur Kachori & Chai Walk', type: 'street_food_walk', pricePerPerson: 350, duration: '2 hours', description: 'Pyaaz kachori, mirchi bada, jalebi and masala chai by Gangaur Ghat.', image: '/images/thumb-exp-culinary.webp' },
      { id: 'uda-food-2', name: 'Mewari Royal Dining on Lake Terrace', type: 'heritage_thali', pricePerPerson: 850, duration: '2 hours', description: 'Traditional Ker Sangri, Laal Maas or Gatte ki Sabzi served with moonlit lake views.', image: '/images/thumb-exp-heritage.webp' }
    ]
  },
  {
    id: 'bengaluru',
    name: 'Bengaluru',
    state: 'Karnataka',
    coords: { lat: 12.9716, lng: 77.5946 },
    cardImage: '/images/band-1.webp',
    bannerImage: '/images/band-2.webp',
    description: 'The Garden City of India, heritage botanical glass houses, craft breweries, and tech innovation.',
    defaultDays: 3,
    attractions: [
      { id: 'blr-1', name: 'Lalbagh Botanical Gardens & Glass House', area: 'Mavalli', typicalVisitTime: '2.5 hours', ticketPricePerPerson: 30, image: '/images/band-2.webp', description: '240-acre botanical haven founded by Hyder Ali featuring centuries-old trees and Victorian glass pavilion.' },
      { id: 'blr-2', name: 'Bangalore Palace & Royal Grounds', area: 'Vasanth Nagar', typicalVisitTime: '2 hours', ticketPricePerPerson: 250, image: '/images/dest-jaipur-card.webp', description: 'Tudor-revival royal palace inspired by Windsor Castle with wood carvings.', isHeritage: true },
      { id: 'blr-3', name: 'Cubbon Park & Vidhana Soudha', area: 'Central Bengaluru', typicalVisitTime: '2 hours', ticketPricePerPerson: 0, image: '/images/dest-delhi-banner.webp', description: 'Shaded 300-acre park leading to the neo-Dravidian seat of state legislature.' },
      { id: 'blr-4', name: 'National Gallery of Modern Art (NGMA)', area: 'Palace Road', typicalVisitTime: '2 hours', ticketPricePerPerson: 20, image: '/images/dest-delhi-card.webp', description: 'Heritage Manikyavelu Mansion housing Raja Ravi Varma and modern masters.' },
      { id: 'blr-5', name: 'Tipu Sultan’s Summer Palace', area: 'Chamrajpet', typicalVisitTime: '1 hour', ticketPricePerPerson: 20, image: '/images/thumb-stay-haveli.webp', description: '1791 teakwood palace adorned with carved pillars and floral frescoes.', isHeritage: true },
      { id: 'blr-6', name: 'Indiranagar & Church Street Walk', area: 'East Bengaluru', typicalVisitTime: '2.5 hours', ticketPricePerPerson: 0, image: '/images/street-food.webp', description: 'Iconic bookstores, microbreweries, specialty cafes, and lively street culture.' }
    ],
    stays: [
      { id: 'blr-stay-1', name: 'Church Street Pod & Stay', tier: 'budget', area: 'Central Business District', roomType: 'Studio AC Room', ratePerNight: 1250, rating: 4.3, inclusions: ['Free WiFi', 'Breakfast', 'Metro access'], image: '/images/thumb-stay-budget.webp' },
      { id: 'blr-stay-2', name: 'Villa Pottipati Heritage Residence', tier: 'boutique', area: 'Malleshwaram', roomType: 'Colonial Suite', ratePerNight: 3200, rating: 4.7, inclusions: ['South Indian breakfast', 'Veranda', 'Heritage garden'], image: '/images/thumb-stay-haveli.webp' },
      { id: 'blr-stay-3', name: 'The Leela Palace Bengaluru', tier: 'luxury', area: 'Old Airport Road', roomType: 'Royal Premier Room', ratePerNight: 7400, rating: 4.9, inclusions: ['Palatial gardens view', 'Breakfast buffet', 'Chauffeur pickup'], image: '/images/thumb-stay-boutique.webp' }
    ],
    localTransit: {
      hasMetro: true, // Namma Metro
      metroPassPerDay: 130,
      autoPerRide: 60,
      cabFullDay: 1900,
      airportPickupCab: 950,
      stationPickupCab: 250,
      bikeModels: [
        { id: 'activa', name: 'Honda Activa 6G', category: 'scooter', dailyRate: 400, engineCc: '110cc', image: '/images/thumb-rental.webp' },
        { id: 'pulsar', name: 'Bajaj Pulsar 150', category: 'commuter', dailyRate: 600, engineCc: '150cc', image: '/images/thumb-rental.webp' },
        { id: 'classic', name: 'Royal Enfield Classic 350', category: 'cruiser', dailyRate: 1000, engineCc: '350cc', image: '/images/thumb-rental.webp' }
      ],
      carSelfDriveDaily: 1900,
      carWithDriverDaily: 2500
    },
    foodExperiences: [
      { id: 'blr-food-1', name: 'Malleshwaram & VV Puram Dosa Trail', type: 'street_food_walk', pricePerPerson: 400, duration: '2 hours', description: 'Crispy CTR Benne Dosa, idli vada at Brahmin’s Coffee Bar, and piping hot filter coffee.', image: '/images/thumb-exp-culinary.webp' },
      { id: 'blr-food-2', name: 'Traditional Karavali Coastal Feast', type: 'heritage_thali', pricePerPerson: 750, duration: '1.5 hours', description: 'Mangalorean ghee roast, neer dosa, kori gassi, and coconut payasam.', image: '/images/thumb-exp-heritage.webp' }
    ]
  },
  {
    id: 'chennai',
    name: 'Chennai',
    state: 'Tamil Nadu',
    coords: { lat: 13.0827, lng: 80.2707 },
    cardImage: '/images/band-1.webp',
    bannerImage: '/images/cta-sunrise.webp',
    description: 'Dravidian temple gopurams, wide Marina beach promenade, Carnatic music traditions, and silk weaving.',
    defaultDays: 3,
    attractions: [
      { id: 'chn-1', name: 'Kapaleeshwarar Temple', area: 'Mylapore', typicalVisitTime: '2 hours', ticketPricePerPerson: 0, image: '/images/hampi.webp', description: '7th-century Shiva temple featuring a rainbow-colored 37-meter Dravidian gopuram.', isHeritage: true },
      { id: 'chn-2', name: 'Marina Beach & Lighthouse', area: 'Triplicane', typicalVisitTime: '2 hours', ticketPricePerPerson: 20, image: '/images/cta-sunrise.webp', description: 'Second longest urban natural beach in the world with sea views from the lighthouse.' },
      { id: 'chn-3', name: 'Fort St. George & Museum', area: 'Rajaji Salai', typicalVisitTime: '2 hours', ticketPricePerPerson: 25, image: '/images/dest-delhi-card.webp', description: 'First English fortress built in India (1644) housing St. Mary’s Church and colonial relics.', isHeritage: true },
      { id: 'chn-4', name: 'Santhome Cathedral Basilica', area: 'Santhome', typicalVisitTime: '1 hour', ticketPricePerPerson: 0, image: '/images/dest-delhi-banner.webp', description: 'Neo-Gothic Roman Catholic cathedral built over the tomb of St. Thomas the Apostle.' },
      { id: 'chn-5', name: 'DakshinaChitra Heritage Museum Excursion', area: 'East Coast Road', typicalVisitTime: '3.5 hours', ticketPricePerPerson: 175, image: '/images/dest-alleppey-card.webp', description: 'Living history museum with 18 authentic reconstructed South Indian heritage houses.' },
      { id: 'chn-6', name: 'Mylapore Cultural Heritage Walk', area: 'Mylapore', typicalVisitTime: '2 hours', ticketPricePerPerson: 0, image: '/images/street-food.webp', description: 'Fresh jasmine flower stalls, bronze statues, and traditional South Indian filter coffee joints.' }
    ],
    stays: [
      { id: 'chn-stay-1', name: 'Mylapore Cultural Residency', tier: 'budget', area: 'Mylapore', roomType: 'Standard AC Room', ratePerNight: 1100, rating: 4.2, inclusions: ['Filter coffee', 'Free WiFi', 'Temple proximity'], image: '/images/thumb-stay-budget.webp' },
      { id: 'chn-stay-2', name: 'Appaswamy Heritage Mansion', tier: 'boutique', area: 'Alwarpet', roomType: 'Heritage Suite', ratePerNight: 2900, rating: 4.7, inclusions: ['Breakfast included', 'Garden courtyard', 'Air conditioning'], image: '/images/thumb-stay-haveli.webp' },
      { id: 'chn-stay-3', name: 'Taj Connemara Heritage Wing', tier: 'luxury', area: 'Binny Road', roomType: 'Colonial Deluxe Suite', ratePerNight: 6800, rating: 4.9, inclusions: ['Historic property', 'Breakfast buffet', 'Airport chauffeur'], image: '/images/thumb-stay-boutique.webp' }
    ],
    localTransit: {
      hasMetro: true, // Chennai Metro
      metroPassPerDay: 100,
      autoPerRide: 60,
      cabFullDay: 1700,
      airportPickupCab: 550,
      stationPickupCab: 200,
      bikeModels: [
        { id: 'activa', name: 'Honda Activa 6G', category: 'scooter', dailyRate: 400, engineCc: '110cc', image: '/images/thumb-rental.webp' },
        { id: 'pulsar', name: 'Bajaj Pulsar 150', category: 'commuter', dailyRate: 600, engineCc: '150cc', image: '/images/thumb-rental.webp' },
        { id: 'classic', name: 'Royal Enfield Classic 350', category: 'cruiser', dailyRate: 950, engineCc: '350cc', image: '/images/thumb-rental.webp' }
      ],
      carSelfDriveDaily: 1700,
      carWithDriverDaily: 2300
    },
    foodExperiences: [
      { id: 'chn-food-1', name: 'Mylapore Filter Coffee & Tiffin Trail', type: 'street_food_walk', pricePerPerson: 350, duration: '2 hours', description: 'Hot ghee podi idli, medu vada, crispy masala dosa, and davarah-tumbler filter coffee.', image: '/images/thumb-exp-culinary.webp' },
      { id: 'chn-food-2', name: 'Authentic Chettinad Spicy Banana Leaf Feast', type: 'heritage_thali', pricePerPerson: 750, duration: '1.5 hours', description: 'Black pepper Chettinad gravy, vathal kuzhambu, appalam, and sweet paal payasam.', image: '/images/thumb-exp-heritage.webp' }
    ]
  }
];

// Helper: Haversine distance in kilometers
export function calculateHaversineDistanceKm(c1: CityCoordinates, c2: CityCoordinates): number {
  const R = 6371; // Earth radius in km
  const dLat = ((c2.lat - c1.lat) * Math.PI) / 180;
  const dLng = ((c2.lng - c1.lng) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((c1.lat * Math.PI) / 180) *
      Math.cos((c2.lat * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

// Lookup city by name or alias
export function findCityByName(cityName: string): DestinationInfo | undefined {
  if (!cityName) return undefined;
  const normalized = cityName.trim().toLowerCase();
  
  return SUPPORTED_CITIES.find(c => {
    const cName = c.name.toLowerCase();
    const cId = c.id.toLowerCase();
    if (cName === normalized || cId === normalized) return true;
    if (normalized === 'delhi' && c.id === 'delhi') return true;
    if (normalized === 'bangalore' && c.id === 'bengaluru') return true;
    if (normalized === 'bombay' && c.id === 'mumbai') return true;
    if (normalized === 'madras' && c.id === 'chennai') return true;
    if (normalized === 'kerala' && c.id === 'alleppey') return true;
    if (normalized === 'alleppey' && c.id === 'alleppey') return true;
    if (normalized === 'kochi' && c.id === 'alleppey') return true;
    if (normalized === 'cochin' && c.id === 'alleppey') return true;
    if (normalized === 'banaras' && c.id === 'varanasi') return true;
    if (normalized === 'kashi' && c.id === 'varanasi') return true;
    return false;
  });
}

export interface GeneratedTransportOption {
  id: string;
  mode: 'bus' | 'train' | 'flight';
  operator: string;
  serviceName: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  origin: string;
  destination: string;
  boardingPoint: string;
  dropPoint: string;
  farePerPerson: number; // One-way fare
  roundTripFarePerPerson: number;
  amenities: string[];
  cancellationPolicy: string;
  sourceLabel: 'ESTIMATED';
  tag?: 'Best fit' | 'Cheapest' | 'Fastest';
  thumbnail: string;
}

/**
 * Deterministic Transport Generator
 * Calculates valid transport options based on haversine distance.
 * Rules:
 * - Bus: ~₹1.4/km/person (hidden if distance > 1500 km)
 * - Train: sleeper ~₹0.9/km, AC ~₹2.2/km
 * - Flight: only above 300 km (~₹3,000 + ₹3.5/km)
 * - All options marked "Estimated"
 * - All fields mandatory, price > 0
 */
export function generateTransportOptions(
  originCityName: string,
  destCityName: string
): {
  distanceKm: number;
  options: GeneratedTransportOption[];
  hiddenModesReason?: { mode: 'bus' | 'flight'; reason: string }[];
} {
  const originCity = findCityByName(originCityName) || SUPPORTED_CITIES[0];
  const destCity = findCityByName(destCityName) || SUPPORTED_CITIES[1];

  const distanceKm = Math.max(80, calculateHaversineDistanceKm(originCity.coords, destCity.coords));
  const options: GeneratedTransportOption[] = [];
  const hiddenModesReason: { mode: 'bus' | 'flight'; reason: string }[] = [];

  // 1. Bus options (feasible if distance <= 1500 km)
  if (distanceKm <= 1500) {
    const baseBusFare = Math.max(350, Math.round(distanceKm * 1.4));
    const busHours = Math.max(3, Math.round(distanceKm / 50));
    
    options.push({
      id: `bus-slp-${originCity.id}-${destCity.id}`,
      mode: 'bus',
      operator: 'IntrCity SmartBus',
      serviceName: 'AC Sleeper 2+1 Comfort',
      departureTime: '21:00',
      arrivalTime: `${String((21 + busHours) % 24).padStart(2, '0')}:30`,
      duration: `${busHours}h 30m`,
      origin: originCity.name,
      destination: destCity.name,
      boardingPoint: `${originCity.name} Central Bus Terminal`,
      dropPoint: `${destCity.name} City Gateway`,
      farePerPerson: baseBusFare,
      roundTripFarePerPerson: Math.round(baseBusFare * 1.9),
      amenities: ['AC Sleeper Berth', 'Reading Light', 'Water Bottle', 'Charging Port'],
      cancellationPolicy: 'Cancellation policy shown before payment',
      sourceLabel: 'ESTIMATED',
      tag: 'Best fit',
      thumbnail: '/images/thumb-bus.webp'
    });

    const premiumBusFare = Math.round(baseBusFare * 1.25);
    options.push({
      id: `bus-volvo-${originCity.id}-${destCity.id}`,
      mode: 'bus',
      operator: 'KSRTC / SRS Travels',
      serviceName: 'Multi-Axle Volvo Club Class',
      departureTime: '22:30',
      arrivalTime: `${String((22 + busHours) % 24).padStart(2, '0')}:45`,
      duration: `${busHours}h 15m`,
      origin: originCity.name,
      destination: destCity.name,
      boardingPoint: `${originCity.name} Outer Ring Junction`,
      dropPoint: `${destCity.name} Central Hub`,
      farePerPerson: premiumBusFare,
      roundTripFarePerPerson: Math.round(premiumBusFare * 1.9),
      amenities: ['Semi-Sleeper Calf Support', 'Air Suspension', 'Live GPS Tracking (Simulated)'],
      cancellationPolicy: 'Cancellation policy shown before payment',
      sourceLabel: 'ESTIMATED',
      thumbnail: '/images/thumb-bus.webp'
    });
  } else {
    hiddenModesReason.push({
      mode: 'bus',
      reason: `Bus options are hidden for long-distance journeys over 1,500 km (${distanceKm} km). Trains and flights provide safer, faster transit.`
    });
  }

  // 2. Train options (Always feasible for intercity)
  const trainHours = Math.max(2, Math.round(distanceKm / 65));
  const sleeperFare = Math.max(280, Math.round(distanceKm * 0.9));
  const acFare = Math.max(650, Math.round(distanceKm * 2.2));

  // Option A: Sleeper Superfast
  options.push({
    id: `train-slp-${originCity.id}-${destCity.id}`,
    mode: 'train',
    operator: 'Indian Railways Express',
    serviceName: 'Express Sleeper Class (SL)',
    departureTime: '19:45',
    arrivalTime: `${String((19 + trainHours) % 24).padStart(2, '0')}:15`,
    duration: `${trainHours}h 30m`,
    origin: originCity.name,
    destination: destCity.name,
    boardingPoint: `${originCity.name} Main Junction`,
    dropPoint: `${destCity.name} Central Railway Station`,
    farePerPerson: sleeperFare,
    roundTripFarePerPerson: Math.round(sleeperFare * 2),
    amenities: ['Reserved Berth', 'Open Windows', 'On-board Catering Available'],
    cancellationPolicy: 'Cancellation policy shown before payment',
    sourceLabel: 'ESTIMATED',
    tag: 'Cheapest',
    thumbnail: '/images/thumb-train-sleeper.webp'
  });

  // Option B: 3AC / AC Chair Car (Vande Bharat / Rajdhani style)
  options.push({
    id: `train-ac-${originCity.id}-${destCity.id}`,
    mode: 'train',
    operator: distanceKm < 600 ? 'Vande Bharat Express' : 'Superfast Rajdhani Express',
    serviceName: distanceKm < 600 ? 'Executive AC Chair Car' : 'AC 3-Tier Comfort (3A)',
    departureTime: '06:15',
    arrivalTime: `${String((6 + trainHours) % 24).padStart(2, '0')}:40`,
    duration: `${trainHours}h 25m`,
    origin: originCity.name,
    destination: destCity.name,
    boardingPoint: `${originCity.name} Main Junction Platform 1`,
    dropPoint: `${destCity.name} Central Railway Station`,
    farePerPerson: acFare,
    roundTripFarePerPerson: Math.round(acFare * 2),
    amenities: ['Air Conditioned', 'Clean Bedrolls', 'Catering Meals Included', 'Charging Sockets'],
    cancellationPolicy: 'Cancellation policy shown before payment',
    sourceLabel: 'ESTIMATED',
    tag: 'Best fit',
    thumbnail: '/images/thumb-train-ac.webp'
  });

  // 3. Flight options (Feasible only if distance > 300 km)
  if (distanceKm > 300) {
    const flightHours = Math.max(1, Math.round(distanceKm / 600));
    const totalFlightDuration = `${flightHours + 1}h 15m`; // Includes airport transit
    const flightFare = Math.max(2800, Math.round(3000 + distanceKm * 3.5));

    options.push({
      id: `flight-ind-${originCity.id}-${destCity.id}`,
      mode: 'flight',
      operator: 'IndiGo / Air India Express',
      serviceName: 'Economy Standard (Direct)',
      departureTime: '08:45',
      arrivalTime: `${String((8 + flightHours + 1) % 24).padStart(2, '0')}:00`,
      duration: totalFlightDuration,
      origin: originCity.name,
      destination: destCity.name,
      boardingPoint: `${originCity.name} Domestic Airport (T1)`,
      dropPoint: `${destCity.name} Airport (T2)`,
      farePerPerson: flightFare,
      roundTripFarePerPerson: Math.round(flightFare * 1.95),
      amenities: ['15 kg Check-in Baggage', '7 kg Hand Baggage', 'Web Check-in'],
      cancellationPolicy: 'Cancellation policy shown before payment',
      sourceLabel: 'ESTIMATED',
      tag: 'Fastest',
      thumbnail: '/images/thumb-flight.webp'
    });
  } else {
    hiddenModesReason.push({
      mode: 'flight',
      reason: `Direct flight options are hidden for routes under 300 km (${distanceKm} km). High-speed train or cab is faster and more economical door-to-door.`
    });
  }

  return { distanceKm, options, hiddenModesReason };
}
