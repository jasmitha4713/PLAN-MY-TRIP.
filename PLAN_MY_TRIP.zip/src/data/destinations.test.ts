import { describe, it, expect } from 'vitest';
import { 
  SUPPORTED_CITIES, 
  generateTransportOptions, 
  calculateHaversineDistanceKm,
  findCityByName 
} from './destinations';

describe('Destination Database & Generator', () => {
  it('has all 14 required cities with coordinates, attractions, stays and transit', () => {
    expect(SUPPORTED_CITIES.length).toBeGreaterThanOrEqual(10);
    const cityNames = SUPPORTED_CITIES.map(c => c.name);
    expect(cityNames).toContain('New Delhi');
    expect(cityNames).toContain('Mumbai');
    expect(cityNames).toContain('Jaipur');
    expect(cityNames).toContain('Hyderabad');
    expect(cityNames).toContain('Goa');
    expect(cityNames).toContain('Agra');
    expect(cityNames).toContain('Varanasi');
    expect(cityNames).toContain('Hampi');
    expect(cityNames).toContain('Alleppey and Kochi');
    expect(cityNames).toContain('Coorg');
    expect(cityNames).toContain('Udaipur');
    expect(cityNames).toContain('Bengaluru');
    expect(cityNames).toContain('Chennai');

    for (const city of SUPPORTED_CITIES) {
      expect(city.coords.lat).toBeGreaterThan(0);
      expect(city.coords.lng).toBeGreaterThan(0);
      expect(city.attractions.length).toBeGreaterThanOrEqual(6);
      expect(city.stays.length).toBeGreaterThanOrEqual(3);
      expect(city.localTransit.bikeModels.length).toBeGreaterThanOrEqual(3);
      expect(city.localTransit.cabFullDay).toBeGreaterThan(0);

      for (const attraction of city.attractions) {
        expect(attraction.name.trim()).not.toBe('');
        expect(attraction.typicalVisitTime.trim()).not.toBe('');
        expect(attraction.ticketPricePerPerson).toBeGreaterThanOrEqual(0);
      }

      for (const stay of city.stays) {
        expect(stay.name.trim()).not.toBe('');
        expect(stay.ratePerNight).toBeGreaterThan(0);
        expect(stay.roomType.trim()).not.toBe('');
      }
    }
  });

  it('generates non-empty valid transport for all origin-destination pairs', () => {
    for (let i = 0; i < SUPPORTED_CITIES.length; i++) {
      for (let j = 0; j < SUPPORTED_CITIES.length; j++) {
        if (i === j) continue;
        const origin = SUPPORTED_CITIES[i];
        const dest = SUPPORTED_CITIES[j];

        const result = generateTransportOptions(origin.name, dest.name);
        expect(result.distanceKm).toBeGreaterThan(0);
        expect(result.options.length).toBeGreaterThan(0);

        for (const opt of result.options) {
          expect(opt.id.trim()).not.toBe('');
          expect(opt.serviceName.trim()).not.toBe('');
          expect(opt.operator.trim()).not.toBe('');
          expect(opt.departureTime.trim()).not.toBe('');
          expect(opt.arrivalTime.trim()).not.toBe('');
          expect(opt.duration.trim()).not.toBe('');
          expect(opt.farePerPerson).toBeGreaterThan(0);
          expect(opt.roundTripFarePerPerson).toBeGreaterThan(opt.farePerPerson);
          expect(opt.sourceLabel).toBe('ESTIMATED');
        }

        // Distance rules
        if (result.distanceKm > 1500) {
          const hasBus = result.options.some(o => o.mode === 'bus');
          expect(hasBus).toBe(false);
          expect(result.hiddenModesReason?.some(r => r.mode === 'bus')).toBe(true);
        }
        if (result.distanceKm <= 300) {
          const hasFlight = result.options.some(o => o.mode === 'flight');
          expect(hasFlight).toBe(false);
          expect(result.hiddenModesReason?.some(r => r.mode === 'flight')).toBe(true);
        }
      }
    }
  });

  it('correctly maps city aliases', () => {
    expect(findCityByName('delhi')?.name).toBe('New Delhi');
    expect(findCityByName('bangalore')?.name).toBe('Bengaluru');
    expect(findCityByName('bombay')?.name).toBe('Mumbai');
    expect(findCityByName('kerala')?.name).toBe('Alleppey and Kochi');
    expect(findCityByName('kashi')?.name).toBe('Varanasi');
  });
});
