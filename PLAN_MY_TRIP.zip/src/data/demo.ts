export interface BudgetItem {
  category: string;
  amount: number;
  color: string;
}

export interface TripData {
  id: string;
  route: string;
  duration: string;
  budgetLimit: number;
  busOptions: {
    id: string;
    label: string;
    transportCost: number;
  }[];
  baseItems: {
    stay: number;
    food: number;
    activities: number;
    localTravel: number;
    contingency: number;
  };
}

export const DEMO_TRIP: TripData = {
  id: "PMT-0142",
  route: "Hyderabad → Vijayawada",
  duration: "2 days",
  budgetLimit: 4000,
  busOptions: [
    { id: "bus-a", label: "Bus A · ₹1,100", transportCost: 1100 },
    { id: "bus-b", label: "Bus B · ₹900", transportCost: 900 }
  ],
  baseItems: {
    stay: 1200,
    food: 700,
    activities: 400,
    localTravel: 300,
    contingency: 300
  }
};

export const RESCUE_SCENARIO = {
  reportedIssue: "Bus now arrives 8:40 PM. Hotel check-in closes at 9:00 PM. That leaves 20 minutes.",
  options: [
    {
      id: "opt-1",
      title: "Intercity train",
      detail: "Intercity train · Arrives 7:15 PM · Extra cost ₹240 · Subject to seat availability."
    },
    {
      id: "opt-2",
      title: "Notify the hotel about late arrival",
      detail: "Notify the hotel about late arrival · Arrive 8:40 PM · Extra cost ₹0 · The front desk must confirm before check-in closes at 9:00 PM."
    }
  ],
  ruleNote: "We never assume a grace period. If we don't know, we say so."
};

export const ACT_SAFELY_DEMO = {
  preview: {
    action: "Send late-arrival notice to the hotel",
    recipient: "Haveli Dharampura Front Desk",
    cost: "₹0"
  },
  resultStates: [
    {
      status: "CONFIRMED" as const,
      title: "Confirmed by Hotel",
      chipLabel: "CONFIRMED",
      detail: "The hotel front desk acknowledged late check-in. Your room is held until 10:30 PM with late arrival acknowledged."
    },
    {
      status: "PENDING" as const,
      title: "Awaiting Acknowledgement",
      chipLabel: "PENDING",
      detail: "Late check-in notification dispatched via WhatsApp & front desk system. Awaiting receptionist confirmation."
    },
    {
      status: "FAILED" as const,
      title: "Delivery Unsuccessful",
      chipLabel: "FAILED",
      detail: "Front desk unreachable. Your original booking remains unchanged and backup alternatives are presented."
    }
  ],
  ruleNote: "We never say an action is confirmed or room held unless it is verified by code."
};

export const VOICE_TURNS = [
  {
    speaker: "Traveller",
    type: "user",
    text: "Plan a two-day trip to Vijayawada within ₹4,000."
  },
  {
    speaker: "Alexa+",
    type: "orchestration",
    text: "Understands the request and picks the right tool."
  },
  {
    speaker: "Plan My Trip",
    type: "system",
    text: "Calculates the budget and builds the itinerary."
  },
  {
    speaker: "Assistant",
    type: "response",
    text: "Here's your proposed itinerary and budget breakdown. Would you like to save this trip?"
  }
];

export const TRY_ASKING_ITEMS = [
  {
    id: "sample-1",
    image: "/images/sample-1.webp",
    alt: "Prakasam Barrage bridge over the Krishna river at dusk",
    prompt: "Plan a two-day trip from Hyderabad to Vijayawada within ₹4,000."
  },
  {
    id: "sample-2",
    image: "/images/sample-2.webp",
    alt: "Misty pine forest park and trees",
    prompt: "Plan a weekend trip under ₹3,000."
  },
  {
    id: "sample-3",
    image: "/images/sample-3.webp",
    alt: "Aerial view of Tirupati hills and winding road",
    prompt: "Plan a one-day Tirupati hills trip within ₹2,500."
  }
];

export const PROMISES = [
  {
    title: "No action without your approval.",
    body: "You see the exact action and cost before anything happens."
  },
  {
    title: "No refund claims until verified.",
    body: "If we can't confirm it, we say it's pending."
  },
  {
    title: "No guessing on grace periods.",
    body: "If a hotel or operator hasn't confirmed, we tell you what we don't know."
  }
];

export const FAQ_ITEMS = [
  {
    q: "Does it book real tickets?",
    a: "Not in this prototype. It shows sample options and always asks for your approval before any action."
  },
  {
    q: "What happens if I miss my bus?",
    a: "Report the delay or missed bus. Plan My Trip checks your saved trip, shows what it affects, such as hotel check-in, and compares your options."
  },
  {
    q: "Does it remember my trip?",
    a: "Yes. Once you save a trip, follow-up questions use its transport, hotel timings and budget."
  },
  {
    q: "Can I use voice?",
    a: "Yes. You can speak or type. If voice isn't available in your browser, typing works the same."
  }
];
