import { TransportOption, StayOption, LocalTravelOption, ExperienceOption, TripSelections } from '../lib/budget';

export interface DestinationMeta {
  id: string;
  name: string;
  state: string;
  image: string;
  cardImage: string;
  bannerImage: string;
  thumbnail: string;
  typicalTripPrice: number;
  durationDays: number;
  description: string;
  highlights: string[];
}

export interface TripDraft {
  id: string;
  backendTripId?: string;
  userId: string;
  origin: string;
  destination: string;
  days: number;
  travellers: number;
  totalBudget: number;
  status: 'draft' | 'planned';
  selections: TripSelections;
  createdAt: string;
  updatedAt: string;
  // Saved itinerary timings
  schedule?: {
    plannedArrival: string;
    stayCutoff: string;
    checkInTime: string;
    checkOutTime: string;
  };
  itineraryData?: Array<{
    day: number;
    time: string;
    activity: string;
    cost_inr: number;
  }>;
}

// Six Curated Indian Destinations
export const DESTINATIONS: DestinationMeta[] = [
  {
    id: 'delhi',
    name: 'New Delhi',
    state: 'National Capital',
    image: '/images/dest-delhi-card.webp',
    cardImage: '/images/dest-delhi-card.webp',
    bannerImage: '/images/dest-delhi-banner.webp',
    thumbnail: '/images/dest-delhi-card.webp',
    typicalTripPrice: 12700,
    durationDays: 3,
    description: 'Centuries of empire, bustling haveli lanes, and monumental Mughal architecture.',
    highlights: ['India Gate', 'Old Delhi Haveli', 'Qutub Minar', 'Chandni Chowk Food Trail']
  },
  {
    id: 'jaipur',
    name: 'Jaipur',
    state: 'Rajasthan',
    image: '/images/dest-jaipur-card.webp',
    cardImage: '/images/dest-jaipur-card.webp',
    bannerImage: '/images/dest-jaipur-banner.webp',
    thumbnail: '/images/dest-jaipur-card.webp',
    typicalTripPrice: 7500,
    durationDays: 3,
    description: 'Amber sandstone ramparts, geometric observatories, and vibrant textile bazaars.',
    highlights: ['Amber Fort', 'Arya Niwas Heritage', 'Hawa Mahal', 'Local Tuk-Tuk Pass']
  },
  {
    id: 'hampi',
    name: 'Hampi',
    state: 'Karnataka',
    image: '/images/dest-hampi-card.webp',
    cardImage: '/images/dest-hampi-card.webp',
    bannerImage: '/images/dest-hampi-banner.webp',
    thumbnail: '/images/dest-hampi-card.webp',
    typicalTripPrice: 6200,
    durationDays: 3,
    description: 'A surreal boulder kingdom with UNESCO-protected 14th-century Vijayanagara ruins.',
    highlights: ['Virupaksha Temple', 'Stone Chariot', 'Tungabhadra Coracle', 'Boutique Guesthouse']
  },
  {
    id: 'varanasi',
    name: 'Varanasi',
    state: 'Uttar Pradesh',
    image: '/images/dest-varanasi-card.webp',
    cardImage: '/images/dest-varanasi-card.webp',
    bannerImage: '/images/dest-varanasi-banner.webp',
    thumbnail: '/images/dest-varanasi-card.webp',
    typicalTripPrice: 5500,
    durationDays: 2,
    description: 'Timeless stone river ghats, morning wooden boat rides, and evening Ganga Aarti chants.',
    highlights: ['Ahilya Ghat', 'Subah-e-Banaras Boat', 'Kashi Alleys', 'Silk Weaver Walk']
  },
  {
    id: 'kerala',
    name: 'Alleppey and Kochi',
    state: 'Kerala',
    image: '/images/dest-alleppey-card.webp',
    cardImage: '/images/dest-alleppey-card.webp',
    bannerImage: '/images/dest-alleppey-banner.webp',
    thumbnail: '/images/dest-alleppey-card.webp',
    typicalTripPrice: 14000,
    durationDays: 4,
    description: 'Palm-fringed canal backwaters, traditional kettuvallam houseboats, and spice trade streets.',
    highlights: ['Backwaters Houseboat', 'Fort Kochi Heritage', 'Kathakali Centre', 'Spice Trail']
  },
  {
    id: 'coorg',
    name: 'Coorg',
    state: 'Karnataka',
    image: '/images/dest-coorg-card.webp',
    cardImage: '/images/dest-coorg-card.webp',
    bannerImage: '/images/dest-coorg-banner.webp',
    thumbnail: '/images/dest-coorg-card.webp',
    typicalTripPrice: 6500,
    durationDays: 3,
    description: 'Misty Western Ghats valleys, rolling coffee and cardamom estates, and cool hill trails.',
    highlights: ['Tadiandamol Valley', 'Coffee Estate Homestay', 'Abbey Falls', 'Madikeri Fort']
  }
];

// Primary Demo Fixtures: Hyderabad -> New Delhi (3 days, 2 pax, ₹15,000 budget)
export const DEFAULT_TRANSPORT_OPTIONS: TransportOption[] = [
  {
    id: 'train-sleeper',
    name: 'Overnight sleeper train',
    mode: 'train',
    farePerPerson: 1050,
    roundTripMultiplier: 2,
    duration: '22h 30m',
    operatorType: 'Express Sleeper Berth',
    tag: 'Best fit',
    thumbnail: '/images/thumb-train-sleeper.webp',
    image: '/images/thumb-train-sleeper.webp',
  },
  {
    id: 'train-3ac',
    name: 'AC 3-Tier train',
    mode: 'train',
    farePerPerson: 2700,
    roundTripMultiplier: 2,
    duration: '21h 15m',
    operatorType: 'Superfast AC 3-Tier',
    tag: 'Comfort',
    thumbnail: '/images/thumb-train-ac.webp',
    image: '/images/thumb-train-ac.webp',
  },
  {
    id: 'flight-economy',
    name: 'Economy direct flight',
    mode: 'flight',
    farePerPerson: 5200,
    roundTripMultiplier: 2,
    duration: '2h 15m',
    operatorType: 'Non-stop Domestic Airline',
    tag: 'Fastest',
    thumbnail: '/images/thumb-flight.webp',
    image: '/images/thumb-flight.webp',
  }
];

export const DEFAULT_STAY_OPTIONS: StayOption[] = [
  {
    id: 'stay-haveli',
    name: 'Old Delhi Haveli Stay',
    tier: 'heritage',
    ratePerNight: 1800,
    location: 'Chandni Chowk / Old Delhi',
    inclusions: ['Courtyard breakfast', 'Wi-Fi', '24h desk'],
    tag: 'Best fit',
    thumbnail: '/images/thumb-stay-haveli.webp',
    image: '/images/thumb-stay-haveli.webp',
  },
  {
    id: 'stay-hostel',
    name: 'Budget Hostel Room',
    tier: 'hostel',
    ratePerNight: 900,
    location: 'Paharganj / Central Delhi',
    inclusions: ['Private double room', 'Shared lounge', 'Wi-Fi'],
    tag: 'Cheapest',
    thumbnail: '/images/thumb-stay-budget.webp',
    image: '/images/thumb-stay-budget.webp',
  },
  {
    id: 'stay-boutique',
    name: 'Boutique Hotel',
    tier: 'boutique',
    ratePerNight: 3400,
    location: 'South Delhi / Mehrauli',
    inclusions: ['Executive suite', 'Breakfast buffet', 'Airport shuttle option'],
    tag: 'Comfort',
    thumbnail: '/images/thumb-stay-boutique.webp',
    image: '/images/thumb-stay-boutique.webp',
  }
];

export const DEFAULT_LOCAL_OPTIONS: LocalTravelOption[] = [
  {
    id: 'local-station-cab',
    name: 'Station cab',
    type: 'cab',
    pricingModel: 'per_ride',
    unitPrice: 350,
    quantity: 2,
    tag: 'Best fit',
    thumbnail: '/images/thumb-cab.webp',
    image: '/images/thumb-cab.webp',
  },
  {
    id: 'local-auto-day',
    name: 'Auto day hire',
    type: 'auto',
    pricingModel: 'per_day',
    unitPrice: 800,
    quantity: 1,
    tag: 'Best fit',
    thumbnail: '/images/thumb-auto.webp',
    image: '/images/thumb-auto.webp',
  },
  {
    id: 'local-metro-pass',
    name: 'Metro day pass',
    type: 'metro',
    pricingModel: 'per_person',
    unitPrice: 300,
    quantity: 1,
    tag: 'Cheapest',
    thumbnail: '/images/thumb-metro.webp',
    image: '/images/thumb-metro.webp',
  },
  {
    id: 'local-self-drive',
    name: 'Self-drive rental',
    type: 'rental',
    pricingModel: 'per_day',
    unitPrice: 1600,
    quantity: 1,
    tag: 'Flexible',
    thumbnail: '/images/thumb-rental.webp',
    image: '/images/thumb-rental.webp',
  }
];

export const DEFAULT_EXPERIENCE_OPTIONS: ExperienceOption[] = [
  {
    id: 'exp-heritage-walk',
    name: 'Old Delhi heritage walk',
    pricePerPerson: 600,
    duration: '2.5 hours',
    timing: 'Morning 9:00 AM',
    category: 'Cultural',
    tag: 'Essential',
    thumbnail: '/images/thumb-exp-heritage.webp',
    image: '/images/thumb-exp-heritage.webp',
  },
  {
    id: 'exp-qutub-minar',
    name: 'Qutub Minar and Mehrauli',
    pricePerPerson: 200,
    duration: '2 hours',
    timing: 'Afternoon 3:00 PM',
    category: 'Architecture',
    tag: 'Popular',
    thumbnail: '/images/thumb-exp-heritage.webp',
    image: '/images/thumb-exp-heritage.webp',
  },
  {
    id: 'exp-food-trail',
    name: 'Chandni Chowk food trail',
    pricePerPerson: 900,
    duration: '3 hours',
    timing: 'Evening 6:30 PM',
    category: 'Food',
    tag: 'Popular',
    thumbnail: '/images/thumb-exp-culinary.webp',
    image: '/images/thumb-exp-culinary.webp',
  },
  {
    id: 'exp-humayun-tomb',
    name: "Humayun's Tomb",
    pricePerPerson: 150,
    duration: '1.5 hours',
    timing: 'Morning 10:00 AM',
    category: 'Heritage',
    tag: 'Popular',
    thumbnail: '/images/dest-delhi-card.webp',
    image: '/images/dest-delhi-card.webp',
  }
];

// Baseline Primary Demo Trip (Default Plan)
export function createDefaultDemoTrip(userId: string = 'demo-traveler-001'): TripDraft {
  const selections: TripSelections = {
    transport: DEFAULT_TRANSPORT_OPTIONS[0], // Sleeper train ₹1,050
    stay: DEFAULT_STAY_OPTIONS[0],           // Old Delhi Haveli Stay ₹1,800
    localTravel: [
      { ...DEFAULT_LOCAL_OPTIONS[0], quantity: 2 }, // Station cab x2 = ₹700
      { ...DEFAULT_LOCAL_OPTIONS[1], quantity: 1 }, // Auto day hire x1 = ₹800
    ],
    experiences: [
      DEFAULT_EXPERIENCE_OPTIONS[0], // Old Delhi heritage walk ₹600 pp
      DEFAULT_EXPERIENCE_OPTIONS[1], // Qutub Minar ₹200 pp
    ],
    foodPerPersonPerDay: 300,
  };

  return {
    id: 'PMT-0142',
    backendTripId: 'trip_hyd_del_001',
    userId,
    origin: 'Hyderabad',
    destination: 'New Delhi',
    days: 3,
    travellers: 2,
    totalBudget: 15000,
    status: 'planned',
    selections,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    schedule: {
      plannedArrival: '7:55 PM',
      stayCutoff: '9:00 PM',
      checkInTime: '2:00 PM',
      checkOutTime: '11:00 AM'
    }
  };
}

// Rescue Simulation Scenario Data
export const RESCUE_SCENARIO = {
  tripId: 'PMT-0142',
  route: 'Hyderabad to New Delhi',
  transitName: 'Overnight sleeper train',
  plannedArrival: '7:55 PM',
  stayCutoff: '9:00 PM',
  stayName: 'Old Delhi Haveli Stay',
  delayMinutes: 45,
  newArrival: '8:40 PM',
  remainingWindowMinutes: 20,
  options: [
    {
      id: 'opt-cab',
      title: 'Priority station cab',
      costDifference: 180,
      costLabel: '+₹180',
      estimateText: 'saves about 15 minutes (estimate)',
      actionDescription: 'Dispatch priority prepaid sedan directly from Ajmeri Gate exit.',
      recipient: 'Station Cab Provider',
    },
    {
      id: 'opt-stay-notice',
      title: 'Message the stay about late arrival',
      costDifference: 0,
      costLabel: '₹0',
      estimateText: "they must confirm; we don't assume they'll wait.",
      actionDescription: 'Send late check-in notification to Old Delhi Haveli Stay front desk.',
      recipient: 'Stay front desk',
    }
  ]
};

// Deterministic Fixture Generator for Any Destination
export function getFixturesForDestination(destinationName: string, originName: string = 'Hyderabad') {
  const norm = destinationName.toLowerCase();
  
  if (norm.includes('delhi')) {
    return {
      transports: DEFAULT_TRANSPORT_OPTIONS,
      stays: DEFAULT_STAY_OPTIONS,
      local: DEFAULT_LOCAL_OPTIONS,
      experiences: DEFAULT_EXPERIENCE_OPTIONS,
    };
  }

  // Multiplier based on destination type
  const isSouth = norm.includes('hampi') || norm.includes('coorg') || norm.includes('kerala');
  const distanceFactor = isSouth ? 0.75 : 1.1;

  const transports: TransportOption[] = [
    {
      id: `train-sleeper-${norm}`,
      name: 'Overnight sleeper train',
      mode: 'train',
      farePerPerson: Math.round(950 * distanceFactor),
      roundTripMultiplier: 2,
      duration: isSouth ? '12h 00m' : '26h 00m',
      operatorType: 'Express Sleeper Berth',
      tag: 'Best fit',
      thumbnail: '/images/thumb-train-sleeper.webp',
      image: '/images/thumb-train-sleeper.webp',
    },
    {
      id: `train-3ac-${norm}`,
      name: 'AC 3-Tier train',
      mode: 'train',
      farePerPerson: Math.round(2300 * distanceFactor),
      roundTripMultiplier: 2,
      duration: isSouth ? '11h 30m' : '24h 00m',
      operatorType: 'Superfast AC 3-Tier',
      tag: 'Comfort',
      thumbnail: '/images/thumb-train-ac.webp',
      image: '/images/thumb-train-ac.webp',
    },
    {
      id: `flight-${norm}`,
      name: 'Economy direct flight',
      mode: 'flight',
      farePerPerson: Math.round(4800 * distanceFactor),
      roundTripMultiplier: 2,
      duration: '1h 50m',
      operatorType: 'Non-stop Domestic Airline',
      tag: 'Fastest',
      thumbnail: '/images/thumb-flight.webp',
      image: '/images/thumb-flight.webp',
    }
  ];

  const stays: StayOption[] = [
    {
      id: `stay-heritage-${norm}`,
      name: `${destinationName} Heritage Guesthouse`,
      tier: 'heritage',
      ratePerNight: 1600,
      location: 'Central Old Town',
      inclusions: ['Traditional breakfast', 'Wi-Fi'],
      tag: 'Best fit',
      thumbnail: '/images/thumb-stay-haveli.webp',
      image: '/images/thumb-stay-haveli.webp',
    },
    {
      id: `stay-budget-${norm}`,
      name: `Budget Travel Room`,
      tier: 'hostel',
      ratePerNight: 850,
      location: 'Near Station',
      inclusions: ['Clean private room', 'Wi-Fi'],
      tag: 'Cheapest',
      thumbnail: '/images/thumb-stay-budget.webp',
      image: '/images/thumb-stay-budget.webp',
    },
    {
      id: `stay-boutique-${norm}`,
      name: `Boutique Resort`,
      tier: 'boutique',
      ratePerNight: 3100,
      location: 'Scenic Outskirts',
      inclusions: ['Scenic view', 'Buffet breakfast'],
      tag: 'Comfort',
      thumbnail: '/images/thumb-stay-boutique.webp',
      image: '/images/thumb-stay-boutique.webp',
    }
  ];

  const local: LocalTravelOption[] = [
    {
      id: `local-cab-${norm}`,
      name: 'Station cab',
      type: 'cab',
      pricingModel: 'per_ride',
      unitPrice: 320,
      quantity: 2,
      tag: 'Best fit',
      thumbnail: '/images/thumb-cab.webp',
      image: '/images/thumb-cab.webp',
    },
    {
      id: `local-auto-${norm}`,
      name: 'Auto day hire',
      type: 'auto',
      pricingModel: 'per_day',
      unitPrice: 750,
      quantity: 1,
      tag: 'Best fit',
      thumbnail: '/images/thumb-auto.webp',
      image: '/images/thumb-auto.webp',
    },
    {
      id: `local-rental-${norm}`,
      name: 'Scooter / bike rental',
      type: 'rental',
      pricingModel: 'per_day',
      unitPrice: 500,
      quantity: 1,
      tag: 'Flexible',
      thumbnail: '/images/thumb-rental.webp',
      image: '/images/thumb-rental.webp',
    }
  ];

  const experiences: ExperienceOption[] = [
    {
      id: `exp-1-${norm}`,
      name: `${destinationName} guided heritage walk`,
      pricePerPerson: 500,
      duration: '2.5 hours',
      category: 'Cultural',
      tag: 'Essential',
      thumbnail: '/images/thumb-exp-heritage.webp',
      image: '/images/thumb-exp-heritage.webp',
    },
    {
      id: `exp-2-${norm}`,
      name: 'Local landmark entry & tour',
      pricePerPerson: 250,
      duration: '2 hours',
      category: 'Sightseeing',
      tag: 'Popular',
      thumbnail: '/images/dest-delhi-card.webp',
      image: '/images/dest-delhi-card.webp',
    },
    {
      id: `exp-3-${norm}`,
      name: 'Regional cuisine food trail',
      pricePerPerson: 750,
      duration: '3 hours',
      category: 'Food',
      tag: 'Popular',
      thumbnail: '/images/thumb-exp-culinary.webp',
      image: '/images/thumb-exp-culinary.webp',
    }
  ];

  return { transports, stays, local, experiences };
}
