import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import {
  User,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  signInWithPhoneNumber,
  RecaptchaVerifier,
  ConfirmationResult
} from 'firebase/auth';
import { auth } from '../lib/firebase';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  authError: string | null;
  clearError: () => void;
  signInWithGoogle: () => Promise<User | null>;
  loginWithGoogle: () => Promise<User | null>;
  signInWithEmail: (email: string, pass: string) => Promise<User | null>;
  loginWithEmail: (email: string, pass: string) => Promise<User | null>;
  signUpWithEmail: (email: string, pass: string, name?: string) => Promise<User | null>;
  registerWithEmail: (email: string, pass: string, name?: string) => Promise<User | null>;
  initRecaptcha: (containerId: string) => RecaptchaVerifier;
  setupRecaptcha: (containerId: string) => RecaptchaVerifier;
  sendPhoneOtp: (phoneNumber: string, verifier: RecaptchaVerifier) => Promise<ConfirmationResult>;
  confirmPhoneOtp: (confirmationResult: ConfirmationResult, verificationCode: string) => Promise<User | null>;
  signInWithDemoUser: () => Promise<User | null>;
  loginAsGuest: () => Promise<User | null>;
  logout: () => Promise<void>;
  isAuthModalOpen: boolean;
  openAuthModal: () => void;
  closeAuthModal: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Human-friendly error messages for common Firebase Auth error codes
export function formatAuthError(codeOrMessage: string): string {
  if (!codeOrMessage) return 'An unexpected error occurred. Please try again.';

  if (codeOrMessage.includes('auth/invalid-credential') || codeOrMessage.includes('auth/wrong-password') || codeOrMessage.includes('auth/user-not-found')) {
    return 'Invalid email or password. Please check your details and try again.';
  }
  if (codeOrMessage.includes('auth/email-already-in-use')) {
    return 'An account with this email address already exists. Please sign in instead.';
  }
  if (codeOrMessage.includes('auth/weak-password')) {
    return 'Password should be at least 6 characters long.';
  }
  if (codeOrMessage.includes('auth/invalid-email')) {
    return 'Please enter a valid email address.';
  }
  if (codeOrMessage.includes('auth/popup-closed-by-user')) {
    return 'Sign in was cancelled. Please try again.';
  }
  if (codeOrMessage.includes('auth/cancelled-popup-request')) {
    return 'Sign in was cancelled.';
  }
  if (codeOrMessage.includes('auth/popup-blocked')) {
    return 'Sign-in popup was blocked by your browser. Please allow popups for this site.';
  }
  if (codeOrMessage.includes('auth/invalid-phone-number')) {
    return 'Please enter a valid phone number with country code (e.g., +91 98765 43210).';
  }
  if (codeOrMessage.includes('auth/missing-phone-number')) {
    return 'Please enter a phone number.';
  }
  if (codeOrMessage.includes('auth/quota-exceeded')) {
    return 'SMS quota exceeded for today. Please try again later or use Google/Email sign in.';
  }
  if (codeOrMessage.includes('auth/invalid-verification-code')) {
    return 'The 6-digit verification code is incorrect. Please check and re-enter.';
  }
  if (codeOrMessage.includes('auth/code-expired')) {
    return 'The verification code has expired. Please request a new code.';
  }
  if (codeOrMessage.includes('auth/too-many-requests')) {
    return 'Too many attempts. Access has been temporarily disabled. Please wait a moment and try again.';
  }
  if (codeOrMessage.includes('auth/network-request-failed')) {
    return 'Network connection issue. Please check your internet connection.';
  }
  if (codeOrMessage.includes('auth/operation-not-allowed')) {
    return 'Google sign-in is not enabled in your Firebase console. Please enable Google under Firebase Authentication -> Sign-in method.';
  }
  if (codeOrMessage.includes('auth/unauthorized-domain')) {
    return 'This domain is not authorized in your Firebase console. Add localhost to Authorized Domains under Firebase Authentication -> Settings.';
  }
  if (codeOrMessage.includes('auth/configuration-not-found')) {
    return 'Firebase authentication configuration was not found. Please verify your project credentials.';
  }

  // Clean raw messages
  return codeOrMessage.replace(/^Firebase:\s*/i, '').replace(/\(auth\/[^)]+\)\.?/i, '').trim() || 'Authentication failed. Please try again.';
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const dev = localStorage.getItem('pmt_dev_test_session');
      return dev ? JSON.parse(dev) : null;
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState<boolean>(() => {
    try {
      return !localStorage.getItem('pmt_dev_test_session');
    } catch {
      return true;
    }
  });
  const [authError, setAuthError] = useState<string | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  useEffect(() => {
    // Auth state listener for user session changes
    const unsubscribe = onAuthStateChanged(
      auth,
      (currentUser) => {
        if (currentUser) {
          setUser(currentUser);
        } else {
          try {
            const devSession = localStorage.getItem('pmt_dev_test_session');
            if (devSession) {
              setUser(JSON.parse(devSession));
            } else {
              setUser(null);
            }
          } catch (e) {
            setUser(null);
          }
        }
        setLoading(false);
      },
      (error) => {
        console.error('Firebase onAuthStateChanged error:', error);
        setAuthError(formatAuthError(error.code || error.message));
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  const clearError = () => setAuthError(null);
  const openAuthModal = () => {
    setAuthError(null);
    setIsAuthModalOpen(true);
  };
  const closeAuthModal = () => {
    setAuthError(null);
    setIsAuthModalOpen(false);
  };

  // Google Sign-in
  const signInWithGoogle = async (): Promise<User | null> => {
    setAuthError(null);
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      const result = await signInWithPopup(auth, provider);
      closeAuthModal();
      return result.user;
    } catch (err: any) {
      console.error('Google sign-in error:', err);
      setAuthError(formatAuthError(err.code || err.message));
      throw err;
    }
  };

  // Email & Password Sign-in
  const signInWithEmail = async (email: string, pass: string): Promise<User | null> => {
    setAuthError(null);
    try {
      const result = await signInWithEmailAndPassword(auth, email.trim(), pass);
      closeAuthModal();
      return result.user;
    } catch (err: any) {
      console.error('Email sign-in error:', err);
      setAuthError(formatAuthError(err.code || err.message));
      throw err;
    }
  };

  // Email & Password Registration
  const signUpWithEmail = async (email: string, pass: string, name?: string): Promise<User | null> => {
    setAuthError(null);
    try {
      const result = await createUserWithEmailAndPassword(auth, email.trim(), pass);
      if (name && name.trim()) {
        await updateProfile(result.user, { displayName: name.trim() });
      }
      closeAuthModal();
      return result.user;
    } catch (err: any) {
      console.error('Email registration error:', err);
      setAuthError(formatAuthError(err.code || err.message));
      throw err;
    }
  };

  // Setup reCAPTCHA Verifier for Phone Auth
  const initRecaptcha = (containerId: string): RecaptchaVerifier => {
    // If an existing verifier exists on window, clear it first
    if ((window as any).recaptchaVerifier) {
      try {
        (window as any).recaptchaVerifier.clear();
      } catch (e) {
        // ignore
      }
    }

    const verifier = new RecaptchaVerifier(auth, containerId, {
      size: 'invisible',
      callback: () => {
        // reCAPTCHA solved
      },
      'expired-callback': () => {
        setAuthError('reCAPTCHA expired. Please try again.');
      }
    });

    (window as any).recaptchaVerifier = verifier;
    return verifier;
  };

  // Send Phone SMS OTP
  const sendPhoneOtp = async (phoneNumber: string, verifier: RecaptchaVerifier): Promise<ConfirmationResult> => {
    setAuthError(null);
    try {
      const confirmationResult = await signInWithPhoneNumber(auth, phoneNumber.trim(), verifier);
      return confirmationResult;
    } catch (err: any) {
      console.error('Phone OTP request error:', err);
      setAuthError(formatAuthError(err.code || err.message));
      throw err;
    }
  };

  // Confirm Phone SMS OTP
  const confirmPhoneOtp = async (confirmationResult: ConfirmationResult, verificationCode: string): Promise<User | null> => {
    setAuthError(null);
    try {
      const result = await confirmationResult.confirm(verificationCode.trim());
      closeAuthModal();
      return result.user;
    } catch (err: any) {
      console.error('OTP confirmation error:', err);
      setAuthError(formatAuthError(err.code || err.message));
      throw err;
    }
  };

  // Logout
  const logout = async (): Promise<void> => {
    setAuthError(null);
    try {
      localStorage.removeItem('pmt_dev_test_session');
      await signOut(auth);
      setUser(null);
    } catch (err: any) {
      console.error('Logout error:', err);
      setAuthError(formatAuthError(err.code || err.message));
      throw err;
    }
  };

  // Instant Demo User Sign-in for local development & preview
  const signInWithDemoUser = async (): Promise<User | null> => {
    setAuthError(null);
    const demoUser = {
      uid: 'demo-traveler-001',
      displayName: 'Aarav Sharma',
      email: 'aarav.sharma@example.com',
      photoURL: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
      emailVerified: true,
      isAnonymous: false,
      metadata: {},
      providerData: [{
        providerId: 'google.com',
        uid: 'demo-traveler-001',
        displayName: 'Aarav Sharma',
        email: 'aarav.sharma@example.com',
        phoneNumber: null,
        photoURL: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
      }],
      refreshToken: 'demo-token',
      tenantId: null,
      delete: async () => {},
      getIdToken: async () => 'demo-token',
      getIdTokenResult: async () => ({
        token: 'demo-token',
        signInProvider: 'google.com',
        claims: {},
        authTime: Date.now().toString(),
        issuedAtTime: Date.now().toString(),
        expirationTime: (Date.now() + 3600000).toString(),
      }),
      reload: async () => {},
      toJSON: () => ({}),
      phoneNumber: null,
      providerId: 'firebase',
    } as unknown as User;

    localStorage.setItem('pmt_dev_test_session', JSON.stringify(demoUser));
    setUser(demoUser);
    closeAuthModal();
    return demoUser;
  };

  const contextValue = useMemo(
    () => ({
      user,
      loading,
      authError,
      clearError,
      signInWithGoogle,
      loginWithGoogle: signInWithGoogle,
      signInWithEmail,
      loginWithEmail: signInWithEmail,
      signUpWithEmail,
      registerWithEmail: signUpWithEmail,
      initRecaptcha,
      setupRecaptcha: initRecaptcha,
      sendPhoneOtp,
      confirmPhoneOtp,
      signInWithDemoUser,
      loginAsGuest: signInWithDemoUser,
      logout,
      isAuthModalOpen,
      openAuthModal,
      closeAuthModal,
    }),
    [user, loading, authError, isAuthModalOpen]
  );

  return <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
