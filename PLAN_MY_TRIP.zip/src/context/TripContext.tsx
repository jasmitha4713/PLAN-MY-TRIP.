import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { 
  TripDraft, 
  createDefaultDemoTrip, 
  getFixturesForDestination, 
  DESTINATIONS 
} from '../data/fixtures';
import { 
  TripSelections, 
  TransportOption, 
  StayOption, 
  LocalTravelOption, 
  ExperienceOption, 
  BudgetResult, 
  calculateBudget 
} from '../lib/budget';
import { useAuth } from './AuthContext';

export interface TravellerDetail {
  id: string;
  fullName: string;
  age?: number;
  isPrimary: boolean;
}

interface TripContextType {
  currentTrip: TripDraft;
  updateTrip: (updates: Partial<TripDraft>) => void;
  updateSelections: (updates: Partial<TripSelections>) => void;
  
  // Specific selection updaters
  setTransport: (option: TransportOption | null) => void;
  setStay: (option: StayOption | null) => void;
  toggleLocalTravel: (option: LocalTravelOption) => void;
  toggleExperience: (option: ExperienceOption) => void;
  setFoodPerPersonPerDay: (rate: number) => void;

  // Live Budget
  budget: BudgetResult;

  // Saved Trips
  savedTrips: TripDraft[];
  activeTripId: string;
  saveCurrentTrip: (status?: 'planned' | 'draft') => TripDraft;
  loadTrip: (tripId: string) => void;
  deleteTrip: (tripId: string) => void;
  resetTrip: (destinationName?: string, budget?: number, days?: number, travellers?: number) => TripDraft;
  setAuthoritativeTrip: (trip: TripDraft) => void;

  // Travellers list
  travellers: TravellerDetail[];
  addTraveller: (name: string, age?: number) => void;
  removeTraveller: (id: string) => void;
  updateTraveller: (id: string, updates: Partial<TravellerDetail>) => void;

  // Helpers
  applyPatch: (patch: Partial<TripDraft>) => void;
}

const TripContext = createContext<TripContextType | undefined>(undefined);

export function TripProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const userId = user?.uid || 'demo-traveler-001';
  const storageKey = `pmt_trips_${userId}`;
  const draftKey = `pmt_active_draft_${userId}`;

  // 1. Saved Trips State
  const [savedTrips, setSavedTrips] = useState<TripDraft[]>(() => {
    try {
      const stored = localStorage.getItem(storageKey);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      // ignore
    }
    // Default saved trip for initial demo / rescue testing
    return [createDefaultDemoTrip(userId)];
  });

  // 2. Active Trip Draft
  const [currentTrip, setCurrentTrip] = useState<TripDraft>(() => {
    try {
      const stored = localStorage.getItem(draftKey);
      if (stored) return JSON.parse(stored);
    } catch (e) {
      // ignore
    }
    return savedTrips[0] || createDefaultDemoTrip(userId);
  });

  // 3. Travellers State
  const [travellers, setTravellers] = useState<TravellerDetail[]>([
    {
      id: 'traveller-primary',
      fullName: user?.displayName || 'Aarav Sharma',
      age: 28,
      isPrimary: true
    },
    {
      id: 'traveller-2',
      fullName: 'Rohan Sharma',
      age: 26,
      isPrimary: false
    }
  ]);

  // Sync draft and saved trips to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(savedTrips));
    } catch (e) {}
  }, [savedTrips, storageKey]);

  useEffect(() => {
    try {
      localStorage.setItem(draftKey, JSON.stringify(currentTrip));
    } catch (e) {}
  }, [currentTrip, draftKey]);

  // Compute live budget deterministically
  const budget = useMemo(() => {
    return calculateBudget({
      totalBudget: currentTrip.totalBudget,
      travellers: currentTrip.travellers,
      days: currentTrip.days,
      selections: currentTrip.selections
    });
  }, [currentTrip]);

  const updateTrip = useCallback((updates: Partial<TripDraft>) => {
    setCurrentTrip(prev => ({
      ...prev,
      ...updates,
      updatedAt: new Date().toISOString()
    }));
  }, []);

  const updateSelections = useCallback((updates: Partial<TripSelections>) => {
    setCurrentTrip(prev => ({
      ...prev,
      selections: {
        ...prev.selections,
        ...updates
      },
      updatedAt: new Date().toISOString()
    }));
  }, []);

  const setTransport = useCallback((option: TransportOption | null) => {
    setCurrentTrip(prev => ({
      ...prev,
      selections: {
        ...prev.selections,
        transport: option
      },
      updatedAt: new Date().toISOString()
    }));
  }, []);

  const setStay = useCallback((option: StayOption | null) => {
    setCurrentTrip(prev => ({
      ...prev,
      selections: {
        ...prev.selections,
        stay: option
      },
      updatedAt: new Date().toISOString()
    }));
  }, []);

  const toggleLocalTravel = useCallback((option: LocalTravelOption) => {
    setCurrentTrip(prev => {
      const exists = prev.selections.localTravel.some(l => l.id === option.id);
      let updated: LocalTravelOption[];
      if (exists) {
        updated = prev.selections.localTravel.filter(l => l.id !== option.id);
      } else {
        updated = [...prev.selections.localTravel, option];
      }
      return {
        ...prev,
        selections: {
          ...prev.selections,
          localTravel: updated
        },
        updatedAt: new Date().toISOString()
      };
    });
  }, []);

  const toggleExperience = useCallback((option: ExperienceOption) => {
    setCurrentTrip(prev => {
      const exists = prev.selections.experiences.some(e => e.id === option.id);
      let updated: ExperienceOption[];
      if (exists) {
        updated = prev.selections.experiences.filter(e => e.id !== option.id);
      } else {
        updated = [...prev.selections.experiences, option];
      }
      return {
        ...prev,
        selections: {
          ...prev.selections,
          experiences: updated
        },
        updatedAt: new Date().toISOString()
      };
    });
  }, []);

  const setFoodPerPersonPerDay = useCallback((rate: number) => {
    setCurrentTrip(prev => ({
      ...prev,
      selections: {
        ...prev.selections,
        foodPerPersonPerDay: rate
      },
      updatedAt: new Date().toISOString()
    }));
  }, []);

  const saveCurrentTrip = useCallback((status: 'planned' | 'draft' = 'planned'): TripDraft => {
    const finalTrip: TripDraft = {
      ...currentTrip,
      status,
      updatedAt: new Date().toISOString()
    };

    setSavedTrips(prev => {
      const index = prev.findIndex(t => t.id === finalTrip.id);
      if (index >= 0) {
        const copy = [...prev];
        copy[index] = finalTrip;
        return copy;
      }
      return [finalTrip, ...prev];
    });

    setCurrentTrip(finalTrip);
    return finalTrip;
  }, [currentTrip]);

  const loadTrip = useCallback((tripId: string) => {
    const found = savedTrips.find(t => t.id === tripId);
    if (found) {
      setCurrentTrip(found);
    }
  }, [savedTrips]);

  const deleteTrip = useCallback((tripId: string) => {
    setSavedTrips(prev => prev.filter(t => t.id !== tripId));
    if (currentTrip.id === tripId) {
      const remaining = savedTrips.filter(t => t.id !== tripId);
      if (remaining.length > 0) {
        setCurrentTrip(remaining[0]);
      } else {
        setCurrentTrip(createDefaultDemoTrip(userId));
      }
    }
  }, [savedTrips, currentTrip, userId]);

  const resetTrip = useCallback((
    destinationName: string = 'New Delhi',
    budget: number = 15000,
    days: number = 3,
    travellers: number = 2
  ): TripDraft => {
    const fixtures = getFixturesForDestination(destinationName, 'Hyderabad');
    const newId = `PMT-${Math.floor(1000 + Math.random() * 9000)}`;

    const newTrip: TripDraft = {
      id: newId,
      userId,
      origin: 'Hyderabad',
      destination: destinationName,
      days,
      travellers,
      totalBudget: budget,
      status: 'draft',
      selections: {
        transport: fixtures.transports[0] || null,
        stay: fixtures.stays[0] || null,
        localTravel: fixtures.local.slice(0, 2),
        experiences: fixtures.experiences.slice(0, 2),
        foodPerPersonPerDay: 300,
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      schedule: {
        plannedArrival: '7:55 PM',
        stayCutoff: '9:00 PM',
        checkInTime: '2:00 PM',
        checkOutTime: '11:00 AM'
      }
    };

    setCurrentTrip(newTrip);
    return newTrip;
  }, [userId]);

  const setAuthoritativeTrip = useCallback((trip: TripDraft) => {
    setCurrentTrip(trip);
    setSavedTrips(prev => {
      const idx = prev.findIndex(t => t.id === trip.id || (t as any).backendTripId === trip.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = trip;
        return copy;
      }
      return [trip, ...prev];
    });
  }, []);

  const applyPatch = useCallback((patch: Partial<TripDraft>) => {
    setCurrentTrip(prev => ({
      ...prev,
      ...patch,
      selections: patch.selections ? { ...prev.selections, ...patch.selections } : prev.selections,
      updatedAt: new Date().toISOString()
    }));
  }, []);

  const addTraveller = useCallback((name: string, age?: number) => {
    const newT: TravellerDetail = {
      id: `traveller-${Date.now()}`,
      fullName: name,
      age: age || 25,
      isPrimary: false
    };
    setTravellers(prev => [...prev, newT]);
  }, []);

  const removeTraveller = useCallback((id: string) => {
    setTravellers(prev => prev.filter(t => t.id !== id || t.isPrimary));
  }, []);

  const updateTraveller = useCallback((id: string, updates: Partial<TravellerDetail>) => {
    setTravellers(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
  }, []);

  const value = useMemo(() => ({
    currentTrip,
    updateTrip,
    updateSelections,
    setTransport,
    setStay,
    toggleLocalTravel,
    toggleExperience,
    setFoodPerPersonPerDay,
    budget,
    savedTrips,
    activeTripId: currentTrip.id,
    saveCurrentTrip,
    loadTrip,
    deleteTrip,
    resetTrip,
    setAuthoritativeTrip,
    travellers,
    addTraveller,
    removeTraveller,
    updateTraveller,
    applyPatch
  }), [
    currentTrip,
    updateTrip,
    updateSelections,
    setTransport,
    setStay,
    toggleLocalTravel,
    toggleExperience,
    setFoodPerPersonPerDay,
    budget,
    savedTrips,
    saveCurrentTrip,
    loadTrip,
    deleteTrip,
    resetTrip,
    setAuthoritativeTrip,
    travellers,
    addTraveller,
    removeTraveller,
    updateTraveller,
    applyPatch
  ]);

  return <TripContext.Provider value={value}>{children}</TripContext.Provider>;
}

export function useTrip() {
  const context = useContext(TripContext);
  if (!context) {
    throw new Error('useTrip must be used within a TripProvider');
  }
  return context;
}
