import { describe, it, expect } from 'vitest';
import { calculateBudget, formatINR, TripSelections } from './budget';

describe('Pure Budget Engine Unit Tests', () => {
  const defaultSelections: TripSelections = {
    transport: {
      id: 'train-sleeper',
      name: 'Overnight sleeper train',
      mode: 'train',
      farePerPerson: 1050,
      roundTripMultiplier: 2,
    },
    stay: {
      id: 'stay-haveli',
      name: 'Old Delhi Haveli Stay',
      tier: 'heritage',
      ratePerNight: 1800,
    },
    localTravel: [
      {
        id: 'local-station-cab',
        name: 'Station cab',
        type: 'cab',
        pricingModel: 'per_ride',
        unitPrice: 350,
        quantity: 2,
      },
      {
        id: 'local-auto-day',
        name: 'Auto day hire',
        type: 'auto',
        pricingModel: 'per_day',
        unitPrice: 800,
        quantity: 1,
      },
    ],
    experiences: [
      {
        id: 'exp-heritage-walk',
        name: 'Old Delhi heritage walk',
        pricePerPerson: 600,
      },
      {
        id: 'exp-qutub-minar',
        name: 'Qutub Minar and Mehrauli',
        pricePerPerson: 200,
      },
    ],
    foodPerPersonPerDay: 300,
  };

  it('calculates the primary demo baseline within budget with exact numbers', () => {
    const res = calculateBudget({
      totalBudget: 15000,
      travellers: 2,
      days: 3,
      selections: defaultSelections,
    });

    expect(res.buffer).toBe(1200); // 8% of 15,000
    expect(res.spendableTarget).toBe(13800); // 15,000 - 1,200
    expect(res.spent.transport).toBe(4200); // 1,050 * 2 travellers * 2 legs
    expect(res.spent.stay).toBe(3600); // 1,800 * 1 room * 2 nights
    expect(res.spent.local).toBe(1500); // 350*2 + 800*1
    expect(res.spent.experiences).toBe(1600); // (600 + 200) * 2 travellers
    expect(res.spent.food).toBe(1800); // 300 * 2 travellers * 3 days
    expect(res.totalSpent).toBe(12700);
    expect(res.safeToSpend).toBe(1100); // 13,800 - 12,700
    expect(res.state).toBe('within');
  });

  it('transitions to using_buffer when spendable target is exceeded', () => {
    const selectionsWithFoodTrail: TripSelections = {
      ...defaultSelections,
      experiences: [
        ...defaultSelections.experiences,
        {
          id: 'exp-food-trail',
          name: 'Chandni Chowk food trail',
          pricePerPerson: 900,
        },
      ],
    };

    const res = calculateBudget({
      totalBudget: 15000,
      travellers: 2,
      days: 3,
      selections: selectionsWithFoodTrail,
    });

    expect(res.totalSpent).toBe(14500); // 12,700 + 1,800
    expect(res.state).toBe('using_buffer');
    expect(res.stateAmount).toBe(700); // 14,500 - 13,800
  });

  it('transitions to over budget state when total budget is exceeded', () => {
    const expensiveSelections: TripSelections = {
      ...defaultSelections,
      stay: {
        id: 'stay-boutique',
        name: 'Boutique Hotel',
        tier: 'boutique',
        ratePerNight: 3500,
      },
    };

    const res = calculateBudget({
      totalBudget: 15000,
      travellers: 2,
      days: 3,
      selections: expensiveSelections,
    });

    // Stay becomes 3,500 * 1 room * 2 nights = 7,000 (was 3,600) -> +3,400 -> total 16,100
    expect(res.totalSpent).toBe(16100);
    expect(res.state).toBe('over');
    expect(res.stateAmount).toBe(1100); // 16,100 - 15,000
    expect(res.remaining).toBe(-1100);
  });

  it('formats INR correctly with standard comma placement and negative support', () => {
    expect(formatINR(12700)).toBe('₹12,700');
    expect(formatINR(0)).toBe('₹0');
    expect(formatINR(150000)).toBe('₹1,50,000');
    expect(formatINR(-1100)).toBe('-₹1,100');
  });
});
