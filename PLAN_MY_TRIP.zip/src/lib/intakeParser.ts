import { SUPPORTED_CITIES, findCityByName } from '../data/destinations';

export interface ParsedTripIntake {
  origin?: string;
  destination?: string;
  isUnsupportedDestination: boolean;
  unsupportedDestinationName?: string;
  suggestedDestinations: string[];
  startDate?: string;
  days?: number;
  travellers?: number | null; // null if range provided like "5-6" or missing
  travellerRange?: [number, number]; // e.g. [5, 6]
  adults?: number;
  children?: number;
  budget?: number | null; // null if range or missing
  approximateBudget?: number;
  preferences: string[];
  rawText: string;
  clarifications: {
    origin?: string;
    destination?: string;
    dates?: string;
    days?: string;
    travellers?: string;
    budget?: string;
  };
}

// Common popular non-supported tourist destinations in India / abroad
const COMMON_UNSUPPORTED: Record<string, string[]> = {
  manali: ['Coorg', 'Jaipur', 'New Delhi'],
  shimla: ['New Delhi', 'Jaipur', 'Agra'],
  ladakh: ['New Delhi', 'Jaipur', 'Varanasi'],
  leh: ['New Delhi', 'Jaipur'],
  rishikesh: ['New Delhi', 'Varanasi', 'Agra'],
  ooty: ['Coorg', 'Bengaluru', 'Alleppey and Kochi'],
  munnar: ['Alleppey and Kochi', 'Coorg', 'Bengaluru'],
  pondicherry: ['Chennai', 'Bengaluru'],
  darjeeling: ['Varanasi', 'New Delhi'],
  paris: ['Mumbai', 'New Delhi', 'Goa'],
  dubai: ['Mumbai', 'New Delhi', 'Goa'],
  bangkok: ['Goa', 'Mumbai', 'Kochi']
};

const WORD_TO_NUM: Record<string, number> = {
  zero: 0,
  one: 1,
  a: 1,
  two: 2,
  couple: 2,
  pair: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  eleven: 11,
  twelve: 12
};

function parseWordOrDigit(val: string): number | null {
  if (!val) return null;
  const clean = val.trim().toLowerCase();
  if (/^\d+$/.test(clean)) return parseInt(clean, 10);
  if (WORD_TO_NUM[clean] !== undefined) return WORD_TO_NUM[clean];
  return null;
}

/**
 * Normalizes common speech-recognition acoustic mistakes when surrounding travel context confirms intent.
 */
export function normalizeSpeechTranscript(text: string): string {
  if (!text) return '';
  let normalized = text.trim();

  // Normalize speech-to-text mishearing of "Plan a trip" / "Plan trip" as "Planet trip" / "Plant trip"
  normalized = normalized.replace(/\bplanet\s+trip\s+(to|for|in|from|[a-z]+)/gi, 'plan a trip $1');
  normalized = normalized.replace(/\bplanet\s+(a\s+)?trip\b/gi, 'plan a trip');
  normalized = normalized.replace(/\bplant\s+(a\s+)?trip\b/gi, 'plan a trip');
  normalized = normalized.replace(/\bplay\s+(a\s+)?trip\b/gi, 'plan a trip');
  normalized = normalized.replace(/\bplanner\s+trip\b/gi, 'plan a trip');

  return normalized;
}

function parseBudgetFromText(lower: string): {
  budget: number | null | undefined;
  approximateBudget?: number;
  clarification?: string;
  isRange?: boolean;
} {
  // Standardize textual words to digits for common Indian travel amounts
  let s = lower
    .replace(/\bone\s+lakh\b|\ba\s+lakh\b/gi, '100000')
    .replace(/\btwo\s+lakhs?\b/gi, '200000')
    .replace(/\bthree\s+lakhs?\b/gi, '300000')
    .replace(/\bfive\s+lakhs?\b/gi, '500000')
    .replace(/\bten\s+thousand\b/gi, '10000')
    .replace(/\bfifteen\s+thousand\b/gi, '15000')
    .replace(/\btwenty\s+five\s+thousand\b/gi, '25000')
    .replace(/\btwenty\s+thousand\b/gi, '20000')
    .replace(/\bthirty\s+thousand\b/gi, '30000')
    .replace(/\bforty\s+thousand\b/gi, '40000')
    .replace(/\bfifty\s+thousand\b/gi, '50000')
    .replace(/\bsixty\s+thousand\b/gi, '60000')
    .replace(/\bseventy\s+thousand\b/gi, '70000')
    .replace(/\beighty\s+thousand\b/gi, '80000')
    .replace(/\bninety\s+thousand\b/gi, '90000')
    .replace(/\b(\d+)\s*thousand\b/gi, '$1000')
    .replace(/\b(\d+)\s+k\b/gi, '$1k')
    .replace(/\bsixty\s+k\b/gi, '60k')
    .replace(/\bfifty\s+k\b/gi, '50k')
    .replace(/\bforty\s+k\b/gi, '40k')
    .replace(/\bthirty\s+k\b/gi, '30k')
    .replace(/\btwenty\s+k\b/gi, '20k');

  // Detect genuine budget ranges like "50k to 60k", "50-60k", "50000 to 60000"
  const rangeMatch = s.match(/(?:budget|under|within|around|approx)?\s*(?:₹|rs\.?|inr)?\s*(\d+k|\d{4,6})\s*(?:-|to)\s*(?:₹|rs\.?|inr)?\s*(\d+k|\d{4,6})/i);
  if (rangeMatch) {
    return {
      budget: null,
      clarification: 'What is your exact total budget limit?',
      isRange: true
    };
  }

  // Detect single amount with "around 60k", "around ₹60,000", "approx 60k"
  const aroundMatch = s.match(/\b(?:around|approx|approximately)\s*(?:₹|rs\.?|inr)?\s*(\d{1,3}(?:,\d{3})+|\d+k|\d{4,6})\b/i);
  if (aroundMatch) {
    let bStr = aroundMatch[1].replace(/,/g, '').toLowerCase();
    let numVal = bStr.endsWith('k') ? parseInt(bStr.slice(0, -1), 10) * 1000 : parseInt(bStr, 10);
    if (numVal >= 1000) {
      return {
        budget: null,
        approximateBudget: numVal,
        clarification: 'What is your exact total budget limit? (You mentioned around)'
      };
    }
  }

  // Detect exact budget matches e.g. "budget 60,000", "under 60k", "₹60,000", "60k", "under 60 thousand"
  const budgetMatch = s.match(/(?:budget|under|within|max|total)?\s*(?:₹|rs\.?|inr)?\s*(\d{1,3}(?:,\d{3})+|\d+k|\d{4,6})\b/i);
  if (budgetMatch) {
    let bStr = budgetMatch[1].replace(/,/g, '').toLowerCase();
    let numVal = bStr.endsWith('k') ? parseInt(bStr.slice(0, -1), 10) * 1000 : parseInt(bStr, 10);
    if (numVal >= 1000) {
      return { budget: numVal };
    }
  }

  return {
    budget: undefined,
    clarification: 'What is your total budget in rupees (₹)?'
  };
}

/**
 * Pure free-text intake parser for natural typed and spoken travel requests
 * Adheres strictly to the Honesty Model: NEVER guesses ranges.
 */
export function parseTripIntake(text: string, defaultOriginCity?: string): ParsedTripIntake {
  const normalizedText = normalizeSpeechTranscript(text);
  const raw = normalizedText.trim();
  const lower = raw.toLowerCase();

  const clarifications: ParsedTripIntake['clarifications'] = {};
  const preferences: string[] = [];

  // 1. Destination Matching
  let destination: string | undefined = undefined;
  let isUnsupported = false;
  let unsupportedName: string | undefined = undefined;
  let suggested: string[] = ['Jaipur', 'New Delhi', 'Mumbai', 'Goa'];

  // Check supported cities
  for (const city of SUPPORTED_CITIES) {
    const cityNameLower = city.name.toLowerCase();
    const cityId = city.id.toLowerCase();
    
    // Check aliases
    const aliases = [cityNameLower, cityId];
    if (city.id === 'delhi') aliases.push('delhi');
    if (city.id === 'bengaluru') aliases.push('bangalore');
    if (city.id === 'mumbai') aliases.push('bombay');
    if (city.id === 'chennai') aliases.push('madras');
    if (city.id === 'alleppey') aliases.push('kerala', 'alleppey', 'kochi', 'cochin');
    if (city.id === 'varanasi') aliases.push('banaras', 'kashi');

    const matchedAlias = aliases.find(alias => {
      const regex = new RegExp(`\\b${alias}\\b`, 'i');
      return regex.test(lower);
    });

    if (matchedAlias) {
      destination = city.name;
      break;
    }
  }

  // Check common unsupported places
  if (!destination) {
    for (const [unsupp, recs] of Object.entries(COMMON_UNSUPPORTED)) {
      if (new RegExp(`\\b${unsupp}\\b`, 'i').test(lower)) {
        isUnsupported = true;
        unsupportedName = unsupp.charAt(0).toUpperCase() + unsupp.slice(1);
        suggested = recs;
        clarifications.destination = `We don't have sample data for ${unsupportedName} yet. Would you like to explore nearest destinations like ${recs.join(', ')}?`;
        break;
      }
    }
  }

  // If destination is still missing
  if (!destination && !isUnsupported) {
    clarifications.destination = 'Where would you like to travel?';
  }

  // 2. Origin Matching
  let origin: string | undefined = undefined;
  const fromMatch = lower.match(/\bfrom\s+([a-z\s]+?)(?=\s+(?:to|for|with|in|under|budget|\d|$))/i);
  if (fromMatch) {
    const rawOrigin = fromMatch[1].trim();
    const matchedCity = findCityByName(rawOrigin);
    if (matchedCity) origin = matchedCity.name;
  }

  if (!origin) {
    for (const city of SUPPORTED_CITIES) {
      if (city.name !== destination) {
        const regex = new RegExp(`\\b${city.id}\\b|\\b${city.name.toLowerCase()}\\b`, 'i');
        if (regex.test(lower) && !destination?.toLowerCase().includes(city.id)) {
          origin = city.name;
          break;
        }
      }
    }
  }

  if (!origin && defaultOriginCity) {
    origin = defaultOriginCity;
  } else if (!origin) {
    origin = 'Hyderabad';
  }

  // 3. Travellers Count (Digit and Word Numbers, Strictly NO Guessing Ranges)
  let travellers: number | null | undefined = undefined;
  let travellerRange: [number, number] | undefined = undefined;
  let adults = 0;
  let children = 0;

  const numToken = '(?:\\d+|one|two|three|four|five|six|seven|eight|nine|ten|couple|solo)';
  // Range detection: e.g. "5 to 6 members", "five to six members", "5 or 6 people", "5-6 pax"
  const rangeMatch = lower.match(new RegExp(`(${numToken})\\s*(?:-|to|or)\\s*(${numToken})\\s*(?:people|members|travellers|travelers|pax|adults|guests|persons)?(?!\\s*(?:days?|nights?|hours?|months?|k\\b|\\d{3}))`, 'i'));
  if (rangeMatch && !rangeMatch[0].includes('day') && !rangeMatch[0].includes('night')) {
    const minVal = parseWordOrDigit(rangeMatch[1]);
    const maxVal = parseWordOrDigit(rangeMatch[2]);
    if (minVal !== null && maxVal !== null && minVal > 0 && maxVal > minVal) {
      travellers = null;
      travellerRange = [minVal, maxVal];
      clarifications.travellers = `Would you like to plan for ${minVal} or ${maxVal} travellers?`;
    }
  }

  if (travellers === undefined && !travellerRange) {
    if (/\bsolo\b/i.test(lower)) {
      travellers = 1;
      adults = 1;
    } else if (/\bcouple\b/i.test(lower)) {
      travellers = 2;
      adults = 2;
    } else {
      // Look for correction patterns: "actually, make it 3", "make it 3", "change to 3", "update to 3"
      const correctionMatch = lower.match(new RegExp(`\\b(?:actually[,\\s]+)?(?:make it|change(?:\\s+it)?\\s+to|update(?:\\s+it)?\\s+to|instead(?:\\s+of\\s+${numToken})?\\s+make it)\\s+(${numToken})\\b`, 'i'));

      // Look for "(for )?(five|5|...) (people|members|travellers...)"
      const memberMatch = lower.match(new RegExp(`\\b(?:for\\s+)?(${numToken})\\s*(?:people|members|travellers|travelers|pax|adults|guests|persons)\\b`, 'i'));
      const forMatch = lower.match(new RegExp(`\\bfor\\s+(${numToken})\\b(?!\\s*(?:days?|nights?|hours?|months?|k\\b|\\d{3}))`, 'i'));
      
      if (correctionMatch) {
        const count = parseWordOrDigit(correctionMatch[1]);
        if (count !== null && count > 0) {
          travellers = count;
          adults = count;
        }
      } else if (memberMatch) {
        const count = parseWordOrDigit(memberMatch[1]);
        if (count !== null && count > 0) {
          travellers = count;
          adults = count;
        }
      } else if (forMatch) {
        const count = parseWordOrDigit(forMatch[1]);
        if (count !== null && count > 0) {
          travellers = count;
          adults = count;
        }
      }
    }
  }

  if (travellers === undefined && !travellerRange) {
    clarifications.travellers = 'How many travellers are going on this journey?';
  }

  // 4. Duration in Days
  let days: number | undefined = undefined;
  const daysMatch = lower.match(/(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\s*(?:days?|nights?)\b/i);
  if (daysMatch) {
    days = parseWordOrDigit(daysMatch[1]) || 3;
  } else if (/\bweekend\b/i.test(lower)) {
    days = 2;
  } else if (/\blong weekend\b/i.test(lower)) {
    days = 3;
  } else if (/\bweek\b/i.test(lower)) {
    days = 7;
  }

  if (!days) {
    clarifications.days = 'How many days will your trip be?';
  }

  // 5. Total Budget (Standardized Words & Digits)
  const budgetResult = parseBudgetFromText(lower);
  let budget = budgetResult.budget;
  if (budgetResult.clarification) {
    clarifications.budget = budgetResult.clarification;
  }

  // 6. Dates
  let startDate: string | undefined = undefined;
  const today = new Date();
  const nextSaturday = new Date();
  nextSaturday.setDate(today.getDate() + ((6 - today.getDay() + 7) % 7 || 7));
  startDate = nextSaturday.toISOString().split('T')[0];

  // 7. Preferences
  if (/heritage|history|fort|palace|ancient/i.test(lower)) preferences.push('heritage');
  if (/food|culinary|chaat|thali|eat|dining/i.test(lower)) preferences.push('culinary');
  if (/nature|beach|mountain|valley|waterfall|green/i.test(lower)) preferences.push('nature');
  if (/luxury|resort|5 star|palace hotel/i.test(lower)) preferences.push('luxury');
  if (/budget|hostel|backpack/i.test(lower)) preferences.push('budget');

  return {
    origin,
    destination,
    isUnsupportedDestination: isUnsupported,
    unsupportedDestinationName: unsupportedName,
    suggestedDestinations: suggested,
    startDate,
    days: days || 3,
    travellers: travellers !== undefined ? travellers : null,
    travellerRange,
    adults: travellers ? Math.max(1, travellers) : (travellerRange ? travellerRange[0] : 0),
    children,
    budget: budget !== undefined ? budget : null,
    approximateBudget: budgetResult.approximateBudget,
    preferences,
    rawText: raw,
    clarifications
  };
}
