import { AlexaClient } from './types';
import { MockAlexaClient } from './mockClient';
import { RemoteAlexaClient } from './remoteClient';

let clientInstance: AlexaClient | null = null;

export function getAlexaClient(): AlexaClient {
  if (clientInstance) return clientInstance;

  const mode = import.meta.env.VITE_ALEXA_MODE || 'remote';
  if (mode === 'mock') {
    clientInstance = new MockAlexaClient();
  } else {
    clientInstance = new RemoteAlexaClient();
  }

  return clientInstance;
}
