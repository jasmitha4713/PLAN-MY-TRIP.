/**
 * PLAN MY TRIP — Conversational Intelligence Engine (Alexa+-style Multimodal Companion)
 *
 * Provides:
 * 1. Multi-turn dialogue state tracking with sliding conversation history window.
 * 2. Single authoritative trip draft state & slot preservation across conversational turns.
 * 3. Conversational slot-filling (asking only for missing info).
 * 4. In-flight conversational corrections (e.g., "Actually, make it five people") without losing destination, duration, or budget.
 * 5. MCP tool orchestration (plan_trip, get_saved_trip, assess_disruption, prepare_recovery_action, approve_recovery_action).
 * 6. Multimodal structured response cards (itinerary, budget breakdown, disruption impact, recovery approval gate).
 * 7. Pluggable backend LLM proxy support (if API keys are configured on server) with zero frontend credential exposure.
 */

import { AlexaContext, AlexaReply, AlexaCard, ToolCallRecord, ToolInfo, BudgetCardPayload, ApprovalCardPayload } from './types';
import { TripDraft } from '../../data/fixtures';
import { calculateBudget, formatINR } from '../budget';

export interface ConversationTurn {
  id: string;
  role: 'user' | 'assistant' | 'tool';
  text: string;
  timestamp: number;
  toolCalls?: ToolCallRecord[];
  cards?: AlexaCard[];
}

export interface TripDraftState {
  destination?: string;
  origin?: string;
  durationDays?: number;
  travelersCount?: number;
  budgetINR?: number;
  startDate?: string;
  endDate?: string;
  activities?: string[];
  interests?: string[];
  activeTripId?: string;
  status: 'empty' | 'drafting' | 'planned' | 'booked' | 'disrupted';
}

export interface ItineraryCardPayload {
  type: 'itinerary_card';
  title: string;
  destination: string;
  durationDays: number;
  travelersCount: number;
  days: Array<{
    day: number;
    title: string;
    highlights: string[];
    costEstimate?: string;
  }>;
}

export interface DisruptionCardPayload {
  type: 'disruption_card';
  title: string;
  delayMinutes: number;
  transportMode: 'train' | 'bus' | 'flight' | 'cab';
  impactSummary: string;
  affectedHotel?: string;
  missedActivities?: string[];
  options: Array<{
    id: string;
    title: string;
    cost: number;
    timeSavedMinutes?: number;
    description: string;
    recommended?: boolean;
  }>;
}

export type ExpandedAlexaCard =
  | BudgetCardPayload
  | ApprovalCardPayload
  | ItineraryCardPayload
  | DisruptionCardPayload
  | { type: 'option_picker'; category: string; title: string; options: any[] };

export class ConversationEngine {
  private history: ConversationTurn[] = [];
  private maxHistoryTurns: number = 10;
  private tripDraft: TripDraftState = {
    origin: 'Hyderabad',
    status: 'empty',
    activities: []
  };

  private stagedAction: any = null;
  private lastDisruption: any = null;

  constructor() {
    this.loadState();
  }

  private loadState(): void {
    if (typeof window !== 'undefined' && window.sessionStorage) {
      try {
        const savedDraft = window.sessionStorage.getItem('pmt_conversation_trip_draft');
        if (savedDraft) this.tripDraft = JSON.parse(savedDraft);

        const savedAction = window.sessionStorage.getItem('pmt_conversation_staged_action');
        if (savedAction) this.stagedAction = JSON.parse(savedAction);

        const savedDisrupt = window.sessionStorage.getItem('pmt_conversation_disruption');
        if (savedDisrupt) this.lastDisruption = JSON.parse(savedDisrupt);
      } catch {}
    }
  }

  private persistState(): void {
    if (typeof window !== 'undefined' && window.sessionStorage) {
      try {
        window.sessionStorage.setItem('pmt_conversation_trip_draft', JSON.stringify(this.tripDraft));
        if (this.stagedAction) {
          window.sessionStorage.setItem('pmt_conversation_staged_action', JSON.stringify(this.stagedAction));
        } else {
          window.sessionStorage.removeItem('pmt_conversation_staged_action');
        }
        if (this.lastDisruption) {
          window.sessionStorage.setItem('pmt_conversation_disruption', JSON.stringify(this.lastDisruption));
        } else {
          window.sessionStorage.removeItem('pmt_conversation_disruption');
        }
      } catch {}
    }
  }

  public getDraft(): TripDraftState {
    return { ...this.tripDraft };
  }

  public getHistory(): ConversationTurn[] {
    return [...this.history];
  }

  public resetDraft(): void {
    this.tripDraft = {
      origin: 'Hyderabad',
      status: 'empty',
      activities: []
    };
    this.stagedAction = null;
    this.lastDisruption = null;
    this.persistState();
  }

  public clearHistory(): void {
    this.history = [];
  }

  public appendTurn(turn: Omit<ConversationTurn, 'id' | 'timestamp'>): ConversationTurn {
    const fullTurn: ConversationTurn = {
      ...turn,
      id: `turn-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now()
    };
    this.history.push(fullTurn);
    if (this.history.length > this.maxHistoryTurns * 2) {
      this.history = this.history.slice(-this.maxHistoryTurns * 2);
    }
    return fullTurn;
  }

  /**
   * Main conversational reasoning step.
   * Analyzes user intent, checks context history, updates slot values, calls MCP tools, and returns multimodal response.
   */
  public async processMessage(
    rawMessage: string,
    ctx: AlexaContext,
    mcpCallTool: (toolName: string, args: Record<string, unknown>) => Promise<any>
  ): Promise<AlexaReply> {
    const message = rawMessage.trim();
    const lower = message.toLowerCase();

    // 1. Record User Turn
    this.appendTurn({ role: 'user', text: message });

    // Sync authoritative active trip ID from context if provided
    if (ctx.tripId) {
      this.tripDraft.activeTripId = ctx.tripId;
    }
    if (ctx.draft) {
      if (ctx.draft.destination && !this.tripDraft.destination) {
        this.tripDraft.destination = ctx.draft.destination;
      }
      if (ctx.draft.totalBudget && !this.tripDraft.budgetINR) {
        this.tripDraft.budgetINR = ctx.draft.totalBudget;
      }
      if (ctx.draft.days && !this.tripDraft.durationDays) {
        this.tripDraft.durationDays = ctx.draft.days;
      }
      if (ctx.draft.travelers && !this.tripDraft.travelersCount) {
        this.tripDraft.travelersCount = ctx.draft.travelers;
      }
    }

    // -------------------------------------------------------------------------
    // INTENT 0: Conversational Greetings & Small Talk
    // -------------------------------------------------------------------------
    const isGreeting =
      /^(hi|hello|hey|good\s+(morning|afternoon|evening)|namaste|greetings)\b/i.test(lower) &&
      lower.split(/\s+/).length <= 4 &&
      !lower.includes('plan') &&
      !lower.includes('budget') &&
      !lower.includes('trip') &&
      !lower.includes('add');

    if (isGreeting) {
      const activeDesc = this.tripDraft.destination
        ? ` We're currently following your journey to ${this.tripDraft.destination}.`
        : '';
      const replyText = `Hello! How can I assist your travels today?${activeDesc} You can plan a new itinerary, adjust your budget, add local experiences, or report a delay.`;
      const reply: AlexaReply = {
        text: replyText,
        toolCalls: []
      };
      this.appendTurn({ role: 'assistant', text: replyText });
      return reply;
    }

    // -------------------------------------------------------------------------
    // INTENT 1: Safety Gate Rejection / Cancellation
    // -------------------------------------------------------------------------
    const hasConditional = /\b(until|before|unless|without|if)\b/i.test(lower);
    const mentionsBookingEntity = /\b(bus|train|flight|hotel|cab|taxi|ticket|seat|room|booking|reservation|trip|journey)\b/i.test(lower);

    const isExplicitRejection =
      !hasConditional &&
      !mentionsBookingEntity &&
      (lower === 'no' ||
        lower === "don't send" ||
        lower.startsWith('reject') ||
        lower.includes('reject that') ||
        lower.includes('reject action') ||
        lower.includes('cancel action') ||
        lower.includes('cancel proposal') ||
        lower.includes('do not send') ||
        lower.includes("don't proceed"));

    if (isExplicitRejection) {
      const toolCalls: ToolCallRecord[] = [];
      const actionToCancel = this.stagedAction?.action_id || 'act_recov_001';

      try {
        const mcpRes = await mcpCallTool('approve_recovery_action', {
          action_id: actionToCancel,
          approved: false,
          user_confirmation: message
        });
        const data = mcpRes?.data || mcpRes;
        toolCalls.push({
          name: 'approve_recovery_action',
          input: { action_id: actionToCancel, approved: false, user_confirmation: message },
          output: data,
          status: 'ok'
        });
      } catch (err: any) {
        toolCalls.push({
          name: 'approve_recovery_action',
          input: { action_id: actionToCancel, approved: false },
          output: { error: err.message },
          status: 'failed'
        });
      }

      this.stagedAction = null;
      this.persistState();

      const replyText = `The proposed recovery action (${actionToCancel}) has been cancelled and will not be executed. Your current bookings remain safe. Let me know if you would like to explore alternative options.`;
      const reply: AlexaReply = {
        text: replyText,
        toolCalls,
        action: {
          id: actionToCancel,
          status: 'failed',
          label: 'Cancelled',
          simulated: true
        }
      };
      this.appendTurn({ role: 'assistant', text: replyText, toolCalls });
      return reply;
    }

    // -------------------------------------------------------------------------
    // INTENT 2: Safety Gate Approval & Execution
    // -------------------------------------------------------------------------
    const isExplicitApproval =
      !hasConditional &&
      (lower === 'yes' ||
        lower === 'approve' ||
        lower === 'confirm' ||
        lower.startsWith('approve') ||
        lower.includes('yes, approve') ||
        lower.includes('yes, confirm') ||
        lower.includes('confirm and notify') ||
        lower.includes('approve & send') ||
        lower.includes('please confirm'));

    if (isExplicitApproval) {
      const toolCalls: ToolCallRecord[] = [];
      if (!this.stagedAction || !this.stagedAction.action_id) {
        const replyText =
          'There is no pending recovery action awaiting approval right now. If your journey is disrupted, report the delay first so I can prepare a solution for your review.';
        const reply: AlexaReply = { text: replyText, toolCalls: [] };
        this.appendTurn({ role: 'assistant', text: replyText });
        return reply;
      }

      const actionId = this.stagedAction.action_id;
      let actionResult: any = null;

      try {
        const mcpRes = await mcpCallTool('approve_recovery_action', {
          action_id: actionId,
          approved: true,
          user_confirmation: message
        });
        actionResult = mcpRes?.data || mcpRes;
        toolCalls.push({
          name: 'approve_recovery_action',
          input: { action_id: actionId, approved: true, user_confirmation: message },
          output: actionResult,
          status: 'ok'
        });
      } catch (err: any) {
        toolCalls.push({
          name: 'approve_recovery_action',
          input: { action_id: actionId, approved: true },
          output: { error: err.message },
          status: 'failed'
        });
      }

      const details = actionResult?.confirmation_details || 'Request dispatched to provider';
      const replyText = `Action ${actionId} has been confirmed and executed! ${details}. I have updated your trip status and notified the relevant provider.`;
      this.stagedAction = null;
      this.persistState();

      const reply: AlexaReply = {
        text: replyText,
        toolCalls,
        action: {
          id: actionId,
          status: 'confirmed',
          label: 'Executed',
          simulated: true
        }
      };
      this.appendTurn({ role: 'assistant', text: replyText, toolCalls });
      return reply;
    }

    // -------------------------------------------------------------------------
    // INTENT 3: In-Flight Slot Correction (e.g., "Actually, make it five people")
    // -------------------------------------------------------------------------
    const isCorrection =
      /\b(actually|change it to|make it|update to|instead of|reduce to|increase to)\b/i.test(lower) ||
      (/\b(five|5|six|6|four|4|two|2|three|3|seven|7)\s+(people|members|travellers|travelers|passengers)\b/i.test(lower) &&
        Boolean(this.tripDraft.destination));

    if (isCorrection) {
      const numberMatch = lower.match(/\b(one|two|three|four|five|six|seven|eight|nine|ten|\d+)\s*(people|members|travellers|travelers|passengers)?\b/i);
      let newCount: number | null = null;
      if (numberMatch) {
        const rawNum = numberMatch[1].toLowerCase();
        const wordMap: Record<string, number> = {
          one: 1, two: 2, three: 3, four: 4, five: 5,
          six: 6, seven: 7, eight: 8, nine: 9, ten: 10
        };
        newCount = wordMap[rawNum] || parseInt(rawNum, 10);
      }

      if (newCount && !isNaN(newCount)) {
        this.tripDraft.travelersCount = newCount;
        this.persistState();

        const patch: Partial<TripDraft> = {
          travelers: newCount,
          adults: newCount
        };

        const replyText = `Updated traveller count to ${newCount}. All other details remain intact: ${this.tripDraft.durationDays || 3}-day trip to ${this.tripDraft.destination || 'your destination'}, budget ${this.tripDraft.budgetINR ? formatINR(this.tripDraft.budgetINR) : 'as planned'}.`;

        const toolCalls: ToolCallRecord[] = [];
        const cards: AlexaCard[] = [];

        // If all slots are present, run plan_trip tool to update itinerary
        if (this.tripDraft.destination && this.tripDraft.budgetINR) {
          try {
            const planRes = await mcpCallTool('plan_trip', {
              origin: this.tripDraft.origin || 'Hyderabad',
              destination: this.tripDraft.destination,
              budget_inr: this.tripDraft.budgetINR,
              start_date: this.tripDraft.startDate || '2026-11-15',
              end_date: this.tripDraft.endDate || '2026-11-18',
              travelers_count: newCount,
              preferences: this.tripDraft.preferences || ['food', 'sightseeing']
            });
            const planData = planRes?.data || planRes;
            toolCalls.push({
              name: 'plan_trip',
              input: {
                destination: this.tripDraft.destination,
                travelers_count: newCount,
                budget_inr: this.tripDraft.budgetINR
              },
              output: planData,
              status: 'ok'
            });

            const breakdown = calculateBudget({
              days: this.tripDraft.durationDays || 3,
              travelers: newCount,
              totalBudget: this.tripDraft.budgetINR,
              tier: 'smart'
            });

            cards.push({
              type: 'budget_summary',
              title: `Updated Budget (${newCount} Travellers)`,
              budget: breakdown
            });
          } catch {}
        }

        const reply: AlexaReply = {
          text: replyText,
          toolCalls,
          cards,
          tripPatch: patch
        };
        this.appendTurn({ role: 'assistant', text: replyText, toolCalls, cards });
        return reply;
      }
    }

    // -------------------------------------------------------------------------
    // INTENT 4: Add Experience / Food Trail / Attraction
    // -------------------------------------------------------------------------
    const isAddActivity =
      lower.includes('add') &&
      (lower.includes('food') ||
        lower.includes('trail') ||
        lower.includes('culinary') ||
        lower.includes('walk') ||
        lower.includes('tour') ||
        lower.includes('experience') ||
        lower.includes('sightseeing'));

    if (isAddActivity) {
      const activeDest = this.tripDraft.destination || (ctx.draft?.destination) || 'New Delhi';
      const isMumbai = /mumbai|bombay/i.test(activeDest);

      const activityName = isMumbai
        ? 'Mumbai Street Food Trail: Chowpatty & Mohammed Ali Road'
        : 'Old Delhi Midnight Culinary Walk';
      const costPerPerson = isMumbai ? 750 : 650;
      const travelers = this.tripDraft.travelersCount || ctx.draft?.travelers || 2;
      const totalCost = costPerPerson * travelers;

      if (!this.tripDraft.activities) this.tripDraft.activities = [];
      if (!this.tripDraft.activities.includes(activityName)) {
        this.tripDraft.activities.push(activityName);
      }
      this.persistState();

      const toolCalls: ToolCallRecord[] = [
        {
          name: 'update_itinerary',
          input: {
            destination: activeDest,
            activity: activityName,
            cost_per_person: costPerPerson,
            travelers
          },
          output: {
            status: 'success',
            activity: activityName,
            total_added_cost: totalCost
          },
          status: 'ok'
        }
      ];

      const currentBudgetTotal = this.tripDraft.budgetINR || ctx.draft?.totalBudget || 15000;
      const calculatedBudget = calculateBudget({
        days: this.tripDraft.durationDays || ctx.draft?.days || 3,
        travelers,
        totalBudget: currentBudgetTotal,
        tier: 'smart'
      });

      const cards: AlexaCard[] = [
        {
          type: 'itinerary_card',
          title: `Updated Itinerary — ${activeDest}`,
          destination: activeDest,
          durationDays: this.tripDraft.durationDays || 3,
          travelersCount: travelers,
          days: [
            {
              day: 1,
              title: 'Arrival & Local Orientation',
              highlights: ['Morning check-in', 'Heritage district walk', 'Local market explore']
            },
            {
              day: 2,
              title: 'Curated Cultural Experience',
              highlights: [activityName, 'Guided culinary tastings', 'Sunset photography'],
              costEstimate: formatINR(totalCost)
            },
            {
              day: 3,
              title: 'Scenic Vistas & Departure',
              highlights: ['Souvenir shopping', 'Late afternoon station transfer']
            }
          ]
        } as any,
        {
          type: 'budget_summary',
          title: `Budget with ${activityName}`,
          budget: calculatedBudget
        }
      ];

      const replyText = `Added "${activityName}" for ${travelers} traveller${travelers > 1 ? 's' : ''} to Day 2 of your ${activeDest} itinerary (${formatINR(totalCost)} total at ${formatINR(costPerPerson)}/person). Your revised budget remains within the ${formatINR(currentBudgetTotal)} ceiling.`;

      const reply: AlexaReply = {
        text: replyText,
        toolCalls,
        cards,
        tripPatch: {
          experiences: [
            {
              id: 'exp_food_trail',
              name: activityName,
              costPerPerson,
              durationHours: 3,
              rating: 4.8
            }
          ]
        }
      };
      this.appendTurn({ role: 'assistant', text: replyText, toolCalls, cards });
      return reply;
    }

    // -------------------------------------------------------------------------
    // INTENT 5: Budget Inquiry
    // -------------------------------------------------------------------------
    const isBudgetInquiry =
      lower.includes('budget') ||
      lower.includes('how much') ||
      lower.includes('cost') ||
      lower.includes('expense') ||
      lower.includes('ceiling');

    if (isBudgetInquiry && !lower.includes('keep it under') && !lower.includes('plan')) {
      const activeCeiling = this.tripDraft.budgetINR || ctx.draft?.totalBudget || 15000;
      const travelers = this.tripDraft.travelersCount || ctx.draft?.travelers || 2;
      const days = this.tripDraft.durationDays || ctx.draft?.days || 3;
      const dest = this.tripDraft.destination || ctx.draft?.destination || 'New Delhi';

      const breakdown = calculateBudget({
        days,
        travelers,
        totalBudget: activeCeiling,
        tier: 'smart'
      });

      const cards: AlexaCard[] = [
        {
          type: 'budget_summary',
          title: `Live Budget Breakdown: ${dest}`,
          budget: breakdown
        }
      ];

      const replyText = `Your current trip budget ceiling for ${dest} (${travelers} travellers, ${days} days) is ${formatINR(activeCeiling)}. Total estimated expenses are ${formatINR(breakdown.totalEstimatedCost)} with a transparent cushion of ${formatINR(breakdown.unallocatedBuffer)}.`;

      const reply: AlexaReply = {
        text: replyText,
        toolCalls: [],
        cards
      };
      this.appendTurn({ role: 'assistant', text: replyText, cards });
      return reply;
    }

    // -------------------------------------------------------------------------
    // INTENT 6: Trip Planning & Follow-Up (Slot Filling: Destination, Days, People, Budget)
    // -------------------------------------------------------------------------
    const isPlanRequest =
      lower.includes('plan') ||
      lower.includes('trip to') ||
      lower.includes('travel to') ||
      lower.includes('keep it under');

    if (isPlanRequest) {
      // 1. Extract Destination
      const destMatch = lower.match(/(?:to|visit|in|explore)\s+([a-zA-Z]+(?:\s+[a-zA-Z]+)?)/i);
      const recognizedCities = ['mumbai', 'delhi', 'jaipur', 'goa', 'bengaluru', 'hyderabad', 'chennai', 'kolkata', 'varanasi', 'manali'];
      if (destMatch) {
        const potentialDest = destMatch[1].toLowerCase().trim();
        for (const city of recognizedCities) {
          if (potentialDest.includes(city)) {
            this.tripDraft.destination = city.charAt(0).toUpperCase() + city.slice(1);
            break;
          }
        }
      }

      // 2. Extract Duration
      const dayMatch = lower.match(/(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\s*[- ]*(?:day|days|night|nights)/i);
      if (dayMatch) {
        const wordMap: Record<string, number> = {
          one: 1, two: 2, three: 3, four: 4, five: 5,
          six: 6, seven: 7, eight: 8, nine: 9, ten: 10
        };
        const raw = dayMatch[1].toLowerCase();
        this.tripDraft.durationDays = wordMap[raw] || parseInt(raw, 10);
      }

      // 3. Extract Travellers
      const peopleMatch = lower.match(/(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\s*(?:people|members|travellers|travelers|passengers|adults)/i);
      if (peopleMatch) {
        const wordMap: Record<string, number> = {
          one: 1, two: 2, three: 3, four: 4, five: 5,
          six: 6, seven: 7, eight: 8, nine: 9, ten: 10
        };
        const raw = peopleMatch[1].toLowerCase();
        this.tripDraft.travelersCount = wordMap[raw] || parseInt(raw, 10);
      }

      // 4. Extract Budget (e.g., "under sixty thousand", "budget ₹60,000", "under 60k")
      const budgetMatch = lower.match(/(?:under|budget|ceiling|within|keep it under)\s*(?:rs\.?|inr|₹)?\s*(\d+[kK]?|\d+[\d,]*|sixty\s+thousand|fifty\s+thousand|forty\s+thousand|thirty\s+thousand|twenty\s+thousand|ten\s+thousand|seventy\s+thousand|eighty\s+thousand|ninety\s+thousand|one\s+lakh)/i);
      if (budgetMatch) {
        const rawBudget = budgetMatch[1].toLowerCase();
        if (rawBudget.includes('sixty thousand')) this.tripDraft.budgetINR = 60000;
        else if (rawBudget.includes('fifty thousand')) this.tripDraft.budgetINR = 50000;
        else if (rawBudget.includes('forty thousand')) this.tripDraft.budgetINR = 40000;
        else if (rawBudget.includes('thirty thousand')) this.tripDraft.budgetINR = 30000;
        else if (rawBudget.includes('twenty thousand')) this.tripDraft.budgetINR = 20000;
        else if (rawBudget.includes('one lakh')) this.tripDraft.budgetINR = 100000;
        else if (rawBudget.endsWith('k')) {
          this.tripDraft.budgetINR = parseInt(rawBudget.replace('k', ''), 10) * 1000;
        } else {
          this.tripDraft.budgetINR = parseInt(rawBudget.replace(/,/g, ''), 10);
        }
      }

      this.persistState();

      // Check missing fields for conversational continuous flow
      const missing: string[] = [];
      if (!this.tripDraft.destination) missing.push('destination');
      if (!this.tripDraft.durationDays) missing.push('duration');
      if (!this.tripDraft.travelersCount) missing.push('travellers');
      if (!this.tripDraft.budgetINR) missing.push('budget');

      // If budget is missing, ask ONLY for missing information
      if (missing.includes('budget') && this.tripDraft.destination) {
        const replyText = `I have started planning your ${this.tripDraft.durationDays || 3}-day trip to ${this.tripDraft.destination} for ${this.tripDraft.travelersCount || 2} travellers. What total budget ceiling would you like to keep for this trip?`;
        const reply: AlexaReply = {
          text: replyText,
          toolCalls: [],
          tripPatch: {
            destination: this.tripDraft.destination,
            days: this.tripDraft.durationDays || 3,
            travelers: this.tripDraft.travelersCount || 2
          }
        };
        this.appendTurn({ role: 'assistant', text: replyText });
        return reply;
      }

      // If all critical slots are filled, call MCP tool 'plan_trip'
      if (this.tripDraft.destination && this.tripDraft.budgetINR) {
        const origin = this.tripDraft.origin || 'Hyderabad';
        const toolCalls: ToolCallRecord[] = [];
        let planData: any = null;

        try {
          const mcpRes = await mcpCallTool('plan_trip', {
            origin,
            destination: this.tripDraft.destination,
            budget_inr: this.tripDraft.budgetINR,
            start_date: this.tripDraft.startDate || '2026-11-15',
            end_date: this.tripDraft.endDate || '2026-11-18',
            travelers_count: this.tripDraft.travelersCount || 2,
            preferences: this.tripDraft.preferences || ['sightseeing', 'local_culture']
          });
          planData = mcpRes?.data || mcpRes;
          toolCalls.push({
            name: 'plan_trip',
            input: {
              origin,
              destination: this.tripDraft.destination,
              budget_inr: this.tripDraft.budgetINR,
              travelers_count: this.tripDraft.travelersCount || 2
            },
            output: planData,
            status: 'ok'
          });
        } catch (err: any) {
          toolCalls.push({
            name: 'plan_trip',
            input: { destination: this.tripDraft.destination },
            output: { error: err.message },
            status: 'failed'
          });
        }

        const breakdown = calculateBudget({
          days: this.tripDraft.durationDays || 3,
          travelers: this.tripDraft.travelersCount || 2,
          totalBudget: this.tripDraft.budgetINR,
          tier: 'smart'
        });

        const cards: AlexaCard[] = [
          {
            type: 'itinerary_card',
            title: `${this.tripDraft.durationDays || 3}-Day ${this.tripDraft.destination} Travel Plan`,
            destination: this.tripDraft.destination,
            durationDays: this.tripDraft.durationDays || 3,
            travelersCount: this.tripDraft.travelersCount || 2,
            days: [
              {
                day: 1,
                title: 'Arrival & Neighborhood Discovery',
                highlights: [`Express connection from ${origin}`, 'Hotel check-in', 'Evening promenade']
              },
              {
                day: 2,
                title: 'City Landmarks & Culinary Trails',
                highlights: ['Iconic monuments', 'Local specialty tasting', 'Sunset viewpoint']
              },
              {
                day: 3,
                title: 'Cultural Heritage & Farewell',
                highlights: ['Artisan bazaars', 'Farewell lunch', 'Evening return departure']
              }
            ]
          } as any,
          {
            type: 'budget_summary',
            title: `Planned Budget: ${formatINR(this.tripDraft.budgetINR)}`,
            budget: breakdown
          }
        ];

        const replyText = `I have planned your ${this.tripDraft.durationDays || 3}-day trip to ${this.tripDraft.destination} for ${this.tripDraft.travelersCount || 2} travellers with a total budget of ${formatINR(this.tripDraft.budgetINR)}. You have a transparent cushion of ${formatINR(breakdown.unallocatedBuffer)}. Would you like to adjust anything or add activities?`;

        const reply: AlexaReply = {
          text: replyText,
          toolCalls,
          cards,
          tripPatch: {
            destination: this.tripDraft.destination,
            origin,
            days: this.tripDraft.durationDays || 3,
            travelers: this.tripDraft.travelersCount || 2,
            totalBudget: this.tripDraft.budgetINR
          }
        };
        this.appendTurn({ role: 'assistant', text: replyText, toolCalls, cards });
        return reply;
      }
    }

    // -------------------------------------------------------------------------
    // INTENT 6B: Bus Cancellation & Next-Bus Rebooking (Transport Cancellation)
    // -------------------------------------------------------------------------
    const isBusChange =
      (lower.includes('cancel') && (lower.includes('bus') || lower.includes('next bus'))) ||
      lower.includes('cancel my bus') ||
      lower.includes('cancel the bus') ||
      lower.includes('cancel bus') ||
      lower.includes('reschedule my bus') ||
      lower.includes('rebook bus');

    if (isBusChange) {
      const activeTripId = this.tripDraft.activeTripId || ctx.tripId || 'trip_del_jai_001';
      const operator = 'RSRTC Express';
      const busNo = 'RJ-14-PC-8921';
      const pnr = 'RSRTC-DEL-99231';
      const depTime = '06:00 AM';
      const boarding = 'Kashmere Gate ISBT, Delhi';
      const cost = 450.0;
      const refundEst = Math.round(cost * 0.85);

      const toolCalls: ToolCallRecord[] = [];
      let prepData: any = null;

      try {
        const assessRes = await mcpCallTool('assess_disruption', {
          trip_id: activeTripId,
          disruption_type: 'bus_cancellation',
          delay_minutes: 150,
          notes: message
        });
        toolCalls.push({
          name: 'assess_disruption',
          input: { trip_id: activeTripId, disruption_type: 'bus_cancellation', delay_minutes: 150 },
          output: assessRes?.data || assessRes,
          status: 'ok'
        });

        const prepRes = await mcpCallTool('prepare_recovery_action', {
          trip_id: activeTripId,
          action_type: 'rebook_bus',
          selected_option_id: 'opt_next_volvo_bus',
          estimated_cost_inr: 350.0
        });
        prepData = prepRes?.data || prepRes;
        toolCalls.push({
          name: 'prepare_recovery_action',
          input: { trip_id: activeTripId, action_type: 'rebook_bus', selected_option_id: 'opt_next_volvo_bus' },
          output: prepData,
          status: 'ok'
        });
      } catch (err: any) {
        toolCalls.push({
          name: 'prepare_recovery_action',
          input: { trip_id: activeTripId },
          output: { error: err.message },
          status: 'failed'
        });
      }

      const actionId = prepData?.action_id || 'act_bus_rebook_001';
      this.stagedAction = {
        action_id: actionId,
        action_type: 'rebook_bus',
        recipient: `${operator} Ticketing & Dispatch`
      };
      this.persistState();

      const cards: AlexaCard[] = [
        {
          type: 'approval_card',
          actionId,
          title: `Cancel & Rebook Bus (${operator})`,
          recipient: `${operator} Ticketing & Dispatch`,
          extraCost: 350,
          extraCostLabel: '₹350 (Simulated Fare)',
          explanation: `Cancel ticket ${pnr} (eligible for ~₹${refundEst} refund) and reserve seat on next express service (~08:30 AM).`,
          caveat: 'Simulated operator inventory. Explicit approval strictly required before booking.',
          simulated: true
        }
      ];

      const replyText = `I identified your scheduled bus journey and prepared the cancellation and rebooking action for your review:\n\n` +
        `• **Active Bus Booking:** ${operator} (${busNo}) departing ${depTime} from ${boarding}\n` +
        `• **Booking Reference (PNR):** ${pnr}\n` +
        `• **Cancellation Confirmation Terms:** Cancelling more than 2 hours before departure qualifies for an ~85% refund (approx ₹${refundEst} of your ₹${cost} fare). Cancellations under 2 hours are non-refundable.\n\n` +
        `• **Next Available Bus (Supported Schedule):** Next ${operator} Express service departs at ~08:30 AM from ${boarding} (Estimated Rebooking Fare: ₹350).\n\n` +
        `⚠️ **Honest Disclosure:** Real-time seat inventory, vacant berths, and instant PNR issuance for the next bus are simulated in this preview because direct state transport API connectivity is not active. We do not invent seat numbers or charge fares without verification.\n\n` +
        `I have staged recovery action **${actionId}** for your review (Rebooking Cost: ₹350). Would you like me to confirm this bus cancellation and rebooking? Say **"Approve & Send"** to confirm or **"Don't send"** to cancel.`;

      const reply: AlexaReply = {
        text: replyText,
        toolCalls,
        cards,
        action: {
          id: actionId,
          status: 'pending',
          label: 'Awaiting User Approval',
          simulated: true
        }
      };
      this.appendTurn({ role: 'assistant', text: replyText, toolCalls, cards });
      return reply;
    }

    // -------------------------------------------------------------------------
    // INTENT 7: Disruption Assessment & Recovery Staging
    // -------------------------------------------------------------------------
    const isDisruption =
      lower.includes('delay') ||
      lower.includes('delayed') ||
      lower.includes('traffic') ||
      lower.includes('late') ||
      lower.includes('cancelled') ||
      lower.includes('breakdown') ||
      lower.includes('broke down') ||
      lower.includes('missed') ||
      lower.includes('recovery');

    if (isDisruption) {
      const activeTripId = this.tripDraft.activeTripId || ctx.tripId || 'trip_hyd_del_001';
      const isTrain = activeTripId === 'trip_hyd_del_001' || activeTripId === 'PMT-0142';

      // 7A: Propose / Prepare Recovery Action
      const isPrepareProposal =
        lower.includes('prepare') ||
        lower.includes('propose') ||
        lower.includes('recovery action') ||
        lower.includes('review') ||
        lower.includes('solution') ||
        lower.includes('help me recover');

      if (isPrepareProposal) {
        const toolCalls: ToolCallRecord[] = [];
        let prepData: any = null;

        const actionType = isTrain ? 'notify_hotel_late_checkin' : 'rebook_bus';
        const selectedOptionId = isTrain ? 'opt_reschedule_checkin' : 'opt_next_volvo_bus';

        try {
          const mcpRes = await mcpCallTool('prepare_recovery_action', {
            trip_id: activeTripId,
            action_type: actionType,
            selected_option_id: selectedOptionId,
            estimated_cost_inr: 0.0
          });
          prepData = mcpRes?.data || mcpRes;
          toolCalls.push({
            name: 'prepare_recovery_action',
            input: {
              trip_id: activeTripId,
              action_type: actionType,
              selected_option_id: selectedOptionId
            },
            output: prepData,
            status: 'ok'
          });
        } catch (err: any) {
          toolCalls.push({
            name: 'prepare_recovery_action',
            input: { trip_id: activeTripId },
            output: { error: err.message },
            status: 'failed'
          });
        }

        const actionId = prepData?.action_id || 'act_recov_001';
        const approvalPrompt =
          prepData?.approval_prompt ||
          `I can notify Old Delhi Haveli Stay to hold your reservation until midnight without penalty. Would you like me to confirm this?`;

        this.stagedAction = {
          action_id: actionId,
          action_type: actionType,
          approval_prompt: approvalPrompt,
          recipient: isTrain ? 'Old Delhi Haveli Stay' : 'Front Desk / Vendor Dispatch'
        };
        this.persistState();

        const cards: AlexaCard[] = [
          {
            type: 'approval_card',
            actionId,
            title: isTrain ? 'Hotel Hold Request' : 'Bus Rescheduling Request',
            recipient: isTrain ? 'Old Delhi Haveli Stay' : 'RSRTC Transit Dispatch',
            extraCost: 0,
            extraCostLabel: '₹0 (Free Rescheduling)',
            explanation: approvalPrompt,
            caveat: 'Requires explicit human confirmation before dispatching',
            simulated: true
          }
        ];

        const replyText = `I have staged recovery action ${actionId}: "${approvalPrompt}" Please review the proposal above. Say "Approve & Send" to dispatch or "Don't send" to cancel.`;

        const reply: AlexaReply = {
          text: replyText,
          toolCalls,
          cards,
          action: {
            id: actionId,
            status: 'pending',
            label: 'Awaiting User Approval',
            simulated: true
          }
        };
        this.appendTurn({ role: 'assistant', text: replyText, toolCalls, cards });
        return reply;
      }

      // 7B: Disruption Impact Assessment
      const toolCalls: ToolCallRecord[] = [];
      let assessData: any = null;

      try {
        const mcpRes = await mcpCallTool('assess_disruption', {
          trip_id: activeTripId,
          disruption_type: isTrain ? 'train_delay' : 'bus_delay',
          delay_minutes: 60,
          notes: message
        });
        assessData = mcpRes?.data || mcpRes;
        toolCalls.push({
          name: 'assess_disruption',
          input: { trip_id: activeTripId, delay_minutes: 60, notes: message },
          output: assessData,
          status: 'ok'
        });
      } catch (err: any) {
        toolCalls.push({
          name: 'assess_disruption',
          input: { trip_id: activeTripId },
          output: { error: err.message },
          status: 'failed'
        });
      }

      this.lastDisruption = assessData;
      this.persistState();

      const cards: AlexaCard[] = [
        {
          type: 'disruption_card',
          title: 'Journey Disruption Assessment',
          delayMinutes: 60,
          transportMode: isTrain ? 'train' : 'bus',
          impactSummary: isTrain
            ? 'Arrival into New Delhi Railway Station delayed by ~60 minutes. Night check-in and evening transit affected.'
            : 'Bus journey delayed. Afternoon check-in window and activities impacted.',
          affectedHotel: isTrain ? 'Old Delhi Haveli Stay' : 'Zostel Jaipur',
          missedActivities: ['Evening Chandni Chowk Walk'],
          options: isTrain
            ? [
                {
                  id: 'opt_reschedule_checkin',
                  title: 'Notify Hotel of Late Arrival',
                  cost: 0,
                  description: 'Hold room guarantee past 23:00 without late cancellation penalty.',
                  recommended: true
                },
                {
                  id: 'opt_station_cab',
                  title: 'Pre-arrange Station Pickup Cab',
                  cost: 450,
                  timeSavedMinutes: 25,
                  description: 'Dedicated pre-booked cab waiting at Paharganj exit for instant transfer.'
                }
              ]
            : [
                {
                  id: 'opt_reschedule_checkin',
                  title: 'Notify Hotel to Hold Room',
                  cost: 0,
                  description: 'Hold room without penalty until late evening.',
                  recommended: true
                },
                {
                  id: 'opt_emergency_cab',
                  title: 'Highway Emergency Cab',
                  cost: 1200,
                  timeSavedMinutes: 75,
                  description: 'Skip disabled vehicle with direct private cab transfer.'
                }
              ]
        } as any
      ];

      const optionsDesc = isTrain
        ? '1) Free: Notify Old Delhi Haveli Stay to hold your room until midnight.\n2) ₹450: Pre-arrange a station taxi from Paharganj gate to save 25 minutes.'
        : '1) Free: Notify your hotel to hold your room.\n2) ₹1,200: Highway emergency cab.';

      const replyText = `I evaluated the disruption for trip ${activeTripId}. Because of the delay, your check-in timing is affected. Here are the recommended recovery options:\n${optionsDesc}\n\nWould you like me to prepare a recovery action for you to review?`;

      const reply: AlexaReply = {
        text: replyText,
        toolCalls,
        cards
      };
      this.appendTurn({ role: 'assistant', text: replyText, toolCalls, cards });
      return reply;
    }

    // -------------------------------------------------------------------------
    // DEFAULT CONVERSATIONAL FALLBACK
    // -------------------------------------------------------------------------
    const fallbackText = `I understand: "${message}". I can help plan a new multi-day trip, adjust your budget, add attractions or food trails, or manage disruption recovery. What would you like to do?`;
    const reply: AlexaReply = {
      text: fallbackText,
      toolCalls: []
    };
    this.appendTurn({ role: 'assistant', text: fallbackText });
    return reply;
  }
}
