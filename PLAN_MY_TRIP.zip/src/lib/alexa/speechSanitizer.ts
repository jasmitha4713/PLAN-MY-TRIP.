/**
 * Sanitizes assistant responses into natural, concise Alexa-style spoken summaries.
 * Strictly prevents reading raw tables, UI labels, buttons, technical IDs, or long card lists.
 */
export function sanitizeSpeechText(rawText: string): string {
  if (!rawText) return '';

  let text = rawText;

  // 1. If response contains a markdown table, strip the table out
  const hasTable = /\|.+\|[\r\n]+\|[-:| ]+\|/m.test(text);
  if (hasTable) {
    // Remove the table lines
    text = text.replace(/\|.+?\|[\r\n]*/g, ' ').trim();
    if (!text || text.length < 15) {
      return "I've displayed the transport options and fares on your screen. You can review and choose your preferred service.";
    }
  }

  // 2. Remove suggested prompt sections, technical receipts, or audit disclosures
  const cutOffPatterns = [
    /\b(here are some things you can ask|suggested questions|what you should do next|you can say|say "approve & send"|say "don't send")\b/i,
    /\b(audit receipt:|pnr reference:|receipt reference:)/i,
    /\b(⚠️\s*honest disclosure:)/i,
    /\b(note:\s*real-time seat inventory is simulated)/i
  ];

  for (const pattern of cutOffPatterns) {
    const idx = text.search(pattern);
    if (idx > 30) {
      text = text.substring(0, idx);
    }
  }

  // 3. Remove raw bullet points if they list multiple items, preserving intro & call-to-action
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
  if (lines.length > 3) {
    const nonBulletLines = lines.filter((l) => !l.startsWith('•') && !l.startsWith('-') && !l.startsWith('*'));
    if (nonBulletLines.length >= 1) {
      text = nonBulletLines.join(' ');
    }
  }

  // 4. Clean out technical identifiers for conversational voice
  text = text
    .replace(/\btrip_[a-z0-9_-]+\b/gi, 'your trip')
    .replace(/\bact_[a-z0-9_-]+\b/gi, 'this recovery action')
    .replace(/\b(PMT-\d+)\b/gi, 'your trip')
    .replace(/[*#_`•\[\]\(\)]/g, ' ')
    .replace(/[⚠️✓]/g, '')
    .replace(/₹\s*(\d+[\d,]*)/g, '$1 rupees')
    .replace(/\bRs\.?\s*(\d+[\d,]*)/gi, '$1 rupees')
    .replace(/\s+/g, ' ')
    .trim();

  // 5. Keep voice concise: limit to 1-2 natural sentences (~180 characters)
  const sentences = text.match(/[^.!?]+[.!?]+/g);
  if (sentences && sentences.length > 0) {
    const brief = sentences.slice(0, 2).join(' ').trim();
    if (brief.length > 25 && brief.length <= 200) {
      return brief;
    }
  }

  if (text.length > 180) {
    const truncated = text.substring(0, 180);
    const lastSpace = truncated.lastIndexOf(' ');
    return (lastSpace > 80 ? truncated.substring(0, lastSpace) : truncated) + '.';
  }

  return text;
}
