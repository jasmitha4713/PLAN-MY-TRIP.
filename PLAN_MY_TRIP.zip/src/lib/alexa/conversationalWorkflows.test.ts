import { describe, it, expect } from 'vitest';
import { RemoteAlexaClient } from './remoteClient';
import { AlexaContext } from './types';

describe('Alexa+ Multi-Turn Conversational Workflows', () => {
  const client = new RemoteAlexaClient({ baseUrl: 'http://localhost:8001' });
  const mockCtx: AlexaContext = {
    tripId: 'PMT-0142',
    draft: {
      id: 'PMT-0142',
      destination: 'New Delhi',
      origin: 'Hyderabad',
      days: 3,
      travellers: 2,
      totalBudget: 15000,
      status: 'draft',
      selections: {
        transport: null,
        stay: null,
        localTravel: [],
        experiences: [],
        foodPerPersonPerDay: 300
      }
    }
  };

  it('1. "Train" follow-up returns selectable train transport options card', async () => {
    const res = await client.send('Train', mockCtx);
    expect(res.text).toContain('train options');
    expect(res.cards).toBeDefined();
    expect(res.cards?.length).toBeGreaterThan(0);
    const card = res.cards?.[0] as any;
    expect(card.type).toBe('option_picker');
    expect(card.category).toBe('transport');
    expect(card.options.some((opt: any) => opt.id === 'train-sleeper')).toBe(true);
  });

  it('2. "Choose the cheapest one" selects the cheapest option without auto-booking', async () => {
    const res = await client.send('Choose the cheapest one', mockCtx);
    expect(res.text).toContain('Overnight Sleeper Train');
    expect(res.text).toContain('₹1,050');
    expect(res.text.toLowerCase()).toContain('no booking or payment has been made yet');
    expect(res.tripPatch?.selections?.transport?.id).toBe('train-sleeper');
  });

  it('3. "Find hotels near the attractions" returns accommodation near sights', async () => {
    const res = await client.send('Find hotels near the attractions', mockCtx);
    expect(res.text).toContain('close to key attractions');
    expect(res.cards).toBeDefined();
    const card = res.cards?.[0] as any;
    expect(card.type).toBe('option_picker');
    expect(card.category).toBe('stay');
    expect(card.options.some((opt: any) => opt.id === 'stay-haveli')).toBe(true);
  });

  it('4. "Make it cheaper" optimizes both transport and stay for maximum cushion', async () => {
    const res = await client.send('Make it cheaper', mockCtx);
    expect(res.text).toContain('Overnight Sleeper Train');
    expect(res.text).toContain('Budget Hostel Room');
    expect(res.text).toContain('cushion');
    expect(res.tripPatch?.selections?.transport?.id).toBe('train-sleeper');
    expect(res.tripPatch?.selections?.stay?.id).toBe('stay-hostel');
  });

  it('5. "What happens if my train is delayed?" explains proactive disruption handling without auto-booking', async () => {
    const res = await client.send('What happens if my train is delayed?', mockCtx);
    expect(res.text).toContain('IRCTC');
    expect(res.text).toContain('hotel');
    expect(res.text).toContain('never rebook or spend without your explicit confirmation');
  });
});
