import { AlexaClient, AlexaReply, AlexaContext, ToolInfo, ToolCallRecord } from './types';
import { calculateBudget, formatINR } from '../budget';
import { createDefaultDemoTrip, DEFAULT_STAY_OPTIONS, DEFAULT_LOCAL_OPTIONS, RESCUE_SCENARIO, TripDraft } from '../../data/fixtures';

export const MOCK_TOOLS: ToolInfo[] = [
  { name: 'create_trip_plan', description: 'Generates a complete balanced trip draft within budget' },
  { name: 'calculate_budget', description: 'Deterministic pure arithmetic calculation of all categories and buffer' },
  { name: 'save_trip', description: 'Persists active trip draft to user trip store' },
  { name: 'get_trip', description: 'Retrieves active saved trip details' },
  { name: 'report_disruption', description: 'Logs delay or schedule change on transit leg' },
  { name: 'evaluate_trip_impact', description: 'Checks downstream hotel cutoffs and connection buffers' },
  { name: 'find_alternatives', description: 'Retrieves viable recovery actions with cost estimates' },
  { name: 'prepare_action', description: 'Generates user approval card with exact recipient and cost' },
  { name: 'execute_approved_action', description: 'Simulates dispatch of approved rescue adjustment' },
  { name: 'verify_action_status', description: 'Verifies partner acknowledgment of action' }
];

export class MockAlexaClient implements AlexaClient {
  modeName: 'mock' = 'mock';
  connectionStatus: 'simulation' = 'simulation';

  async listTools(): Promise<ToolInfo[]> {
    return MOCK_TOOLS;
  }

  async send(rawMessage: string, ctx: AlexaContext, scope?: import('./types').AlexaScope): Promise<AlexaReply> {
    const effectiveScope = scope || ctx.scope || { mode: 'plan' };
    const text = rawMessage.trim().toLowerCase();
    const currentTrip = ctx.draft || createDefaultDemoTrip(ctx.userId);

    // If scoped to trip companion mode
    if (effectiveScope.mode === 'trip') {
      if (text.includes('late') || text.includes('30') || text.includes('friend')) {
        return {
          text: 'I checked your cab booking (SIM-CAB-123). Moving pickup to 10:00 PM keeps you safe before the 11:00 PM hotel desk cutoff. May I notify driver Ramesh Patel?',
          toolCalls: [
            { name: 'get_booking_context', input: { tripId: currentTrip.id, bookingType: 'cab' }, status: 'ok' },
            { name: 'verify_downstream_cutoffs', input: { checkInCutoff: '11:00 PM', proposedArrival: '10:30 PM' }, status: 'ok' },
            { name: 'draft_vendor_message', input: { recipient: 'Driver: Ramesh Patel', message: 'Move pickup to 10:00 PM' }, status: 'ok' }
          ]
        };
      }
    }

    // Step 7: Approval of action
    if (
      text.includes('approve') ||
      text.includes('confirm cab') ||
      text.includes('yes approve') ||
      text === 'yes'
    ) {
      const toolCalls: ToolCallRecord[] = [
        { name: 'execute_approved_action', input: { actionId: 'opt-cab', tripId: currentTrip.id }, status: 'ok' },
        { name: 'verify_action_status', input: { actionId: 'opt-cab', partner: 'Station Cab Provider' }, status: 'ok' }
      ];

      return {
        text: 'Action confirmed (simulated). Priority station cab booked from Ajmeri Gate exit. Your estimated arrival at Old Delhi Haveli Stay is now 8:52 PM before the 9:00 PM cutoff.',
        toolCalls,
        action: {
          id: 'opt-cab',
          status: 'confirmed',
          label: 'Priority station cab · Confirmed (simulated)',
          simulated: true
        }
      };
    }

    // Step 6: Show alternatives
    if (text.includes('show alternative') || text.includes('alternatives') || text.includes('options')) {
      const toolCalls: ToolCallRecord[] = [
        { name: 'find_alternatives', input: { tripId: currentTrip.id, delayMinutes: 45 }, status: 'ok' },
        { name: 'prepare_action', input: { preferredOption: 'opt-cab' }, status: 'ok' }
      ];

      return {
        text: "I compared two recovery options:\n\n1. **Priority station cab**: +₹180 · saves about 15 minutes (estimate)\n2. **Message the stay**: ₹0 · they must confirm; we don't assume they'll wait.\n\nReview the action details below and approve when ready.",
        toolCalls,
        cards: [
          {
            type: 'approval_card',
            actionId: 'opt-cab',
            title: 'Priority station cab',
            recipient: 'Station Cab Provider',
            extraCost: 180,
            extraCostLabel: '+₹180',
            explanation: 'Dispatches pre-assigned sedan at Ajmeri Gate exit to bypass Old Delhi bazaar congestion.',
            caveat: 'Estimated arrival 8:52 PM (8 mins before 9:00 PM cutoff).',
            simulated: true
          }
        ]
      };
    }

    // Step 5: Report delay
    if (text.includes('delayed') || text.includes('delay') || text.includes('late') || text.includes('check-in')) {
      const toolCalls: ToolCallRecord[] = [
        { name: 'report_disruption', input: { transit: 'Overnight sleeper train', delayMinutes: 45 }, status: 'ok' },
        { name: 'evaluate_trip_impact', input: { arrivalTime: '8:40 PM', stayCutoff: '9:00 PM' }, status: 'ok' }
      ];

      return {
        text: 'With a 45-minute delay, your new arrival at New Delhi station is 8:40 PM. Old Delhi Haveli Stay check-in cutoff is strictly 9:00 PM, leaving only 20 minutes to cross town. That is very tight. Say "Show alternatives" to compare recovery options.',
        toolCalls
      };
    }

    // Step 4: Save trip
    if (text.includes('save') || text.includes('lock in')) {
      const toolCalls: ToolCallRecord[] = [
        { name: 'save_trip', input: { tripId: currentTrip.id, status: 'planned' }, status: 'ok' }
      ];

      const updatedDraft: TripDraft = {
        ...currentTrip,
        status: 'planned',
        updatedAt: new Date().toISOString()
      };

      return {
        text: `Trip saved as ${currentTrip.id}. Your transport, stay, ₹15,000 budget, and 9:00 PM check-in cutoff are saved in your trips.`,
        toolCalls,
        tripPatch: updatedDraft
      };
    }

    // Step 3: Add a cab
    if (text.includes('add a cab') || text.includes('add cab') || text.includes('station cab')) {
      const cabItem = DEFAULT_LOCAL_OPTIONS[0];
      const existingCabs = currentTrip.selections.localTravel.find(l => l.id === cabItem.id);
      
      let updatedLocal = [...currentTrip.selections.localTravel];
      if (existingCabs) {
        updatedLocal = updatedLocal.map(l => l.id === cabItem.id ? { ...l, quantity: l.quantity + 1 } : l);
      } else {
        updatedLocal.push({ ...cabItem, quantity: 1 });
      }

      const updatedSelections = {
        ...currentTrip.selections,
        localTravel: updatedLocal
      };

      const budgetRes = calculateBudget({
        totalBudget: currentTrip.totalBudget,
        travellers: currentTrip.travellers,
        days: currentTrip.days,
        selections: updatedSelections
      });

      const toolCalls: ToolCallRecord[] = [
        { name: 'calculate_budget', input: { localCost: budgetRes.spent.local }, status: 'ok' },
        { name: 'save_trip', input: { tripId: currentTrip.id }, status: 'ok' }
      ];

      return {
        text: `Added an extra station cab ride for ₹350. Total is now ${formatINR(budgetRes.totalSpent)} of ${formatINR(budgetRes.totalBudget)} (${budgetRes.stateMessage}).`,
        toolCalls,
        cards: [
          {
            type: 'budget_summary',
            budget: budgetRes,
            title: 'Updated Budget Breakdown'
          }
        ],
        tripPatch: {
          selections: updatedSelections
        }
      };
    }

    // Step 2: Make it cheaper
    if (text.includes('cheaper') || text.includes('save money') || text.includes('budget stay')) {
      // Switch stay to Budget Hostel Room
      const cheaperStay = DEFAULT_STAY_OPTIONS[1]; // Budget Hostel Room ₹900
      const updatedSelections = {
        ...currentTrip.selections,
        stay: cheaperStay
      };

      const budgetRes = calculateBudget({
        totalBudget: currentTrip.totalBudget,
        travellers: currentTrip.travellers,
        days: currentTrip.days,
        selections: updatedSelections
      });

      const savings = (currentTrip.selections.stay?.ratePerNight || 1800) * 2 - (cheaperStay.ratePerNight * 2);

      const toolCalls: ToolCallRecord[] = [
        { name: 'evaluate_trip_impact', input: { category: 'stay', savings }, status: 'ok' },
        { name: 'calculate_budget', input: { newTotal: budgetRes.totalSpent }, status: 'ok' }
      ];

      return {
        text: `Switched stay to Budget Hostel Room at ₹900/night. Saved ₹${savings}, bringing total spent to ${formatINR(budgetRes.totalSpent)}. You now have ${formatINR(budgetRes.safeToSpend)} safe to spend.`,
        toolCalls,
        cards: [
          {
            type: 'budget_summary',
            budget: budgetRes,
            title: 'Budget After Savings'
          }
        ],
        tripPatch: {
          selections: updatedSelections
        }
      };
    }

    // Step 1: Plan a trip (Free text parser)
    if (text.includes('plan') || text.includes('trip') || text.includes('delhi') || text.includes('hyderabad')) {
      // Extract numbers or use defaults
      const budgetMatch = text.match(/(\d+[\d,]*)\s*(?:rs|rupees|inr|k)?/i);
      let extractedBudget = 15000;
      if (text.includes('15000') || text.includes('15,000') || text.includes('15k')) extractedBudget = 15000;
      else if (text.includes('20000') || text.includes('20,000') || text.includes('20k')) extractedBudget = 20000;
      else if (text.includes('10000') || text.includes('10,000') || text.includes('10k')) extractedBudget = 10000;

      const demoTrip = createDefaultDemoTrip(ctx.userId);
      demoTrip.totalBudget = extractedBudget;

      const budgetRes = calculateBudget({
        totalBudget: extractedBudget,
        travellers: demoTrip.travellers,
        days: demoTrip.days,
        selections: demoTrip.selections
      });

      const toolCalls: ToolCallRecord[] = [
        { name: 'create_trip_plan', input: { origin: 'Hyderabad', destination: 'New Delhi', days: 3, travellers: 2 }, status: 'ok' },
        { name: 'calculate_budget', input: { totalBudget: extractedBudget, buffer: budgetRes.buffer }, status: 'ok' }
      ];

      return {
        text: `Done. Here's a plan that fits, with ${formatINR(budgetRes.buffer)} kept as a buffer. Transport, stay, local travel, and two heritage walks are allocated.`,
        toolCalls,
        cards: [
          {
            type: 'budget_summary',
            budget: budgetRes,
            title: '3-Day Hyderabad to New Delhi Plan'
          }
        ],
        tripPatch: demoTrip
      };
    }

    // General fallback / help
    const toolCalls: ToolCallRecord[] = [
      { name: 'get_trip', input: { tripId: currentTrip.id }, status: 'ok' }
    ];

    return {
      text: 'I can help you plan and adjust your trip. Try asking:\n• "Plan 3 days in Delhi from Hyderabad for two under ₹15,000"\n• "Make it cheaper"\n• "My train is delayed by 45 minutes"\n• "Save this trip"',
      toolCalls
    };
  }
}
