import { sanitizeSpeechText } from './speechSanitizer';

export interface VoicePreference {
  voiceName: string | null;
  rate: number;
  pitch: number;
}

const STORAGE_KEY_VOICE = 'pmt_alexa_selected_voice';
const STORAGE_KEY_RATE = 'pmt_alexa_voice_rate';
const STORAGE_KEY_PITCH = 'pmt_alexa_voice_pitch';

class VoiceService {
  private voices: SpeechSynthesisVoice[] = [];
  private isInitialized = false;
  private listeners: Array<() => void> = [];

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.initVoices();
      window.speechSynthesis.onvoiceschanged = () => {
        this.initVoices();
      };
    }
  }

  private initVoices() {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    const vList = window.speechSynthesis.getVoices();
    if (vList && vList.length > 0) {
      this.voices = vList;
      this.isInitialized = true;
      this.notifyListeners();
    }
  }

  public onVoicesLoaded(callback: () => void): () => void {
    this.listeners.push(callback);
    if (this.isInitialized && this.voices.length > 0) {
      callback();
    }
    return () => {
      this.listeners = this.listeners.filter((l) => l !== callback);
    };
  }

  private notifyListeners() {
    this.listeners.forEach((fn) => {
      try {
        fn();
      } catch {}
    });
  }

  /**
   * Retrieves all available speech synthesis voices, prioritizing English and Indian English.
   */
  public getAvailableVoices(): SpeechSynthesisVoice[] {
    if (this.voices.length === 0 && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.voices = window.speechSynthesis.getVoices();
    }

    // Sort: en-IN first, then other English voices, then others
    return [...this.voices].sort((a, b) => {
      const aIsInd = a.lang.toLowerCase().includes('en-in') || a.name.toLowerCase().includes('india');
      const bIsInd = b.lang.toLowerCase().includes('en-in') || b.name.toLowerCase().includes('india');
      if (aIsInd && !bIsInd) return -1;
      if (!aIsInd && bIsInd) return 1;

      const aIsEn = a.lang.toLowerCase().startsWith('en');
      const bIsEn = b.lang.toLowerCase().startsWith('en');
      if (aIsEn && !bIsEn) return -1;
      if (!aIsEn && bIsEn) return 1;

      return a.name.localeCompare(b.name);
    });
  }

  /**
   * Returns the currently selected voice or the best natural default.
   */
  public getSelectedVoice(): SpeechSynthesisVoice | null {
    const voices = this.getAvailableVoices();
    if (voices.length === 0) return null;

    if (typeof window !== 'undefined' && window.localStorage) {
      const savedName = window.localStorage.getItem(STORAGE_KEY_VOICE);
      if (savedName) {
        const found = voices.find((v) => v.name === savedName);
        if (found) return found;
      }
    }

    // Default heuristic: en-IN Natural / Google / Microsoft / en-US Natural
    const preferred = voices.find(
      (v) =>
        (v.lang.toLowerCase().includes('en-in') || v.name.toLowerCase().includes('india')) &&
        (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Heera') || v.name.includes('Neerja'))
    ) || voices.find(
      (v) => v.lang.toLowerCase().includes('en-in') || v.name.toLowerCase().includes('india')
    ) || voices.find(
      (v) => v.lang.toLowerCase().startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Zira'))
    ) || voices.find(
      (v) => v.lang.toLowerCase().startsWith('en')
    );

    return preferred || voices[0] || null;
  }

  public setSelectedVoice(voiceName: string): boolean {
    const voices = this.getAvailableVoices();
    const match = voices.find((v) => v.name === voiceName);
    if (!match) return false;

    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(STORAGE_KEY_VOICE, match.name);
    }
    return true;
  }

  public getVoiceSettings(): { rate: number; pitch: number } {
    let rate = 1.0;
    let pitch = 1.0;

    if (typeof window !== 'undefined' && window.localStorage) {
      const savedRate = window.localStorage.getItem(STORAGE_KEY_RATE);
      const savedPitch = window.localStorage.getItem(STORAGE_KEY_PITCH);
      if (savedRate) rate = parseFloat(savedRate) || 1.0;
      if (savedPitch) pitch = parseFloat(savedPitch) || 1.0;
    }

    return { rate, pitch };
  }

  public setVoiceSettings(settings: { rate?: number; pitch?: number }) {
    if (typeof window !== 'undefined' && window.localStorage) {
      if (settings.rate !== undefined) {
        window.localStorage.setItem(STORAGE_KEY_RATE, String(settings.rate));
      }
      if (settings.pitch !== undefined) {
        window.localStorage.setItem(STORAGE_KEY_PITCH, String(settings.pitch));
      }
    }
  }

  /**
   * Preview a voice by speaking a short friendly greeting.
   */
  public previewVoice(voiceName?: string, onEnd?: () => void) {
    const text = 'Hello! This is your travel assistant voice for Plan My Trip.';
    this.speak(text, {
      onEnd,
      overrideVoiceName: voiceName
    });
  }

  /**
   * Speaks sanitized text using the selected voice and settings.
   */
  public speak(
    rawText: string,
    options: {
      overrideVoiceName?: string;
      onStart?: () => void;
      onEnd?: () => void;
      onError?: (err: any) => void;
    } = {}
  ): void {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      if (options.onEnd) options.onEnd();
      return;
    }

    // Cancel active playback to support immediate interruption
    window.speechSynthesis.cancel();

    const cleanText = sanitizeSpeechText(rawText);
    if (!cleanText) {
      if (options.onEnd) options.onEnd();
      return;
    }

    const utterance = new SpeechSynthesisUtterance(cleanText);
    const { rate, pitch } = this.getVoiceSettings();
    utterance.rate = rate;
    utterance.pitch = pitch;

    // Resolve voice
    const voices = this.getAvailableVoices();
    let voiceToUse: SpeechSynthesisVoice | null = null;
    if (options.overrideVoiceName) {
      voiceToUse = voices.find((v) => v.name === options.overrideVoiceName) || null;
    }
    if (!voiceToUse) {
      voiceToUse = this.getSelectedVoice();
    }

    if (voiceToUse) {
      utterance.voice = voiceToUse;
      utterance.lang = voiceToUse.lang || 'en-IN';
    } else {
      utterance.lang = 'en-IN';
    }

    utterance.onstart = () => {
      if (options.onStart) options.onStart();
    };

    utterance.onend = () => {
      if (options.onEnd) options.onEnd();
    };

    utterance.onerror = (e) => {
      console.warn('SpeechSynthesis error:', e);
      if (options.onError) options.onError(e);
      if (options.onEnd) options.onEnd();
    };

    window.speechSynthesis.speak(utterance);
  }

  /**
   * Immediately stops any speech playback.
   */
  public stopSpeaking(): void {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }

  public isSpeaking(): boolean {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      return window.speechSynthesis.speaking;
    }
    return false;
  }
}

export const voiceService = new VoiceService();
