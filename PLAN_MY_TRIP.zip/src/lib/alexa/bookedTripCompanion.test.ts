import { describe, it, expect } from 'vitest';
import { getAlexaClient } from './client';
import { RemoteAlexaClient } from './remoteClient';

describe('Alexa Travel Companion Complete Acceptance & Regression Tests', () => {
  const sampleTripContext = {
    userId: 'test-user',
    tripId: 'PMT-0142',
    draft: {
      id: 'PMT-0142',
      backendTripId: 'trip_del_jai_001',
      destination: 'Jaipur',
      origin: 'Delhi',
      days: 3,
      travellers: 1,
      totalBudget: 5000,
      status: 'planned' as const,
      userId: 'test-user',
      createdAt: '2026-10-21',
      updatedAt: '2026-10-21',
      selections: {
        transport: null,
        stay: null,
        localTravel: [],
        experiences: [],
        foodPerPersonPerDay: 500
      }
    }
  };

  it('A. "What is my current trip budget?" → Returns active trip\'s actual budget and breakdown', async () => {
    const client = getAlexaClient();
    const reply = await client.send('What is my current trip budget?', sampleTripContext);

    expect(reply.text.toLowerCase()).toContain('budget');
    expect(reply.text).toContain('5,000');
    expect(reply.text).toMatch(/transport|stay|hotel|allocated/i);
    expect(reply.cards && reply.cards.length > 0).toBe(true);
    expect(reply.cards?.[0].type).toBe('budget_summary');
  });

  it('B. "I\'m in traffic and my bus leaves in 10 minutes. What should I do?" → Assesses disruption and returns recommendations', async () => {
    const client = getAlexaClient();
    const prompt = "I'm in traffic and my bus leaves in 10 minutes. What should I do?";
    const reply = await client.send(prompt, sampleTripContext);

    // Must not display generic tool catalogue or canned S3 text
    expect(reply.text).not.toContain('Available Tools (5)');
    expect(reply.text).not.toContain("How long do you think you need to reach the boarding point?");
    
    // Must assess disruption and explain downstream impacts
    expect(reply.text).toMatch(/assessed|disruption|impact/i);
    expect(reply.text).toMatch(/hotel|check-in/i);
    expect(reply.text).toMatch(/recovery options/i);

    // Check tool call
    const toolNames = reply.toolCalls?.map(t => t.name) || [];
    expect(toolNames).toContain('assess_disruption');
  });

  it('C. "Prepare a recovery action for my delayed bus, but don\'t book anything until I approve." → Stages recovery preview without booking', async () => {
    const client = getAlexaClient();
    const prompt = "Prepare a recovery action for my delayed bus, but don't book anything until I approve.";
    const reply = await client.send(prompt, sampleTripContext);

    // Must NOT say there is no pending action
    expect(reply.text).not.toContain("There is no pending recovery action waiting for your approval");

    // Must prepare the action and explain it is staged
    expect(reply.text).toMatch(/recovery action|staged|pending/i);
    expect(reply.text).toContain('Nothing has been booked');
    
    // Must return explicit approval card
    expect(reply.cards && reply.cards.length > 0).toBe(true);
    const card = reply.cards?.[0];
    expect(card?.type).toBe('approval_card');
    expect(card?.actionId).toBeDefined();
    expect(card?.actionId).toMatch(/^act_/);
    expect(card?.extraCostLabel).toBeDefined();

    // Check tool calls chained: assess_disruption and prepare_recovery_action
    const toolNames = reply.toolCalls?.map(t => t.name) || [];
    expect(toolNames).toContain('prepare_recovery_action');
  });

  it('D. Click Reject / "Reject that action" → Action remains unexecuted and is marked rejected', async () => {
    const client = getAlexaClient();

    // First stage an action
    await client.send("Prepare a recovery action for my delayed bus, but don't book anything until I approve.", sampleTripContext);

    // Now reject it
    const reply = await client.send("Reject that action", sampleTripContext);

    expect(reply.text).toMatch(/cancelled|rejected/i);
    expect(reply.text).toContain('No booking');
    expect(reply.action?.status).toBe('rejected');

    const toolNames = reply.toolCalls?.map(t => t.name) || [];
    expect(toolNames).toContain('approve_recovery_action');
  });

  it('E. Prepare another action and click Approve → Only exact pending action is executed', async () => {
    const client = getAlexaClient();

    // Stage an action
    const prepReply = await client.send("Prepare a recovery action for my delayed bus, but don't book anything until I approve.", sampleTripContext);
    const actionId = prepReply.cards?.[0]?.actionId;
    expect(actionId).toBeDefined();

    // Approve the exact action
    const reply = await client.send(`Approve action ${actionId}`, sampleTripContext);

    expect(reply.text).toMatch(/executed|completed|succeeded/i);
    expect(reply.text).toMatch(/receipt/i);
    expect(reply.action?.status).toBe('confirmed');

    const toolNames = reply.toolCalls?.map(t => t.name) || [];
    expect(toolNames).toContain('approve_recovery_action');
  });

  it('F. Non-existent trip ID → Shows helpful error and NEVER silently substitutes another trip', async () => {
    const remoteClient = new RemoteAlexaClient({ baseUrl: 'http://localhost:8001' });

    const reply = await remoteClient.send("I'm in traffic and my bus leaves in 10 minutes. What should I do?", {
      userId: 'test-user',
      tripId: 'chennai-2279',
      draft: { id: 'chennai-2279' } as any
    });

    expect(reply.text).toContain("chennai-2279");
    expect(reply.text).toContain("not found in the backend trip repository");
    expect(reply.text).toContain("PMT-0142");
    // Ensure no fallback tools were executed for a non-existent trip
    expect(reply.toolCalls?.length || 0).toBe(0);
  });

  it('G. Preserves pending staged action state across re-initialization', async () => {
    const client1 = new RemoteAlexaClient({ baseUrl: 'http://localhost:8001' });
    const prepReply = await client1.send("Prepare a recovery action for my delayed bus, but don't book anything until I approve.", sampleTripContext);
    const actionId = prepReply.cards?.[0]?.actionId;
    expect(actionId).toBeDefined();

    // Simulate page refresh / new client instance
    const client2 = new RemoteAlexaClient({ baseUrl: 'http://localhost:8001' });
    const approveReply = await client2.send("Approve the recovery action I just reviewed", sampleTripContext);

    expect(approveReply.text).toMatch(/executed|completed/i);
    expect(approveReply.action?.status).toBe('confirmed');
  });

  // -------------------------------------------------------------
  // REGRESSION TESTS FOR BUGS 1, 2, 3, 4
  // -------------------------------------------------------------

  it('BUG 2A. "hi" → Returns a short conversational reply rather than the default welcome guide', async () => {
    const client = getAlexaClient();
    const reply = await client.send('hi', sampleTripContext);

    expect(reply.text).toMatch(/hello! how can i help you/i);
    expect(reply.text.length).toBeLessThan(200);
    expect(reply.text).not.toContain('I am your Alexa Travel Companion connected to the live Model Context Protocol');
    expect(reply.text).not.toContain('Available Tools');
  });

  it('BUG 2B. "Add Old Delhi culinary food trail" → Updates active itinerary draft and recalculates budget', async () => {
    const client = getAlexaClient();
    const delhiContext = {
      userId: 'test-user',
      tripId: 'PMT-0142',
      draft: {
        id: 'PMT-0142',
        backendTripId: 'trip_hyd_del_001',
        destination: 'New Delhi',
        origin: 'Hyderabad',
        days: 3,
        travellers: 2,
        totalBudget: 15000,
        status: 'planned' as const,
        userId: 'test-user',
        createdAt: '2026-10-21',
        updatedAt: '2026-10-21',
        selections: {
          transport: null,
          stay: null,
          localTravel: [],
          experiences: [],
          foodPerPersonPerDay: 300
        }
      }
    };

    const reply = await client.send('Add Old Delhi culinary food trail', delhiContext);

    expect(reply.text).toMatch(/added.*old delhi.*culinary walk/i);
    expect(reply.tripPatch?.selections?.experiences).toBeDefined();
    expect(reply.tripPatch?.selections?.experiences?.length).toBe(1);
    expect(reply.tripPatch?.selections?.experiences?.[0].name).toContain('Culinary Walk');
    expect(reply.cards?.[0]?.type).toBe('budget_summary');
  });

  it('BUG 2C. "Add Atlantis submarine ride" → Clarifies what information is needed rather than dumping welcome', async () => {
    const client = getAlexaClient();
    const reply = await client.send('Add Atlantis submarine ride', sampleTripContext);

    expect(reply.text).toContain("couldn't locate an attraction or food trail");
    expect(reply.text).toMatch(/available experiences you can add/i);
    expect(reply.text).not.toContain('I am your Alexa Travel Companion connected to the live Model Context Protocol');
  });

  it('BUG 3A & 4. Authoritative Hyderabad → New Delhi trip (PMT-0142) budget calculates from actual trip, not hardcoded Jaipur fixture', async () => {
    const client = getAlexaClient();
    const delhiTripContext = {
      userId: 'test-user',
      tripId: 'PMT-0142',
      draft: {
        id: 'PMT-0142',
        backendTripId: 'trip_hyd_del_001',
        destination: 'New Delhi',
        origin: 'Hyderabad',
        days: 3,
        travellers: 2,
        totalBudget: 15000,
        status: 'planned' as const,
        userId: 'test-user',
        createdAt: '2026-10-21',
        updatedAt: '2026-10-21',
        selections: {
          transport: { id: 'tr-train-1', name: 'Telangana Express (Train)', category: 'Train' as const, farePerPerson: 1050, roundTripFarePerPerson: 2100, price: 4200 },
          stay: { id: 'st-haveli', name: 'Old Delhi Haveli Stay', tier: 'heritage' as const, ratePerNight: 1800, price: 3600 },
          localTravel: [],
          experiences: [],
          foodPerPersonPerDay: 300
        }
      }
    };

    const reply = await client.send('What is my current trip budget?', delhiTripContext);

    // Ceiling must be 15,000 (not Jaipur 5,000)
    expect(reply.text).toContain('15,000');
    expect(reply.text).toContain('Hyderabad → New Delhi');
    expect(reply.cards?.[0]?.budget?.totalBudget).toBe(15000);
  });

  it('BUG 3B & 4. Train disruption on Hyderabad → New Delhi journey recommends train-relevant recovery without switching buses', async () => {
    const client = getAlexaClient();
    const delhiTrainContext = {
      userId: 'test-user',
      tripId: 'PMT-0142',
      draft: {
        id: 'PMT-0142',
        backendTripId: 'trip_hyd_del_001',
        destination: 'New Delhi',
        origin: 'Hyderabad',
        days: 3,
        travellers: 2,
        totalBudget: 15000,
        status: 'planned' as const,
        userId: 'test-user',
        createdAt: '2026-10-21',
        updatedAt: '2026-10-21',
        selections: {
          transport: { id: 'tr-train-1', name: 'Telangana Express (Train)', category: 'Train' as const, farePerPerson: 1050, price: 4200 },
          stay: { id: 'st-haveli', name: 'Old Delhi Haveli Stay', tier: 'heritage' as const, ratePerNight: 1800, price: 3600 },
          localTravel: [],
          experiences: [],
          foodPerPersonPerDay: 300
        }
      }
    };

    const reply = await client.send('My train is delayed by 2 hours. What should I do?', delhiTrainContext);

    // Must recommend hotel late check-in notice or station taxi
    expect(reply.text).toMatch(/hotel|check-in/i);
    // Must NOT recommend switching to an interstate Volvo bus for a 1500km train journey
    expect(reply.text).not.toContain('Switch to Following Express Volvo AC Bus');
    expect(reply.toolCalls?.map(t => t.name)).toContain('assess_disruption');
  });

  it('BUG 3C & 4. Prepares train recovery action staged without executing before explicit approval', async () => {
    const client = getAlexaClient();
    const delhiTrainContext = {
      userId: 'test-user',
      tripId: 'PMT-0142',
      draft: {
        id: 'PMT-0142',
        backendTripId: 'trip_hyd_del_001',
        destination: 'New Delhi',
        origin: 'Hyderabad',
        days: 3,
        travellers: 2,
        totalBudget: 15000,
        status: 'planned' as const,
        userId: 'test-user',
        createdAt: '2026-10-21',
        updatedAt: '2026-10-21',
        selections: {
          transport: { id: 'tr-train-1', name: 'Telangana Express (Train)', category: 'Train' as const, farePerPerson: 1050, price: 4200 },
          stay: { id: 'st-haveli', name: 'Old Delhi Haveli Stay', tier: 'heritage' as const, ratePerNight: 1800, price: 3600 },
          localTravel: [],
          experiences: [],
          foodPerPersonPerDay: 300
        }
      }
    };

    const reply = await client.send("Prepare a recovery action for my delayed train, but don't book anything until I approve.", delhiTrainContext);

    expect(reply.text).toMatch(/recovery action|staged|pending/i);
    expect(reply.text).toContain('Nothing has been booked');
    const card = reply.cards?.[0];
    expect(card?.type).toBe('approval_card');
    expect(card?.actionId).toBeDefined();

    // Rejecting leaves action unexecuted
    const rejectReply = await client.send('Reject that action', delhiTrainContext);
    expect(rejectReply.text).toMatch(/cancelled|rejected/i);
    expect(rejectReply.action?.status).toBe('rejected');
  });

  // =========================================================================
  // MANDATORY REGRESSION TESTS (A, B, C, D)
  // =========================================================================

  it('Mandatory Test A — Transport cancellation: "Cancel my bus and get me the next bus."', async () => {
    const client = getAlexaClient();
    const busContext = {
      userId: 'test-user',
      tripId: 'DEMO-JAI-001',
      draft: {
        id: 'DEMO-JAI-001',
        backendTripId: 'trip_del_jai_001',
        destination: 'Jaipur',
        origin: 'Delhi',
        days: 3,
        travellers: 1,
        totalBudget: 5000,
        status: 'planned' as const,
        userId: 'test-user',
        createdAt: '2026-10-21',
        updatedAt: '2026-10-21',
        selections: {
          transport: {
            id: 'tr-bus-1',
            name: 'RSRTC Express (Bus)',
            category: 'Bus' as const,
            farePerPerson: 450,
            price: 450
          },
          stay: null,
          localTravel: [],
          experiences: [],
          foodPerPersonPerDay: 500
        }
      }
    };

    const reply = await client.send("Cancel my bus and get me the next bus.", busContext);

    // 1. Identify the bus
    expect(reply.text).toMatch(/RSRTC Express|RJ-14-PC-8921|RSRTC-DEL-99231/i);
    // 2. Explain necessary cancellation confirmation & refund terms
    expect(reply.text).toMatch(/cancellation|refund|85%/i);
    // 3. Find next available bus using actual supported data source
    expect(reply.text).toMatch(/next.*bus|08:30\s*AM|express service/i);
    // 4. Obtain approval before a consequential action
    expect(reply.text).toMatch(/approve|don't send|staged/i);
    expect(reply.action?.status).toBe('pending');
    expect(reply.cards?.some(c => c.type === 'approval_card')).toBe(true);
    // 5. Never respond with unrelated hotel check-in or taxi advice
    expect(reply.text).not.toMatch(/Old Delhi Haveli/i);
    expect(reply.text).not.toMatch(/hotel check-in at risk/i);
    expect(reply.text).not.toMatch(/station taxi|emergency cab/i);
  });

  it('Mandatory Test B — Follow-up context: "Plan for 5 travellers." -> "Actually, make it 3."', async () => {
    const client = getAlexaClient();
    
    // First turn: "Plan for 5 travellers."
    const turn1 = await client.send("Plan for 5 travellers.", {
      userId: 'test-user',
      tripId: 'temp-draft',
      draft: null as any
    });
    expect(turn1.tripPatch?.travellers).toBe(5);

    // Second turn: "Actually, make it 3."
    const turn2 = await client.send("Actually, make it 3.", {
      userId: 'test-user',
      tripId: 'temp-draft',
      draft: {
        destination: turn1.tripPatch?.destination || 'Delhi',
        days: turn1.tripPatch?.days || 3,
        travellers: turn1.tripPatch?.travellers,
        origin: 'Hyderabad'
      } as any
    });

    // The final traveller count must be 3 everywhere
    expect(turn2.text).toContain('3');
    expect(turn2.tripPatch?.travellers).toBe(3);
    expect(turn2.tripPatch?.adults).toBe(3);
    // Old clarification value 5 must NOT restore
    expect(turn2.tripPatch?.travellers).not.toBe(5);
  });

  it('Mandatory Test C — Voice conversation: Follow-up request preserves conversation context', async () => {
    const client = getAlexaClient();

    // Turn 1: Specify destination and duration without budget
    const turn1 = await client.send("Plan a trip to Mumbai for 3 days", {
      userId: 'test-user',
      tripId: 'temp-conv-1',
      draft: null as any
    });
    expect(turn1.text.toLowerCase()).toContain('mumbai');
    expect(turn1.text.toLowerCase()).toMatch(/budget/i);

    // Turn 2: Follow-up providing budget without repeating destination or days
    const turn2 = await client.send("Keep it under sixty thousand", {
      userId: 'test-user',
      tripId: 'temp-conv-1',
      draft: {
        destination: 'Mumbai',
        days: 3,
        travellers: 2,
        origin: 'Hyderabad'
      } as any
    });

    // Context preserved: destination is Mumbai, 3 days, budget 60,000
    expect(turn2.text.toLowerCase()).toContain('mumbai');
    expect(turn2.text).toMatch(/60,000/i);
    expect(turn2.cards?.some(c => c.type === 'budget_summary')).toBe(true);
    expect(turn2.tripPatch?.destination).toBe('Mumbai');
    expect(turn2.tripPatch?.totalBudget).toBe(60000);
  });

  it('Mandatory Test D — Approval and honesty: Requests confirmation, executes via supported tool, discloses simulation', async () => {
    const client = getAlexaClient();
    const busContext = {
      userId: 'test-user',
      tripId: 'DEMO-JAI-001',
      draft: {
        id: 'DEMO-JAI-001',
        backendTripId: 'trip_del_jai_001',
        destination: 'Jaipur',
        origin: 'Delhi',
        days: 3,
        travellers: 1,
        totalBudget: 5000,
        status: 'planned' as const,
        userId: 'test-user',
        createdAt: '2026-10-21',
        updatedAt: '2026-10-21',
        selections: {
          transport: { id: 'tr-bus-1', name: 'RSRTC Express (Bus)', category: 'Bus' as const, farePerPerson: 450, price: 450 },
          stay: null,
          localTravel: [],
          experiences: [],
          foodPerPersonPerDay: 500
        }
      }
    };

    // 1. Stage an action - must NOT execute immediately
    const stageReply = await client.send("Cancel my bus and get me the next bus.", busContext);
    expect(stageReply.action?.status).toBe('pending');
    expect(stageReply.text).toMatch(/staged|review|approve/i);
    expect(stageReply.text).toMatch(/simulated/i); // Honest disclosure

    const actionId = stageReply.action?.id || 'act_bus_rebook_001';

    // 2. Explicit approval executes through approve_recovery_action
    const approveReply = await client.send(`Approve action ${actionId}`, busContext);
    expect(approveReply.action?.status).toBe('confirmed');
    expect(approveReply.action?.simulated).toBe(true);
    expect(approveReply.text).toMatch(/executed|receipt/i);
    expect(approveReply.toolCalls?.map(t => t.name)).toContain('approve_recovery_action');
  });
});
