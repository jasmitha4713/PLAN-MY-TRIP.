import { describe, it, expect } from 'vitest';
import { RemoteAlexaClient } from './remoteClient';

describe('Live End-to-End MCP Server & Alexa Assistant Integration', () => {
  const client = new RemoteAlexaClient({ baseUrl: 'http://localhost:8001' });

  it('1. Connects to live MCP server and lists tools via tools/list', async () => {
    const tools = await client.listTools();
    expect(client.connectionStatus).toBe('connected');
    expect(tools.length).toBeGreaterThanOrEqual(5);
    const names = tools.map(t => t.name);
    expect(names).toContain('plan_trip');
    expect(names).toContain('get_saved_trip');
    expect(names).toContain('assess_disruption');
    expect(names).toContain('prepare_recovery_action');
    expect(names).toContain('approve_recovery_action');
  });

  it('2. Prompt: "Plan a 2-person trip from Hyderabad to Delhi under ₹15,000."', async () => {
    const reply = await client.send('Plan a 2-person trip from Hyderabad to Delhi under ₹15,000.', {
      userId: 'demo-traveler-001',
      tripId: 'draft_hyd_del'
    });

    expect(reply.text).toContain('plan_trip');
    expect(reply.text).toContain('Hyderabad');
    expect(reply.text).toContain('Delhi');
    expect(reply.toolCalls).toHaveLength(1);
    expect(reply.toolCalls[0].name).toBe('plan_trip');
    expect(reply.toolCalls[0].status).toBe('ok');
    expect(client.connectionStatus).toBe('connected');
    expect(reply.tripPatch?.backendTripId).toBeDefined();
    expect(reply.tripPatch?.backendTripId).toMatch(/^trip_/);
  });

  it('3. Prompt: "Show me my saved trip."', async () => {
    const reply = await client.send('Show me my saved trip.', {
      userId: 'demo-traveler-001',
      tripId: 'trip_del_jai_001'
    });

    expect(reply.text).toContain('get_saved_trip');
    expect(reply.text).toContain('Delhi → Jaipur');
    expect(reply.toolCalls).toHaveLength(1);
    expect(reply.toolCalls[0].name).toBe('get_saved_trip');
    expect(reply.toolCalls[0].status).toBe('ok');
  });

  it('4. Prompt: "What happens if my bus is cancelled?"', async () => {
    const reply = await client.send('What happens if my bus is cancelled?', {
      userId: 'demo-traveler-001',
      tripId: 'trip_del_jai_001'
    });

    expect(reply.text.toLowerCase()).toContain('refund');
    expect(reply.text.toLowerCase()).toMatch(/alternative|policy|transport/);
    expect(reply.toolCalls).toHaveLength(0);
  });

  it('5. Prompt: "Find an alternative for my disrupted journey."', async () => {
    const reply = await client.send('Find an alternative for my disrupted journey.', {
      userId: 'demo-traveler-001',
      tripId: 'trip_del_jai_001'
    });

    expect(reply.text).toContain('assessed your travel disruption');
    expect(reply.toolCalls).toHaveLength(1);
    expect(reply.toolCalls[0].name).toBe('assess_disruption');
    expect(reply.toolCalls[0].status).toBe('ok');
  });

  it('6. Prompt: "Prepare a recovery action, but let me review it first."', async () => {
    const reply = await client.send('Prepare a recovery action, but let me review it first.', {
      userId: 'demo-traveler-001',
      tripId: 'trip_del_jai_001'
    });

    expect(reply.cards).toBeDefined();
    expect(reply.cards?.[0].type).toBe('approval_card');
    const approvalCard = reply.cards?.[0] as any;
    expect(approvalCard.actionId).toBeDefined();
    expect(approvalCard.actionId).toMatch(/^act_/);
    expect(reply.toolCalls).toHaveLength(1);
    expect(reply.toolCalls[0].name).toBe('prepare_recovery_action');
    expect(reply.toolCalls[0].status).toBe('ok');
  });

  it('7. Prompt: "Reject that action."', async () => {
    await client.send('Prepare a recovery action, but let me review it first.', {
      userId: 'demo-traveler-001',
      tripId: 'trip_del_jai_001'
    });

    const rejectReply = await client.send('Reject that action.', {
      userId: 'demo-traveler-001',
      tripId: 'trip_del_jai_001'
    });

    expect(rejectReply.text).toMatch(/(Simulated Action Cancelled|Demo Action Cancelled)/i);
    expect(rejectReply.toolCalls).toHaveLength(1);
    expect(rejectReply.toolCalls[0].name).toBe('approve_recovery_action');
    expect(rejectReply.toolCalls[0].input.approved).toBe(false);
    expect(rejectReply.toolCalls[0].status).toBe('ok');
  });

  it('8. Prompt: "Approve the recovery action I just reviewed."', async () => {
    const stageReply = await client.send('Prepare a recovery action, but let me review it first.', {
      userId: 'demo-traveler-001',
      tripId: 'trip_del_jai_001'
    });
    const stagedId = (stageReply.cards?.[0] as any)?.actionId;
    expect(stagedId).toBeDefined();

    const approveReply = await client.send('Approve the recovery action I just reviewed.', {
      userId: 'demo-traveler-001',
      tripId: 'trip_del_jai_001'
    });

    expect(approveReply.text).toMatch(/(Simulated Action Executed|Demo Action Executed)/i);
    expect(approveReply.toolCalls).toHaveLength(1);
    expect(approveReply.toolCalls[0].name).toBe('approve_recovery_action');
    expect(approveReply.toolCalls[0].input.approved).toBe(true);
    expect(approveReply.toolCalls[0].input.action_id).toBe(stagedId);
    expect(approveReply.toolCalls[0].status).toBe('ok');
    expect(approveReply.action?.status).toBe('confirmed');
  });

  it('9. Prompt: "What is my current trip budget?"', async () => {
    const reply = await client.send('What is my current trip budget?', {
      userId: 'demo-traveler-001',
      tripId: 'trip_del_jai_001',
      draft: {
        id: 'draft-hyd-del',
        origin: 'Hyderabad',
        destination: 'Delhi',
        budget: 15000,
        travelers: 2,
        days: 3,
        outbound: { mode: 'bus', price: 3200, name: 'Volvo A/C' },
        lodging: { type: 'hotel', price: 4500, name: 'Heritage Haveli' }
      } as any
    });

    expect(reply.text).toMatch(/(verified trip budget|total budget for)/i);
    expect(reply.text).toContain('15,000');
    expect(reply.cards).toBeDefined();
    expect(reply.cards?.[0].type).toBe('budget_summary');
    expect(reply.toolCalls).toHaveLength(1);
    expect(reply.toolCalls[0].name).toBe('calculate_budget');
  });

  it('10. Regression: Handles un-persisted frontend draft ID (e.g. PMT-5458) safely without 404 crash', async () => {
    const unlinkedClient = new RemoteAlexaClient({ baseUrl: 'http://localhost:8001' });

    // User attempts to prepare recovery on an un-persisted client-side draft ID with no active backend trip
    const reply = await unlinkedClient.send('Prepare a recovery action for my disrupted journey, but let me review it first.', {
      userId: 'test-user',
      tripId: 'PMT-5458',
      draft: { id: 'PMT-5458', origin: 'Hyderabad', destination: 'Delhi' } as any
    });

    expect(reply.text).toContain("don't have an active saved trip");
    expect(reply.text).toContain('PMT-5458');
    expect(reply.text).toContain('Plan a 2-person trip');
    expect(reply.cards).toBeUndefined();
    expect(reply.toolCalls).toHaveLength(0);
  });

  it('11. Complete Life-Cycle: Plan trip -> Canonical ID preservation -> Disruption -> Recovery -> Reject -> Approve', async () => {
    const sessionClient = new RemoteAlexaClient({ baseUrl: 'http://localhost:8001' });

    // Step 1: Plan trip
    const planReply = await sessionClient.send('Plan a 2-person trip from Hyderabad to Delhi under ₹15,000.', {
      userId: 'traveler-e2e',
      draft: { id: 'PMT-9999', origin: 'Hyderabad', destination: 'Delhi' } as any
    });
    const canonicalTripId = planReply.tripPatch?.backendTripId;
    expect(canonicalTripId).toBeDefined();
    expect(canonicalTripId).toMatch(/^trip_hyd_del_/);

    // Step 2: Disruption on that planned trip
    const disruptReply = await sessionClient.send('Find an alternative for my disrupted journey.', {
      userId: 'traveler-e2e',
      draft: { id: 'PMT-9999', backendTripId: canonicalTripId } as any
    });
    expect(disruptReply.text).toContain('assessed your travel disruption');
    expect(disruptReply.toolCalls[0].name).toBe('assess_disruption');
    expect(disruptReply.toolCalls[0].status).toBe('ok');
    expect(disruptReply.toolCalls[0].input.trip_id).toBe(canonicalTripId);

    // Step 3: Prepare recovery action without 404
    const prepReply = await sessionClient.send('Prepare a recovery action for my disrupted journey, but let me review it first.', {
      userId: 'traveler-e2e',
      draft: { id: 'PMT-9999', backendTripId: canonicalTripId } as any
    });
    expect(prepReply.cards).toBeDefined();
    expect(prepReply.cards?.[0].type).toBe('approval_card');
    const action1Id = (prepReply.cards?.[0] as any)?.actionId;
    expect(action1Id).toMatch(/^act_/);
    expect(prepReply.toolCalls[0].name).toBe('prepare_recovery_action');
    expect(prepReply.toolCalls[0].status).toBe('ok');
    expect(prepReply.toolCalls[0].input.trip_id).toBe(canonicalTripId);

    // Step 4: Reject action
    const rejectReply = await sessionClient.send('Reject that action.', {
      userId: 'traveler-e2e',
      draft: { id: 'PMT-9999', backendTripId: canonicalTripId } as any
    });
    expect(rejectReply.text).toMatch(/(Simulated Action Cancelled|Demo Action Cancelled)/i);
    expect(rejectReply.toolCalls[0].input.approved).toBe(false);
    expect(rejectReply.toolCalls[0].input.action_id).toBe(action1Id);

    // Step 5: Prepare second action (cab option)
    const prep2Reply = await sessionClient.send('Book cab option 2 and prepare it for review', {
      userId: 'traveler-e2e',
      draft: { id: 'PMT-9999', backendTripId: canonicalTripId } as any
    });
    const action2Id = (prep2Reply.cards?.[0] as any)?.actionId;
    expect(action2Id).toMatch(/^act_/);
    expect(prep2Reply.toolCalls[0].input.trip_id).toBe(canonicalTripId);

    // Step 6: Approve second action
    const approveReply = await sessionClient.send('Approve the recovery action I just reviewed.', {
      userId: 'traveler-e2e',
      draft: { id: 'PMT-9999', backendTripId: canonicalTripId } as any
    });
    expect(approveReply.text).toMatch(/(Simulated Action Executed|Demo Action Executed)/i);
    expect(approveReply.action?.status).toBe('confirmed');
    expect(approveReply.toolCalls[0].input.approved).toBe(true);
    expect(approveReply.toolCalls[0].input.action_id).toBe(action2Id);
  });

  it('12. Critical Bus Rebooking Flow: "I want to cancel my bus. I want to go in the next bus; I have some work."', async () => {
    const prompt = 'I want to cancel my bus. I want to go in the next bus; I have some work.';
    const reply = await client.send(prompt, {
      userId: 'demo-traveler-001',
      tripId: 'trip_del_jai_001'
    });

    // 1. Must recognize intent to change bus journey
    expect(reply.text).toMatch(/recognize your request to cancel|cancel.*current bus.*switch.*next/i);

    // 2. Must verify active bus booking and PNR
    expect(reply.text).toContain('RSRTC-DEL-99231');
    expect(reply.text).toContain('RSRTC Express');

    // 3. Must explain verified cancellation refund policy
    expect(reply.text).toMatch(/cancellation conditions/i);
    expect(reply.text).toMatch(/85% refund|non-refundable/i);

    // 4. Must honestly disclose that live next-bus seats and fares are simulated
    expect(reply.text).toMatch(/honest disclosure|simulated/i);
    expect(reply.text).not.toMatch(/confirmed seat \d+[A-Z]/i); // No fabricated seat numbers

    // 5. Must chain assess_disruption and prepare_recovery_action
    const toolNames = reply.toolCalls.map(t => t.name);
    expect(toolNames).toContain('assess_disruption');
    expect(toolNames).toContain('prepare_recovery_action');

    // 6. Must return an approval card in pending state with explicit safety gate
    expect(reply.cards && reply.cards.length > 0).toBe(true);
    const approvalCard = reply.cards?.[0] as any;
    expect(approvalCard.type).toBe('approval_card');
    expect(approvalCard.actionId).toMatch(/^act_/);
    expect(approvalCard.extraCostLabel).toContain('350');
    expect(reply.action?.status).toBe('pending');
  });
});
