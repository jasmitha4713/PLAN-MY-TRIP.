import { describe, it, expect, vi, beforeEach } from 'vitest';
import { RemoteAlexaClient } from './remoteClient';

describe('RemoteAlexaClient MCP Integration', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('lists registered tools over MCP tools/list', async () => {
    const mockTools = [
      { name: 'plan_trip', description: 'Plan an affordable trip' },
      { name: 'get_saved_trip', description: 'Retrieve saved trip' },
      { name: 'assess_disruption', description: 'Analyze delay' },
      { name: 'prepare_recovery_action', description: 'Stage action' },
      { name: 'approve_recovery_action', description: 'Execute action' }
    ];

    vi.spyOn(global, 'fetch').mockImplementation(async (url, init) => {
      const body = JSON.parse((init?.body as string) || '{}');
      if (body.method === 'initialize') {
        return new Response(JSON.stringify({
          jsonrpc: '2.0',
          id: body.id,
          result: { protocolVersion: '2025-11-25', serverInfo: { name: 'plan-my-trip-alexa-mcp', version: '1.0.0' } }
        }), {
          status: 200,
          headers: { 'mcp-session-id': 'sess-test-123', 'content-type': 'application/json' }
        });
      }
      if (body.method === 'notifications/initialized') {
        return new Response(null, { status: 202 });
      }
      if (body.method === 'tools/list') {
        return new Response(JSON.stringify({
          jsonrpc: '2.0',
          id: body.id,
          result: { tools: mockTools }
        }), { status: 200, headers: { 'content-type': 'application/json' } });
      }
      return new Response(null, { status: 404 });
    });

    const client = new RemoteAlexaClient({ baseUrl: 'http://localhost:8001' });
    const tools = await client.listTools();

    expect(tools).toHaveLength(5);
    expect(tools.map(t => t.name)).toContain('plan_trip');
    expect(tools.map(t => t.name)).toContain('assess_disruption');
    expect(client.connectionStatus).toBe('connected');
  });

  it('invokes assess_disruption and returns formatted reply with tool call record', async () => {
    vi.spyOn(global, 'fetch').mockImplementation(async (url, init) => {
      const body = JSON.parse((init?.body as string) || '{}');
      if (body.method === 'initialize') {
        return new Response(JSON.stringify({
          jsonrpc: '2.0',
          id: body.id,
          result: { protocolVersion: '2025-11-25', serverInfo: { name: 'plan-my-trip-alexa-mcp', version: '1.0.0' } }
        }), { status: 200, headers: { 'mcp-session-id': 'sess-test-456' } });
      }
      if (body.method === 'notifications/initialized') return new Response(null, { status: 202 });
      if (body.method === 'tools/call' && body.params?.name === 'assess_disruption') {
        return new Response(JSON.stringify({
          jsonrpc: '2.0',
          id: body.id,
          result: {
            content: [{
              type: 'text',
              text: JSON.stringify({
                status: 'success',
                data: {
                  disruption: { severity: 'high' },
                  impact: { check_in_notes: 'Arrival delayed 180m.', hotel_check_in_affected: true },
                  recovery_options: [{ title: 'Notify hotel' }, { title: 'Book cab' }]
                }
              })
            }]
          }
        }), { status: 200, headers: { 'content-type': 'application/json' } });
      }
      return new Response(null, { status: 404 });
    });

    const client = new RemoteAlexaClient({ baseUrl: 'http://localhost:8001' });
    const reply = await client.send('Our bus broke down, delayed by 3 hours', { userId: 'usr-1', tripId: 'trip_del_jai_001' });

    expect(reply.text).toContain('assessed your travel disruption');
    expect(reply.toolCalls).toHaveLength(1);
    expect(reply.toolCalls[0].name).toBe('assess_disruption');
    expect(reply.toolCalls[0].status).toBe('ok');
    expect(client.connectionStatus).toBe('connected');
  });

  it('invokes prepare_recovery_action and generates an approval card', async () => {
    vi.spyOn(global, 'fetch').mockImplementation(async (url, init) => {
      const body = JSON.parse((init?.body as string) || '{}');
      if (body.method === 'initialize') {
        return new Response(JSON.stringify({
          jsonrpc: '2.0',
          id: body.id,
          result: { protocolVersion: '2025-11-25', serverInfo: { name: 'plan-my-trip-alexa-mcp', version: '1.0.0' } }
        }), { status: 200, headers: { 'mcp-session-id': 'sess-test-789' } });
      }
      if (body.method === 'notifications/initialized') return new Response(null, { status: 202 });
      if (body.method === 'tools/call' && body.params?.name === 'prepare_recovery_action') {
        return new Response(JSON.stringify({
          jsonrpc: '2.0',
          id: body.id,
          result: {
            content: [{
              type: 'text',
              text: JSON.stringify({
                status: 'success',
                data: {
                  action_id: 'act_staged_999',
                  approval_prompt: 'May I alert the hotel to hold your room without fee?',
                  status: 'pending_approval'
                }
              })
            }]
          }
        }), { status: 200, headers: { 'content-type': 'application/json' } });
      }
      return new Response(null, { status: 404 });
    });

    const client = new RemoteAlexaClient({ baseUrl: 'http://localhost:8001' });
    const reply = await client.send('Notify the hotel about my late check-in', { userId: 'usr-1', tripId: 'trip_del_jai_001' });

    expect(reply.cards).toBeDefined();
    expect(reply.cards?.[0].type).toBe('approval_card');
    expect(reply.toolCalls[0].name).toBe('prepare_recovery_action');
  });

  it('falls back gracefully to built-in simulation if MCP server is offline', async () => {
    vi.spyOn(global, 'fetch').mockRejectedValue(new Error('Connection refused'));

    const client = new RemoteAlexaClient({ baseUrl: 'http://localhost:8001' });
    const reply = await client.send('Plan a trip to Mumbai for 3 days', { userId: 'usr-1' });

    expect(client.connectionStatus).toBe('fallback');
    expect(reply.text).toContain('Notice: MCP Server at http://localhost:8001 unreachable');
  });
});
