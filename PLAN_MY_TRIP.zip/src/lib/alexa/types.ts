import { TripDraft } from '../../data/fixtures';
import { BudgetResult } from '../budget';

export interface ToolInfo {
  name: string;
  description: string;
  inputSchema?: Record<string, unknown>;
}

export interface ToolCallRecord {
  name: string;
  input: unknown;
  output?: unknown;
  status: 'ok' | 'pending' | 'failed';
}

export interface BudgetCardPayload {
  type: 'budget_summary';
  budget: BudgetResult;
  title?: string;
}

export interface OptionPickerPayload {
  type: 'option_picker';
  category: 'transport' | 'stay' | 'local' | 'experience';
  title: string;
  options: Array<{
    id: string;
    title: string;
    priceLabel: string;
    tag?: string;
    details?: string;
    terms?: string;
    simulated?: boolean;
  }>;
}

export interface ApprovalCardPayload {
  type: 'approval_card';
  actionId: string;
  title: string;
  recipient: string;
  extraCost: number;
  extraCostLabel: string;
  explanation: string;
  caveat?: string;
  simulated: boolean;
}

export type AlexaCard = BudgetCardPayload | OptionPickerPayload | ApprovalCardPayload;

export interface AlexaActionState {
  id: string;
  status: 'pending' | 'confirmed' | 'failed';
  label: string;
  simulated: boolean;
}

export interface AlexaReply {
  text: string;
  toolCalls: ToolCallRecord[];
  cards?: AlexaCard[];
  tripPatch?: Partial<TripDraft>;
  action?: AlexaActionState;
}

export interface AlexaScope {
  mode: 'plan' | 'trip';
  tripId?: string;
}

export interface AlexaContext {
  userId: string;
  scope?: AlexaScope;
  tripId?: string;
  draft?: TripDraft;
}

export interface AlexaClient {
  modeName: 'mock' | 'remote';
  connectionStatus: 'simulation' | 'connected' | 'fallback';
  send(message: string, ctx: AlexaContext, scope?: AlexaScope): Promise<AlexaReply>;
  listTools(): Promise<ToolInfo[]>;
}
