import { useState, useEffect, useRef, useCallback } from 'react';
import { sanitizeSpeechText } from './speechSanitizer';
import { voiceService } from './voiceService';

export type VoiceState = 'idle' | 'listening' | 'thinking' | 'speaking' | 'error';

export interface UseAlexaVoiceOptions {
  lang?: string;
  autoSpeak?: boolean;
  onTranscriptReady?: (transcript: string) => void;
  continuousConversationalMode?: boolean;
}

export function useAlexaVoice(options: UseAlexaVoiceOptions = {}) {
  const {
    lang = 'en-IN',
    autoSpeak = true,
    onTranscriptReady,
    continuousConversationalMode = true
  } = options;

  const [voiceState, setVoiceState] = useState<VoiceState>('idle');
  const [voiceAudioEnabled, setVoiceAudioEnabled] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      const saved = window.localStorage.getItem('pmt_alexa_voice_audio');
      return saved !== null ? saved === 'true' : true;
    }
    return true;
  });

  const [isSpeechSupported, setIsSpeechSupported] = useState(true);
  const [isSynthesisSupported, setIsSynthesisSupported] = useState(true);

  const [interimTranscript, setInterimTranscript] = useState('');
  const [finalTranscript, setFinalTranscript] = useState('');
  const [editableTranscript, setEditableTranscript] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const recognitionRef = useRef<any>(null);
  const isManuallyStoppedRef = useRef(false);
  const isListeningRef = useRef(false);
  const autoSubmitTimeoutRef = useRef<any>(null);
  const onTranscriptReadyRef = useRef(onTranscriptReady);
  onTranscriptReadyRef.current = onTranscriptReady;

  const voiceAudioEnabledRef = useRef(voiceAudioEnabled);
  voiceAudioEnabledRef.current = voiceAudioEnabled;

  // Initialize Speech Recognition & Synthesis support
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setIsSpeechSupported(false);
    }

    if (!('speechSynthesis' in window)) {
      setIsSynthesisSupported(false);
    }

    return () => {
      if (autoSubmitTimeoutRef.current) {
        clearTimeout(autoSubmitTimeoutRef.current);
      }
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {}
        recognitionRef.current = null;
      }
      voiceService.stopSpeaking();
    };
  }, []);

  const clearTranscript = useCallback(() => {
    if (autoSubmitTimeoutRef.current) {
      clearTimeout(autoSubmitTimeoutRef.current);
    }
    setFinalTranscript('');
    setInterimTranscript('');
    setEditableTranscript('');
    setErrorMessage(null);
  }, []);

  const updateTranscript = useCallback((text: string) => {
    setEditableTranscript(text);
    setFinalTranscript(text);
  }, []);

  const initRecognition = useCallback(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setIsSpeechSupported(false);
      return null;
    }

    // Safely cleanup existing recognition before re-creating
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch {}
      recognitionRef.current = null;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = lang;

      recognition.onstart = () => {
        isListeningRef.current = true;
        setVoiceState('listening');
        setErrorMessage(null);
        isManuallyStoppedRef.current = false;
      };

      recognition.onresult = (event: any) => {
        let currentInterim = '';
        let currentFinal = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const res = event.results[i];
          if (res.isFinal) {
            currentFinal += res[0].transcript + ' ';
          } else {
            currentInterim += res[0].transcript;
          }
        }

        const trimmedInterim = currentInterim.trim();
        setInterimTranscript(trimmedInterim);

        if (currentFinal) {
          const updatedFinal = currentFinal.trim();
          setFinalTranscript((prev) => {
            const combined = (prev ? `${prev} ${updatedFinal}` : updatedFinal).trim();
            setEditableTranscript(combined);

            // If auto-submission callback is provided, trigger it after a brief pause
            if (onTranscriptReadyRef.current && combined.length >= 2) {
              if (autoSubmitTimeoutRef.current) {
                clearTimeout(autoSubmitTimeoutRef.current);
              }
              autoSubmitTimeoutRef.current = setTimeout(() => {
                if (!isManuallyStoppedRef.current && onTranscriptReadyRef.current) {
                  const toSubmit = combined.trim();
                  // Reset buffer before dispatching
                  setFinalTranscript('');
                  setInterimTranscript('');
                  setEditableTranscript('');
                  setVoiceState('thinking');
                  onTranscriptReadyRef.current(toSubmit);
                }
              }, 750);
            }

            return combined;
          });
        } else if (trimmedInterim) {
          // Display live interim speech in input field so the user sees words live
          setEditableTranscript((prev) => {
            return prev ? `${prev} ${trimmedInterim}` : trimmedInterim;
          });
        }
      };

      recognition.onerror = (event: any) => {
        const errType = event.error;
        console.warn('Alexa Voice recognition event error:', errType);

        // 1. Silent normal cancellations & restarts (DO NOT show scary error banner)
        if (errType === 'aborted' || errType === 'no-speech') {
          if (isManuallyStoppedRef.current) {
            isListeningRef.current = false;
            setVoiceState('idle');
          }
          return;
        }

        // 2. Permission denied
        if (errType === 'not-allowed' || errType === 'service-not-allowed') {
          isListeningRef.current = false;
          setErrorMessage('Microphone access was denied. You can type directly in the box below.');
          setVoiceState('error');
          return;
        }

        // 3. Network or hardware capture
        if (errType === 'network') {
          isListeningRef.current = false;
          setErrorMessage('Speech recognition service network issue. You can retry or type below.');
          setVoiceState('error');
          return;
        }

        // 4. Other unexpected errors
        if (!isManuallyStoppedRef.current) {
          isListeningRef.current = false;
          setErrorMessage(`Audio input notice (${errType}). You can type or retry.`);
          setVoiceState('error');
        }
      };

      recognition.onend = () => {
        isListeningRef.current = false;
        // If not manually stopped, keep conversational listening active
        if (!isManuallyStoppedRef.current && voiceAudioEnabledRef.current && continuousConversationalMode) {
          // Restart after short delay if still enabled
          setTimeout(() => {
            if (!isManuallyStoppedRef.current && voiceAudioEnabledRef.current && !isListeningRef.current) {
              try {
                recognition.start();
                setVoiceState('listening');
              } catch {}
            }
          }, 300);
          return;
        }
        setVoiceState((prev) => (prev === 'listening' ? 'idle' : prev));
      };

      recognitionRef.current = recognition;
      return recognition;
    } catch (e) {
      console.warn('Failed to construct SpeechRecognition:', e);
      setIsSpeechSupported(false);
      return null;
    }
  }, [lang, continuousConversationalMode]);

  // Start listening to microphone
  const startListening = useCallback(() => {
    setErrorMessage(null);
    setInterimTranscript('');
    isManuallyStoppedRef.current = false;

    // Cancel any active speech when listening starts
    voiceService.stopSpeaking();

    let rec = recognitionRef.current;
    if (!rec) {
      rec = initRecognition();
    }
    if (!rec) {
      setErrorMessage('Speech recognition is not supported in this browser. Please type.');
      return;
    }

    try {
      rec.start();
      isListeningRef.current = true;
      setVoiceState('listening');
    } catch (err: any) {
      // If already started, confirm state is listening
      isListeningRef.current = true;
      setVoiceState('listening');
    }
  }, [initRecognition]);

  // Stop listening
  const stopListening = useCallback(() => {
    isManuallyStoppedRef.current = true;
    isListeningRef.current = false;
    if (autoSubmitTimeoutRef.current) {
      clearTimeout(autoSubmitTimeoutRef.current);
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
    }
    setVoiceState((prev) => (prev === 'listening' ? 'idle' : prev));
  }, []);

  // Toggle listening
  const toggleListening = useCallback(() => {
    if (voiceState === 'listening') {
      stopListening();
    } else {
      startListening();
    }
  }, [voiceState, startListening, stopListening]);

  // Text to Speech playback using central voiceService
  const speakText = useCallback(
    (rawText: string, onEnd?: () => void) => {
      if (!voiceAudioEnabled || typeof window === 'undefined' || !('speechSynthesis' in window)) {
        if (onEnd) onEnd();
        return;
      }

      // Temporarily stop microphone while assistant is speaking so it doesn't hear itself
      if (recognitionRef.current && isListeningRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {}
        isListeningRef.current = false;
      }

      voiceService.speak(rawText, {
        onStart: () => setVoiceState('speaking'),
        onEnd: () => {
          setVoiceState('idle');
          if (onEnd) onEnd();
          // Resume conversational listening after speaking if voice is enabled and not manually stopped
          if (continuousConversationalMode && voiceAudioEnabledRef.current && !isManuallyStoppedRef.current) {
            setTimeout(() => {
              if (voiceAudioEnabledRef.current && !isManuallyStoppedRef.current) {
                startListening();
              }
            }, 400);
          }
        },
        onError: () => {
          setVoiceState('idle');
          if (onEnd) onEnd();
          if (continuousConversationalMode && voiceAudioEnabledRef.current && !isManuallyStoppedRef.current) {
            setTimeout(() => {
              if (voiceAudioEnabledRef.current && !isManuallyStoppedRef.current) {
                startListening();
              }
            }, 400);
          }
        }
      });
    },
    [voiceAudioEnabled, continuousConversationalMode, startListening]
  );

  // Stop active speech playback immediately
  const stopSpeaking = useCallback(() => {
    voiceService.stopSpeaking();
    setVoiceState((prev) => (prev === 'speaking' ? 'idle' : prev));
  }, []);

  // Replay given message text
  const replayMessage = useCallback(
    (text: string) => {
      speakText(text);
    },
    [speakText]
  );

  // Toggle voice audio output ON/OFF
  const toggleVoiceAudio = useCallback(() => {
    setVoiceAudioEnabled((prev) => {
      const next = !prev;
      voiceAudioEnabledRef.current = next;

      // When turned OFF: halt speech synthesis and halt recognition immediately
      if (!next) {
        voiceService.stopSpeaking();
        isManuallyStoppedRef.current = true;
        isListeningRef.current = false;
        if (recognitionRef.current) {
          try {
            recognitionRef.current.abort();
          } catch {}
        }
        setVoiceState('idle');
      }

      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem('pmt_alexa_voice_audio', String(next));
      }
      return next;
    });
  }, []);

  return {
    voiceState,
    setVoiceState,
    voiceAudioEnabled,
    toggleVoiceAudio,
    isSpeechSupported,
    isSynthesisSupported,
    interimTranscript,
    finalTranscript,
    editableTranscript,
    updateTranscript,
    fullTranscript: (finalTranscript + ' ' + interimTranscript).trim(),
    errorMessage,
    startListening,
    stopListening,
    toggleListening,
    clearTranscript,
    speakText,
    stopSpeaking,
    replayMessage
  };
}
