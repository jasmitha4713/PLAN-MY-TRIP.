/**
 * Deterministic Dialogue Manager for Scoped Trip Companion
 * Scenarios S1-S5:
 * S1: Cab delayed by group
 * S2: Stuck in traffic to the hotel
 * S3: Bus about to leave
 * S4: Need more time at the hotel
 * S5: Change plan
 */

export interface DialogueAction {
  type: 'propose_message' | 'slot_fill' | 'update_schedule' | 'offer_alternatives';
  recipient?: string;
  draftedText?: string;
  responsePrompt: string;
  timelineNotice?: string;
  requiresApproval: boolean;
  metadata?: Record<string, any>;
}

export interface DialogueState {
  tripId: string;
  activeScenario?: 'S1' | 'S2' | 'S3' | 'S4' | 'S5';
  awaitingSlot?: string;
  cabPickupTime: string;
  hotelCutoffTime: string;
  scheduledBusDeparture: string;
}

export class DialogueManager {
  private state: DialogueState;

  constructor(tripId: string) {
    this.state = {
      tripId,
      cabPickupTime: '09:30 PM',
      hotelCutoffTime: '11:00 PM',
      scheduledBusDeparture: '09:00 PM'
    };
  }

  processInput(userInput: string): DialogueAction {
    const text = userInput.trim().toLowerCase();

    // 1. Scenario S1: "My friends arrived late, I need 30 more minutes before the driver comes."
    if (
      (text.includes('friend') && text.includes('late')) ||
      (text.includes('30') && text.includes('minute') && (text.includes('driver') || text.includes('cab')))
    ) {
      this.state.activeScenario = 'S1';
      return {
        type: 'propose_message',
        recipient: 'Driver: Ramesh Patel (SIM-CAB-123)',
        draftedText: 'Hello, pickup time for booking SIM-CAB-123 has changed from 9:30 PM to 10:00 PM. Please confirm.',
        responsePrompt: 'I checked your cab booking (currently scheduled for 9:30 PM). Moving pickup by 30 minutes makes it 10:00 PM. Your hotel check-in desk is open until 11:00 PM, so you will arrive safely before cutoff. May I send this message to the driver?',
        timelineNotice: 'Pickup moves from 09:30 PM → 10:00 PM. Check-in cutoff 11:00 PM remains safe.',
        requiresApproval: true,
        metadata: { scenario: 'S1', newPickup: '10:00 PM' }
      };
    }

    // 2. Scenario S2: "I'm stuck in traffic, I'll reach the hotel late."
    if (text.includes('traffic') && (text.includes('hotel') || text.includes('reach'))) {
      this.state.activeScenario = 'S2';
      this.state.awaitingSlot = 'delayDuration';
      return {
        type: 'slot_fill',
        responsePrompt: 'How long do you think you need before reaching the hotel?',
        requiresApproval: false,
        metadata: { scenario: 'S2' }
      };
    }

    // Follow-up for S2 after user says duration (e.g. "45 minutes" or "1 hour")
    if (this.state.activeScenario === 'S2' && (text.includes('min') || text.includes('hour') || /\d+/.test(text))) {
      return {
        type: 'propose_message',
        recipient: 'Front Desk Duty Manager: Rajesh Kumar (SIM-HTL-890)',
        draftedText: 'Hello, guest Aarav Sharma for booking SIM-HTL-890 is delayed in heavy traffic. New estimated arrival is 10:30 PM. Please note the late arrival.',
        responsePrompt: 'Your expected arrival is now 10:30 PM. The front desk cutoff is 11:00 PM, but we do not know if traffic will worsen. I drafted a message to alert the duty manager. May I send it?',
        timelineNotice: 'Estimated arrival at hotel shifted to 10:30 PM.',
        requiresApproval: true,
        metadata: { scenario: 'S2' }
      };
    }

    // 3. Scenario S3: "I'm in traffic and my bus leaves in 10 minutes."
    if (text.includes('bus') && (text.includes('traffic') || text.includes('leave') || text.includes('10 min'))) {
      this.state.activeScenario = 'S3';
      this.state.awaitingSlot = 'reachTime';
      return {
        type: 'slot_fill',
        responsePrompt: 'How long to reach the boarding point?',
        requiresApproval: false,
        metadata: { scenario: 'S3' }
      };
    }

    // Follow-up for S3 after user says "20 minutes"
    if (this.state.activeScenario === 'S3' && (text.includes('20') || text.includes('min'))) {
      return {
        type: 'propose_message',
        recipient: 'Bus Operator Dispatch: IntrCity SmartBus (SIM-BUS-456)',
        draftedText: 'Passenger for seat 12 is on the way and needs 10 more minutes. Can you hold the bus until 09:20 PM?',
        responsePrompt: 'Your bus leaves in 10 minutes and you need 20 minutes (a 10-minute gap). May I ask the operator to hold the bus?',
        timelineNotice: 'Holding request for 10 minutes (departure 09:20 PM).',
        requiresApproval: true,
        metadata: { scenario: 'S3' }
      };
    }

    // 4. Scenario S4: "I need 45 more minutes before the cab."
    if (text.includes('45') || (text.includes('more time') && text.includes('cab'))) {
      this.state.activeScenario = 'S4';
      return {
        type: 'propose_message',
        recipient: 'Driver: Ramesh Patel (SIM-CAB-123)',
        draftedText: 'Hello, pickup for booking SIM-CAB-123 is requested 45 minutes later at 10:15 PM. Please confirm availability.',
        responsePrompt: 'Shifting the cab pickup by 45 minutes makes it 10:15 PM. Your first sightseeing entry is flexible until 01:00 PM tomorrow, so this change will not cause any missed monument slots. May I notify the cab provider?',
        timelineNotice: 'Cab pickup updated to 10:15 PM.',
        requiresApproval: true,
        metadata: { scenario: 'S4' }
      };
    }

    // 5. Scenario S5: "Skip Qutub Minar and add a food walk"
    if ((text.includes('skip') || text.includes('remove')) && (text.includes('food') || text.includes('walk') || text.includes('add'))) {
      this.state.activeScenario = 'S5';
      return {
        type: 'propose_message',
        recipient: 'Itinerary Engine',
        draftedText: 'Update itinerary: Remove monument ticket (₹50/person) and add Old Delhi Food Walk (₹650/person). Total budget difference: +₹600/person.',
        responsePrompt: 'Skipping Qutub Minar saves ₹50/person. Adding the Old Delhi Food Walk costs ₹650/person. The net difference is +₹600/person (+₹1,200 for 2). Your trip remains within budget using available surplus. May I update your trip itinerary?',
        timelineNotice: 'Monument slot replaced with Evening Culinary Walk.',
        requiresApproval: true,
        metadata: { scenario: 'S5' }
      };
    }

    // Default conversational reply
    return {
      type: 'slot_fill',
      responsePrompt: `I am monitoring your bookings for trip ${this.state.tripId}. If you are running late or need to adjust any timing, simply tell me (e.g. "Friends arrived late, need 30 minutes").`,
      requiresApproval: false
    };
  }
}
