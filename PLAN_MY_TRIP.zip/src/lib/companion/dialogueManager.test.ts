import { describe, it, expect } from 'vitest';
import { DialogueManager } from './dialogueManager';

describe('Dialogue Manager Scenarios S1 - S5', () => {
  it('handles S1: Cab delayed by group with exact drafted message and cutoff verification', () => {
    const dm = new DialogueManager('SIM-PMT-0142');
    const action = dm.processInput('My friends arrived late, I need 30 more minutes before the driver comes.');

    expect(action.type).toBe('propose_message');
    expect(action.recipient).toContain('Driver: Ramesh Patel');
    expect(action.draftedText).toBe('Hello, pickup time for booking SIM-CAB-123 has changed from 9:30 PM to 10:00 PM. Please confirm.');
    expect(action.requiresApproval).toBe(true);
    expect(action.responsePrompt).toContain('11:00 PM');
  });

  it('handles S2: Stuck in traffic to the hotel with slot filling and alert message', () => {
    const dm = new DialogueManager('SIM-PMT-0142');
    const step1 = dm.processInput("I'm stuck in traffic, I'll reach the hotel late.");
    expect(step1.type).toBe('slot_fill');
    expect(step1.responsePrompt).toContain('How long do you think you need');

    const step2 = dm.processInput('45 minutes');
    expect(step2.type).toBe('propose_message');
    expect(step2.recipient).toContain('Front Desk Duty Manager');
    expect(step2.draftedText).toContain('delayed in heavy traffic');
    expect(step2.draftedText).toContain('Please note the late arrival.');
    expect(step2.requiresApproval).toBe(true);
  });

  it('handles S3: Bus about to leave with gap calculation and hold proposal', () => {
    const dm = new DialogueManager('SIM-PMT-0142');
    const step1 = dm.processInput("I'm in traffic and my bus leaves in 10 minutes.");
    expect(step1.type).toBe('slot_fill');
    expect(step1.responsePrompt).toBe('How long to reach the boarding point?');

    const step2 = dm.processInput('20 minutes');
    expect(step2.type).toBe('propose_message');
    expect(step2.draftedText).toBe('Passenger for seat 12 is on the way and needs 10 more minutes. Can you hold the bus until 09:20 PM?');
    expect(step2.requiresApproval).toBe(true);
  });

  it('handles S4: Need more time at hotel and verifies no missed activities', () => {
    const dm = new DialogueManager('SIM-PMT-0142');
    const action = dm.processInput('I need 45 more minutes before the cab.');
    expect(action.type).toBe('propose_message');
    expect(action.draftedText).toContain('10:15 PM');
    expect(action.requiresApproval).toBe(true);
  });

  it('handles S5: Change plan using budget engine differences', () => {
    const dm = new DialogueManager('SIM-PMT-0142');
    const action = dm.processInput('Skip Qutub Minar and add a food walk');
    expect(action.type).toBe('propose_message');
    expect(action.responsePrompt).toContain('Skipping Qutub Minar saves ₹50');
    expect(action.responsePrompt).toContain('Old Delhi Food Walk costs ₹650');
    expect(action.requiresApproval).toBe(true);
  });
});
