/**
 * Simulated Payment & Settlement Architecture
 * Adheres strictly to the Honesty Model:
 * In this prototype, no real cards or money are processed.
 * Stubs for Razorpay Route and Stripe Connect throw 'needs backend'.
 */

export interface SettlementLine {
  id: string;
  providerId: string;
  providerName: string;
  serviceType: 'transport' | 'stay' | 'local' | 'activities';
  amount: number;
  status: 'Pending' | 'Paid out';
  payoutReference: string;
  estimatedPayoutTime: string;
}

export interface RefundRecord {
  id: string;
  bookingId: string;
  providerName: string;
  amount: number;
  reason: string;
  status: 'Requested' | 'Processing' | 'Credited';
  requestedAt: string;
  processedAt?: string;
  creditedAt?: string;
  sampleTimelineNote: string;
}

export interface PaymentOrder {
  orderId: string;
  amount: number;
  currency: 'INR';
  createdAt: string;
  status: 'created' | 'paid' | 'failed';
  transactionId?: string;
  settlementLines: SettlementLine[];
  refunds: RefundRecord[];
}

export interface PaymentProvider {
  createOrder: (amount: number, currency?: string) => Promise<{ orderId: string }>;
  confirm: (
    orderId: string, 
    simulateFailure?: boolean
  ) => Promise<{ success: boolean; transactionId?: string; error?: string }>;
}

export interface VendorSettlement {
  split: (orderAmount: number, items: {
    transport?: { operator: string; cost: number };
    stay?: { name: string; cost: number };
    local?: { name: string; cost: number };
    places?: { count: number; cost: number };
  }) => SettlementLine[];
}

/**
 * Mock In-Memory Payment Provider for Presentation & Prototype
 */
export const mockPaymentProvider: PaymentProvider = {
  async createOrder(amount: number, currency = 'INR') {
    const orderId = `ORD-SIM-${Date.now().toString().slice(-6)}`;
    return { orderId };
  },

  async confirm(orderId: string, simulateFailure = false) {
    // Simulated processing latency
    await new Promise(r => setTimeout(r, 1200));

    if (simulateFailure) {
      return {
        success: false,
        error: 'Simulated bank decline: Transaction was deliberately failed for demo testing.'
      };
    }

    const transactionId = `TXN-SIM-${Math.random().toString(36).substring(2, 9).toUpperCase()}`;
    return {
      success: true,
      transactionId
    };
  }
};

/**
 * Real Provider Stubs
 * In production, split payouts require a marketplace payment product like Razorpay Route or Stripe Connect.
 * Client-side secret exposure is forbidden; server-side order generation and webhook signature verification are required.
 */
export const razorpayRouteStub: PaymentProvider = {
  async createOrder() {
    throw new Error('Razorpay Route integration requires a secure server-side backend with API secrets. Real mode is disabled in this presentation prototype.');
  },
  async confirm() {
    throw new Error('Razorpay Route requires server-side payment signature verification.');
  }
};

export const stripeConnectStub: PaymentProvider = {
  async createOrder() {
    throw new Error('Stripe Connect split payouts require server-side backend authentication and KYC onboarding.');
  },
  async confirm() {
    throw new Error('Stripe Connect requires server-side webhook verification.');
  }
};

/**
 * Vendor Settlement Split Calculator
 */
export const vendorSettlementEngine: VendorSettlement = {
  split(orderAmount, items) {
    const lines: SettlementLine[] = [];

    if (items.transport && items.transport.cost > 0) {
      lines.push({
        id: `set-trans-${Date.now()}-1`,
        providerId: 'prov-trans-01',
        providerName: items.transport.operator,
        serviceType: 'transport',
        amount: items.transport.cost,
        status: 'Pending',
        payoutReference: `PAYOUT-TR-${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
        estimatedPayoutTime: 'T+2 business days after departure (Simulated)'
      });
    }

    if (items.stay && items.stay.cost > 0) {
      lines.push({
        id: `set-stay-${Date.now()}-2`,
        providerId: 'prov-stay-02',
        providerName: items.stay.name,
        serviceType: 'stay',
        amount: items.stay.cost,
        status: 'Pending',
        payoutReference: `PAYOUT-ST-${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
        estimatedPayoutTime: 'T+1 business day after check-in (Simulated)'
      });
    }

    if (items.local && items.local.cost > 0) {
      lines.push({
        id: `set-loc-${Date.now()}-3`,
        providerId: 'prov-local-03',
        providerName: items.local.name,
        serviceType: 'local',
        amount: items.local.cost,
        status: 'Pending',
        payoutReference: `PAYOUT-LC-${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
        estimatedPayoutTime: 'Direct driver escrow payout upon trip completion (Simulated)'
      });
    }

    if (items.places && items.places.cost > 0) {
      lines.push({
        id: `set-pla-${Date.now()}-4`,
        providerId: 'prov-monuments-04',
        providerName: 'Archaeological Survey & Heritage Ticketing',
        serviceType: 'activities',
        amount: items.places.cost,
        status: 'Pending',
        payoutReference: `PAYOUT-ASI-${Math.random().toString(36).substring(2, 7).toUpperCase()}`,
        estimatedPayoutTime: 'Automated digital voucher clearance (Simulated)'
      });
    }

    return lines;
  }
};
