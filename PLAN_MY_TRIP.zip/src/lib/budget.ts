/**
 * Pure Budget Engine for Plan My Trip
 * All monetary calculations use integer rupees (₹).
 * Never compute arithmetic outside this module.
 */

export interface TransportOption {
  id: string;
  name: string;
  mode: 'train' | 'flight' | 'bus';
  farePerPerson: number; // One-way fare per traveller
  roundTripMultiplier?: number; // Defaults to 2
  duration?: string;
  operatorType?: string;
  tag?: 'Best fit' | 'Cheapest' | 'Fastest';
  thumbnail?: string;
  image?: string;
}

export interface StayOption {
  id: string;
  name: string;
  tier: 'hostel' | 'heritage' | 'boutique' | 'luxury';
  ratePerNight: number; // Per room per night
  location?: string;
  inclusions?: string[];
  tag?: 'Best fit' | 'Cheapest' | 'Comfort';
  thumbnail?: string;
  image?: string;
}

export interface LocalTravelOption {
  id: string;
  name: string;
  type: 'cab' | 'auto' | 'metro' | 'rental';
  pricingModel: 'per_ride' | 'per_day' | 'per_person';
  unitPrice: number;
  quantity: number; // rides or days or pax
  tag?: 'Best fit' | 'Cheapest' | 'Flexible';
  thumbnail?: string;
  image?: string;
}

export interface ExperienceOption {
  id: string;
  name: string;
  pricePerPerson: number;
  duration?: string;
  timing?: string;
  category?: string;
  tag?: 'Essential' | 'Popular' | 'Free';
  thumbnail?: string;
  image?: string;
}

export interface TripSelections {
  transport?: TransportOption | null;
  stay?: StayOption | null;
  localTravel: LocalTravelOption[];
  experiences: ExperienceOption[];
  foodPerPersonPerDay: number; // Default ₹300, range ₹250 - ₹900
}

export interface BudgetInput {
  totalBudget: number; // B (₹)
  travellers: number;  // T
  days: number;        // D
  selections: TripSelections;
}

export type BudgetState = 'within' | 'using_buffer' | 'over';

export interface CategoryBreakdown {
  transport: number;
  stay: number;
  food: number;
  local: number;
  experiences: number;
}

export interface CategoryAllocations {
  transport: number;
  stay: number;
  food: number;
  local: number;
  experiences: number;
}

export interface BudgetResult {
  totalBudget: number;         // B
  buffer: number;              // Math.round(0.08 * B)
  spendableTarget: number;     // B - buffer
  allocations: CategoryAllocations;
  categories: CategoryAllocations; // alias for allocations
  spent: CategoryBreakdown;
  totalSpent: number;
  totalCost: number;           // alias for totalSpent
  remaining: number;           // B - totalSpent
  safeToSpend: number;         // B - buffer - totalSpent
  state: BudgetState;          // within | using_buffer | over
  status: BudgetState;         // alias for state
  bufferRemaining: number;     // safe remaining buffer
  stateAmount: number;         // 0 if within, amount of buffer used, or amount over budget
  stateMessage: string;
}

/**
 * Quick category allocation for budget demo
 */
export function calculateBudgetAllocation(totalBudget: number) {
  const B = Math.round(totalBudget);
  const buffer = Math.round(0.08 * B);
  const spendableTarget = B - buffer;
  return {
    totalBudget: B,
    buffer,
    spendableTarget,
    categories: {
      transport: Math.round(spendableTarget * 0.35),
      stay: Math.round(spendableTarget * 0.30),
      food: Math.round(spendableTarget * 0.15),
      local: Math.round(spendableTarget * 0.10),
      experiences: Math.round(spendableTarget * 0.10),
    }
  };
}

/**
 * Format integer rupees into standard Indian currency representation (e.g. ₹14,200)
 */
export function formatINR(amount: number): string {
  if (isNaN(amount) || amount === null || amount === undefined) return '₹0';
  const rounded = Math.round(amount);
  const formatted = new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: 0,
  }).format(Math.abs(rounded));
  return `${rounded < 0 ? '-' : ''}₹${formatted}`;
}

/**
 * Pure calculation function for all budget values
 */
export function calculateBudget(input: BudgetInput): BudgetResult {
  const B = Math.round(input.totalBudget || 0);
  const T = Math.max(1, Math.round(input.travellers || 1));
  const D = Math.max(1, Math.round(input.days || 1));
  const N = Math.max(1, D - 1); // Nights = D - 1 (min 1)
  const sel = input.selections || {
    transport: null,
    stay: null,
    localTravel: [],
    experiences: [],
    foodPerPersonPerDay: 300,
  };

  // 1. Buffer = round(0.08 * B)
  const buffer = Math.round(0.08 * B);
  const spendableTarget = B - buffer;

  // 2. Category Allocations from (B - buffer)
  const allocations: CategoryAllocations = {
    transport: Math.round(spendableTarget * 0.35),
    stay: Math.round(spendableTarget * 0.30),
    food: Math.round(spendableTarget * 0.15),
    local: Math.round(spendableTarget * 0.10),
    experiences: Math.round(spendableTarget * 0.10),
  };

  // 3. Computed Costs
  // Transport: per-person fare x T x legs (default 2 legs for round trip)
  const transportLegs = sel.transport?.roundTripMultiplier ?? 2;
  const transportCost = sel.transport ? Math.round(sel.transport.farePerPerson * T * transportLegs) : 0;

  // Stay: nightly rate x ceil(T / 2) rooms x N
  const roomsNeeded = Math.ceil(T / 2);
  const stayCost = sel.stay ? Math.round(sel.stay.ratePerNight * roomsNeeded * N) : 0;

  // Food: f x T x D
  const foodRate = Math.round(sel.foodPerPersonPerDay || 300);
  const foodCost = Math.round(foodRate * T * D);

  // Local travel: sum of items
  const localList = Array.isArray(sel.localTravel) ? sel.localTravel : [];
  const localCost = localList.reduce((sum, item) => {
    let cost = 0;
    if (item.pricingModel === 'per_person') {
      cost = item.unitPrice * T * (item.quantity || 1);
    } else {
      cost = item.unitPrice * (item.quantity || 1);
    }
    return sum + Math.round(cost);
  }, 0);

  // Experiences: per-person price x T
  const experiencesList = Array.isArray(sel.experiences) ? sel.experiences : [];
  const experiencesCost = experiencesList.reduce((sum, item) => {
    return sum + Math.round(item.pricePerPerson * T);
  }, 0);

  const spent: CategoryBreakdown = {
    transport: transportCost,
    stay: stayCost,
    food: foodCost,
    local: localCost,
    experiences: experiencesCost,
  };

  const totalSpent = transportCost + stayCost + foodCost + localCost + experiencesCost;
  const remaining = B - totalSpent;
  const safeToSpend = spendableTarget - totalSpent;

  let state: BudgetState = 'within';
  let stateAmount = 0;
  let stateMessage = '';

  if (totalSpent <= spendableTarget) {
    state = 'within';
    stateAmount = safeToSpend;
    stateMessage = `Within budget · ${formatINR(safeToSpend)} safe to spend`;
  } else if (totalSpent <= B) {
    state = 'using_buffer';
    stateAmount = totalSpent - spendableTarget;
    stateMessage = `Using ${formatINR(stateAmount)} of your ${formatINR(buffer)} buffer`;
  } else {
    state = 'over';
    stateAmount = totalSpent - B;
    stateMessage = `${formatINR(stateAmount)} over budget`;
  }

  const bufferRemaining = Math.max(0, buffer - Math.max(0, totalSpent - spendableTarget));

  return {
    totalBudget: B,
    buffer,
    spendableTarget,
    allocations,
    categories: allocations,
    spent,
    totalSpent,
    totalCost: totalSpent,
    remaining,
    safeToSpend,
    state,
    status: state,
    bufferRemaining,
    stateAmount,
    stateMessage,
  };
}

/**
 * Recommended tier text for landing page budget slider
 */
export function getRecommendedTierForBudget(b: number): string {
  if (b <= 14000) {
    return 'Sleeper train · Budget stay · Metro and auto · Free and low-cost sights';
  }
  if (b <= 22000) {
    return 'Sleeper train · Heritage guesthouse · Station cab + auto · Guided walks';
  }
  if (b <= 32000) {
    return '3AC train or flight one way · Boutique hotel · Private cab · Guided tours';
  }
  return 'Flights both ways · Premium hotel · Car with driver · Private experiences';
}
