/**
 * Simulated Vendor Network & Messaging Dispatch
 * Adheres strictly to the Honesty Model:
 * All results from vendors, drivers, hotel desks, and bus operators are labeled "Simulated".
 * No message is sent to a third party without explicit user approval.
 */

export interface VendorMessageResult {
  messageId: string;
  status: 'sent' | 'delivered' | 'acknowledged' | 'declined' | 'no_reply';
  replyText?: string;
  vendorName: string;
  timestamp: string;
}

export interface HoldResult {
  status: 'acknowledged' | 'declined' | 'no_reply';
  heldUntil?: string;
  note?: string;
}

export interface BusAlternative {
  id: string;
  serviceName: string;
  operator: string;
  departureTime: string;
  arrivalTime: string;
  farePerPerson: number;
  seatsAvailable: number;
  differenceVsOriginal: number;
}

export interface VendorNetwork {
  sendMessage(
    vendorId: string, 
    text: string, 
    overrideOutcome?: 'Accept' | 'Decline' | 'No reply'
  ): Promise<VendorMessageResult>;

  requestHold(
    bookingId: string, 
    minutes: number, 
    overrideOutcome?: 'Accept' | 'Decline' | 'No reply'
  ): Promise<HoldResult>;

  findAlternatives(
    bookingId: string, 
    afterTime: string
  ): Promise<BusAlternative[]>;

  requestRefund(
    bookingId: string, 
    amount: number, 
    reason: string
  ): Promise<{ refundId: string; status: 'Requested' | 'Processing' | 'Credited'; sampleTimeline: string }>;
}

/**
 * Mock Vendor Network Implementation
 */
export class MockVendorNetwork implements VendorNetwork {
  private demoReplySetting: 'Accept' | 'Decline' | 'No reply' = 'Accept';

  setDemoReply(reply: 'Accept' | 'Decline' | 'No reply') {
    this.demoReplySetting = reply;
  }

  getDemoReply(): 'Accept' | 'Decline' | 'No reply' {
    return this.demoReplySetting;
  }

  async sendMessage(
    vendorId: string, 
    text: string, 
    overrideOutcome?: 'Accept' | 'Decline' | 'No reply'
  ): Promise<VendorMessageResult> {
    const outcome = overrideOutcome || this.demoReplySetting;
    const messageId = `MSG-SIM-${Date.now().toString().slice(-5)}`;
    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    let status: VendorMessageResult['status'] = 'acknowledged';
    let replyText = 'Confirmed. We have noted the update.';

    if (outcome === 'Decline') {
      status = 'declined';
      replyText = 'Sorry, we are unable to accommodate this schedule change due to prior bookings.';
    } else if (outcome === 'No reply') {
      status = 'no_reply';
      replyText = undefined;
    }

    return {
      messageId,
      status,
      replyText,
      vendorName: vendorId,
      timestamp: now
    };
  }

  async requestHold(
    bookingId: string, 
    minutes: number, 
    overrideOutcome?: 'Accept' | 'Decline' | 'No reply'
  ): Promise<HoldResult> {
    const outcome = overrideOutcome || this.demoReplySetting;

    if (outcome === 'Accept') {
      return {
        status: 'acknowledged',
        heldUntil: '09:20 PM',
        note: `Operator agreed to hold departure by ${minutes} minutes. Please board promptly upon arrival.`
      };
    } else if (outcome === 'Decline') {
      return {
        status: 'declined',
        note: 'Operator cannot hold departure because the vehicle is on a scheduled highway transit route.'
      };
    } else {
      return {
        status: 'no_reply',
        note: 'Operator did not respond within the 2-minute emergency window.'
      };
    }
  }

  async findAlternatives(bookingId: string, afterTime: string): Promise<BusAlternative[]> {
    return [
      {
        id: 'alt-bus-01',
        serviceName: 'IntrCity SmartBus Multi-Axle Club',
        operator: 'IntrCity SmartBus',
        departureTime: '10:15 PM',
        arrivalTime: '06:00 AM',
        farePerPerson: 1550,
        seatsAvailable: 4,
        differenceVsOriginal: 150
      },
      {
        id: 'alt-bus-02',
        serviceName: 'KSRTC Airavat Diamond Class',
        operator: 'KSRTC Express',
        departureTime: '11:00 PM',
        arrivalTime: '06:45 AM',
        farePerPerson: 1680,
        seatsAvailable: 6,
        differenceVsOriginal: 280
      }
    ];
  }

  async requestRefund(bookingId: string, amount: number, reason: string) {
    const refundId = `REF-SIM-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    return {
      refundId,
      status: 'Requested' as const,
      sampleTimeline: 'Sample timeline: a few hours. Real timing depends on your bank and the provider.'
    };
  }
}

export const mockVendorNetwork = new MockVendorNetwork();
