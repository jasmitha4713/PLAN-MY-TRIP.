import { describe, it, expect } from 'vitest';
import { parseTripIntake } from './intakeParser';

describe('Free-text Intake Parser', () => {
  it('parses "Plan a trip to Mumbai for 3 days, 5 to 6 members, budget ₹60,000" and asks for exact count', () => {
    const parsed = parseTripIntake('Plan a trip to Mumbai for 3 days, 5 to 6 members, budget ₹60,000');
    expect(parsed.destination).toBe('Mumbai');
    expect(parsed.origin).toBe('Hyderabad');
    expect(parsed.days).toBe(3);
    // Strict range rule: does NOT guess
    expect(parsed.travellers).toBeNull();
    expect(parsed.travellerRange).toEqual([5, 6]);
    expect(parsed.clarifications.travellers).toBe('Would you like to plan for 5 or 6 travellers?');
    expect(parsed.budget).toBe(60000);
  });

  it('handles default origin from profile when available', () => {
    const parsed = parseTripIntake('Plan a weekend in Jaipur for 2 under ₹15,000', 'New Delhi');
    expect(parsed.destination).toBe('Jaipur');
    expect(parsed.origin).toBe('New Delhi');
    expect(parsed.days).toBe(2);
    expect(parsed.travellers).toBe(2);
    expect(parsed.budget).toBe(15000);
  });

  it('handles unsupported destinations with nearest recommendations', () => {
    const parsed = parseTripIntake('Plan a trip to Manali for 4 days');
    expect(parsed.isUnsupportedDestination).toBe(true);
    expect(parsed.unsupportedDestinationName).toBe('Manali');
    expect(parsed.suggestedDestinations.length).toBeGreaterThan(0);
    expect(parsed.clarifications.destination).toContain("We don't have sample data for Manali yet");
  });

  it('detects ambiguous budgets and requests exact limit', () => {
    const parsed = parseTripIntake('Trip to Goa for 4 people around 20k');
    expect(parsed.budget).toBeNull();
    expect(parsed.clarifications.budget).toBeDefined();
  });

  it('parses typed "Plan a trip to Mumbai for three days, five people, budget ₹60,000." correctly', () => {
    const parsed = parseTripIntake('Plan a trip to Mumbai for three days, five people, budget ₹60,000.');
    expect(parsed.destination).toBe('Mumbai');
    expect(parsed.days).toBe(3);
    expect(parsed.travellers).toBe(5);
    expect(parsed.budget).toBe(60000);
  });

  it('parses spoken "Plan a trip to Mumbai for three days, for five people, with a total budget of sixty thousand rupees." identically', () => {
    const parsed = parseTripIntake('Plan a trip to Mumbai for three days, for five people, with a total budget of sixty thousand rupees.');
    expect(parsed.destination).toBe('Mumbai');
    expect(parsed.days).toBe(3);
    expect(parsed.travellers).toBe(5);
    expect(parsed.budget).toBe(60000);
  });
});
