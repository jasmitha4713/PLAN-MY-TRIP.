"""Interactive Alexa+ Conversational Experience Simulator.

Simulates the voice assistant dialogue flow using the MCP tools
for India-first travel planning and proactive delay recovery.
"""

import asyncio
import json
import os
import sys
from alexa_mcp.tools.saved_trip import handle_get_saved_trip
from alexa_mcp.tools.disruption import handle_assess_disruption
from alexa_mcp.tools.recovery import (
    handle_prepare_recovery_action,
    handle_approve_recovery_action,
)
from alexa_mcp.tools.plan_trip import handle_plan_trip


class ColoredOutput:
    CYAN = "\033[96m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    BOLD = "\033[1m"
    RESET = "\033[0m"


C = ColoredOutput


def alexa_speak(text: str):
    """Render Alexa's spoken response."""
    print(f"\n{C.CYAN}{C.BOLD}[Alexa+ Voice]{C.RESET} {text}")


def user_speak(text: str):
    """Render User's voice command."""
    print(f"\n{C.YELLOW}{C.BOLD}[User Speech]{C.RESET} \"{text}\"")


def tool_call_log(tool_name: str, arguments: dict):
    """Render MCP tool invocation log."""
    print(f"{C.MAGENTA}  [MCP Tool Call] -> {tool_name}{json.dumps(arguments, indent=2)}{C.RESET}")


async def check_or_setup_backend():
    """Verify if external backend is active; fallback to in-memory mock if not."""
    import httpx
    from mock_backend.app import app as mock_app
    from alexa_mcp.backend_client import BackendClient, set_backend_client

    try:
        async with httpx.AsyncClient(timeout=0.5) as client:
            res = await client.get("http://localhost:8000/health")
            if res.status_code == 200:
                print(f"{C.GREEN}✓ Connected to live backend at http://localhost:8000{C.RESET}")
                return
    except Exception:
        pass

    print(f"{C.BLUE}ℹ Using local mock backend engine (in-memory mode){C.RESET}")
    transport = httpx.ASGITransport(app=mock_app)
    set_backend_client(BackendClient(base_url="http://mock-in-memory", transport=transport))


async def run_scenario():
    await check_or_setup_backend()

    print("=" * 75)
    print(f"{C.BOLD}PLAN MY TRIP — Alexa+ Hackathon Conversational Demonstration{C.RESET}")
    print(f"Role: Voice AI Travel Companion (India-first Disruption Rescue)")
    print("=" * 75)

    trip_id = "trip_del_jai_001"

    # Step 1: User queries saved trip
    user_speak("Alexa, check my upcoming trip to Jaipur.")
    tool_call_log("get_saved_trip", {"trip_id": trip_id})
    res_trip = await handle_get_saved_trip(trip_id)
    if res_trip["status"] != "success":
        alexa_speak("Sorry, I could not find that trip right now.")
        return

    trip_data = res_trip["data"]
    alexa_speak(
        f"You have an upcoming trip: '{trip_data['title']}' starting {trip_data['start_date']}. "
        f"Your {trip_data['transport']['operator']} bus departs from {trip_data['transport']['boarding_point']} "
        f"at {trip_data['transport']['departure_time']}. Hotel stay is at {trip_data['accommodation']['name']}."
    )

    await asyncio.sleep(1)

    # Step 2: User reports travel disruption
    user_speak("Alexa, our bus broke down near Neemrana highway. We are going to be delayed by about 3 hours!")
    delay_minutes = 180
    tool_call_log(
        "assess_disruption",
        {
            "trip_id": trip_id,
            "disruption_type": "bus_delay",
            "delay_minutes": delay_minutes,
            "notes": "Bus breakdown near Neemrana",
        },
    )
    res_disrupt = await handle_assess_disruption(
        trip_id=trip_id,
        disruption_type="bus_delay",
        delay_minutes=delay_minutes,
        notes="Bus breakdown near Neemrana",
    )
    if res_disrupt["status"] != "success":
        alexa_speak("I encountered an error checking the disruption impact.")
        return

    disrupt_data = res_disrupt["data"]
    impact = disrupt_data["impact"]
    hotel_name = impact["hotel_name"]
    options = disrupt_data["recovery_options"]

    alexa_speak(
        f"I've assessed the situation. Because of the 3-hour delay, your check-in at {hotel_name} is affected. "
        f"You might also miss your afternoon visit to Hawa Mahal. "
        f"I found {len(options)} recovery options for you:\n"
        f"  1. Free: Notify {hotel_name} to hold your room until late evening.\n"
        f"  2. Option 2: Book an emergency highway cab for Rs. 1,200 to save 75 minutes.\n"
        f"  3. Option 3: Switch to the next passing Volvo bus for Rs. 350."
    )

    await asyncio.sleep(1)

    # Step 3: User requests hotel check-in notification
    user_speak("Alexa, let's notify the hotel first so they don't cancel our room.")
    tool_call_log(
        "prepare_recovery_action",
        {
            "trip_id": trip_id,
            "action_type": "notify_hotel_late_checkin",
            "selected_option_id": "opt_reschedule_checkin",
            "estimated_cost_inr": 0.0,
        },
    )
    res_prep = await handle_prepare_recovery_action(
        trip_id=trip_id,
        action_type="notify_hotel_late_checkin",
        selected_option_id="opt_reschedule_checkin",
        estimated_cost_inr=0.0,
    )
    if res_prep["status"] != "success":
        alexa_speak("I was unable to stage this action.")
        return

    action_data = res_prep["data"]
    action_id = action_data["action_id"]

    # Critical Safety Gate: Alexa asks for explicit confirmation
    alexa_speak(f"[Safety Gate - Action Staged: {action_id} - Pending Approval]")
    alexa_speak(f"{action_data['approval_prompt']}")

    await asyncio.sleep(1)

    # Step 4: User grants explicit approval
    user_speak("Yes Alexa, please notify Zostel Jaipur right away.")
    tool_call_log(
        "approve_recovery_action",
        {
            "action_id": action_id,
            "approved": True,
            "user_confirmation": "Yes Alexa, please notify Zostel Jaipur right away.",
        },
    )
    res_appr = await handle_approve_recovery_action(
        action_id=action_id,
        approved=True,
        user_confirmation="Yes Alexa, please notify Zostel Jaipur right away.",
    )
    if res_appr["status"] != "success":
        alexa_speak("Execution failed.")
        return

    exec_data = res_appr["data"]
    alexa_speak(
        f"{C.GREEN}Confirmed! {exec_data['message']} (Receipt: {exec_data['receipt_id']}). "
        f"Your room is safe. Lean back and stay safe on the road.{C.RESET}"
    )

    print("\n" + "=" * 75)
    print(f"{C.GREEN}✓ Demonstration completed successfully with full tool integration!{C.RESET}")
    print("=" * 75)


if __name__ == "__main__":
    asyncio.run(run_scenario())
