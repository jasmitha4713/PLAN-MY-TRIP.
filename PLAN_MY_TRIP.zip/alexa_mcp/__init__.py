"""Alexa+ Model Context Protocol (MCP) Integration for PLAN MY TRIP."""

__version__ = "1.0.0"
