"""Backend HTTP Client for PLAN MY TRIP.

This module acts as the integration adapter between the Alexa+ MCP Server
and the main application's REST API. It maintains single-source-of-truth
business logic by delegating all trip computations, persistence, and rescue
logic to the main application.
"""

from typing import Any, Dict, Optional
import httpx
from alexa_mcp.config import settings


class BackendAPIError(Exception):
    """Raised when the backend API returns an error or is unreachable."""

    def __init__(self, message: str, status_code: Optional[int] = None, details: Optional[Any] = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.details = details


class BackendClient:
    """Async HTTP client to communicate with the main application's FastAPI backend."""

    def __init__(
        self,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        transport: Optional[httpx.AsyncBaseTransport] = None,
    ):
        self.base_url = (base_url or settings.main_backend_url).rstrip("/")
        self.timeout = timeout or settings.backend_timeout
        self.transport = transport

    async def _request(
        self, method: str, endpoint: str, json_data: Optional[Dict[str, Any]] = None, params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        url = f"{self.base_url}{endpoint}"
        try:
            async with httpx.AsyncClient(timeout=self.timeout, transport=self.transport) as client:
                response = await client.request(
                    method=method,
                    url=url,
                    json=json_data,
                    params=params,
                    headers={"Content-Type": "application/json", "User-Agent": "Alexa-Plus-MCP-Client/1.0"},
                )
                
                # Check HTTP response
                if response.status_code >= 400:
                    try:
                        error_payload = response.json()
                        error_detail = error_payload.get("detail", error_payload.get("message", response.text))
                    except Exception:
                        error_detail = response.text
                    raise BackendAPIError(
                        message=f"Backend request failed with status {response.status_code}: {error_detail}",
                        status_code=response.status_code,
                        details=error_detail,
                    )
                
                return response.json()
        except httpx.ConnectError:
            raise BackendAPIError(
                message=f"Could not connect to main backend service at {self.base_url}. Please ensure the backend is running.",
                status_code=503,
            )
        except httpx.TimeoutException:
            raise BackendAPIError(
                message=f"Request to main backend service timed out after {self.timeout} seconds.",
                status_code=504,
            )
        except BackendAPIError:
            raise
        except Exception as e:
            raise BackendAPIError(
                message=f"Unexpected error communicating with main backend: {str(e)}",
                status_code=500,
            )

    async def plan_trip(self, plan_data: Dict[str, Any]) -> Dict[str, Any]:
        """POST /api/trips/plan - Generate a new budget trip itinerary."""
        return await self._request("POST", "/api/trips/plan", json_data=plan_data)

    async def get_saved_trip(self, trip_id: str) -> Dict[str, Any]:
        """GET /api/trips/{trip_id} - Fetch an existing saved trip."""
        return await self._request("GET", f"/api/trips/{trip_id}")

    async def assess_disruption(self, trip_id: str, disruption_data: Dict[str, Any]) -> Dict[str, Any]:
        """POST /api/trips/{trip_id}/rescue - Analyze delay/missed bus impact and propose recoveries."""
        return await self._request("POST", f"/api/trips/{trip_id}/rescue", json_data=disruption_data)

    async def prepare_recovery_action(self, action_data: Dict[str, Any]) -> Dict[str, Any]:
        """POST /api/actions/prepare - Create a recovery action in 'pending_approval' status."""
        return await self._request("POST", "/api/actions/prepare", json_data=action_data)

    async def approve_recovery_action(self, action_id: str, approved: bool, user_confirmation: str) -> Dict[str, Any]:
        """POST /api/actions/{action_id}/approve - Submit explicit user approval for a recovery action."""
        payload = {"approved": approved, "user_confirmation": user_confirmation}
        return await self._request("POST", f"/api/actions/{action_id}/approve", json_data=payload)

    async def get_action(self, action_id: str) -> Dict[str, Any]:
        """GET /api/actions/{action_id} - Retrieve current status of a recovery action."""
        return await self._request("GET", f"/api/actions/{action_id}")

    async def search_transport_options(self, search_data: Dict[str, Any]) -> Dict[str, Any]:
        """POST /api/transport/search - Search available transport options."""
        return await self._request("POST", "/api/transport/search", json_data=search_data)

    async def search_accommodation_options(self, search_data: Dict[str, Any]) -> Dict[str, Any]:
        """POST /api/accommodation/search - Search available lodging options."""
        return await self._request("POST", "/api/accommodation/search", json_data=search_data)

    async def get_budget_breakdown(self, trip_id: str) -> Dict[str, Any]:
        """GET /api/trips/{trip_id}/budget - Retrieve authoritative budget breakdown."""
        return await self._request("GET", f"/api/trips/{trip_id}/budget")


_client_instance: Optional[BackendClient] = None


def get_backend_client() -> BackendClient:
    """Retrieve the active BackendClient instance."""
    global _client_instance
    if _client_instance is None:
        _client_instance = BackendClient()
    return _client_instance


def set_backend_client(client: Optional[BackendClient]) -> None:
    """Override the active BackendClient instance (useful for testing and mocking)."""
    global _client_instance
    _client_instance = client


class _BackendClientProxy:
    """Dynamic proxy that delegates attribute lookups to the currently configured backend client."""

    def __getattr__(self, name: str):
        return getattr(get_backend_client(), name)


backend_client = _BackendClientProxy()
