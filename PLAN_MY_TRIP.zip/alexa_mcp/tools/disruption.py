"""Tool implementation for assess_disruption."""

from typing import Any, Dict, Optional
from alexa_mcp.backend_client import backend_client, BackendAPIError


async def handle_assess_disruption(
    trip_id: str,
    disruption_type: str,
    delay_minutes: int,
    notes: Optional[str] = None,
) -> Dict[str, Any]:
    """Analyze a reported travel disruption (bus delay, missed connection) and its downstream impact.

    Args:
        trip_id: The unique identifier of the active trip (e.g., 'trip_del_jai_001').
        disruption_type: Type of disruption (e.g., 'bus_delay', 'missed_bus', 'train_delay').
        delay_minutes: Total estimated delay in minutes (e.g., 180 for 3 hours).
        notes: Optional context describing the disruption (e.g., 'Breakdown at Neemrana highway').

    Returns:
        Impact analysis detailing hotel check-in conflicts, missed activities, and recovery options.
    """
    if not trip_id or not trip_id.strip():
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": "Trip ID is required and cannot be empty.",
        }
    if not disruption_type or not disruption_type.strip():
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": "Disruption type is required (e.g., 'bus_delay', 'missed_bus').",
        }
    if delay_minutes < 0:
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": f"Delay minutes must be non-negative (received: {delay_minutes}).",
        }

    payload = {
        "disruption_type": disruption_type.strip().lower(),
        "delay_minutes": int(delay_minutes),
        "notes": notes or "Disruption reported via Alexa+",
    }

    try:
        response = await backend_client.assess_disruption(trip_id.strip(), payload)
        return {
            "status": "success",
            "data": response,
        }
    except BackendAPIError as e:
        return {
            "status": "error",
            "code": "BACKEND_ERROR",
            "error": e.message,
            "status_code": e.status_code,
        }
    except Exception as e:
        return {
            "status": "error",
            "code": "UNEXPECTED_ERROR",
            "error": f"Unexpected error assessing disruption: {str(e)}",
        }
