"""Tool implementations for transport and accommodation discovery, and budget breakdown."""

from typing import Any, Dict, List, Optional
from alexa_mcp.backend_client import backend_client, BackendAPIError


async def handle_search_transport_options(
    origin: str,
    destination: str,
    travel_date: str = "2026-11-01",
    max_price_inr: Optional[float] = None,
    mode_preference: Optional[str] = None,
) -> Dict[str, Any]:
    """Search available transport options (trains, buses, flights) with transparent fares, times, and refund rules.

    Args:
        origin: Starting city or hub (e.g. 'Hyderabad', 'Delhi').
        destination: Destination city or hub (e.g. 'Mumbai', 'Goa').
        travel_date: Date of departure in YYYY-MM-DD format (default: '2026-11-01').
        max_price_inr: Optional upper budget ceiling per passenger in INR.
        mode_preference: Optional mode filter ('train', 'bus', 'flight').

    Returns:
        Structured list of transport options with fares, operator details, and cancellation policies.
    """
    if not origin or not origin.strip():
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": "Origin city is required and cannot be empty.",
        }
    if not destination or not destination.strip():
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": "Destination city is required and cannot be empty.",
        }

    payload = {
        "origin": origin.strip(),
        "destination": destination.strip(),
        "travel_date": travel_date.strip() if travel_date else "2026-11-01",
        "max_price_inr": float(max_price_inr) if max_price_inr is not None else None,
        "mode_preference": mode_preference.strip() if mode_preference else None,
    }

    try:
        response = await backend_client.search_transport_options(payload)
        return {
            "status": "success",
            "data": response,
        }
    except BackendAPIError as e:
        return {
            "status": "error",
            "code": "BACKEND_ERROR",
            "error": e.message,
            "status_code": e.status_code,
        }
    except Exception as e:
        return {
            "status": "error",
            "code": "UNEXPECTED_ERROR",
            "error": f"Unexpected error searching transport options: {str(e)}",
        }


async def handle_search_accommodation_options(
    destination: str,
    checkin_date: str = "2026-11-01",
    checkout_date: str = "2026-11-03",
    preference_tier: Optional[str] = None,
    max_rate_per_night_inr: Optional[float] = None,
) -> Dict[str, Any]:
    """Search available lodging and hotel tiers with room amenities and verified cancellation rules.

    Args:
        destination: Destination city or locality (e.g. 'Mumbai', 'Jaipur').
        checkin_date: Check-in date in YYYY-MM-DD format (default: '2026-11-01').
        checkout_date: Check-out date in YYYY-MM-DD format (default: '2026-11-03').
        preference_tier: Optional tier filter ('hostel', 'heritage', 'boutique', 'resort').
        max_rate_per_night_inr: Optional price ceiling per room night in INR.

    Returns:
        Structured list of accommodation choices with rates, amenities, and terms.
    """
    if not destination or not destination.strip():
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": "Destination city is required and cannot be empty.",
        }

    payload = {
        "destination": destination.strip(),
        "checkin_date": checkin_date.strip() if checkin_date else "2026-11-01",
        "checkout_date": checkout_date.strip() if checkout_date else "2026-11-03",
        "preference_tier": preference_tier.strip() if preference_tier else None,
        "max_rate_per_night_inr": float(max_rate_per_night_inr) if max_rate_per_night_inr is not None else None,
    }

    try:
        response = await backend_client.search_accommodation_options(payload)
        return {
            "status": "success",
            "data": response,
        }
    except BackendAPIError as e:
        return {
            "status": "error",
            "code": "BACKEND_ERROR",
            "error": e.message,
            "status_code": e.status_code,
        }
    except Exception as e:
        return {
            "status": "error",
            "code": "UNEXPECTED_ERROR",
            "error": f"Unexpected error searching accommodation options: {str(e)}",
        }


async def handle_get_budget_breakdown(trip_id: str) -> Dict[str, Any]:
    """Retrieve authoritative category spend and remaining unallocated buffer for a saved trip.

    Args:
        trip_id: Unique canonical identifier of the trip (e.g. 'trip_del_jai_001' or 'PMT-0142').

    Returns:
        Authoritative budget breakdown including transport, stay, food, buffer, and spend health.
    """
    if not trip_id or not trip_id.strip():
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": "Trip ID is required and cannot be empty.",
        }

    try:
        response = await backend_client.get_budget_breakdown(trip_id.strip())
        return {
            "status": "success",
            "data": response,
        }
    except BackendAPIError as e:
        return {
            "status": "error",
            "code": "BACKEND_ERROR",
            "error": e.message,
            "status_code": e.status_code,
        }
    except Exception as e:
        return {
            "status": "error",
            "code": "UNEXPECTED_ERROR",
            "error": f"Unexpected error retrieving budget breakdown: {str(e)}",
        }
