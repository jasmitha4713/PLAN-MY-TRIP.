"""Tool implementation for plan_trip."""

from typing import Any, Dict, List, Optional
from alexa_mcp.backend_client import backend_client, BackendAPIError


async def handle_plan_trip(
    origin: str,
    destination: str,
    budget_inr: float,
    start_date: str = "2026-11-01",
    end_date: str = "2026-11-03",
    travelers_count: int = 1,
    preferences: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Plan an affordable India trip based on natural language inputs, budget, and travel dates.

    Args:
        origin: Starting city or town (e.g., 'Delhi', 'Bangalore', 'Mumbai').
        destination: Destination city or location (e.g., 'Jaipur', 'Coorg', 'Goa').
        budget_inr: Total budget in Indian Rupees (INR) for the entire group.
        start_date: Trip start date in YYYY-MM-DD format (default: '2026-11-01').
        end_date: Trip end date in YYYY-MM-DD format (default: '2026-11-03').
        travelers_count: Number of travelers (default: 1).
        preferences: Optional list of travel preferences (e.g., ['budget', 'sightseeing', 'veg_food']).

    Returns:
        Structured trip plan with itinerary, budget breakdown, transport, and hotel details.
    """
    # 1. Validation
    if not origin or not origin.strip():
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": "Origin city is required and cannot be empty.",
        }
    if not destination or not destination.strip():
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": "Destination city is required and cannot be empty.",
        }
    if budget_inr <= 0:
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": f"Budget must be greater than 0 INR (received: {budget_inr}).",
        }
    if travelers_count < 1:
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": f"Travelers count must be at least 1 (received: {travelers_count}).",
        }

    # 2. Prepare payload for main application backend
    payload = {
        "origin": origin.strip(),
        "destination": destination.strip(),
        "budget_inr": float(budget_inr),
        "start_date": start_date,
        "end_date": end_date,
        "travelers_count": int(travelers_count),
        "preferences": preferences or ["budget", "sightseeing"],
    }

    # 3. Call backend API
    try:
        response = await backend_client.plan_trip(payload)
        return {
            "status": "success",
            "data": response,
        }
    except BackendAPIError as e:
        return {
            "status": "error",
            "code": "BACKEND_ERROR",
            "error": e.message,
            "status_code": e.status_code,
        }
    except Exception as e:
        return {
            "status": "error",
            "code": "UNEXPECTED_ERROR",
            "error": f"Unexpected error while planning trip: {str(e)}",
        }
