"""Tools exposed by the Alexa+ MCP Server."""
