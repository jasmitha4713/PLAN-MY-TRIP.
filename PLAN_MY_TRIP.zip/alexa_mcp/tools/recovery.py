"""Tool implementations for prepare_recovery_action and approve_recovery_action."""

from typing import Any, Dict
from alexa_mcp.backend_client import backend_client, BackendAPIError


async def handle_prepare_recovery_action(
    trip_id: str,
    action_type: str,
    selected_option_id: str,
    estimated_cost_inr: float = 0.0,
) -> Dict[str, Any]:
    """Prepare a recovery action preview for the user to review before execution.

    This ensures human-in-the-loop safety: actions (such as rebooking or notifying vendors)
    are staged in 'pending_approval' state with an explicit verbal approval prompt.

    Args:
        trip_id: The unique identifier of the active trip.
        action_type: Category of action (e.g., 'notify_hotel_late_checkin', 'rebook_bus', 'book_cab').
        selected_option_id: The identifier of the recovery option selected by the user.
        estimated_cost_inr: Anticipated additional cost in INR (default: 0.0).

    Returns:
        Action preview containing action_id, status ('pending_approval'), and approval_prompt.
    """
    if not trip_id or not trip_id.strip():
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": "Trip ID is required and cannot be empty.",
        }
    if not action_type or not action_type.strip():
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": "Action type is required (e.g., 'notify_hotel_late_checkin', 'rebook_bus').",
        }
    if not selected_option_id or not selected_option_id.strip():
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": "Selected option ID is required.",
        }
    if estimated_cost_inr < 0:
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": f"Estimated cost must be non-negative (received: {estimated_cost_inr}).",
        }

    payload = {
        "trip_id": trip_id.strip(),
        "action_type": action_type.strip(),
        "selected_option_id": selected_option_id.strip(),
        "estimated_cost_inr": float(estimated_cost_inr),
    }

    try:
        response = await backend_client.prepare_recovery_action(payload)
        return {
            "status": "success",
            "data": response,
        }
    except BackendAPIError as e:
        return {
            "status": "error",
            "code": "BACKEND_ERROR",
            "error": e.message,
            "status_code": e.status_code,
        }
    except Exception as e:
        return {
            "status": "error",
            "code": "UNEXPECTED_ERROR",
            "error": f"Unexpected error preparing recovery action: {str(e)}",
        }


async def handle_approve_recovery_action(
    action_id: str,
    approved: bool,
    user_confirmation: str = "yes",
) -> Dict[str, Any]:
    """Execute or reject a previously prepared recovery action after explicit user confirmation.

    Critical Safety Rule: An action cannot be executed without approved=True and explicit confirmation.

    Args:
        action_id: The unique identifier of the prepared action (e.g., 'act_recov_001').
        approved: True if user explicitly granted consent; False if user rejected or cancelled.
        user_confirmation: The transcript of user confirmation (e.g., 'Yes, book the cab').

    Returns:
        Execution status ('succeeded', 'failed', or 'cancelled') with confirmation details.
    """
    if not action_id or not action_id.strip():
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": "Action ID is required and cannot be empty.",
        }

    try:
        response = await backend_client.approve_recovery_action(
            action_id=action_id.strip(),
            approved=approved,
            user_confirmation=user_confirmation,
        )
        if not approved:
            return {
                "status": "cancelled",
                "action_id": action_id.strip(),
                "message": "Action was cancelled per user instruction. No booking or notification changes were executed.",
                "requires_user_approval": False,
            }
        return {
            "status": "success",
            "data": response,
        }
    except BackendAPIError as e:
        return {
            "status": "error",
            "code": "BACKEND_ERROR",
            "error": e.message,
            "status_code": e.status_code,
        }
    except Exception as e:
        return {
            "status": "error",
            "code": "UNEXPECTED_ERROR",
            "error": f"Unexpected error approving recovery action: {str(e)}",
        }
