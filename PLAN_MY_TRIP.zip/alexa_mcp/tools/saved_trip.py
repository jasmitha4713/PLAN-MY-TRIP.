"""Tool implementation for get_saved_trip."""

from typing import Any, Dict
from alexa_mcp.backend_client import backend_client, BackendAPIError


async def handle_get_saved_trip(trip_id: str) -> Dict[str, Any]:
    """Retrieve an existing saved trip and itinerary by its unique trip ID.

    Args:
        trip_id: The unique identifier of the saved trip (e.g., 'trip_del_jai_001').

    Returns:
        Structured saved trip details including schedule, bookings, and budget tracking.
    """
    if not trip_id or not trip_id.strip():
        return {
            "status": "error",
            "code": "VALIDATION_ERROR",
            "error": "Trip ID is required and cannot be empty.",
        }

    try:
        response = await backend_client.get_saved_trip(trip_id.strip())
        return {
            "status": "success",
            "data": response,
        }
    except BackendAPIError as e:
        return {
            "status": "error",
            "code": "BACKEND_ERROR",
            "error": e.message,
            "status_code": e.status_code,
        }
    except Exception as e:
        return {
            "status": "error",
            "code": "UNEXPECTED_ERROR",
            "error": f"Unexpected error while retrieving trip: {str(e)}",
        }
