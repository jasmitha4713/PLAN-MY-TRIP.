"""Main Alexa+ Model Context Protocol (MCP) Server.

Implements the official Model Context Protocol (Spec version 2025-11-25+)
over Streamable HTTP transport for the Alexa+ hackathon track.
"""

from pathlib import Path
import sys
from typing import Any, Dict, List, Optional
import uvicorn
from starlette.middleware.cors import CORSMiddleware
from starlette.responses import HTMLResponse, JSONResponse

from mcp.server.mcpserver import MCPServer
from alexa_mcp.config import settings
from alexa_mcp.tools.plan_trip import handle_plan_trip
from alexa_mcp.tools.saved_trip import handle_get_saved_trip
from alexa_mcp.tools.disruption import handle_assess_disruption
from alexa_mcp.tools.recovery import (
    handle_prepare_recovery_action,
    handle_approve_recovery_action,
)
from alexa_mcp.tools.discovery import (
    handle_search_transport_options,
    handle_search_accommodation_options,
    handle_get_budget_breakdown,
)

# 1. Initialize MCP Server instance
mcp_server = MCPServer(
    name=settings.server_name,
    version=settings.server_version,
    instructions=(
        "PLAN MY TRIP Alexa+ MCP Server. Provides agentic tools for affordable India-first "
        "travel planning, itinerary retrieval, proactive disruption handling, and safety-gated "
        "recovery action execution."
    ),
)


# 2. Register MCP Tools
@mcp_server.tool(name="plan_trip")
async def plan_trip(
    origin: str,
    destination: str,
    budget_inr: float,
    start_date: str = "2026-11-01",
    end_date: str = "2026-11-03",
    travelers_count: int = 1,
    preferences: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Plan an affordable India trip based on natural language inputs, budget, and travel dates.

    Args:
        origin: Starting city or town (e.g., 'Delhi', 'Bangalore', 'Mumbai').
        destination: Destination city or location (e.g., 'Jaipur', 'Coorg', 'Goa').
        budget_inr: Total budget in Indian Rupees (INR) for the entire group.
        start_date: Trip start date in YYYY-MM-DD format (default: '2026-11-01').
        end_date: Trip end date in YYYY-MM-DD format (default: '2026-11-03').
        travelers_count: Number of travelers (default: 1).
        preferences: Optional list of travel preferences (e.g., ['budget', 'sightseeing', 'veg_food']).

    Returns:
        Structured trip plan with itinerary, budget breakdown, transport, and hotel details.
    """
    return await handle_plan_trip(
        origin=origin,
        destination=destination,
        budget_inr=budget_inr,
        start_date=start_date,
        end_date=end_date,
        travelers_count=travelers_count,
        preferences=preferences,
    )


@mcp_server.tool(name="get_saved_trip")
async def get_saved_trip(trip_id: str) -> Dict[str, Any]:
    """Retrieve an existing saved trip and itinerary by its unique trip ID.

    Args:
        trip_id: The unique identifier of the saved trip (e.g., 'trip_del_jai_001').

    Returns:
        Structured saved trip details including schedule, bookings, and budget tracking.
    """
    return await handle_get_saved_trip(trip_id=trip_id)


@mcp_server.tool(name="assess_disruption")
async def assess_disruption(
    trip_id: str,
    disruption_type: str,
    delay_minutes: int,
    notes: Optional[str] = None,
) -> Dict[str, Any]:
    """Analyze a reported travel disruption (bus delay, missed connection) and its downstream impact.

    Args:
        trip_id: The unique identifier of the active trip (e.g., 'trip_del_jai_001').
        disruption_type: Type of disruption (e.g., 'bus_delay', 'missed_bus', 'train_delay').
        delay_minutes: Total estimated delay in minutes (e.g., 180 for 3 hours).
        notes: Optional context describing the disruption (e.g., 'Breakdown at Neemrana highway').

    Returns:
        Impact analysis detailing hotel check-in conflicts, missed activities, and recovery options.
    """
    return await handle_assess_disruption(
        trip_id=trip_id,
        disruption_type=disruption_type,
        delay_minutes=delay_minutes,
        notes=notes,
    )


@mcp_server.tool(name="prepare_recovery_action")
async def prepare_recovery_action(
    trip_id: str,
    action_type: str,
    selected_option_id: str,
    estimated_cost_inr: float = 0.0,
) -> Dict[str, Any]:
    """Prepare a recovery action preview for the user to review before execution.

    This ensures human-in-the-loop safety: actions (such as rebooking or notifying vendors)
    are staged in 'pending_approval' state with an explicit verbal approval prompt.

    Args:
        trip_id: The unique identifier of the active trip.
        action_type: Category of action (e.g., 'notify_hotel_late_checkin', 'rebook_bus', 'book_cab').
        selected_option_id: The identifier of the recovery option selected by the user.
        estimated_cost_inr: Anticipated additional cost in INR (default: 0.0).

    Returns:
        Action preview containing action_id, status ('pending_approval'), and approval_prompt.
    """
    return await handle_prepare_recovery_action(
        trip_id=trip_id,
        action_type=action_type,
        selected_option_id=selected_option_id,
        estimated_cost_inr=estimated_cost_inr,
    )


@mcp_server.tool(name="approve_recovery_action")
async def approve_recovery_action(
    action_id: str,
    approved: bool,
    user_confirmation: str = "yes",
) -> Dict[str, Any]:
    """Execute or reject a previously prepared recovery action after explicit user confirmation.

    Critical Safety Rule: An action cannot be executed without approved=True and explicit confirmation.

    Args:
        action_id: The unique identifier of the prepared action (e.g., 'act_recov_001').
        approved: True if user explicitly granted consent; False if user rejected or cancelled.
        user_confirmation: The transcript of user confirmation (e.g., 'Yes, book the cab').

    Returns:
        Execution status ('succeeded', 'failed', or 'cancelled') with confirmation details.
    """
    return await handle_approve_recovery_action(
        action_id=action_id,
        approved=approved,
        user_confirmation=user_confirmation,
    )


@mcp_server.tool(name="search_transport_options")
async def search_transport_options(
    origin: str,
    destination: str,
    travel_date: str = "2026-11-01",
    max_price_inr: Optional[float] = None,
    mode_preference: Optional[str] = None,
) -> Dict[str, Any]:
    """Search available transport options (trains, buses, flights) with transparent fares, times, and refund rules.

    Args:
        origin: Starting city or hub (e.g., 'Hyderabad', 'Delhi').
        destination: Destination city or hub (e.g., 'Mumbai', 'Goa').
        travel_date: Date of departure in YYYY-MM-DD format (default: '2026-11-01').
        max_price_inr: Optional price ceiling per passenger in INR.
        mode_preference: Optional transport mode filter ('train', 'bus', 'flight').

    Returns:
        Structured list of transport choices with operator, fares, duration, and cancellation policies.
    """
    return await handle_search_transport_options(
        origin=origin,
        destination=destination,
        travel_date=travel_date,
        max_price_inr=max_price_inr,
        mode_preference=mode_preference,
    )


@mcp_server.tool(name="search_accommodation_options")
async def search_accommodation_options(
    destination: str,
    checkin_date: str = "2026-11-01",
    checkout_date: str = "2026-11-03",
    preference_tier: Optional[str] = None,
    max_rate_per_night_inr: Optional[float] = None,
) -> Dict[str, Any]:
    """Search available lodging and hotel tiers with room amenities and verified cancellation rules.

    Args:
        destination: Destination city or locality (e.g., 'Mumbai', 'Jaipur').
        checkin_date: Check-in date in YYYY-MM-DD format (default: '2026-11-01').
        checkout_date: Check-out date in YYYY-MM-DD format (default: '2026-11-03').
        preference_tier: Optional tier filter ('hostel', 'heritage', 'boutique', 'resort').
        max_rate_per_night_inr: Optional price ceiling per room night in INR.

    Returns:
        Structured list of accommodation choices with rates, amenities, and terms.
    """
    return await handle_search_accommodation_options(
        destination=destination,
        checkin_date=checkin_date,
        checkout_date=checkout_date,
        preference_tier=preference_tier,
        max_rate_per_night_inr=max_rate_per_night_inr,
    )


@mcp_server.tool(name="get_budget_breakdown")
async def get_budget_breakdown(trip_id: str) -> Dict[str, Any]:
    """Retrieve authoritative category spend and remaining unallocated buffer for a saved trip.

    Args:
        trip_id: Unique canonical identifier of the trip (e.g., 'trip_del_jai_001' or 'PMT-0142').

    Returns:
        Authoritative budget breakdown including transport, stay, food, buffer, and spend health.
    """
    return await handle_get_budget_breakdown(trip_id=trip_id)


# 3. Create Streamable HTTP Starlette Application
app = mcp_server.streamable_http_app()


# 4. Attach Health / Status Endpoint
async def health_status(request):
    return JSONResponse(
        {
            "status": "online",
            "server": settings.server_name,
            "version": settings.server_version,
            "protocol_spec": "MCP 2025-11-25+",
            "transport": "streamable-http",
            "mcp_endpoint": "/mcp",
            "backend_url": settings.main_backend_url,
            "tools_registered": [
                "plan_trip",
                "get_saved_trip",
                "assess_disruption",
                "prepare_recovery_action",
                "approve_recovery_action",
                "search_transport_options",
                "search_accommodation_options",
                "get_budget_breakdown",
            ],
            "description": "Alexa+ Model Context Protocol server for PLAN MY TRIP hackathon integration.",
        }
    )


HTML_APP_PATH = Path(__file__).parent.parent / "simulation" / "web_tester.html"


async def root_view(request):
    """Serve the interactive voice & visual web application."""
    if HTML_APP_PATH.exists():
        return HTMLResponse(HTML_APP_PATH.read_text(encoding="utf-8"))
    return await health_status(request)


app.add_route("/health", health_status, methods=["GET"])
app.add_route("/app", root_view, methods=["GET"])
app.add_route("/", root_view, methods=["GET"])

# Add CORS Middleware for browser test harnesses
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=[
        "mcp-session-id",
        "Mcp-Session-Id",
        "mcp-protocol-version",
        "content-type",
        "*",
    ],
)


def run():
    """Run MCP Streamable HTTP server."""
    print("=" * 70)
    print(" PLAN MY TRIP — Alexa+ Model Context Protocol (MCP) Server")
    print(f" Spec: 2025-11-25+ | Transport: Streamable HTTP (/mcp)")
    print(f" Host: {settings.mcp_host} | Port: {settings.mcp_port}")
    print(f" Connected Main Backend: {settings.main_backend_url}")
    print("=" * 70)
    uvicorn.run(
        app,
        host=settings.mcp_host,
        port=settings.mcp_port,
        log_level=settings.log_level.lower(),
    )


if __name__ == "__main__":
    run()
