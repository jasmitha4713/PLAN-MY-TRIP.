"""Configuration settings for Alexa+ MCP Server."""

import os
from pydantic import BaseModel, Field
from dotenv import load_dotenv

load_dotenv()


class Settings(BaseModel):
    server_name: str = "plan-my-trip-alexa-mcp"
    server_version: str = "1.0.0"
    mcp_host: str = Field(default_factory=lambda: os.getenv("MCP_SERVER_HOST", "0.0.0.0"))
    mcp_port: int = Field(default_factory=lambda: int(os.getenv("MCP_SERVER_PORT", "8001")))
    main_backend_url: str = Field(
        default_factory=lambda: os.getenv("MAIN_BACKEND_URL", "http://localhost:8000")
    )
    backend_timeout: float = Field(
        default_factory=lambda: float(os.getenv("BACKEND_TIMEOUT_SECONDS", "10.0"))
    )
    log_level: str = Field(default_factory=lambda: os.getenv("LOG_LEVEL", "INFO"))


settings = Settings()
