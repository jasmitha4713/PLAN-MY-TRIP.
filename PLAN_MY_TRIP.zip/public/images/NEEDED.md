# Missing Photos & Sourcing Inventory (NEEDED.md)

In accordance with Plan My Trip's strict integrity standards, no generic, stock, foreign, or AI-garbled imagery is substituted for real places or transit options. The following items currently use clean, minimalist fallback tiles (`--cream-2 #F3E9D8` + monoline Lucide icon) until authentic documentary travel photography is licensed:

| Category | Item Description | Suggested Filename | Recommended Search Term / Source | Current Fallback |
| :--- | :--- | :--- | :--- | :--- |
| **Transport** | Sleeper Train Interior (Indian Railways Berth) | `sleeper-train-interior.webp` | "Indian railways sleeper coach interior berth natural light" | Train monoline icon tile |
| **Transport** | AC 3-Tier Train Coach | `ac3-train-coach.webp` | "AC 3 tier coach Indian railways passenger berth" | Train monoline icon tile |
| **Transport** | Domestic Flight Window / Aircraft | `domestic-flight.webp` | "Domestic flight India wing cloud window natural light" | Plane monoline icon tile |
| **Stays** | Old Delhi Heritage Haveli Room / Courtyard | `old-delhi-haveli.webp` | "Chandni chowk haveli courtyard dharampura traditional architecture" | Home/Building icon tile |
| **Stays** | Budget Travel Hostel Room | `budget-hostel-room.webp` | "clean backpacker hostel dorm India bunk beds minimal" | Bed/Building icon tile |
| **Local Travel** | Station Prepaid Taxi / Sedan at Night | `station-cab.webp` | "white sedan prepaid taxi railway station India evening" | Car icon tile |
| **Local Travel** | Indian Auto-rickshaw on Street | `auto-rickshaw.webp` | "yellow green auto rickshaw Delhi street daytime" | Compass/Car icon tile |
| **Local Travel** | Metro Rail Transit Station | `delhi-metro.webp` | "Delhi metro elevated station train platform clean" | Train/Subway icon tile |
| **Local Travel** | Rental Scooter / Bike | `rental-scooter.webp` | "Activa scooter rental street India" | Bike icon tile |
| **Experiences** | Old Delhi Heritage Walk Alley | `old-delhi-walk.webp` | "Old Delhi narrow alleyways heritage architecture heritage walk" | Footprints/Map icon tile |
| **Background** | Railway Station Terminal (Rescue Scene) | `railway-platform.webp` | "New Delhi railway station platform evening lights Indian trains" | Monoline station badge & timeline |

All fallback tiles render instantly, guarantee zero false depictions, and ensure 100% honesty to presentation judges.
