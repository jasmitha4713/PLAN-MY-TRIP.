# Photo Credits & Licensing

All photographic assets used in Plan My Trip are verified for accurate depiction of Indian destinations, transit modes, and landmarks, strictly respecting free licenses (Creative Commons, Public Domain, or custom documentary generation).

| Filename | Subject / Landmark | Source | Author / Attribution | License |
| :--- | :--- | :--- | :--- | :--- |
| `hero-main.webp` | Indian Railways train crossing Pamban Bridge at sunrise | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Pamban_rail_bridge.jpg) | Picsnapr | CC BY-SA 4.0 |
| `band-1.webp` | Sunrise over Bengal from moving train | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Sunrise_view_from_a_moving_train.jpg) | Ankit Tripathi | CC BY-SA 4.0 |
| `band-2.webp` | Amber Fort Jaali stone lattice texture | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Amber_fort_jaali.jpg) | Chayandunks7 | CC BY-SA 4.0 |
| `rescue-station.webp` | Nagda Junction railway platform at dawn | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Nagda_junction_railway_station.jpg) | Ajit lokhande patil | CC BY-SA 4.0 |
| `cta-sunrise.webp` | Western Ghats sunrise over hills | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Sunrise_at_Western_Ghats.jpg) | Deepamurthy | CC BY-SA 4.0 |
| `dest-delhi-banner.webp` / `card.webp` | India Gate, New Delhi | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:India_Gate_Delhi_sunset.jpg) | Shounak Ray | CC BY-SA 4.0 |
| `dest-jaipur-banner.webp` / `card.webp` | Amber Fort, Jaipur, Rajasthan | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Amber_Fort_Jaipur.jpg) | Firoze Edassery | CC BY-SA 3.0 |
| `dest-hampi-banner.webp` / `card.webp` | Virupaksha Temple & Ruins, Hampi | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Wide_angle_of_Galigopuram_of_Virupaksha_Temple,_Hampi_(04)_(cropped).jpg) | Dineshkannambadi | CC BY-SA 3.0 |
| `dest-varanasi-banner.webp` / `card.webp` | Ahilya Ghat along River Ganges, Varanasi | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Ahilya_Ghat_by_the_Ganges,_Varanasi.jpg) | Gerd Eichmann | CC BY-SA 4.0 |
| `dest-alleppey-banner.webp` / `card.webp` | Backwaters Houseboat, Alleppey | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Kerala_Backwaters_Houseboat.jpg) | Sarath Kuchi | CC BY-SA 2.0 |
| `dest-coorg-banner.webp` / `card.webp` | Tadiandamol Valley & Hills, Coorg | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Tadiandamol_Valley,_Western_Ghats.jpg) | Kishorekumar | CC BY-SA 3.0 |
| `thumb-train-sleeper.webp` | LHB Sleeper Coach on Indian Railways | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:LHB_Sleeper_Coach.jpg) | Vikramaditya V. V. | CC BY-SA 4.0 |
| `thumb-train-ac.webp` | Vande Bharat Express | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Vande_Bharat_Express_at_Bolpur_Shantiniketan_Station.jpg) | Voice of Bolpur | CC0 1.0 Public Domain |
| `thumb-flight.webp` | Flight wing over clouds outside Mumbai | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Flight_to_Mumbai.jpg) | Priyaflorenceshah | CC BY-SA 4.0 |
| `thumb-bus.webp` | KSRTC Airavat Volvo Club Class bus | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:KSRTC_Airavat_Club_Class.jpg) | Rsrikanth05 | CC BY-SA 4.0 |
| `thumb-stay-haveli.webp` | Courtyard of Samode Haveli, Jaipur | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Courtyard_of_Samode_Haveli,_Jaipur.jpg) | Richard Moross | CC BY 2.0 |
| `thumb-cab.webp` | Station taxi sedan | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Delhi_Taxi.jpg) | J. Miers | CC BY-SA 4.0 |
| `thumb-auto.webp` | Auto-rickshaw on Indian road | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Auto-rickshaw_in_Delhi.jpg) | Psubhashish | CC BY-SA 3.0 |
| `thumb-metro.webp` | Delhi Metro Airport Express | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Delhi_Metro_Airport_Express.jpg) | DMRC | CC BY-SA 4.0 |
| `thumb-rental.webp` | Scooter in India | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Scooter_India.jpg) | Visdaviva | CC BY-SA 3.0 |
| `thumb-exp-culinary.webp` | Samosas & mint chutney food trail | Unsplash | Unsplash License | Free commercial use |
| `thumb-exp-heritage.webp` | Qutub Minar pass | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Qutb_Minar_2022.jpg) | R. K. Lakhera | CC BY-SA 4.0 |
| `signin-panel.webp` | Traveler on railway platform at dawn | Generative Documentary | Plan My Trip | Project Asset |
| `journey-1.webp` | Hands holding phone route map with cutting chai | Generative Documentary | Plan My Trip | Project Asset |
| `journey-2.webp` | Train window view across lush countryside | Generative Documentary | Plan My Trip | Project Asset |
| `journey-3.webp` | Heritage boutique bedroom in Rajasthan | Generative Documentary | Plan My Trip | Project Asset |
| `journey-4.webp` | Station cab taxi sedan at dawn | Generative Documentary | Plan My Trip | Project Asset |
| `journey-5.webp` | Traveler silhouette overlooking Varanasi ghats | Generative Documentary | Plan My Trip | Project Asset |
| `thumb-stay-boutique.webp` | Contemporary boutique hotel room | Generative Documentary | Plan My Trip | Project Asset |
| `thumb-stay-budget.webp` | Minimalist hostel room | Generative Documentary | Plan My Trip | Project Asset |

All assets are compressed into high-efficiency WebP format with embedded fallback colors for instant rendering.
