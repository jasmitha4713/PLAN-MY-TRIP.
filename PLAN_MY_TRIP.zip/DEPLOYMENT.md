# PLAN MY TRIP — Production Deployment & Hosting Guide

## Architectural Overview

PLAN MY TRIP consists of three decoupled components:
1. **Frontend (Vite / React 19 SPA)**: Static single-page application served via Nginx or edge static hosts (Vercel, Netlify, Cloudflare Pages).
2. **Backend (FastAPI / Python 3.11)**: REST API handling trip planning, persistence, budget calculation, and authorization with Write-Ahead Logging (`WAL`) SQLite storage.
3. **Alexa+ MCP Server (Python 3.11 / Streamable HTTP)**: Model Context Protocol server exposing 8 tools on port `8001` via HTTP SSE / JSON-RPC (`/mcp`).

---

## Deployment Option 1: Docker Compose (Single Host / VM / Railway / Render)

### 1. Prerequisites
- Docker Engine 24+ & Docker Compose v2+
- A persistent volume directory mounted to `/app/data` to ensure SQLite survives container redeployments.

### 2. Startup Command
```bash
docker compose up -d --build
```

### 3. Service Verification
- Frontend: `http://localhost:3000/app`
- Backend API Docs: `http://localhost:8000/docs`
- Backend Health: `http://localhost:8000/health`
- MCP Server Health: `http://localhost:8001/health`
- MCP Endpoint: `http://localhost:8001/mcp`

---

## Deployment Option 2: Cloud PaaS (Render / Railway / Fly.io)

### Component A: Backend (FastAPI)
- **Runtime**: Python 3.11
- **Build Command**: `pip install -r requirements.txt`
- **Start Command**: `uvicorn mock_backend.app:app --host 0.0.0.0 --port $PORT`
- **Persistent Disk**: Attach a 1 GB persistent volume mounted at `/app/data` and set `SQLITE_DB_PATH=/app/data/pmt_data.db`.
- **Health Check Path**: `/health`

### Component B: MCP Server
- **Runtime**: Python 3.11
- **Build Command**: `pip install -r requirements.txt`
- **Start Command**: `python -m alexa_mcp.server`
- **Environment Variable**: `MAIN_BACKEND_URL=https://<your-backend-render-url>.onrender.com`
- **Health Check Path**: `/health`

### Component C: Frontend (Static Site / Vercel)
- **Build Command**: `npm run build`
- **Publish Directory**: `dist`
- **Environment Variables**:
  - `VITE_ALEXA_URL=https://<your-backend-url>.onrender.com`
  - `VITE_ALEXA_MODE=remote`
- **Rewrite Rule (SPA Routing)**:
  - Source: `/*`
  - Destination: `/index.html`

---

## Environment Variables Reference

| Variable | Required | Default | Description |
| :--- | :---: | :---: | :--- |
| `SQLITE_DB_PATH` | No | `mock_backend/pmt_data.db` | Absolute path to SQLite database file on persistent volume. |
| `MAIN_BACKEND_URL` | Yes (MCP) | `http://localhost:8000` | URL connecting MCP server to the FastAPI backend. |
| `VITE_ALEXA_URL` | Yes (FE) | `http://localhost:8000` | Backend API base URL consumed by React frontend. |
| `GEMINI_API_KEY` | No | None | Free Google Gemini key for LLM conversational agent. |
| `GROQ_API_KEY` | No | None | Free Groq key for Llama 3.3 LLM conversational agent. |
